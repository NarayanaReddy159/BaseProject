package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class MemberSearchPage extends BasePage {

	String excepionMessage = "";
	// LI Interaction ID
	@FindBy(xpath = "//span[text()='Interaction ID']/following::span[1]")
	public WebElement interactionIDLI;
	@FindBy(id = "PegaGadget1Ifr")
	public WebElement frame1;
	@FindBy(name = "$PpyWorkPage$pSearchEnrollID")
	public WebElement HMHSMemberID;
	@FindBy(name = "$PpyWorkPage$pUMI")
	public WebElement HMHSUMI;
	@FindBy(name = "$PpyWorkPage$pSearchContractID")
	public WebElement HMHSContractID;
	@FindBy(name = "$PpyWorkPage$pSearchMedicareNumber")
	public WebElement HMHSMedicareID;
	@FindBy(name = "$PpyWorkPage$pSearchSSN")
	public WebElement HMHSSSN;
	@FindBy(name = "$PpyWorkPage$pSearchOptions")
	public WebElement searchBy;
	@FindBy(xpath = "//button[contains(text(),'Search')]")
	public WebElement HMHSSearch;
	@FindBy(xpath = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy(xpath = "//div[2]/div/div/div/div[2]/span/button/i")
	public WebElement HMHSOtherActions;
	@FindBy(xpath = "//span[contains(text(),'Wrap Up, Call Transferred')]")
	public WebElement HMHSWrapUp_CallTransferred;
	@FindBy(name = "$PpyWorkPage$pWrapUpComments")
	public WebElement WrapUpComments;
	@FindBy(xpath = "//button[contains(text(),'Submit')]//ancestor::button")
	public WebElement SubmitWrapUp;
	@FindBy(xpath = "//div[1]/div/div[1]/div/select")
	public WebElement ReasonForInteraction;
	@FindBy(xpath = "//span[contains(text(),'Exit Interaction')]")
	public WebElement HMHSExitInteraction;
	@FindBy(xpath = "//span[contains(text(),'Member Search')]")
	public WebElement HMHSOtherActMemSearch;
	@FindBy(xpath = "//span[contains(text(),'Wrap Up, Member Not Found')]")
	public WebElement HMHSWrapUp_MemberNotFound;
	@FindBy(xpath = "//span[contains(text(),'Prospective Member')]")
	public WebElement prosmem;
	@FindBy(xpath = "//td[11]/div[1]/span[1]/span[1]")
	public WebElement HMHSMemAddrval;
	@FindBy(xpath = "//tbody/tr[2]/td[11]/div/div/span/span")
	public WebElement AddressHover;
	@FindBy(xpath = "//div[5]/div[1]/ul/li[1]/div[2]/div/div[2]/div/div/div")
	//@FindBy(xpath = "//body/div[@id='PEGA_HARNESS']/form[1]/div[5]/div[1]/ul[1]/li[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]")
	public WebElement AddressTooltip;
	@FindBy(xpath = "//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]/td[11]/div/span/span")
	public WebElement MemAddrLineval;
	@FindBy(xpath = "//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]/td[11]/div/span/span")
	public WebElement AddressMouseHover;
	@FindBy(xpath = "//div[5]/div[1]/ul/li[1]/div[2]/div/div[2]/div/div/div")
	public WebElement AddressTooltipHover;
	@FindBy(xpath = "//tbody/tr[1]/th[2]")
	public WebElement HMHSConfCommVal;
	@FindBy(xpath = "//tbody/tr[1]/th[2]")
	public WebElement AddressConfComm;
	@FindBy(xpath = "//div[1]/ul/li[1]/div[2]/div/div")
	public WebElement TooltipConfComm;
	@FindBy(id = "PegaRULESErrorFlag")
	public WebElement HMHSValueBlankMsg;
	@FindBy(xpath = "//span[contains(text(),'Please check you')]")
	public WebElement HMHSNoRecordMsg;
	@FindBy(xpath = "//span[contains(text(),'No member records were found using the search crit')]")
	public WebElement HMHSInvalidUMI;
	@FindBy(xpath = "//div/span[1]/div/span/ul/li")
	public WebElement ClearMemNotListMess;
	@FindBy(xpath = "//button[contains(text(),'Clear')]")
	public WebElement HMHSClearBtn;
	@FindBy(xpath = "//div[1]/div/div/div/div/span/input[2]")
	public WebElement HMHSConMemChkbox;
	@FindBy(xpath = "//div/span[1]/div/span/ul/li")
	public WebElement HMHSMemNotListMsg;
	@FindBy(xpath = "//label[contains(text(),'First name')]//following::input[1]")
	public WebElement prsFname;
	@FindBy(xpath = "//label[contains(text(),'Last name')]//following::input[1]")
	public WebElement prsLname;
	@FindBy(xpath = "//div[7]/div/div/span/input[2]")
	public WebElement preCapturecheckbox;
	@FindBy(id = "d5ce2cac")
	public WebElement prscallReason;
	@FindBy(id = "8b98c3c5")
	public WebElement prsMemtype;
	@FindBy(xpath = "//label[contains(text(),'Date of birth')]//following::input[1]")
	public WebElement prsDob;
	@FindBy(name = "$PpyWorkPage$ppyWorkParty$gProspectiveMember$pMedicareNumber")
	public WebElement prosMedicareNo;
	@FindBy(xpath = "//label[contains(text(),'Phone number')]//following::input[1]")
	public WebElement prsPhno;
	@FindBy(xpath = "//label[contains(text(),'Search by')]//following::select[1]")
	public WebElement prsSearchBy;
	@FindBy(xpath = "//label[contains(text(),'Interaction ID')]//following::input[1]")
	public WebElement prsInteractionID;
	@FindBy(xpath = "//span[contains(text(),'Wrap Up, Call Disconnected')]")
	public WebElement HMHSWrapUp_Disconnected;
	@FindBy(xpath = "//label[contains(text(),'Medicare Number/SSN/UFI Number')]//following::input[1]")
	public WebElement Medicare_SSN_UFI;
	@FindBy(xpath = "(//ul[@class='pageErrorList layout-noheader-errors']/li)[2]")
	public WebElement HMHSAddProsRecordErrMsg;
	@FindBy(xpath = "//*[@id='PegaRULESErrorFlag']")
	public WebElement HMHSAddProsNoReasonErrMsg;
	@FindBy(xpath = "//tr/td/div/div[1]/span/ul/li[3]")
	public WebElement HMHSAddProsNoRecMemErrMsg;
	@FindBy(xpath = "//tr/td/div/div[1]/span/ul/li[4]")
	public WebElement HMHSAddProsNoRecMembErrMsg;
	@FindBy(xpath = "//label[text()='First name']//following::span[@id='PegaRULESErrorFlag'][1]")
	public WebElement HMHSProsMemFNBnk;
	@FindBy(xpath = "//label[text()='First name']//following::span[@id='PegaRULESErrorFlag'][2]")
	public WebElement HMHSProsMemLNBnk;
	@FindBy(xpath = "//div/div/div[3]/div/div/div/div")
	public WebElement HMHSFiveFieldReqErroMsg;
	@FindBy(xpath = "//div[4]/div[2]/div/div[1]/div/div/span")
	public WebElement HMHSProsMemReasonBnk;
	@FindBy(xpath = "//div[4]/div[2]/div/div[2]/div/div/span")
	public WebElement HMHSProsMemMemShipBnk;
	@FindBy(xpath = "(//img[@src='webwb/hcprivacyrestricted_12701373111.gif!!.gif'])[1]")
	public WebElement ConfiCommimg;
	@FindBy(xpath = "//input[@id='42d2e6b8']")
	public WebElement VerifyDOB;
	@FindBy(xpath = "//input[@id='330b39c3']")
	public WebElement VerifyAddress;
    
	@FindBy(xpath = "//label[text()='                    Select Customer Response Type           ']/following::span[1]")
	public WebElement intentIDRTC;
	
	
	@FindBy(xpath = "//label[text()='                    Create Follow-Up           ']/following::div[1]")
	public WebElement intentIDCF;
	
	
	@FindBy(xpath = "//span[@class='standard']")
	public WebElement intentIDReqID;
	

	@FindBy(xpath = "//label[text()='                    Contract Is Inactive           ']/following::span[1]")
	public WebElement intentIDReqID2;
	
	
	@FindBy(xpath = "//label[text()='                    Website Support Details           ']/following::span[1]")
	public WebElement intentIDWeb;
	
	@FindBy(xpath = "//input[@name='$PpyWorkPage$pIsCallerAlsoAMember' and @type='checkbox']")
	public WebElement contactisNotMember;
	@FindBy(xpath = "//div[contains(text(),'Medicare ID')]//following::span[8]")
	public WebElement MedicareID;
	@FindBy(xpath = "//*[@id='RULE_KEY']/div/div[2]/div/div/div/div[1]/button")
	public WebElement settingIcon;
	@FindBy(xpath = "//body/div[7]/ul")
	public WebElement option;
	
	@FindBy(xpath = "//tbody/tr[@id='$PMemberSearchResults$ppxResults$l1']/td[1]/div[1]/span[1]/i[1]/img[1]")
	public WebElement Restricted;
	@FindBy(xpath = "(//div[contains(@data-node-id,'GroupSecurityMessages')])[1]")
	public WebElement Restrictedmessage;
	@FindBy(xpath = "//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[1]/div[1]")
	public WebElement ErrorMessage;
	
	// Get Live interaction ID
	public String getLIInteractionID() {
		String interactionID = "";
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			interactionID = webElementReadText(interactionIDLI);

		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getLIInteractionID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getLIInteractionID method " + e);
			Assert.fail();
		}
		return interactionID;
	}
	
	// Get Research interaction ID
	public String getREInteractionID() {
		String interactionID = "";
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			interactionID = webElementReadText(interactionIDLI);

		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getLIInteractionID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getLIInteractionID method " + e);
			Assert.fail();
		}
		return interactionID;
	}
	
	// HMHS Search For search member
	public void HMHSsearchMember(String memberID) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			waitForElementsToVisible("//button[contains(text(),'Search')]");
			
			webElementSendText(HMHSMemberID, memberID, "Member ID");
			HMHSMemberID.clear();
			HMHSMemberID.sendKeys(memberID);
			//webElementSendText(HMHSMemberID, memberID, "Member ID");
			webElementClick(HMHSSearch, "Search Button");
		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSsearchMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSsearchMember method " + e);
			Assert.fail();
		}

	}
	
	public void HMHSsearchMember(Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			waitForElementsToVisible("//button[contains(text(),'Search')]");
			System.out.println(data.get("SearchBy"));
			if(data.get("SearchBy").equals("UMI"))
			{
				selectDropdownValueByVisibleText(searchBy, data.get("SearchBy"), "Search By");
				wait(1500);
				webElementSendText(HMHSMemberID, data.get("MemberID"), "UMI");
			}else if(data.get("SearchBy").equals("Medicare ID"))
			{
				selectDropdownValueByVisibleText(searchBy, data.get("SearchBy"), "Search By");
				wait(1500);
				webElementSendText(HMHSMedicareID, data.get("MemberID"), "Medicare ID");
			}else if(data.get("SearchBy").equals("SSN"))
			{
				selectDropdownValueByVisibleText(searchBy, data.get("SearchBy"), "Search By");
				wait(1500);
				webElementSendText(HMHSSSN, data.get("MemberID"), "SSN");
			}else if(data.get("SearchBy").equals("Contract ID"))
			{
				selectDropdownValueByVisibleText(searchBy, data.get("SearchBy"), "Search By");
				wait(1500);
				webElementSendText(HMHSContractID, data.get("MemberID"), "Contract ID");
			}
			webElementClick(HMHSSearch, "Search Button");
		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSsearchMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSsearchMember method " + e);
			Assert.fail();
		}

	}

	public void HMHSUMI(Hashtable<String, String> data) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			//webElementClick(HMHSUMI, "Go to UMI field present with dropdown after Click on Search");
			try{
				Select reason= new Select(HMHSUMI);
				reason.selectByIndex(2);
				wait(2500);
			}
			catch(Exception e1)
			{
				Select reason= new Select(HMHSUMI);
				reason.selectByIndex(2);
				wait(2500);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on HMHSUMI method " + e);
			test.log(LogStatus.FAIL, "Error on HMHSUMI method " + e);
			Assert.fail();
		}
	}
	
	// Read Member Details for reading the details retrived from search member.
	
	public void readMemberDetails(String expectedResult) {
		String memberDetails = "";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(9000);
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
			//System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
				System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> colums = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums.size(); j++) {
					if (j == 0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				memberDetails = memberDetails + "," + memdet;
			}
			waitSleep(1000);
			memberDetails = memberDetails.substring(1, memberDetails.length());
			System.out.println(memberDetails);
			// Commented for issue found on 1/19/2021 
			assertEquals(expectedResult, memberDetails, "Member Search Results");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on readMemberDetails method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on readMemberDetails method " + e);
			Assert.fail();
		}
	}

	// Select Member and Navigate to Verify member page
	public void HMHSselectMemberAndNavigatebyfname(String memberSearchFname) {
		try {
			
			switchToFrame("PegaGadget1Ifr");
			waitSleep(5000);
			waitForElementsToVisible("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]");
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
			ele.size();
			String s = "//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				// updated to match current application from td[3] to td[4] - 1/19/2021
				if (driver.findElement(By.xpath(s1 + "//td[4]")).getText().equals(memberSearchFname)) {
					webElementClick(
							driver.findElement(
									By.xpath(String.format("//span[contains(text(),'%s')]", memberSearchFname))),
							"Member First Name");
					break;
				}
			}
			waitSleep(3000);
			webElementClick(Submit, "Submit");
			waitSleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on selectMemberAndNavigatebyfname method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on selectMemberAndNavigatebyfname method " + e);
			Assert.fail();
		}
	}

	// HMHS WrapUp_CallTransffered
	public void WrapUp_CallTransferred() throws Exception {
		try {
			waitSleep(3500);
			webElementClick(HMHSOtherActions, "Other Actions");
			waitSleep(1500);
			webElementClick(HMHSWrapUp_CallTransferred, "WrapUp_CallTransffered");
			test.log(LogStatus.INFO, "clicked WrapUp CallTransffered");
		} catch (Exception e) {
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on click WrapUp_CallTransffered method" + excepionMessage);
			test.log(LogStatus.FAIL, "Error on click WrapUp_CallTransffered method " + e);
			Assert.fail();
		}
	}

	// HMHS WrapUp Disconnected - Enter Comments and Submit
	public void WrapUpSubmit( String comments) {
		try {
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			webElementSendText(WrapUpComments, comments, "Enter Comments");
			waitSleep(2500);
			webElementClick(SubmitWrapUp, "Submit");
		} catch (Exception e) {
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on click WrapUp_CallDisconnected method" + excepionMessage);
			test.log(LogStatus.FAIL, "Error on click WrapUp_CallDisconnected method " + e);
			Assert.fail();
		}
	}

	// HMHS WrapUp Member Not Found - Enter Comments and Submit
	public void WrapUpMemNotFoundSubmit( String comments,
			String interactionReason) {
		try {
			
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			selectDropdownValueByVisibleText(ReasonForInteraction, interactionReason, "Reason For Interaction");
			webElementSendText(WrapUpComments, comments, "Enter Comments");
			webElementClick(SubmitWrapUp, "Submit");

		} catch (Exception e) {
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on click WrapUp_CallDisconnected method" + excepionMessage);
			test.log(LogStatus.FAIL, "Error on click WrapUp_CallDisconnected method " + e);
			Assert.fail();

		}
	}

	// HMHS Exit Interaction
	public void ExitInteraction() {
		try {
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(HMHSOtherActions, "Other Actions");
			test.log(LogStatus.INFO, "Click on Other actions.");
			waitSleep(1500);
			webElementClick(HMHSExitInteraction, "Exit Interaction");
			test.log(LogStatus.INFO, "Click on the Exit Interaction screen.");
		} catch (Exception e) {
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on click Exit Interaction method" + excepionMessage);
			test.log(LogStatus.FAIL, "Error on click Exit Interaction method " + e);
			Assert.fail();

		}
	}

	// HMHS From Exit Interaction come back to Member Search screen.
	public void ExitInteractionBackToSearch() {
		try {
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(HMHSOtherActions, "to go to Other Actions");
			test.log(LogStatus.INFO, "Click on Other actions.");
			waitSleep(1500);
			webElementClick(HMHSExitInteraction, "to go to Exit Interaction screen.");
			test.log(LogStatus.INFO, "Click on the Exit Interaction screen.");
			waitSleep(1500);
			webElementClick(HMHSOtherActions, "to go to Other Actions");
			test.log(LogStatus.INFO, "Click on Other actions.");
			waitSleep(1500);
			webElementClick(HMHSOtherActMemSearch, "to go back to Member Search screen.");
			test.log(LogStatus.INFO, "to go back to Member Search screen.");
		} catch (Exception e) {
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on click Exit Interaction method" + excepionMessage);
			test.log(LogStatus.FAIL, "Error on click Exit Interaction method " + e);
			Assert.fail();

		}
	}

	
	// HMHS WrapUp Not Found
	public void WrapUp_MemberNotFound() {
		try {
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(HMHSOtherActions, "Other Actions");
			waitSleep(1500);
			webElementClick(HMHSWrapUp_MemberNotFound, "Wrap Up Member Not Found");
		} catch (Exception e) {
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on click WrapUp Member Not found method" + excepionMessage);
			test.log(LogStatus.FAIL, "Error on click WrapUp Member Not found method " + e);
			Assert.fail();

		}
	}

	// HMHS Navigate from Exit Interaction to Member Search screen

	public void ExitInteractionMemSearch( String comments) {
		try {
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			webElementSendText(WrapUpComments, comments, "Enter Comments");
			waitSleep(3500);
			webElementClick(HMHSOtherActions, "Other Actions");
			webElementClick(HMHSOtherActMemSearch, "Member Search");
		} catch (Exception e) {
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on click ExitInteractionMemSearch method" + excepionMessage);
			test.log(LogStatus.FAIL, "Error on click ExitInteractionMemSearch method " + e);
			Assert.fail();

		}
	}

	public void movetoProsMem() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(HMHSOtherActions, "other Actions");
			waitSleep(1500);
			webElementClick(prosmem, "Prospective Member");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on movetoProsMem method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on movetoProsMem method " + e);
			Assert.fail();
		}

	}

	// HMHS Mouse House on Address Field

	public void HMHSMouseHovAddr( String expectedAddress, String frame) {
		try {
			waitSleep(3500);
			switchToFrame(frame);
			webElementClick(HMHSMemAddrval, "Address");
			Actions act = new Actions(driver);
			waitSleep(4500);
			act.moveToElement(AddressHover);
			waitSleep(7000);
			String actualAddress = webElementReadText(AddressTooltip);
			assertEquals(expectedAddress, actualAddress, "MouseHover Address");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSMouseHovAddr method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSMouseHovAddr method " + e);
			Assert.fail();
		}
	}

	// HMHS Mouse House on Address Field

	public void HMHSMouseHovFourAddr( String expectedMessage,
			String frame) {
		try {
			waitSleep(3500);
			switchToFrame(frame);
			webElementClick(MemAddrLineval, "Member Address Line Value");
			Actions act = new Actions(driver);
			waitSleep(3500);
			act.moveToElement(AddressMouseHover);
			waitSleep(4000);
			String actualMessage = webElementReadText(AddressTooltipHover);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched");
				test.log(LogStatus.PASS,"Expected Message: "+expectedMessage);
				test.log(LogStatus.PASS,"Actual Message: "+actualMessage);
			} else {
				test.log(LogStatus.FAIL, "Message not Matched" );
				test.log(LogStatus.PASS,"Expected Message: "+expectedMessage);
				test.log(LogStatus.PASS,"Actual Message: "+actualMessage);
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSMouseHovAddr method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSMouseHovAddr method " + e);
			Assert.fail();
		}
	}

	// HMHS Mouse House on Confidental communication row field

	public void HMHSMouseHovConfComm( String expectedMessage,
			String frame) {
		try {
			waitSleep(4500);
			switchToFrame(frame);
			webElementClick(HMHSConfCommVal, "Confidential Communication Value");
			waitSleep(4500);
			Actions act = new Actions(driver);
			act.moveToElement(TooltipConfComm);
			waitSleep(5000);
			String actualMessage = webElementReadText(TooltipConfComm);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched" + expectedMessage + actualMessage);
			} else {
				test.log(LogStatus.FAIL, "Message not Matched" + expectedMessage + actualMessage);
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSMouseHovAddr method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSMouseHovAddr method " + e);
			Assert.fail();
		}
	}

	// HMHS HMHSNoMemberValue
	public void HMHSNoMemberValue() {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			webElementClick(HMHSSearch, "Search Button");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSNoMemberValue method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSNoMemberValue method " + e);
			Assert.fail();
		}

	}

	// HMHS Display error message without entering member and submit
	public void HMHSValueBlankMess( String expectedMessage,
			String frame) {
		try {
			
			
			waitSleep(1500);
			switchToFrame(frame);
			String actualMessage = webElementReadText(HMHSValueBlankMsg);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSValueBlankMess method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSValueBlankMess method " + e);
			Assert.fail();
		}
	}

	// HMHS Display error message without entering member and submit
	public void HMHSNoRecordMess( String expectedMessage, String frame) {
		try {
			
			
			waitSleep(1500);
			switchToFrame(frame);
			String actualMessage = webElementReadText(HMHSInvalidUMI);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
				System.out.println("Actual Message: "+actualMessage);
				System.out.println("Expected Message: "+expected);
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSNoRecordMess method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSNoRecordMess method " + e);
			Assert.fail();
		}
	}

	// HMHS Display error message without entering member and submit
	public void HMHSInvalidUMI(String frame) {
		try {
			waitSleep(1500);
			switchToFrame(frame);
			String actualMessage = webElementReadText(HMHSInvalidUMI);
			String expected = "No member records were found using the search criteria. Retry the search.";
			assertEquals(actualMessage,expected,"Error Message for invalid UMI matched.");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSInvalidUMI method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSInvalidUMI method " + e);
			Assert.fail();
		}
	}
	
	// HMHS - Don't select and click on submit to view error as "Please select member from the list"
	public void HMHSNoMemberSubmit() {
		try {
			
			
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSMemberSubmit method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSMemberSubmit method " + e);
			Assert.fail();
		}

	}

	// Capture error message when user does not select the member from list and
	// click on submit
	public void HMHSClearMemNotListMess( String frame) {
		try {
			waitSleep(1500);
			switchToFrame(frame);
			elementNotPresent(ClearMemNotListMess, "WebElement not present");
			System.out.println("Webelement not present");

		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSMemberNotListMess method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSMemberNotListMess method " + e);
			Assert.fail();
		}
	}
	// Capture error message when user does not select the member from list and
	// click on submit

	// HMHS Select Member from List
	public void HMHClearErrMess() {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			webElementClick(HMHSClearBtn, "Clear Button");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHClearErrMess method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHClearErrMess method " + e);
			Assert.fail();
		}

	}

	// Uncheck Contact Selected Member Checkbox
	public void HMHSUnCheckboxContact() {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			webElementClick(HMHSConMemChkbox, "UnCheck Contact Selected Member");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSUnCheckboxContact method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSUnCheckboxContact method " + e);
			Assert.fail();
		}

	}

	public void HMHSMemberNotListMess( String expectedMessage,
			String frame) {
		try {

			
			
			waitSleep(1500);
			switchToFrame(frame);
			String actualMessage = webElementReadText(HMHSMemNotListMsg);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched" + expectedMessage + "" + actualMessage);
			} else {
				test.log(LogStatus.FAIL, "Message not Matched" + expectedMessage + "" + actualMessage);
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSMemberNotListMess method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSMemberNotListMess method " + e);
			Assert.fail();
		}
	}

	// HMHS Add Prospective member
	public void AddProsMem( Hashtable<String, String> data) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementSendText(prsFname, data.get("prsMFirstName"), "First name");
			webElementSendText(prsLname, data.get("prsMLastName"), "Last name");
			webElementSendText(prsDob, data.get("prsMLastName"), "DOB");
			webElementClick(preCapturecheckbox, "Capture New Porspective Member");
			waitSleep(1500);
			webElementClick(HMHSSearch, "Search");
			waitSleep(1500);
			selectDropdownValueByVisibleText(prscallReason, data.get("prsMRsnForCall"), "Call Reason");
			selectDropdownValueByVisibleText(prsMemtype, data.get("prsMMbrType"), "Membership type");
			waitSleep(2500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on AddProsMem method " + e);
			test.log(LogStatus.FAIL, "Error on AddProsMem method " + e);
			Assert.fail();
		}

	}

	// HMHS Contract having confidential communication Image present or not
	public void HMHSPrsFieldsPresent( String frame) {
		try {

			List<WebElement> prosMedicareNos = driver
					.findElements(By.name("$PpyWorkPage$ppyWorkParty$gProspectiveMember$pMedicareNumber"));
			waitSleep(3500);
			elementPresent(prsFname, "Pros First Name WebElement present");
			elementPresent(prsLname, "Pros Last Name WebElement present");
			elementPresent(prsDob, "Pros DOB WebElement present");
			if (prosMedicareNos.size() == 0) {
				System.out.println("prosMedicareNo Webelement not present");
			}

		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSPrsFieldsPresent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSPrsFieldsPresent method " + e);
			Assert.fail();
		}
	}

	// HMHS Search Prospective member by default selection
	public void searchProsMem( Hashtable<String, String> data) {
		try {
			
			
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementSendText(prsFname, data.get("prsMFirstName"), "First Name");
			webElementSendText(prsLname, data.get("prsMLastName"), "Last name");
			webElementSendText(prsDob, data.get("DOB"), "DOB");
			waitSleep(2500);
			webElementClick(preCapturecheckbox, "Capture New Porspective Member");
			waitSleep(2500);
			webElementClick(preCapturecheckbox, "Capture New Porspective Member");
			waitSleep(2500);
			webElementClick(preCapturecheckbox, "Capture New Porspective Member");
			waitSleep(2500);
			selectDropdownValueByVisibleText(prscallReason, data.get("prsMRsnForCall"), "Call Reason");
			selectDropdownValueByVisibleText(prsMemtype, data.get("prsMMbrType"), "Membership type");
			waitSleep(2500);
			webElementSendText(prsPhno, data.get("prsPhno"), "Phone number");
			waitSleep(10000);
			webElementSendText(prosMedicareNo, data.get("prsMedno"), "Medicare number/SSN/UFI number");
			waitSleep(2500);
			webElementClick(HMHSSearch, "Search");
			waitSleep(4500);
			webElementClick(
					driver.findElement(
							By.xpath(String.format("//span[contains(text(),'%s')]", data.get("prsMFirstName")))),
					"Select Member");
			waitSleep(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on searchProsMem method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on searchProsMem method " + e);
			Assert.fail();
		}
	}

	// HMHS Search Prospective member by using Interaction ID
	public void searchProsMemInterID( Hashtable<String, String> data) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			selectDropdownValueByVisibleText(prsSearchBy, data.get("prsSearch"), "Search by");
			try{
			waitSleep(2500);
			webElementSendText(prsInteractionID, data.get("prsInterID"), "Interaction ID");
			}catch(StaleElementReferenceException e1){
			 waitSleep(2500);
		     webElementSendText(prsInteractionID, data.get("prsInterID"), "Interaction ID");
            }
			waitSleep(1500);
			webElementClick(HMHSSearch, "Search");
			waitSleep(2500);
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on searchProsMem method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on searchProsMem method " + e);
			Assert.fail();
		}
	}

	// HMHS Search Prospective member by using Medicare number
	public void searchProsMemMedicareNo(
			Hashtable<String, String> data) {
		try {
			
			
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			selectDropdownValueByVisibleText(prsSearchBy, data.get("prsSearch"), "Search by");
			webElementSendText(Medicare_SSN_UFI, data.get("prsMedicareNo"), "Medicare Number");
			waitSleep(1500);
			webElementClick(HMHSSearch, "Search");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on searchProsMemMedicareNo method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on searchProsMemMedicareNo method " + e);
			Assert.fail();
		}
	}

	// HMS Navigate to WrapUp Call Disconnected
	public void WrapUp_CallDisconnected() {
		try {
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(HMHSOtherActions, "Other Actions");
			waitSleep(2500);
			webElementClick(HMHSWrapUp_Disconnected, "WrapUp Disconnected");
		} catch (Exception e) {
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on click WrapUp_CallDisconnected method" + excepionMessage);
			test.log(LogStatus.FAIL, "Error on click WrapUp_CallDisconnected method " + e);
			Assert.fail();

		}
	}

	// HMHS Add Prospective member capture error message - Without entering
	// FirstName, LastName click on Submit

	public void AddProsMemFNLNErrMessages(
			Hashtable<String, String> data, String expectedMessage, String expectedMessage1, String expectedMessage2,
			String expectedMessage3, String expectedMessage4, String expectedMessage5) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(Submit, "Submit");
			waitSleep(1500);
			String actualMessage = webElementReadText(HMHSAddProsRecordErrMsg);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
			/*String actualMessage1 = webElementReadText(HMHSAddProsNoReasonErrMsg);
			String expected1 = String.format(expectedMessage1);
			if (actualMessage1.contains(expected1)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
			String actualMessage2 = webElementReadText(HMHSAddProsNoRecMemErrMsg);
			String expected2 = String.format(expectedMessage2);
			if (actualMessage2.contains(expected2)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
			String actualMessage3 = webElementReadText(HMHSAddProsNoRecMembErrMsg);
			String expected3 = String.format(expectedMessage3);
			if (actualMessage3.contains(expected3)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}*/
			// div/div[1]/div/span/div/span
			String actualMessage4 = webElementReadText(HMHSProsMemFNBnk);
			String expected4 = String.format(expectedMessage4);
			if (actualMessage4.contains(expected4)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
			String actualMessage5 = webElementReadText(HMHSProsMemLNBnk);
			String expected5 = String.format(expectedMessage5);
			if (actualMessage5.contains(expected5)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on AddProsMemFNLNErrMessages method " + e);
			test.log(LogStatus.FAIL, "Error on AddProsMemFNLNErrMessages method " + e);
			Assert.fail();
		}
	}

	// HMHS Add Prospective member capture error message - Enter Fname, Lname,
	// Call Reason, MemberShip Type and submit
	public void AddProsMemErrMsg( Hashtable<String, String> data,
			String expectedMessage, String expectedMessage1, String expectedMessage2) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementSendText(prsFname, data.get("prsMFirstName"), "First name");
			webElementSendText(prsLname, data.get("prsMLastName"), "Last name");
			waitSleep(3500);
			webElementClick(preCapturecheckbox, "Capture New Porspective Member");
			waitSleep(2500);
			webElementClick(HMHSSearch, "Search");
			waitSleep(2500);
			selectDropdownValueByVisibleText(prscallReason, data.get("prsMRsnForCall"), "Call Reason");
			selectDropdownValueByVisibleText(prsMemtype, data.get("prsMMbrType"), "Membership type");
			waitSleep(2500);
			webElementClick(Submit, "Submit");
			String actualMessage = webElementReadText(HMHSAddProsRecordErrMsg);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}

			String actualMessage1 = webElementReadText(HMHSAddProsNoReasonErrMsg);
			String expected1 = String.format(expectedMessage1);
			if (actualMessage1.contains(expected1)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
			String actualMessage2 = webElementReadText(HMHSFiveFieldReqErroMsg);
			String expected2 = String.format(expectedMessage2);
			if (actualMessage2.contains(expected2)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on AddProsMemErrMsg method " + e);
			test.log(LogStatus.FAIL, "Error on AddProsMemErrMsg method " + e);
			Assert.fail();
		}
	}

	// HMHS Add Prospective member capture error message - Enter Fname, Lname,
	// DOB, Call Reason and submit
	public void AddProsMemErrMessages( Hashtable<String, String> data,
			String expectedMessage, String expectedMessage1, String expectedMessage2, String expectedMessage3,
			String expectedMessage4) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick(preCapturecheckbox, "Capture New Porspective Member");
			waitSleep(2500);
			webElementClick(HMHSSearch, "Search");
			waitSleep(1500);
			webElementClick(Submit, "Submit");
			waitSleep(1500);

			/*String actualMessage = webElementReadText(HMHSAddProsRecordErrMsg);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
*/
			String actualMessage1 = webElementReadText(HMHSAddProsNoReasonErrMsg);
			assertEquals(expectedMessage1, actualMessage1, "No Reason Err Msg");
			/*String actualMessage2 = webElementReadText(HMHSAddProsNoRecMemErrMsg);
			String expected2 = String.format(expectedMessage2);
			if (actualMessage2.contains(expected2)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
			String actualMessage3 = webElementReadText(HMHSProsMemReasonBnk);
			String expected3 = String.format(expectedMessage3);
			if (actualMessage3.contains(expected3)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
			String actualMessage4 = webElementReadText(HMHSProsMemMemShipBnk);
			String expected4 = String.format(expectedMessage4);
			if (actualMessage4.contains(expected4)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}*/
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on AddProsMemNoMemberErrMsg method " + e);
			test.log(LogStatus.FAIL, "Error on AddProsMemNoMemberErrMsg method " + e);
			Assert.fail();
		}
	}

	// HMHS Add Prospective member capture error message - Enter Fname, Lname,
	// Call Reason, MemberShip Type and submit
	public void ProsMemNoRecordErrMsg( Hashtable<String, String> data,
			String expectedMessage) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementSendText(prsFname, data.get("prsMFirstName"), "First name");
			webElementSendText(prsLname, data.get("prsMLastName"), "Last name");
			waitSleep(3500);
			webElementSendText(prsDob, data.get("DOB"), "DOB");
			waitSleep(3500);
			webElementClick(Submit, "Submit");
			String actualMessage = webElementReadText(HMHSAddProsRecordErrMsg);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on ProsMemNoRecordErrMsg method " + e);
			test.log(LogStatus.FAIL, "Error on ProsMemNoRecordErrMsg method " + e);
			Assert.fail();
		}

	}

	// HMHS Add Prospective member capture error message - Enter Fname, Lname,
	// Call Reason, MemberShip Type and submit
	public void AddProsMemNoReasonErrMsg( Hashtable<String, String> data,
			String expectedMessage, String expectedMessage1) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(HMHSSearch, "Search");
			waitSleep(4500);
			selectDropdownValueByVisibleText(prsMemtype, data.get("prsMMbrType"), "Membership type");
			waitSleep(2500);
			webElementClick(Submit, "Submit");
			String actualMessage = webElementReadText(HMHSAddProsRecordErrMsg);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}

			String actualMessage1 = webElementReadText(HMHSAddProsNoReasonErrMsg);
			String expected1 = String.format(expectedMessage1);
			if (actualMessage1.contains(expected1)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on AddProsMemNoReasonErrMsg method " + e);
			test.log(LogStatus.FAIL, "Error on AddProsMemNoReasonErrMsg method " + e);
			Assert.fail();
		}
	}

	// HMHS Contract having confidential communication Image present or not
	public void HMHSConfCommImg( String frame) {
		try {

			waitSleep(3500);
			switchToFrame(frame);
			elementPresent(ConfiCommimg, "WebElement present");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSMemberNotListMess method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSMemberNotListMess method " + e);
			Assert.fail();
		}
	}
	
	public void searchProsMemHead( Hashtable<String, String> data) {
		try {

			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementSendText(prsFname, data.get("prsMFirstName"), "First name");
			webElementSendText(prsLname, data.get("prsMLastName"), "Last name");
			webElementSendText(prsDob, data.get("DOB"), "DOB");
			waitSleep(2500);
			webElementClick(HMHSSearch, "Search");
			waitSleep(2500);
			webElementClick(
					driver.findElement(
							By.xpath(String.format("//span[contains(text(),'%s')]", data.get("prsMFirstName")))),
					"Select Member");
			waitSleep(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on searchProsMemHead method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on searchProsMemHead method " + e);
			Assert.fail();
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(frame1);
	}

	// HMHS Add Prospective member capture error message - Enter Fname, Lname,
	// DOB, Call Reason and submit
	public void AddProsMemNoMemberErrMsg( Hashtable<String, String> data,
			String expectedMessage, String expectedMessage1) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementSendText(prsFname, data.get("prsMFirstName"), "First name");
			webElementSendText(prsLname, data.get("prsMLastName"), "Last name");
			webElementSendText(prsDob, data.get("DOB"), "DOB");
			waitSleep(2500);
			webElementClick(preCapturecheckbox, "Capture New Porspective Member");
			waitSleep(2500);
			webElementClick(HMHSSearch, "Search");
			selectDropdownValueByVisibleText(prscallReason, data.get("prsMRsnForCall"), "Call Reason");
			waitSleep(2500);
			webElementClick(Submit, "Submit");
			
			String actualMessage1 = webElementReadText(HMHSAddProsNoReasonErrMsg);
			String expected1 = String.format(expectedMessage1);
			if (actualMessage1.contains(expected1)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}
			/*String actualMessage = webElementReadText(HMHSAddProsRecordErrMsg);
			String expected = String.format(expectedMessage);
			if (actualMessage.contains(expected)) {
				test.log(LogStatus.PASS, "Message Matched");
			} else {
				test.log(LogStatus.FAIL, "Message not Matched");
			}*/

		}

		catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on AddProsMemNoMemberErrMsg method " + e);
			test.log(LogStatus.FAIL, "Error on AddProsMemNoMemberErrMsg method " + e);
			Assert.fail();
		}

	}

	public InteractionManagerPage Verifymember() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			try{
			jsClick(VerifyDOB, "Verify DOB");
			}
			catch(StaleElementReferenceException e){
				jsClick(VerifyDOB, "Verify DOB");
			}
			waitSleep(2500);
			try{
				VerifyAddress.click();
				}
				catch(Exception e){
					
				}
			jsClick(Submit, "Submit");
			waitSleep(2500);
		}

		catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on AddProsMemNoMemberErrMsg method " + e);
			test.log(LogStatus.FAIL, "Error on AddProsMemNoMemberErrMsg method " + e);
			Assert.fail();
		}
		return (InteractionManagerPage)openPage(InteractionManagerPage.class);
	}

	public String getIntentID() {
		String intentID = "";
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			intentID = webElementReadText(intentIDRTC);
			intentID = intentID.substring(1, intentID.length()-1);
			System.out.println(intentID);
			test.log(LogStatus.INFO, "Intent ID:" +intentID);

		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentID;
	}
	public String getIntentIDCF() {
		String intentID = "";
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			intentID = webElementReadText(intentIDCF);
			intentID = intentID.substring(1, intentID.length()-1);
			System.out.println(intentID);
			test.log(LogStatus.INFO, "Intent ID:" +intentID);

		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID Create Follow Up method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID Create Follow Up method " + e);
			Assert.fail();
		}
		return intentID;
	}

	
	public String getIntentIDReqID() {
		String intentID = "";
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			intentID = webElementReadText(intentIDReqID);
			intentID = intentID.substring(1, intentID.length()-1);
			System.out.println(intentID);
			test.log(LogStatus.INFO, "Intent ID:" +intentID);

		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID Request ID Card method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID Request ID Card method " + e);
			Assert.fail();
		}
		return intentID;
	}
	
	public String getIntentIDWeb() {
		String intentID = "";
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			intentID = webElementReadText(intentIDWeb);
			intentID = intentID.substring(1, intentID.length()-1);
			System.out.println(intentID);
			test.log(LogStatus.INFO, "Intent ID:" +intentID);

		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID Request ID Card method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID Request ID Card method " + e);
			Assert.fail();
		}
		return intentID;
	}
	
	public String getIntentIDReqID2() {
		String intentID = "";
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			intentID = webElementReadText(intentIDReqID2);
			intentID = intentID.substring(1, intentID.length()-1);
			System.out.println(intentID);
			test.log(LogStatus.INFO, "Intent ID:" +intentID);

		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID2 Request ID Card method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID2 Request ID Card method " + e);
			Assert.fail();
		}
		return intentID;
	}
	
	public InteractionManagerPage cancelIntent() {
		return (InteractionManagerPage)openPage(InteractionManagerPage.class);
	}
	
	public InteractionManagerPage openInteractionPage() {
		return (InteractionManagerPage)openPage(InteractionManagerPage.class);
	}
	
	public InteractionManagerPage wrapIntent() {
		return (InteractionManagerPage)openPage(InteractionManagerPage.class);
	}
	
	public VerifyMemberPage OpenVerifyMember() {
		return (VerifyMemberPage)openPage(VerifyMemberPage.class);
	}
	
	
	public void contactisNotmember()
	{
		try{
			webElementClick(contactisNotMember, "Contact is the selected member");
		}catch(Exception e)
		{
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on contactisNotmember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on contactisNotmember method " + e);
			Assert.fail();
		}
	}
	public void ProsMemMedicareNoDataMasking(Hashtable<String,String> data)
	{
		try{
		String	MedicareId=webElementReadText(MedicareID);
		assertEquals(data.get("ExpectedMedicareId"),MedicareId, "Check Medicare ID is Datamasked or not");
		waitSleep(2500);
		webElementClick(
				driver.findElement(
						By.xpath(String.format("//span[contains(text(),'%s')]", data.get("prsMFirstName")))),
				"Select Member");
		waitSleep(1500);
		webElementClick(Submit, "Submit");
		}catch(Exception e)
		{
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on contactisNotmember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on contactisNotmember method " + e);
			Assert.fail();
		}
	}
	public void Verifysettingoption(Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			
			webElementClick(settingIcon, "setting Icon");
			String Option=webElementReadText(option);
			assertEquals(data.get("ExpectedOption"), Option, "Option");
		} catch (Exception e) {
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on HMHSsearchMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on HMHSsearchMember method " + e);
			Assert.fail();
		}

	}
	public void FGACselectMemberAndNavigatebyRelationship(String Relationship,String ExceptedError) {
		try {
			
			switchToFrame("PegaGadget1Ifr");
			waitSleep(5000);
			waitForElementsToVisible("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]");
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
			ele.size();
			String s = "//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				// updated to match current application from td[3] to td[4] - 1/19/2021
				if (driver.findElement(By.xpath(s1 + "//td[7]")).getText().equals(Relationship)) {
					webElementClick(
							driver.findElement(
									By.xpath(String.format("//span[contains(text(),'%s')]", Relationship))),
							"Member First Name");
					break;
				}
			}
			waitSleep(3000);
			webElementClick(Submit, "Submit");
			String Error=webElementReadText(ErrorMessage);
			System.out.println(Error);
			assertEquals(ExceptedError,Error, "Error message");

			waitSleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on FGACselectMemberAndNavigatebyfname method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on FGACselectMemberAndNavigatebyfname method " + e);
			Assert.fail();
		}
	}

	public void FGAChovermessage(String ExceptedRestrictedhover) {
		try {
			
			switchToFrame("PegaGadget1Ifr");
			waitSleep(5000);
			String Restrictedhover=getTooltipMessage(Restricted, Restrictedmessage);
			System.out.println(Restrictedhover);
			assertEquals(ExceptedRestrictedhover,Restrictedhover, "message Mouseover");
			waitSleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on FGACselectMemberAndNavigatebyfname method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on FGACselectMemberAndNavigatebyfname method " + e);
			Assert.fail();
		}
	}

}
