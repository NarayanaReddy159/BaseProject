package com.nasco.HMHS.TestScripts.G1;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.VerifyMemberPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC003_MemberSearch_SSN extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G1DP")
	public void HMHS_AUTC003_MemberSearch_SSN(Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("HMHS_AUTC003_MemberSearch_SSN ");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_AUTC003_MemberSearch_SSN - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		log.debug("HMHS_TC002_MemberSearch_MemberID_Search -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username2")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		test.log(LogStatus.INFO,"Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed.");
		test.log(LogStatus.INFO,"Member Search Completed.");
		searchMember.readMemberDetails(data.get("ExpectedMemberDetails"));
		log.debug("Reading Member Details Completed");
		test.log(LogStatus.INFO,"Reading Member Details Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
		test.log(LogStatus.INFO,data.get("Fname") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(LogStatus.INFO,"Member Submit Completed.");
		VerifyMemberPage verifyMember=searchMember.OpenVerifyMember();
		verifyMember.wrapUpnotVerified();
		log.debug("Member Wrapped up.");
		test.log(LogStatus.INFO,"Member Wrapped up.");
	}

	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_TC003_MemberSearch_SSN Completed");
		log.debug("HMHS_TC003_MemberSearch_SSN Completed");
		quit();

	}
}
