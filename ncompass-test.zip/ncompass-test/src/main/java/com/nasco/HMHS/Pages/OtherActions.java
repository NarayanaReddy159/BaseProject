package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;

@SuppressWarnings({"rawtypes","unchecked"})
public class OtherActions extends BasePage {

	String excepionMessage = "";

	// web elements
	// New interaction
	String otherActionXpath="//ul[contains(@id,'pyNavigation')]/li[1]";
	
	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	
	@FindBy(how = How.CLASS_NAME, using = "actionTitleBarLabelStyle")
	public WebElement intnetTitle;
	
	
	
	@FindBy(id = "PegaGadget1Ifr")
	public WebElement frame1;
	
	@FindBy(xpath = "//button[@title='Other actions']")
	public WebElement otherActions;
	
	@FindBy(xpath = "//span[contains(text(),'Cancel Work')]")
	public WebElement cancelWork;
	
	@FindBy(xpath = "//span[contains(text(),'Route to Team')]")
	public WebElement routeTeam;
	
	@FindBy(xpath = "//label[text()='Route to']//following::label[1]")
	public WebElement routeTeamMember;
	
	@FindBy(xpath = "//label[text()='Route to']//following::label[2]")
	public WebElement Workbasket;
	
	@FindBy(name = "$PpyWorkPage$pOperator")
	public WebElement assignToTeamMember;
	
	@FindBy(name = "$PpyWorkPage$pRoutedToWB")
	public WebElement assignToWorkbasket;
	
	
	
	@FindBy(xpath = "//span[contains(text(),'Save to Worklist')]")
	public WebElement saveToWorkList;
	
	@FindBy(name = "$PpyWorkPage$pWrapUpComments")
	public WebElement comments;
	
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	
	@FindBy(name = "$PpyWorkPage$pReasonToPend")
	public WebElement ReasonToPend;
	
	@FindBy(how = How.XPATH, using  = "//label[contains(text(),'Comments')]//following::button[2]")
	public WebElement IDCSubmit;
	@FindBy(how = How.NAME,using = "$PpyWorkPage$pComments")
	public WebElement savetoworklisComments;
	@FindBy(how = How.XPATH, using  = "//span[@class='standard']//preceding::label[1]")
	public WebElement Intentname;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(intnetTitle);
	}

	//cancel work
	public void cancelWork(Hashtable<String, String> data)
	{
		try{
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			webElementClick(cancelWork,"Cancel Work");
			waitSleep(2000);
			webElementSendText(comments, data.get("CancelComments"), "Comments");
			if(data.get("Intent").equals("Request ID Card"))
			{
				webElementClick(IDCSubmit, "Submit");
			}
			else{
				webElementClick(Submit, "Submit");	
			}
			
			wait(1000);
		   }
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on cancelWork method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on cancelWork method " + e);
			Assert.fail();
		}
	}

	public void saveToWorklist(Hashtable<String, String> data)
	{
		try{
			waitSleep(2000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			webElementClick(saveToWorkList,"Save to Worklist");
			waitSleep(2000);
			selectDropdownValueByVisibleText(ReasonToPend, data.get("ReasonToPend"), "to select Reason to Pend");
			wait(1500);
			webElementSendText(savetoworklisComments, data.get("Comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(1500);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on cancelWork method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on cancelWork method " + e);
			Assert.fail();
		}
	}
	
    public void routeToTeamMember(Hashtable<String, String> data)
    {
    	String assignOp="//span[contains(text(),'%s')]";
    	String deactiveText="//div[contains(text(),'%s')]";
    	try{
			waitSleep(2500);
			try{
				waitForNoSuchElement(otherActions);
				otherActions.click();
				waitSleep(2000);
				waitForNoSuchElement(routeTeam);
				routeTeam.click();
				waitSleep(2000);
			}
			catch(Exception e1)
			{
				System.out.println("Entered Exception"+e1);
				jsClick(otherActions, "Other Actions");
				waitSleep(2000);
				jsClick(routeTeam, "Route to Team");
				waitSleep(2000);
			}
			
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", routeTeamMember);
			webElementClick(routeTeamMember, "Route to Team member");
			waitSleep(2500);
			webElementClick(routeTeamMember, "Route to Team member");
			if(!data.get("DeactivatedTeam").equals("vid9219"))
			{
				waitSleep(2000);
				webElementSendText(assignToTeamMember, data.get("DeactivatedTeam"), "Assign To");
				driver.findElement(By.xpath(String.format(assignOp, data.get("DeactivatedTeam")))).click();
				waitSleep(2000);
				String deactivemsg=webElementReadText(driver.findElement(By.xpath(String.format(deactiveText, data.get("DeactiveText")))), "Deactive Message");
				assertEquals(data.get("DeactiveText"), deactivemsg, "Deactive Operator Message");
				webElementClick(Workbasket, "Route to workbakset");
				waitSleep(2000);
				webElementClick(routeTeamMember, "Route to Team member");
			}
			waitSleep(2000);
			webElementSendText(assignToTeamMember, data.get("TeamMember"), "Assign To");
			try{
				waitSleep(2000);
				driver.findElement(By.xpath(String.format(assignOp, data.get("TeamMember")))).click();	
			}
			catch(Exception e1)
			{
				System.out.println("Error "+e1);
			}
			wait(1500);
			webElementSendText(savetoworklisComments, data.get("Comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(1500);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on routeToTeamMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on routeToTeamMember method " + e);
			Assert.fail();
		}
    }
  
    public void navigateBackIntentScreen(Hashtable<String, String> data)
	{
		try{
			waitSleep(2000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			webElementClick(saveToWorkList,"Save to Worklist");
			waitSleep(3000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(3000);
			webElementClick(driver.findElement(By.xpath(String.format(otherActionXpath,data.get("Intent")))),"Other option");
			waitSleep(2500);
		    String IntentName=webElementReadText(Intentname, "Intentname");
			System.out.println(IntentName);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on navigateBackIntentScreen method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on navigateBackIntentScreen method " + e);
			Assert.fail();
		}
	}
    public void navigateBackIntentScreenRoutto(Hashtable<String, String> data)
	{
		try{
			waitSleep(2000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			webElementClick(routeTeam,"Route to Team");
			waitSleep(3000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(3000);
			webElementClick(driver.findElement(By.xpath(String.format(otherActionXpath,data.get("Intent")))),"Other option");
			waitSleep(2500);
		    String IntentName=webElementReadText(Intentname, "Intentname");
			System.out.println(IntentName);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on navigateBackIntentScreen method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on navigateBackIntentScreen method " + e);
			Assert.fail();
		}
	}
    public void navigateBackIntentScreenCancelwork(Hashtable<String, String> data)
   	{
   		try{
   			waitSleep(1500);
   			webElementClick(otherActions, "Other Actions");
   			waitSleep(1500);
   			webElementClick(cancelWork,"cancel Work");
   			waitSleep(2500);
   			webElementClick(otherActions, "Other Actions");
   			waitSleep(2500);
   			webElementClick(driver.findElement(By.xpath(String.format(otherActionXpath,data.get("Intent")))),"Other option");
   			waitSleep(1500);
   		    String IntentName=webElementReadText(Intentname, "Intentname");
   			System.out.println(IntentName);
   		}	
   		catch(Exception e)
   		{
   			excepionMessage = Arrays.toString(e.getStackTrace());
   			BaseTest.log.error("Error on navigateBackIntentScreen method " + excepionMessage);
   			test.log(LogStatus.FAIL, "Error on navigateBackIntentScreen method " + e);
   			Assert.fail();
   		}
   	}
    
    public void routeToWorkbasket(Hashtable<String, String> data)
    {
    	String assignWB="//span[contains(text(),'%s')]";
    	try{
			waitSleep(2500);
			try{
				waitForNoSuchElement(otherActions);
				otherActions.click();
				waitSleep(2000);
				waitForNoSuchElement(routeTeam);
				routeTeam.click();
				waitSleep(2000);
			}
			catch(Exception e1)
			{
				System.out.println("Entered Exception"+e1);
				jsClick(otherActions, "Other Actions");
				waitSleep(2000);
				jsClick(routeTeam, "Route to Team");
				waitSleep(2000);
			}
			
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", routeTeamMember);
			webElementClick(Workbasket, "Route to Workbasket");
			waitSleep(2500);
			webElementSendText(assignToWorkbasket, data.get("Workbasket"), "Assign To");
			try{
				waitSleep(2000);
				driver.findElement(By.xpath(String.format(assignWB, data.get("Workbasket")))).click();	
			}
			catch(Exception e1)
			{
				System.out.println("Error "+e1);
			}
			wait(1500);
			webElementSendText(savetoworklisComments, data.get("Comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(1500);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on routeToTeamMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on routeToTeamMember method " + e);
			Assert.fail();
		}
    }

}
