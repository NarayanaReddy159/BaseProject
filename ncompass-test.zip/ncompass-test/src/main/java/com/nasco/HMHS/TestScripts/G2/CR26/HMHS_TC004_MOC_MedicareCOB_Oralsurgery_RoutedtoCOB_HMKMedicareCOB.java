package com.nasco.HMHS.TestScripts.G2.CR26;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.utilities.DataProviders;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC004_MOC_MedicareCOB_Oralsurgery_RoutedtoCOB_HMKMedicareCOB extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC004_MOC_MedicareCOB_Oralsurgery_RoutedtoCOB_HMKMedicareCOB (Hashtable<String, String> data) throws Exception {
		validateskill("HMHS_AUTC004_MOC_MedicareCOB_Oralsurgery_RoutedtoCOB_HMKMedicareCOB", data);
	}
@AfterMethod
	public void tearDown() 
	{	test.log(LogStatus.INFO, "HMHS_TC004_MOC_MedicareCOB_Oralsurgery_RoutedtoCOB_HMKMedicareCOB completed.");
		log.debug("HMHS_TC004_MOC_MedicareCOB_Oralsurgery_RoutedtoCOB_HMKMedicareCOB completed.");
		quit();
	}
}
