package com.nasco.HMHS.Pages;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;


@SuppressWarnings({"rawtypes","unchecked"})
public class ManageClaimsPage extends BasePage{
    
	String otherActionsXpath="//span[contains(text(),'%s')]";
	String XpathHealthplancodedetails="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[2]//span[contains(text(),'%s')]//following::div[1]";
	String XpathViewclaimdetails="//div[contains(@class,' flex content layout-content-default  content-default set-width-auto false')]//span[contains(text(),'%s')]/following::div[1]";
	String XpathTotalValue="//div[contains(@class,'flex content layout-content-inline_grid_quintuple  content-inline_grid_quintuple clearfix')]/div/span[contains(text(),'%s')]/following::div[1]";
	String XpathExpandedlinedetails="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[1]/div/span[contains(text(),'%s')]//following::div[1]";
	String XpathRevenue="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[3]//span[contains(text(),'%s')]//following::div[1]";
	String XpathHealthplancodedetails1="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[4]//span[contains(text(),'%s')]//following::div[1]";
	String XpathHealthplancodedetails2="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[5]//span[contains(text(),'%s')]//following::span[1]";
	String XpathHealthplanclaims="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[7]//span[contains(text(),'%s')]//following::span[1]";
	String XpathManagedcare="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[6]//span[contains(text(),'%s')]//following::div[1]";
	String XpathBenefitsdetails="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[8]//span[contains(text(),'%s')]//following::span[1]";
	String XpathPricinginformation="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[9]//span[contains(text(),'%s')]//following::span[1]";
	String XpathProcessinginformation="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[10]//span[contains(text(),'%s')]//following::span[1]";
	String XpathPerformingprovider="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[11]//span[contains(text(),'%s')]//following::span[1]";
	String XpathHealthplanprovider="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[12]//span[contains(text(),'%s')]//following::span[1]";
	String XpathFacilitydetails="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[13]//span[contains(text(),'%s')]//following::span[1]";
	String XpathHealthplanfacility="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[14]//span[contains(text(),'%s')]//following::span[1]";
	String XpathReferringprovider="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[15]//span[contains(text(),'%s')]//following::span[1]";
	String XpathHealthplanprovider1="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[16]//span[contains(text(),'%s')]//following::span[1]";
    String XpathClaimEOBremittance="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[20]//span[contains(text(),'%s')]//following::span[1]";
    String XpathClaimEOBremittance1="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[20]//label[contains(text(),'%s')]//following::span[1]";
    String Xpathbankdetail="(//div[contains(@class,'flex  content   layout-content-inline_grid_quintuple content-inline_grid_quintuple ')])//span[contains(text(),'%s')]//following::span[1]";
    String XpathPaymentoff="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[17]//span[contains(text(),'%s')]//following::span[1]";
    String XpathTotalsbylist="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[18]//span[contains(text(),'%s')]//following::div[1]";
    String XpathTotalsbylist1="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])[19]//span[contains(text(),'%s')]//following::div[1]";

    @FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pDateSearchOptions")
	public WebElement dateSearchOptions;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pServiceFromDate")
	public WebElement firstDos;
	
	@FindBy(how = How.XPATH, using = "//input[@name='$PHCClaimSearch$pServiceToDate']")
	public WebElement lastDos;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pClaimID")
	public WebElement claimNumber;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pPayment$pCheckOrEFTTraceNumber")
	public WebElement checkNumber;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pFirstFinalizedDate")
	public WebElement firstFinalDate;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pLastFinalizedDate")
	public WebElement lastFinalDate;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pSCCFNbr")
	public WebElement sccfNumber;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pRelationship")
	public WebElement relationShip;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pProfessionalProcedureCode")
	public WebElement procedureCode;

	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pDiagnosisCode")
	public WebElement diagnosisCode;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pRevenueCode")
	public WebElement revenueCode;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pReferenceNumber")
	public WebElement modifiers;
	
	@FindBy(how = How.NAME, using = "$PProvider$ppyWorkPartyUri")
	public WebElement billingProviderID;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pClaimStatus")
	public WebElement claimStatus;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pBENCAT")
	public WebElement Bencat;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pPlaceofServiceDescription")
	public WebElement placeofService;
	
	@FindBy(xpath = "//label[contains(text(),'SCCF #')]/following::div[1]")
	public WebElement Sccf;
	@FindBy(xpath = "//label[contains(text(),'Claim image')]/following::a[1]")
	public WebElement Claimimage;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pProductType")
	public WebElement productLineCode;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pProgramLevelPayment")
	public WebElement programPayLevel;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pRejectionCode")
	public WebElement rejectionCode;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pDeductibleIndicator")
	public WebElement deductiable;
	
	@FindBy(how = How.NAME, using = "$PpyWorkPage$pReasonCode")
	public WebElement reason;
	
	@FindBy(how = How.NAME, using = "$PpyWorkPage$pCSRProcessingInst")
	public WebElement AdjComments;
	
	@FindBy(how = How.NAME, using = "$PpyWorkPage$pAdjustClaims$l1$pComments")
	public WebElement ClaimComments;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Coins or copay')]")
	public WebElement copay;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pOtherPartyPaymentIndicator")
	public WebElement COB;
	
	@FindBy(how = How.NAME, using = "$PHCClaimSearch$pBenefitMaximumIndicator")
	public WebElement benifitMax;
	
	@FindBy(how = How.XPATH, using = "//h2[text()='Additional search criteria']")
	public WebElement addnlSearch;
	
	@FindBy(how = How.XPATH, using = "//button[text()='Submit']")
	public WebElement submitBtn;
	
	@FindBy(how = How.XPATH, using = "//label[@class='actionTitleBarLabelStyle']")
	public WebElement pageTitle;
	
	@FindBy(xpath = "//button[@title='Other actions']")
	public WebElement otherActions;
	@FindBy(xpath = "//div[contains(text(),'More than 200 results were found. Please refine your search criteria')]")
	public WebElement Morethen200;
	
	@FindBy(xpath = "//*[@id='$PpyWorkPage$pAdjustClaims$l1']/td[1]")
	public WebElement AdjclaimNumber;
	@FindBy(xpath = "(//button[contains(text(),'Confirm')])[1]")
	public WebElement Confirm;
	//@FindBy(xpath = "(//input[contains(@name,'$PpyWorkPage$pAdjustClaims$l') and contains(@name,'$pAdjustmentNeeded')])[2]")
	//public WebElement Noteligibleforadjustment;
	@FindBy(xpath = "//*[@id='PegaRULESErrorFlag']")
	public WebElement Noteligibleforadjustment;
	
	@FindBy(xpath = "//span[contains(@title,'Claim is in process and not eligible for adjustment')]")
	public WebElement ClaimInProcessErr;
	
	@FindBy(xpath = "//div[contains(@data-node-id,'PatientDetailsHover')]")
	public WebElement Patienthover;
	@FindBy(xpath = "//div[contains(@class,'smarttip-content')]")
	public WebElement ClaimStatushover;
	@FindBy(xpath = "//span[contains(text(),'Claim number')]//following::span[1]")
	public WebElement Claimid;
	@FindBy (how = How.XPATH, using = "//label[contains(text(),'No')]")
	public WebElement No;
	@FindBy (how = How.XPATH, using = "//label[contains(text(),'Yes')]")
	public WebElement Yes;
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Submit')]")
	public WebElement Submit;

	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Adjustment needed')]")
	public WebElement AdjustmentNeeded;
	
	@FindBy(xpath = "(//span[contains(text(),'Procedure code')]//following::div)[1]")
	public WebElement Procedurecode;
	@FindBy(xpath = "(//h2[contains(text(),'Health plan code details')])[1]")
	public WebElement Healthplancodedetail;
	@FindBy(xpath = "//h2[contains(text(),'Health plan code details - Only primary diagnosis details will display')]")
	public WebElement Healthplancodedetail1;
	@FindBy(xpath = "(//h2[contains(text(),'Additional diagnosis codes on claim')])[1]")
	public WebElement diagnosis;
	@FindBy(xpath = "//span[contains(text(),'Primary diagnosis')]//following::div[1]")
	public WebElement Primarydiagnosis;
	
	@FindBy(xpath = "//h2[contains(text(),'Managed care')]")
	public WebElement managedcare;
	
	@FindBy(xpath="//h2[contains(text(),'Health plan claims managed care details')]")
	public WebElement Healthplanclaims;
	
	@FindBy(xpath="//h3[contains(text(),'Provider details') and contains(@id,'headerlabel')]")
	public WebElement Providerdetails;
	@FindBy(xpath="//h2[contains(text(),'Health plan provider details') and contains(@id,'headerlabel')]")
	public WebElement Healthplan;
	@FindBy(xpath="//h2[contains(text(),'Health plan facility details') and contains(@id,'headerlabel')]")
	public WebElement Healthplanfacilitydetails;
	@FindBy(xpath="(//h2[contains(text(),'Health plan provider details') and contains(@id,'headerlabel')])[2]")
	public WebElement Healthplan1;
	@FindBy(xpath="//h3[contains(text(),'Claim EOB remittance') and contains(@id,'headerlabel')]")
	public WebElement ClaimEOBremittance;
	@FindBy(xpath="//h3[contains(text(),'Claim dollars') and contains(@id,'headerlabel')]")
	public WebElement Claimdollars;
	@FindBy(xpath="//*[@id='$PpyWorkPage$pClaim$pPayment$pPaymentDetails$l1']/td[1]/span")
	public WebElement bankdetail;
	@FindBy(xpath="//button[contains(text(),'Reviewed')]")
	public WebElement ReviewButton;
	@FindBy(xpath="//button[contains(text(),'Proceed without adjustments')]")
	public WebElement Proceedwithoutadjustments;
	@FindBy(xpath="(//*[@id='PegaRULESErrorFlag'])[1]")
	public WebElement FirstDoserror;
	
	@FindBy(xpath="(//*[@id='PegaRULESErrorFlag'])[1]")
	public WebElement lastDoserror;
	@FindBy(xpath="//div[contains(text(),'No claims found, refine your search criteria.')]")
	public WebElement Noclaimsfound;
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Search')]")
	public WebElement SearchBtn;
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(add);
	}

	
	public void searchClaims(Hashtable<String, String> data)
	{
		try{
			if(null != data.get("SearchOptions") && !data.get("SearchOptions").isEmpty())
			{
				selectDropdownValueByVisibleText(dateSearchOptions, data.get("SearchOptions"), "dateSearchOptions");
			}
			
			if(null != data.get("FirstDOS") && !data.get("FirstDOS").isEmpty())
			{
				
				try{
					//(firstDos, data.get("FirstDOS"), "First DOS");
					firstDos.sendKeys(data.get("FirstDOS"));
					waitSleep(2500);
			}catch(Exception e)
			{
				firstDos.sendKeys(data.get("FirstDOS"));
				waitSleep(2500);
			}
				/*webElementSendText(firstDos, data.get("FirstDOS"), "First DOS");
				waitSleep(2500);*/
				driver.findElement(By.xpath("//label[text()='First date of service']")).click();
			}
			if(null != data.get("LastDOS") && !data.get("LastDOS").isEmpty())
			{
				try{
					lastDos.sendKeys(data.get("LastDOS"));
					//webElementSendText(lastDos, data.get("LastDOS"), "Last DOS");
					waitSleep(2500);
			}catch(Exception e)
			{
				lastDos.sendKeys(data.get("LastDOS"));
				waitSleep(2500);
			}
				
				//driver.findElement(By.xpath("//label[text()='First date of service']")).click();
			}
			if(null != data.get("Servicedate") && !data.get("Servicedate").isEmpty())
			{
				try{
					firstDos.sendKeys(data.get("Servicedate"));
					//webElementSendText(lastDos, data.get("LastDOS"), "Last DOS");
					waitSleep(2500);
			}catch(Exception e)
			{
				firstDos.sendKeys(data.get("Servicedate"));
				waitSleep(2500);
			}
				
				//driver.findElement(By.xpath("//label[text()='First date of service']")).click();
			}
			if(null != data.get("ICN") && !data.get("ICN").isEmpty())
			{
				webElementSendText(claimNumber, data.get("ICN"), "Claim Number");
			}
			if(null != data.get("CheckNumber") && !data.get("CheckNumber").isEmpty())
			{
				webElementSendText(checkNumber, data.get("CheckNumber"), "Check Number");
			}
//			if(null != data.get("FirstFinalDate") && !data.get("FirstFinalDate").isEmpty())
//			{
//				webElementSendText(firstFinalDate, data.get("FirstFinalDate"), "First Finalized Date");
//			}
//			if(null != data.get("LastFinalDate") && !data.get("LastFinalDate").isEmpty())
//			{
//				webElementSendText(lastFinalDate, data.get("LastFinalDate"), "Last Finalized Date");
//			}
			if(null != data.get("FirstFinalDate") && !data.get("FirstFinalDate").isEmpty())
			{
				
				try{
					//(firstDos, data.get("FirstDOS"), "First DOS");
					firstFinalDate.sendKeys(data.get("FirstFinalDate"));
					waitSleep(2500);
			}catch(Exception e)
			{
				firstFinalDate.sendKeys(data.get("FirstFinalDate"));
				waitSleep(2500);
			}
				
				driver.findElement(By.xpath("//label[text()='First finalized date']")).click();
			}
			if(null != data.get("lastFinalDate") && !data.get("lastFinalDate").isEmpty())
			{
				try{
					
					driver.findElement(By.xpath("//label[contains(text(),'Check number')]")).click();
					lastFinalDate.sendKeys(data.get("lastFinalDate"));
					waitSleep(2500);
			}catch(Exception e)
			{
				lastFinalDate.sendKeys(data.get("lastFinalDate"));
				waitSleep(2500);
			}
				
				//driver.findElement(By.xpath("//label[text()='First date of service']")).click();
			}
			
			if(null != data.get("SCCF") && !data.get("SCCF").isEmpty())
			{
				webElementSendText(sccfNumber, data.get("SCCF"), "SCCF Number");
			}
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", addnlSearch);
			webElementClick(addnlSearch, "Additional Search");
			if(null != data.get("RelationShip") && !data.get("RelationShip").isEmpty())
			{
				webElementSendText(relationShip, data.get("RelationShip"), "RelationShip");
			}
			if(null != data.get("ProcedureCode") && !data.get("ProcedureCode").isEmpty())
			{
				webElementSendText(procedureCode, data.get("ProcedureCode"), "Procedure Code");
			}
			if(null != data.get("DiagnosisCode") && !data.get("DiagnosisCode").isEmpty())
			{
				webElementSendText(diagnosisCode, data.get("DiagnosisCode"), "Diagnosis Code");
			}
			if(null != data.get("RevenueCode") && !data.get("RevenueCode").isEmpty())
			{
				webElementSendText(revenueCode, data.get("RevenueCode"), "Revenue Code");
			}
			if(null != data.get("Modifiers") && !data.get("Modifiers").isEmpty())
			{
				webElementSendText(modifiers, data.get("Modifiers"), "Modifiers");
			}
			if(null != data.get("BillingProviderID") && !data.get("BillingProviderID").isEmpty())
			{
				webElementSendText(billingProviderID, data.get("BillingProviderID"), "Billing Provider ID");
			}
			if(null != data.get("ClaimStatus") && !data.get("ClaimStatus").isEmpty())
			{
				selectDropdownValueByVisibleText(claimStatus, data.get("ClaimStatus"), "Claim Status");
			}
			if(null != data.get("Bencat") && !data.get("Bencat").isEmpty())
			{
				//selectDropdownValueByVisibleText(Bencat, data.get("Bencat"), "Bencat");
				webElementSendText(Bencat, data.get("Bencat"), "Bencat");
			}
			if(null != data.get("PlaceofService") && !data.get("PlaceofService").isEmpty())
			{
				//selectDropdownValueByVisibleText(placeofService, data.get("PlaceofService"), "Place of Service");
				webElementSendText(placeofService, data.get("PlaceofService"), "Place of Service");
			}
			if(null != data.get("ProductLineCode") && !data.get("ProductLineCode").isEmpty())
			{
				selectDropdownValueByVisibleText(productLineCode, data.get("ProductLineCode"), "Product Line Code");
			}
			if(null != data.get("ProgramPayLevel") && !data.get("ProgramPayLevel").isEmpty())
			{
				selectDropdownValueByVisibleText(programPayLevel, data.get("ProgramPayLevel"), "Program Pay Level");
			}
			if(null != data.get("RejectionCode") && !data.get("RejectionCode").isEmpty())
			{
				webElementSendText(rejectionCode, data.get("RejectionCode"), "Rejection Code");
			}
			if(null != data.get("Deductiable") && !data.get("Deductiable").isEmpty())
			{
				if(data.get("Deductiable").equals("Y"))
				{
					webElementSendText(deductiable, data.get("Deductiable"), "Deductiable");	
				}
				
			}
			if(null != data.get("Copay") && !data.get("Copay").isEmpty())
			{ 
			 if(data.get("Copay").equals("Y"))
				{
				 
				//webElementSendText(copay, data.get("Copay"), "Coins or copay");
					webElementClick(copay, "Coins or copay");
					
				}
			}
			if(null != data.get("COB") && !data.get("COB").isEmpty())
			{
				if(data.get("COB").equals("Y"))
				{
				webElementSendText(COB, data.get("COB"), "COB");
				}
			}
			if(null != data.get("BenifitMax") && !data.get("BenifitMax").isEmpty())
			{
				if(data.get("BenifitMax").equals("Y"))
				{
					webElementSendText(benifitMax, data.get("BenifitMax"), "Benifit Maximum");	
				}
			}
			
			webElementClick(submitBtn, "Submit");
			waitSleep(2500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on searchClaims method " + e);
			test.log(LogStatus.FAIL, "Error on searchClaims method " + e);
			Assert.fail();
		}
	}
	
	public void selectClaim(Hashtable<String, String> data){
		try{
			List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l')]"));
			if(tableRows.size()>0)
			{
				for(int i=1;i<=tableRows.size();i++)
				{
					if(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")).getText().equals(data.get("ICN")))
					{
						WebElement reviewed=driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[1]//input[@type='checkbox']"));
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", reviewed);
						webElementClick(reviewed,"Reviewed");
						waitSleep(3500);
						webElementClick(submitBtn, "Submit");
						waitSleep(3500);
						break;
					}
				}
			}
			waitSleep(7500);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectClaim method " + e);
			test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
			Assert.fail();
		}
	}
		public void selectClaimnotsubmit(Hashtable<String, String> data){
			try{
				List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l')]"));
				if(tableRows.size()>0)
				{
					for(int i=1;i<=tableRows.size();i++)
					{
						if(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")).getText().equals(data.get("ICN")))
						{
							WebElement reviewed =driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[1]//input[@type='checkbox']"));
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", reviewed);
							webElementClick(reviewed,"Reviewed");
							waitSleep(3500);
							
							break;
						}
					}
				}
				
			}catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on selectClaimnotsubmit method " + e);
				test.log(LogStatus.FAIL, "Error on selectClaimnotsubmit method " + e);
				Assert.fail();
			}

	}
	
	public void getPageHeader(String expectedPageTitle)
	{
		try{
			waitSleep(2500);
			String actualpageTitle=webElementReadText(pageTitle, "Page Title");
			System.out.println(actualpageTitle);
			assertEquals(expectedPageTitle, actualpageTitle, "Page Title");
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getPageHeader method " + e);
			test.log(LogStatus.FAIL, "Error on getPageHeader method " + e);
			Assert.fail();
		}
	}
	public void adjust()
	{
		try{
			waitSleep(6500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", AdjustmentNeeded);
			waitSleep(2500);
			if(AdjustmentNeeded.isSelected())
			{
				test.log(LogStatus.INFO, "Adjustment needed is selected ");
			}
			else
			{
				test.log(LogStatus.INFO, "Adjustment needed is not selected ");	
			}
			waitSleep(3500);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on adjust method " + e);
			test.log(LogStatus.FAIL, "Error on adjust method " + e);
			Assert.fail();
		}
	}
	public void SelectotheractionOptions(String Options)
	{
		try{
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			webElementClick( driver.findElement(By.xpath(String.format(otherActionsXpath, Options))),"task Name");
			waitSleep(2500);
			wait(2500);
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getPageHeader method " + e);
			test.log(LogStatus.FAIL, "Error on getPageHeader method " + e);
			Assert.fail();
		}
	}
	public void Morethen200(Hashtable<String, String> data)
	{
		try{
			
			waitSleep(2000);
			String error=webElementReadText(Morethen200);
			assertEquals(data.get("Expectedmessage"), error, "More than 200 results were found.");
			waitSleep(2500);
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Morethen200 method " + e);
			test.log(LogStatus.FAIL, "Error on Morethen200 method " + e);
			Assert.fail();
		}
	}
	public void Viewclaimdetails(Hashtable<String, String> data)
	{
		String Viewclaimdetails ="";
		try{
			
			waitSleep(2000);
			Viewclaimdetails=getrowdata(data.get("Headersdata"), XpathViewclaimdetails);
			System.out.println(data.get("Expected_details"));
			System.out.println(Viewclaimdetails);
			assertEquals(data.get("Expected_details"), Viewclaimdetails, "Check the data masking");
			waitSleep(2500);
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Morethen200 method " + e);
			test.log(LogStatus.FAIL, "Error on Morethen200 method " + e);
			Assert.fail();
		}
	}
	public void AdjustClaim(Hashtable<String, String> data){
		try{
			List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l')]"));
			if(tableRows.size()>0)
			{
				for(int i=1;i<=tableRows.size();i++)
				{
					if(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")).getText().equals(data.get("ICN")))
					{   
					   ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", submitBtn);
						webElementClick(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[1]//input[@type='checkbox']")),"Reviewed");
						waitSleep(3500);
						webElementClick(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[2]//input[@type='checkbox']")),"Adjust");
						waitSleep(3500);
						
						webElementClick(submitBtn, "Submit");
						waitSleep(3500);
						break;
					}
				}
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on AdjustClaim method " + e);
			test.log(LogStatus.FAIL, "Error on AdjustClaim method " + e);
			Assert.fail();
		}
	}
	public void Claimsselectedforadjustment(Hashtable<String, String> data)
	{
		String ClaimNumber ="";
		try{
			
			waitSleep(2000);
			ClaimNumber=webElementReadText(AdjclaimNumber);
			assertEquals(data.get("ICN"), ClaimNumber, "Check the Claim Number");
			waitSleep(2500);
			webElementClick(Confirm, "Confirm");
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Claimsselectedforadjustment method " + e);
			test.log(LogStatus.FAIL, "Error on Claimsselectedforadjustment method " + e);
			Assert.fail();
		}
	}
	public void Noteligibleforadjustment (Hashtable<String, String> data)
	{
		try{
			
			waitSleep(2000);
			Actions act = new Actions(driver);
			waitSleep(1500);
			act.moveToElement(Noteligibleforadjustment);
			waitSleep(1500);
			String actual=Noteligibleforadjustment.getAttribute("title");
			System.out.println("Actual Error message is :" + actual);
			String expected = "Request for adjustment was previously submitted for claim, search for related service intent CLM-4270 in the Member 360.";
			assertEquals(actual,expected,"Claim in process Error should be matched.");
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Noteligibleforadjustment method " + e);
			test.log(LogStatus.FAIL, "Error on Noteligibleforadjustment method " + e);
			Assert.fail();
		}
	}
	
	public void AdjustReason(Hashtable<String, String> data) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			try{
				/*Select Adjreason= new Select(reason);
				Adjreason.selectByIndex(1);
				waitSleep(1500);*/
				waitSleep(1500);
				selectDropdownValueByVisibleText(reason, data.get("AdjReason"), "Reason For Interaction");
				waitSleep(1500);
				try{
					webElementSendText(AdjComments, data.get("Adjcomments"), "Comments");
				}catch(StaleElementReferenceException e)
				{
					webElementSendText(AdjComments, data.get("Adjcomments"), "Comments");	
				}
				waitSleep(1500);
				webElementSendText(ClaimComments,data.get("Clmcomments"), "Enter Selected adjustment claim comments");
				waitSleep(1500);
			    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);
				webElementClick(No,"Select additionals claim for adjustment as No");
				waitSleep(1500);
				webElementClick(Submit, "Submit");
				waitSleep(2500);
			}catch(Exception e1){
				e1.printStackTrace();
				BaseTest.log.error("Error on AdjustReason method " + e1);
				test.log(LogStatus.FAIL, "Error on AdjustReason method " + e1);
				Assert.fail();
			}	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapUp method " + e);
			test.log(LogStatus.FAIL, "Error on wrapUp method " + e);
			Assert.fail();
		}
	}
	public void Validatetheclaimsscreen (Hashtable<String, String> data){
		String claim="";
		String Patientname="";
		String ClaimStatus="";
		String Productline="";
		String Billing="";
		String Paid="";
		try{
			List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l')]"));
			if(tableRows.size()>0)
			{
				for(int i=1;i<=tableRows.size();i++)
				{
					if(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")).getText().equals(data.get("ICN")))
					{
						claim=webElementReadText(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")),"Reviewed");
						waitSleep(3500);
						driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[6]")).click();
						Patientname=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[6]")), Patienthover);
					    waitSleep(1500);
					    ClaimStatus=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[11]")), ClaimStatushover);
					    waitSleep(1500);
					    Productline=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[12]")), ClaimStatushover);
					    waitSleep(1500);
					    Billing=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[13]")), ClaimStatushover); 
					    waitSleep(1500);
					    Paid=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[14]")), ClaimStatushover); 

					    break;
					}
				}
			}
			
			String HoverDetails=claim+"|"+Patientname+"|"+ClaimStatus+"|"+Productline+"|"+Billing+"|"+Paid;
			System.out.println(HoverDetails);
			assertEquals(data.get("ExpectedHoverDetails"), HoverDetails, "Hover Details");
			SearchclaimtableHeader(data);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Validatetheclaimsscreen method " + e);
			test.log(LogStatus.FAIL, "Error on Validatetheclaimsscreen method " + e);
			Assert.fail();
		}
}
	public void claimDetails(Hashtable<String, String> data){
		try{
			String parentWindow=driver.getWindowHandle();
			List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l')]"));
			if(tableRows.size()>0)
			{
				for(int i=1;i<=tableRows.size();i++)
				{
					if(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")).getText().equals(data.get("ICN")))
					{
						webElementClick(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")),"Claim Number");
						waitSleep(3500);
						for (String windowHandle : driver.getWindowHandles())
						{
							if(!parentWindow.equals(windowHandle)){
								 driver.switchTo().window(windowHandle);
								 System.out.println("Switched to"+windowHandle);
							}
							System.out.println(windowHandle);
							
						}
						
						switchToDefault();
						ClaimlineTableHeader(data);
						ValidatetheclaimDetails(data);
						break;
					}
				}
				driver.close();
				driver.switchTo().window(parentWindow);
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on claimDetails method " + e);
			test.log(LogStatus.FAIL, "Error on claimDetails method " + e);
			Assert.fail();
		}
	}
	public void ValidatetheclaimDetails (Hashtable<String, String> data){
		
		String Rejection="";
		String POS="";
		String TOS="";
		String Procedure="";
		String Diagnosis="";
		try{
			String claim=webElementReadText(Claimid);
			assertEquals(data.get("ICN"), claim, "Claim id");
			List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1$pClaimLines$l')]"));
			if(tableRows.size()>0)
			{
				for(int i=1;i<=tableRows.size();i++)
				{
					if(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1$pClaimLines$l"+i+"')]/td[2]")).getText().equals("R"))
					{
						
						Rejection=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1$pClaimLines$l"+i+"')]/td[5]")), ClaimStatushover);
					    waitSleep(1500);
					    POS=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1$pClaimLines$l"+i+"')]/td[13]")), ClaimStatushover);
					    waitSleep(1500);
					    TOS=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1$pClaimLines$l"+i+"')]/td[14]")), ClaimStatushover);
					    waitSleep(1500);
					    Procedure=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1$pClaimLines$l"+i+"')]/td[15]")), ClaimStatushover); 
					    waitSleep(1500);
					    Diagnosis=getTooltipMessage(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1$pClaimLines$l"+i+"')]/td[19]")), ClaimStatushover); 

					    break;
					}
				}
			}
			
			String HoverDetails=Rejection+"|"+POS+"|"+TOS+"|"+Procedure+"|"+Diagnosis;
			System.out.println(HoverDetails);
			assertEquals(data.get("ExpectedHoverclaim"), HoverDetails, "Hover Details");
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on ValidatetheclaimDetails method " + e);
			test.log(LogStatus.FAIL, "Error on ValidatetheclaimDetails method " + e);
			Assert.fail();
		}

}
	public void ClaimlineTableHeader(Hashtable<String, String> data) throws Exception
	{
		String claimtableHeader="";
		try{
			waitSleep(3000);
			List<WebElement> hr = driver.findElements(By.xpath("//tr[1]/th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//tr[1]/th"));
				System.out.println(hr.size());
			}
			
			String h = "//tr[1]/th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						claimtableHeader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						claimtableHeader = claimtableHeader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(claimtableHeader);
			assertEquals(data.get("ExpectedClaimlineTableHeader"), claimtableHeader, "ClaimlineTableHeader");
          
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on ClaimlineTableHeader method " + e);
			test.log(LogStatus.FAIL, "Error on ClaimlineTableHeader method " + e);
			Assert.fail();
		}
	}
	
	public void Submit()
	{
		
		try{
			wait(2500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(submitBtn, "submit Btn");
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Claimsselectedforadjustment method " + e);
			test.log(LogStatus.FAIL, "Error on Claimsselectedforadjustment method " + e);
			Assert.fail();
		}
	}
	public void SearchclaimtableHeader(Hashtable<String, String> data) throws Exception
	{
		String claimtableHeader="";
		try{
			waitSleep(3000);
			List<WebElement> hr = driver.findElements(By.xpath("//h2[text()='Search results']//following::table[2]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[text()='Search results']//following::table[2]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[text()='Search results']//following::table[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						claimtableHeader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						claimtableHeader = claimtableHeader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(claimtableHeader);
			assertEquals(data.get("ExpectedclaimtableHeader"), claimtableHeader, "SearchclaimtableHeader");
          
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on SearchclaimtableHeader method " + e);
			test.log(LogStatus.FAIL, "Error on SearchclaimtableHeader method " + e);
			Assert.fail();
		}
	}
	public void SelectclaimtableHeader(Hashtable<String, String> data) throws Exception
	{
		String claim="";
		String claimtableHeader="";
		try{
			waitSleep(1000);
			switchToFrame("PegaGadget1Ifr");
			List<WebElement> hr = driver.findElements(By.xpath("//h2[text()='Search results']//following::table[4]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[text()='Search results']//following::table[4]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[text()='Search results']//following::table[4]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						claimtableHeader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						claimtableHeader = claimtableHeader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(claimtableHeader);
			assertEquals(data.get("ExpectedclaimtableHeader"), claimtableHeader, "SelectclaimtableHeader");
			List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l')]"));
			if(tableRows.size()>0)
			{
				for(int i=1;i<=tableRows.size();i++)
				{
					if(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")).getText().equals(data.get("ICN")))
					{
						claim=webElementReadText(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")),"Reviewed");
						waitSleep(3500);


					    break;
					}
				}
			}
			assertEquals(data.get("ICN"), claim, "claim");
          
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on SelectclaimtableHeader method " + e);
			test.log(LogStatus.FAIL, "Error on SelectclaimtableHeader method " + e);
			Assert.fail();
		}
	}
	public void Claimimage(Hashtable<String,String> data)
	{
		
		try{
			wait(2500);
			switchToFrame("PegaGadget1Ifr");
			String parentWindow=driver.getWindowHandle();
			String SCCF=webElementReadText(Sccf);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Claimimage);
			webElementClick(Claimimage, "Claim image");
			for (String windowHandle : driver.getWindowHandles())
			{
				if(!parentWindow.equals(windowHandle)){
					 driver.switchTo().window(windowHandle);
					 System.out.println("Switched to"+windowHandle);
				}
				System.out.println(windowHandle);
				
			}
		
			System.out.println(getCurrentURL());
			switchToDefault();
			
	        driver.close();
	        driver.switchTo().window(parentWindow);
	        assertEquals(data.get("SCCF"), SCCF, "Url");
		   }
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Claimsselectedforadjustment method " + e);
			test.log(LogStatus.FAIL, "Error on Claimsselectedforadjustment method " + e);
			Assert.fail();
		}
	}
	public void TotalValuedetails(Hashtable<String, String> data)
	{
		String TotalValuedetails ="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");

			TotalValuedetails=getrowdata(data.get("TotalValueHeaders"), XpathTotalValue);
			assertEquals(data.get("Expected_TotalValue"), TotalValuedetails, "Check the data masking");
			waitSleep(2500);
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on TotalValuedetails method " + e);
			test.log(LogStatus.FAIL, "Error on TotalValuedetails method " + e);
			Assert.fail();
		}
	}
	public void LineTableHeader(Hashtable<String, String> data) throws Exception
	{
		String claimtableHeader="";
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			List<WebElement> hr = driver.findElements(By.xpath("//h2[text()='Line details']//following::table[2]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[text()='Line details']//following::table[2]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[text()='Line details']//following::table[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						claimtableHeader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						claimtableHeader = claimtableHeader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(claimtableHeader);
			assertEquals(data.get("ExpectedlineTableHeader"), claimtableHeader, "ClaimlineTableHeader");
          
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on ClaimlineTableHeader method " + e);
			test.log(LogStatus.FAIL, "Error on ClaimlineTableHeader method " + e);
			Assert.fail();
		}
	}
	public void Expandedlinedetails(Hashtable<String, String> data)
	{
		String Expandedlinedetails ="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");

			Expandedlinedetails=getrowdata(data.get("ExpandedlinedetailsHeaders"), XpathExpandedlinedetails);
			assertEquals(data.get("Expected_Expandedlinedetails"), Expandedlinedetails, "Expandedlinedetails");
			waitSleep(2500);
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Expandedlinedetails method " + e);
			test.log(LogStatus.FAIL, "Error on Expandedlinedetails method " + e);
			Assert.fail();
		}
	}
	public void Procedurecode(Hashtable<String, String> data)
	{
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			String Procedurecodemodifier="";
			String Proceduremodifier="";
			String ProcedureCode=webElementReadText(Procedurecode);
			System.out.println(ProcedureCode);
            List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pClaim$pClaimLines$l')]"));
			if(tableRows.size()>0)
			{
				for(int i=1;i<=tableRows.size();i++)
				{
					if(driver.findElement(By.xpath("//tr[@id='$PpyWorkPage$pClaim$pClaimLines$l"+i+"']/td[15]")).getText().equals(ProcedureCode))
					{   
						waitSleep(500);
						Proceduremodifier=driver.findElement(By.xpath("//tr[@id='$PpyWorkPage$pClaim$pClaimLines$l1']/td[16]")).getText();
						waitSleep(1500);
						break;
					}
				}
			}
			
			try{
			String[] values = Proceduremodifier.split(",");
			for (int i=0;i<values.length;i++)
			{	
			driver.findElement(By.xpath(String.format("//*[contains(@id,'$PpyWorkPage$pClaim$pSelectedClaimLine$pProcedure$pModifiers$l')]//span[contains(text(),'%s')]", values[i]))).getText();
			test.log(LogStatus.PASS, "Verify Procedure code modifier " );
			}
            System.out.println(values[0]);
            System.out.println(values[1]);
			}
			catch(Exception e1)
			{
				driver.findElement(By.xpath(String.format("//*[contains(@id,'$PpyWorkPage$pClaim$pSelectedClaimLine$pProcedure$pModifiers$l')]//span[contains(text(),'%s')]", Proceduremodifier))).getText();
				test.log(LogStatus.PASS, "Verify Procedure code modifier " );
			}
        
			List<WebElement> hr = driver.findElements(By.xpath("//h2[text()='Procedure & diagnosis']//following::table[1]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[text()='Procedure & diagnosis']//following::table[1]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[text()='Procedure & diagnosis']//following::table[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						Procedurecodemodifier = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						Procedurecodemodifier = Procedurecodemodifier + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(Procedurecodemodifier);
			assertEquals(data.get("ExpectedProcedurecodemodifier"), Procedurecodemodifier, "Procedurecodemodifier");
          
		}
		
		   
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Expandedlinedetails method " + e);
			test.log(LogStatus.FAIL, "Error on Expandedlinedetails method " + e);
			Assert.fail();
		}
	}
	public void Healthplancodedetails(String HealthplancodedetailsHeaders,String Expected_Healthplancodedetails)
	{
		String Healthplancodedetails ="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Healthplancodedetail);
            webElementClick(Healthplancodedetail, "Healthplancodedetails");
            waitSleep(500);
			Healthplancodedetails=getrowdata(HealthplancodedetailsHeaders, XpathHealthplancodedetails);
			assertEquals(Expected_Healthplancodedetails, Healthplancodedetails, "Healthplancodedetails");
			waitSleep(2500);
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Healthplancodedetails method " + e);
			test.log(LogStatus.FAIL, "Error on Healthplancodedetails method " + e);
			Assert.fail();
		}
	}
	public void Reclasscode(Hashtable<String, String> data)
	{
		String Reclasscode="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			
			List<WebElement> hr = driver.findElements(By.xpath("//h2[text()='Reclass code']//following::table[1]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[text()='Reclass code']//following::table[1]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[text()='Reclass code']//following::table[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						Reclasscode = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						Reclasscode = Reclasscode + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(Reclasscode);
			assertEquals(data.get("ExpectedReclasscode"), Reclasscode, "Reclass code");
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Healthplancodedetails method " + e);
			test.log(LogStatus.FAIL, "Error on Healthplancodedetails method " + e);
			Assert.fail();
		}
	}
	public void Revenue(Hashtable<String, String> data)
	{
		String Revenuedetails ="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
          
            waitSleep(500);
            Revenuedetails=getrowdata(data.get("RevenueHeaders"), XpathRevenue);
			assertEquals(data.get("Expected_Revenue"), Revenuedetails, "Revenuedetails");
			waitSleep(2500);
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Healthplancodedetails method " + e);
			test.log(LogStatus.FAIL, "Error on Healthplancodedetails method " + e);
			Assert.fail();
		}
	}
	public void Healthplancodedetails1(String HealthplancodedetailsHeaders1,String Expected_Healthplancodedetails)
	{
		String Healthplancodedetails ="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Healthplancodedetail1);
            webElementClick(Healthplancodedetail1, "Healthplancodedetails");
            waitSleep(500);
			Healthplancodedetails=getrowdata(HealthplancodedetailsHeaders1, XpathHealthplancodedetails1);
			assertEquals(Expected_Healthplancodedetails, Healthplancodedetails, "Healthplancodedetails");
			waitSleep(2500);
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Healthplancodedetails method " + e);
			test.log(LogStatus.FAIL, "Error on Healthplancodedetails method " + e);
			Assert.fail();
		}
	}
	public void Diagnosis(Hashtable<String, String> data)
	{
		String Diagnosis="";
		String Diagnosisdetails="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", diagnosis);
			webElementClick(diagnosis, "Diagnosis");
			System.out.println(webElementReadText(Primarydiagnosis));
			waitSleep(5000);
			List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Additional diagnosis codes')]//following::table[2]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("(//h2[contains(text(),'Additional diagnosis codes')]//following::table[@id='bodyTbl_right']/tbody/tr[1])[1]//th"));
				System.out.println(hr.size());
			}
			
			String h = "(//h2[contains(text(),'Additional diagnosis codes')]//following::table[@id='bodyTbl_right']/tbody/tr[1])[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						Diagnosis = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						Diagnosis = Diagnosis + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(Diagnosis);
			assertEquals(data.get("ExpectedDiagnosis"), Diagnosis, "Diagnosis");
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pClaim$pSelectedClaimLine$pAdditionalDiagnosisCodes$l')]"));
			//System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pClaim$pSelectedClaimLine$pAdditionalDiagnosisCodes$l')]"));
				System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$pClaim$pSelectedClaimLine$pAdditionalDiagnosisCodes$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String Diagnosises = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						Diagnosises = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						Diagnosises = Diagnosises + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				Diagnosisdetails = Diagnosisdetails + "," + Diagnosises;
			}
			waitSleep(1000);
			Diagnosisdetails = Diagnosisdetails.substring(1, Diagnosisdetails.length());
			System.out.println(Diagnosisdetails);
			// Commented for issue found on 1/19/2021 
			assertEquals(data.get("Expected_Diagnosisdetails"), Diagnosisdetails, "Member Search Results");

		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Healthplancodedetails method " + e);
			test.log(LogStatus.FAIL, "Error on Healthplancodedetails method " + e);
			Assert.fail();
		}
	}
	public void Healthplancodedetails2(String HealthplancodedetailsHeaders2,String Expected_Healthplancodedetails2)
	{
		String Healthplancodedetails ="";
		try{
			
			waitSleep(2000);
			/*switchToFrame("PegaGadget1Ifr");
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Healthplancodedetail1);
			webElementClick(Healthplancodedetail1, "Healthplancodedetails");
            waitSleep(1500);*/
            Healthplancodedetails=getrowdata(HealthplancodedetailsHeaders2, XpathHealthplancodedetails2);
			assertEquals(Expected_Healthplancodedetails2, Healthplancodedetails, "Healthplancodedetails");
			waitSleep(2500);
			
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Healthplancodedetails method " + e);
			test.log(LogStatus.FAIL, "Error on Healthplancodedetails method " + e);
			Assert.fail();
		}
	}
	public void Processinginformation(Hashtable<String, String> data)
	{
		String Healthplanclaimsdetails ="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
            String Managedcare=webElementReadText(managedcare);
            getrowdata(data.get("Referencenumber"), XpathManagedcare);
            waitSleep(500);
            webElementClick(Healthplanclaims, "Health plan claims");
            Healthplanclaimsdetails=getrowdata(data.get("HealthplanclaimsHeaders"), XpathHealthplanclaims)+"|"+Managedcare;
            assertEquals(data.get("ExpectedHealthplanclaimsHeaders"), Healthplanclaimsdetails, "Healthplanclaimsdetails");
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Processinginformation method " + e);
			test.log(LogStatus.FAIL, "Error on Processinginformation method " + e);
			Assert.fail();
		}
	}
	public void Benefits(Hashtable<String, String> data)
	{
		String Benefitsdetails ="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
            
			Benefitsdetails=getrowdata(data.get("BenefitsHeaders"), XpathBenefitsdetails);
            assertEquals(data.get("ExpectedBenefitsdetails"), Benefitsdetails, "Benefitsdetails");
		   }
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Benefits method " + e);
			test.log(LogStatus.FAIL, "Error on Benefits method " + e);
			Assert.fail();
		}
	}
	public void Pricinginformation(Hashtable<String, String> data)
	{
		String Pricinginformationdetails ="";
		String Pricinginformation="";
		String Pricinginformationdetail ="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
            
			Pricinginformationdetails=getrowdata(data.get("PricinginformationHeaders"), XpathPricinginformation);
            assertEquals(data.get("ExpectedPricinginformation"), Pricinginformationdetails, "Pricinginformation");
           
            List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Pricing information')]//following::table[1]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[contains(text(),'Pricing information')]//following::table[1]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[contains(text(),'Pricing information')]//following::table[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						Pricinginformation = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						Pricinginformation = Pricinginformation + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println("ExpectedPricinginformationHeader"+Pricinginformation);
			assertEquals(data.get("ExpectedPricinginformationHeader"), Pricinginformation, "Pricinginformation");
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pClaim$pSelectedClaimLine$ppaymentLinePlanSpecifics$l')]"));
			//System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pClaim$pSelectedClaimLine$ppaymentLinePlanSpecifics$l')]"));
				System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$pClaim$pSelectedClaimLine$ppaymentLinePlanSpecifics$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String Pricinginformations = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						Pricinginformations = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						Pricinginformations = Pricinginformations + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				Pricinginformationdetail = Pricinginformationdetail + "," + Pricinginformations;
			}
			waitSleep(1000);
			Pricinginformationdetail = Pricinginformationdetail.substring(1, Pricinginformationdetail.length());
			System.out.println("Expected_Pricinginformationdetails"+Pricinginformationdetails);
			// Commented for issue found on 1/19/2021 
			assertEquals(data.get("Expected_Pricinginformationdetails"), Pricinginformationdetail, "Pricinginformationm details");

		   }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Pricinginformation method " + e);
			test.log(LogStatus.FAIL, "Error on Pricinginformation method " + e);
			Assert.fail();
		}
	}
	public void Processinginformation_adjust(Hashtable<String, String> data)
	{
		String Processinginformation ="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			Processinginformation=getrowdata(data.get("ProcessinginformationHeaders"), XpathProcessinginformation);
            assertEquals(data.get("ExpectedPricinginformationadjust"), Processinginformation, "Processinginformation");
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Benefits method " + e);
			test.log(LogStatus.FAIL, "Error on Benefits method " + e);
			Assert.fail();
		}
	}
	public void Adjustmentinformation(Hashtable<String, String> data) throws Exception
	{
		String Adjustmentinformation="";
		String Adjustmentheader="";
		try{
			waitSleep(1000);
			switchToFrame("PegaGadget1Ifr");
			List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Adjustment information')]//following::table[2]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[contains(text(),'Adjustment information')]//following::table[2]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[contains(text(),'Adjustment information')]//following::table[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						Adjustmentheader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						Adjustmentheader = Adjustmentheader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(Adjustmentheader);
			assertEquals(data.get("ExpectedAdjustmentheader"), Adjustmentheader, "Adjustmentheader");
			List<WebElement> ele=driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pClaim$pAdjustment$l')]"));
			
			
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pClaim$pAdjustment$l')]"));
				System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$pClaim$pAdjustment$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String Pricinginformations = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						Pricinginformations = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						Pricinginformations = Pricinginformations + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				Adjustmentinformation = Adjustmentinformation + "," + Pricinginformations;
			}
			waitSleep(1000);
			Adjustmentinformation = Adjustmentinformation.substring(1, Adjustmentinformation.length());
			System.out.println("Expected_Pricinginformationdetails"+Adjustmentinformation);
			// Commented for issue found on 1/19/2021 
			assertEquals(data.get("Expected_Adjustmentinformation"), Adjustmentinformation, "Pricinginformationm details");

		   
          
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on SelectclaimtableHeader method " + e);
			test.log(LogStatus.FAIL, "Error on SelectclaimtableHeader method " + e);
			Assert.fail();
		}
	}
	public void Providerdetails(Hashtable<String, String> data)
	{
		String Performingprovider ="";
		String Healthplanproviderdetails="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			webElementClick(Providerdetails, "Providerdetails");
			
			Performingprovider=getrowdata(data.get("PerformingproviderHeaders"), XpathPerformingprovider);
			System.out.println(Performingprovider);
            assertEquals(data.get("ExpectedPerformingprovider"), Performingprovider, "Performingprovider");
			webElementClick(Healthplan, "Health plan provider details");
			Healthplanproviderdetails=getrowdata(data.get("HealthplanproviderHeaders"), XpathHealthplanprovider);
			System.out.println(Healthplanproviderdetails);
		assertEquals(data.get("ExpectedHealthplanproviderdetails"), Healthplanproviderdetails, "Healthplanproviderdetails");
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Benefits method " + e);
			test.log(LogStatus.FAIL, "Error on Benefits method " + e);
			Assert.fail();
		}
	}
	public void Facilitydetails(Hashtable<String, String> data)
	{
		String Facilitydetails ="";
		String Healthplanfacilitydetail="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			
			Facilitydetails=getrowdata(data.get("FacilitydetailsHeaders"), XpathFacilitydetails);
			System.out.println(Facilitydetails);
            assertEquals(data.get("ExpectedFacilitydetails"), Facilitydetails, "Facilitydetails");
			webElementClick(Healthplanfacilitydetails, "Health plan facility details");
			Healthplanfacilitydetail=getrowdata(data.get("HealthplanproviderHeaders"), XpathHealthplanfacility);
			System.out.println(Healthplanfacilitydetail);
		assertEquals(data.get("ExpectedHealthplanfacilitydetails"), Healthplanfacilitydetail, "Healthplanfacilitydetails");
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Facilitydetails method " + e);
			test.log(LogStatus.FAIL, "Error on Facilitydetails method " + e);
			Assert.fail();
		}
	}
	public void Referringproviderdetails(Hashtable<String, String> data)
	{
		String Referringprovider ="";
		String Healthplanproviderdetails="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			webElementClick(Providerdetails, "Providerdetails");
			
			Referringprovider=getrowdata(data.get("PerformingproviderHeaders"), XpathReferringprovider);
			System.out.println(Referringprovider);
            assertEquals(data.get("ExpectedReferringprovider"), Referringprovider, "Referringprovider");
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Healthplan1);
			//webElementClick(Healthplan1, "Health plan provider details");
			Healthplanproviderdetails=getrowdata(data.get("HealthplanproviderHeaders"), XpathHealthplanprovider1);
			System.out.println(Healthplanproviderdetails);
		assertEquals(data.get("ExpectedHealthplanproviderdetails1"), Healthplanproviderdetails, "Healthplanproviderdetails");
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Benefits method " + e);
			test.log(LogStatus.FAIL, "Error on Benefits method " + e);
			Assert.fail();
		}
	}
	public void ClaimEOBremittance(Hashtable<String, String> data)
	{
		String ClaimEOBremittancedetails="";
		String ClaimEOBremittancedetails1="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			webElementClick(ClaimEOBremittance, "Claim EOB remittance");
			ClaimEOBremittancedetails=getrowdata(data.get("ClaimEOBremittanceHeaders"), XpathClaimEOBremittance);
			ClaimEOBremittancedetails1=getrowdata(data.get("ClaimEOBremittanceHeaders1"), XpathClaimEOBremittance1);
			System.out.println(ClaimEOBremittancedetails+"|"+ClaimEOBremittancedetails1);
            assertEquals(data.get("ExpectedClaimEOBremittancedetails"), ClaimEOBremittancedetails+"|"+ClaimEOBremittancedetails1, "Referringprovider");
			
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Benefits method " + e);
			test.log(LogStatus.FAIL, "Error on Benefits method " + e);
			Assert.fail();
		}
	}
	public void Claimdollars(Hashtable<String, String> data)
	{
		String claimtableHeader="";
		String Claimdetails="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			webElementClick(Claimdollars, "Claim dollars");
			List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Check details')]//following::table[2]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[contains(text(),'Check details')]//following::table[2]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[contains(text(),'Check details')]//following::table[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						claimtableHeader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						claimtableHeader = claimtableHeader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
				claimtableHeader = claimtableHeader.substring(1, claimtableHeader.length());
			System.out.println(claimtableHeader);
			assertEquals(data.get("ExpectedClaimdetailsHeader"), claimtableHeader, "ClaimdetailsHeader");
List<WebElement> ele=driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pClaim$pPayment$pPaymentDetails$l')]"));
			
			
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pClaim$pPayment$pPaymentDetails$l')]"));
				System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$pClaim$pPayment$pPaymentDetails$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String claiminformations = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						claiminformations = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						claiminformations = claiminformations + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				Claimdetails = Claimdetails + "," + claiminformations;
			}
			waitSleep(1000);
			Claimdetails = Claimdetails.substring(1, Claimdetails.length());
			System.out.println("Expected_Claimdetails::"+Claimdetails);
			// Commented for issue found on 1/19/2021 
			assertEquals(data.get("Expected_Claimaccountdetails"), Claimdetails, "Claim details");


           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Benefits method " + e);
			test.log(LogStatus.FAIL, "Error on Benefits method " + e);
			Assert.fail();
		}
	}
	public void Bankdetail(Hashtable<String, String> data)
	{
		String Accountdetails="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			webElementClick(bankdetail, "Bankdetail");
			Accountdetails=getrowdata(data.get("bankdetailHeaders"), Xpathbankdetail);
			System.out.println(Accountdetails);
            assertEquals(data.get("ExpectedAccountdetails"), Accountdetails, "Account details");
			
			
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Bankdetail method " + e);
			test.log(LogStatus.FAIL, "Error on Bankdetail method " + e);
			Assert.fail();
		}
	}
	public void Paymentoffsetdetails(Hashtable<String, String> data)
	{
		String Paymentoffsetdetails="";
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			//webElementClick(Paymentoff, "Paymentoffsetdetails");
			Paymentoffsetdetails=getrowdata(data.get("PaymentoffHeaders"), XpathPaymentoff);
			System.out.println(Paymentoffsetdetails);
            assertEquals(data.get("ExpectedPaymentoffdetails"), Paymentoffsetdetails, "Paymentoffsetdetails");
			
			
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Paymentoffsetdetails method " + e);
			test.log(LogStatus.FAIL, "Error on Paymentoffsetdetails method " + e);
			Assert.fail();
		}
	}
	public void Otherinsurancedollars(Hashtable<String, String> data)
	{
		String OtherinsuranceHearder="";
		String Totalsbylist="";
		String Otherinsurance="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			
			Totalsbylist=getrowdata(data.get("TotalsbylistHeaders"), XpathTotalsbylist);
			System.out.println(Totalsbylist);
            assertEquals(data.get("ExpectedTotalsbylist"), Totalsbylist, "Totalsbylist");
			
            List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Other insurance dollars')]//following::table[2]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[contains(text(),'Other insurance dollars')]//following::table[2]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[contains(text(),'Other insurance dollars')]//following::table[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						OtherinsuranceHearder = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						OtherinsuranceHearder = OtherinsuranceHearder + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
				//OtherinsuranceHearder = OtherinsuranceHearder.substring(1, OtherinsuranceHearder.length());
			System.out.println(OtherinsuranceHearder);
			assertEquals(data.get("ExpectedOtherinsuranceHearder"), OtherinsuranceHearder, "ClaimdetailsHeader");
List<WebElement> ele=driver.findElements(By.xpath("//h2[contains(text(),'Other insurance dollars')]//following::table[2]//tr[contains(@id,'$PpyWorkPage$pClaim$pClaimLines$l')]"));
			
			
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//h2[contains(text(),'Other insurance dollars')]//following::table[2]//tr[contains(@id,'$PpyWorkPage$pClaim$pClaimLines$l')]"));
				System.out.println(ele.size());
			}
			
			String s = "//h2[contains(text(),'Other insurance dollars')]//following::table[2]//tr[contains(@id,'$PpyWorkPage$pClaim$pClaimLines$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String claiminformations = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						claiminformations = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						claiminformations = claiminformations + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				Otherinsurance = Otherinsurance + "," + claiminformations;
			}
			waitSleep(1000);
			Otherinsurance = Otherinsurance.substring(1, Otherinsurance.length());
			System.out.println("Expected_Otherinsurance::"+Otherinsurance);
			// Commented for issue found on 1/19/2021 
			assertEquals(data.get("Expected_Otherinsurance"), Otherinsurance, "Claim details");


			
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Otherinsurancedollars method " + e);
			test.log(LogStatus.FAIL, "Error on Otherinsurancedollars method " + e);
			Assert.fail();
		}
	}

	public void Medicaredollars(Hashtable<String, String> data)
	{
		String MedicaredollarsHearder="";
		String Totalsbylist="";
		String Medicaredollars="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			
			Totalsbylist=getrowdata(data.get("TotalsbylistMedicareHeaders"), XpathTotalsbylist1);
			System.out.println(Totalsbylist);
            assertEquals(data.get("ExpectedTotalsbylist_Medicaredollars"), Totalsbylist, "Totalsbylist");
			
            List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Medicare dollars')]//following::table[2]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[contains(text(),'Medicare dollars')]//following::table[2]//th"));
				System.out.println(hr.size());
			}
			
			String h = "//h2[contains(text(),'Medicare dollars')]//following::table[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						MedicaredollarsHearder = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						MedicaredollarsHearder = MedicaredollarsHearder + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
				//OtherinsuranceHearder = OtherinsuranceHearder.substring(1, OtherinsuranceHearder.length());
			System.out.println(MedicaredollarsHearder);
			assertEquals(data.get("ExpectedMedicaredollarsHearder"), MedicaredollarsHearder, "MedicaredollarsHearder");
List<WebElement> ele=driver.findElements(By.xpath("//h2[contains(text(),'Medicare dollars')]//following::table[2]//tr[contains(@id,'$PpyWorkPage$pClaim$pClaimLines$l')]"));
			
			
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//h2[contains(text(),'Medicare dollars')]//following::table[2]//tr[contains(@id,'$PpyWorkPage$pClaim$pClaimLines$l')]"));
				System.out.println(ele.size());
			}
			
			String s = "//h2[contains(text(),'Medicare dollars')]//following::table[2]//tr[contains(@id,'$PpyWorkPage$pClaim$pClaimLines$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String claiminformations = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						claiminformations = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						claiminformations = claiminformations + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				Medicaredollars = Medicaredollars + "," + claiminformations;
			}
			waitSleep(1000);
			Medicaredollars = Medicaredollars.substring(1, Medicaredollars.length());
			System.out.println("Expected_Medicaredollars::"+Medicaredollars);
			// Commented for issue found on 1/19/2021 
			assertEquals(data.get("Expected_Medicaredollars"), Medicaredollars, "Medicaredollars");


			
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Paymentoffsetdetails method " + e);
			test.log(LogStatus.FAIL, "Error on Paymentoffsetdetails method " + e);
			Assert.fail();
		}
	}
	public void review()
	{
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(ReviewButton, "Review Button");
			waitSleep(3000);
			webElementClick(Proceedwithoutadjustments, "Proceed without adjustments");
			
			
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on review method " + e);
			test.log(LogStatus.FAIL, "Error on review method " + e);
			Assert.fail();
		}
	}
	
	public void DetermineNextAction(Hashtable<String, String> data)
	{
		
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			if(data.get("DetermineNextAction").equals("Yes"))
			{
			webElementClick(Yes, "Cilck on yes");
			}else{
			webElementClick(No, "Cilck on No");
			}
			webElementClick(Submit, "Cilck on Submit");
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on DetermineNextAction method " + e);
			test.log(LogStatus.FAIL, "Error on DetermineNextAction method " + e);
			Assert.fail();
		}
	}
	public void Search_results(Hashtable<String, String> data)
	{
		String error="";
		//String Patientname="";
		try{
			if(!driver.findElement(By.xpath("(//h2[text()='Search results']//following::table[2]//td)[3]")).getText().equals("No items"))			
			{
				List<WebElement> ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l')]"));
				ele.size();
//				if(null != data.get("RelationShip") && !data.get("RelationShip").isEmpty())
//				{
//					Patientname=getTooltipMessage(driver.findElement(By.xpath("//*[@id='$PHCMemberClaims$ppxResults$l1']/td[6]")), Patienthover);
//				    waitSleep(1500);
//				    System.out.println(Patientname);
//				}
				System.out.println(ele.size());
				test.log(LogStatus.PASS, "search results is displayed  " );
			}
			else{
				error=webElementReadText(Noclaimsfound);
				System.out.println(error);
				assertEquals(data.get("Expected_Noclaimsfound"), error, "Noclaimsfound");
				test.log(LogStatus.PASS, "No search results is displayed  " );
			}
			
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on searchClaims_Error method " + e);
			test.log(LogStatus.FAIL, "Error on searchClaims_Error method " + e);
			Assert.fail();
		}
	}
	public void searchClaims_Error(Hashtable<String, String> data)
	{
		String error="";
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			selectDropdownValueByVisibleText(dateSearchOptions, "Date range", "dateSearchOptions");
			waitSleep(1500);
			if(null != data.get("SearchOptions") && !data.get("SearchOptions").isEmpty())
			{
				selectDropdownValueByVisibleText(dateSearchOptions, data.get("SearchOptions"), "dateSearchOptions");
			}
			waitSleep(500);
			firstDos.clear();
			waitSleep(500);
			if(!data.get("SearchOptions").equals("Date of service")&&!data.get("SearchOptions").equals("Date of service"))
			{
			lastDos.clear();
			}
		    webElementClick(SearchBtn, "SearchBtn");
			waitSleep(500);
			error=webElementReadText(FirstDoserror);
			assertEquals(data.get("Expected_error"), error, "Medicaredollars");
			String Lasterror=webElementReadText(lastDoserror);
			assertEquals(data.get("Expected_error"), Lasterror, "Medicaredollars");
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on searchClaims_Error method " + e);
			test.log(LogStatus.FAIL, "Error on searchClaims_Error method " + e);
			Assert.fail();
		}
	}
}
