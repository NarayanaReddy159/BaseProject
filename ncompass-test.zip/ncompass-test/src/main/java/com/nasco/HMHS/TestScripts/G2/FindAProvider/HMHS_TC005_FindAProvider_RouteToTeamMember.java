package com.nasco.HMHS.TestScripts.G2.FindAProvider;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.utilities.DataProviders;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC005_FindAProvider_RouteToTeamMember extends BaseTest{
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC005_FindAProvider_RouteToTeamMember(Hashtable<String, String> data) throws Exception {
		
		RouteToTeamMember("HMHS_AUTC005_FindAProvider_RouteToTeamMember", data);
	}
	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_AUTC005_FindAProvider_RouteToTeamMember Completed.");
		log.debug("HMHS_AUTC005_FindAProvider_RouteToTeamMember Completed.");
		quit();
	}

}
