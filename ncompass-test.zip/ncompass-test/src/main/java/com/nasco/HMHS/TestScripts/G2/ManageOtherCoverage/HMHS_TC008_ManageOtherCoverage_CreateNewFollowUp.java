package com.nasco.HMHS.TestScripts.G2.ManageOtherCoverage;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.utilities.DataProviders;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC008_ManageOtherCoverage_CreateNewFollowUp extends BaseTest{
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC008_ManageOtherCoverage_CreateNewFollowUp(Hashtable<String, String> data) throws Exception {
		
		createNewFollowup("HMHS_AUTC008_ManageOtherCoverage_CreateNewFollowUp", data);
		
	}
	
	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_AUTC008_ManageOtherCoverage_CreateNewFollowUp Completed.");
		log.debug("HMHS_AUTC008_ManageOtherCoverage_CreateNewFollowUp Completed.");
		quit();
	}

}
