package com.nasco.HMHS.TestScripts.G2.Report;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.ReportPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC003_Report_Vaildate_ResearchInvalidWorkObjects extends BaseTest{
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC003_Report_Vaildate_ResearchInvalidWorkObjects(Hashtable<String, String> data) throws Exception {
		
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC003_Report_Vaildate_ResearchInvalidWorkObjects");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC003_Report_Vaildate_ResearchInvalidWorkObjects - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		log.debug("HMHS_TC002_Report_Vaildate_SLABreakdownofOpenServiceRequests -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username2")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		ReportPage Report = homepage.openReportPage();
		Report.MyReport(data);
		log.debug("Navigated to the Home-My Report Section");
		test.log(LogStatus.INFO, "Navigated to the Home-My Report Section");
		Report.ReportName(data);
		log.debug("Navigated to the Home-My Report SLABreakdownofOpenServiceRequests Section");
		test.log(LogStatus.INFO, "Navigated to the Home-My Report SLABreakdownofOpenServiceRequests Section");
		Report.VaildationSLABreakdownofOpenServiceRequests(data);
		log.debug("Navigated to the Home-My Report VaildationSLABreakdownofOpenServiceRequests Section");
		test.log(LogStatus.INFO, "Navigated to the Home-My Report VaildationSLABreakdownofOpenServiceRequests Section");
		
	}
	
	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_AUTC003_Report_Vaildate_ResearchInvalidWorkObjects Completed.");
		log.debug("HMHS_AUTC003_Report_Vaildate_ResearchInvalidWorkObjects Completed.");
		quit();
	}

}
