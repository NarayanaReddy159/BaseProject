package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;

@SuppressWarnings({"rawtypes","unchecked"})
public class HomePage extends BasePage {

	String excepionMessage = "";

	// web elements
	// New interaction
	@FindBy(linkText = "New")
	public WebElement newLinkText;

	@FindBy(xpath = "//span[contains(text(),'Live Interaction - Member')]")
	public WebElement liveInteraction;

	@FindBy(xpath = "//span[contains(text(),'Research Interaction - Member')]")
	public WebElement ResearchInteraction;
	
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;

	@FindBy(id = "PegaGadget1Ifr")
	public WebElement frame1;
	@FindBy(id = "ModalButtonCancel")
	public WebElement Cancel;
	
	@FindBy(xpath = "//a[contains(text(),'New message')]")
	public WebElement Newmessage;
	
	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;

	@FindBy(xpath = "//h3[contains(text(),'Team')]")
	public WebElement Team;
	
	@FindBy(xpath = "//span[contains(text(),'Manager Tools')]")
	public WebElement ManagerTools;
	
	@FindBy(xpath = "//button[contains(text(),'Bulk actions')]")
	public WebElement Bulkactions;
//	@FindBy(xpath = "//span[@id='close']")
//	public WebElement Close;
	@FindBy(xpath = "//h2[contains(text(),'Search work ID')]")
	public WebElement SearchworkID;
	@FindBy(xpath = "//h2[contains(text(),'Cleanup Utility')]")
	public WebElement CleanupUtility;	
	
	@FindBy(xpath = "//span[contains(text(),'Home')]")
	public WebElement Home;
	
	@FindBy(xpath = "//span[contains(text(),'Dashboard')]")
	public WebElement Dashboard;
	
	public MemberSearchPage clickOnHMHSLiveInteractionMember() {
		try {
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(newLinkText));
			wait(5000);
			jsClick(newLinkText, "New Live interaction");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(liveInteraction));
			wait(1000);
			jsClick(liveInteraction, "New Live interaction");
			waitForPageToLoad(ExpectedConditions.visibilityOf(frame1));
		} catch (Exception e) {
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnLiveInteractionMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnLiveInteractionMember method " + e);
			Assert.fail();
		}
		return (MemberSearchPage) openPage(MemberSearchPage.class);
	}
	
	public MemberSearchPage clickOnHMHSResearchInteractionMember() {
		try {
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(newLinkText));
			wait(5000);
			jsClick(newLinkText, "New interaction");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(ResearchInteraction));
			wait(1000);
			jsClick(ResearchInteraction, "New Research interaction");
			waitForPageToLoad(ExpectedConditions.visibilityOf(frame1));
		} catch (Exception e) {
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnResearchInteractionMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnResearchInteractionMember method " + e);
			Assert.fail();
		}
		return (MemberSearchPage) openPage(MemberSearchPage.class);
	}
	public MemberSearchPage clickOnHMHSResearchInteractionMember1() {
		try {
			waitSleep(3000);
			switchToDefault();
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(newLinkText));
			wait(5000);
			jsClick(newLinkText, "New interaction");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(ResearchInteraction));
			wait(1000);
			jsClick(ResearchInteraction, "New Research interaction");
			waitForPageToLoad(ExpectedConditions.visibilityOf(frame1));
		} catch (Exception e) {
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnResearchInteractionMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnResearchInteractionMember method " + e);
			Assert.fail();
		}
		return (MemberSearchPage) openPage(MemberSearchPage.class);
	}
	
	public RecentWorkPage openrecentWork() {

		return (RecentWorkPage) openPage(RecentWorkPage.class);
	}
	
	public ViewBenefitsPage ViewBenefitsPriorIntent() {

		return (ViewBenefitsPage) openPage(ViewBenefitsPage.class);
	}

	
	public HomePage open() {

		return (HomePage) openPage(HomePage.class);
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(frame);
	}

	public void waittoloadHomePage() {
		waitForFrameTobeVisible("PegaGadget0Ifr");

	}

	
	public CreateFollowUpPage CreateFollowUpIntent() {
		return (CreateFollowUpPage) openPage(CreateFollowUpPage.class);
	}

	public RespondToCustomerPage RespondToCustomerIntentMail() {
		return (RespondToCustomerPage) openPage(RespondToCustomerPage.class);
	}
	
	public RequestIDCardPage RequestIDCardIntent() {
		return (RequestIDCardPage) openPage(RequestIDCardPage.class);
	}

	public ResearchInteractionPage ResearchInteraction() {
		return (ResearchInteractionPage) openPage(ResearchInteractionPage.class);
	}
	public RespondToCustomerPage RespondToCustomerIntentFax() {
		return (RespondToCustomerPage) openPage(RespondToCustomerPage.class);
	}

	public RespondToCustomerPage RespondToCustomerIntentMessageCenter() {
		return (RespondToCustomerPage) openPage(RespondToCustomerPage.class);
	}

	public RespondToCustomerPage RespondToCustomerIntentCallback() {
		return (RespondToCustomerPage) openPage(RespondToCustomerPage.class);
	}
	
	public ViewTotalPage VeiwTotalPage() {

		return (ViewTotalPage) openPage(ViewTotalPage.class);
	}
	public Member360Page Member360Page() {

		return (Member360Page) openPage(Member360Page.class);
	}


	public WorklistPage openrecentWorklist() {
		return (WorklistPage) openPage(WorklistPage.class);
	}

	public WorkbasketPage openrecentWorkbasket() {
		return (WorkbasketPage) openPage(WorkbasketPage.class);
	}
	
	public OtherActions openOtherActions() {
		return (OtherActions) openPage(OtherActions.class);
	}
	public WebsiteSupportPage openWebsiteSupportPage() {
		return (WebsiteSupportPage) openPage(WebsiteSupportPage.class);
	}
	public ReportPage openReportPage() {
		return (ReportPage) openPage(ReportPage.class);
	}
	public InteractionManagerPage InteractionManagerPage() {
		return (InteractionManagerPage) openPage(InteractionManagerPage.class);
	}
	 public void Dashboard() throws Exception
		{
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				webElementClick(Dashboard, "Dashboard");
				waitSleep(1500);
				webElementClick(Newmessage, "New message");
				waitSleep(1500);
				webElementClick(Cancel, "Cancel");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on MyReport method " + e);
				test.log(LogStatus.FAIL, "Error on MyReport method " + e);
				Assert.fail();
			}
		}
	 public void movetoTeamPage() throws Exception
		{
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				webElementClick(myWorkIcon, "My Work");
				waitSleep(2000);
				webElementClick(Team, "Team tab");
				waitSleep(2000);
				 
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on Worklist method " + e);
				test.log(LogStatus.FAIL, "Error on Worklist method " + e);
				Assert.fail();
			}
		}	
	 public void movetoManagerTools(Hashtable<String, String> data) throws Exception
		{
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				webElementClick(ManagerTools, "Manager Tools");
				waitSleep(2000);
				String FieldID=webElementReadText(Bulkactions)+"::"+webElementReadText(SearchworkID)+"::"+webElementReadText(CleanupUtility);
				assertEquals(data.get("ExpectedField"),FieldID, "Field ID");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on Worklist method " + e);
				test.log(LogStatus.FAIL, "Error on Worklist method " + e);
				Assert.fail();
			}
		}	
	 public void VerifyInteraction(Hashtable<String, String> data) {
			try {
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(newLinkText));
				wait(5000);
				jsClick(newLinkText, "New Live interaction");
				wait(1000);
				String InteractionOptions= webElementReadText(liveInteraction)+"::"+webElementReadText(ResearchInteraction);
				assertEquals(data.get("ExpectedInteractionOptions"), InteractionOptions, "Interaction Options");
				waitSleep(1500);
				webElementClick(Home, "Home");
				waitSleep(3000);
			} catch (Exception e) {
				excepionMessage = Arrays.toString(e.getStackTrace());
				BaseTest.log.error("Error on clickOnLiveInteractionMember method " + excepionMessage);
				test.log(LogStatus.FAIL, "Error on clickOnLiveInteractionMember method " + e);
				Assert.fail();
			}
	 }
}
