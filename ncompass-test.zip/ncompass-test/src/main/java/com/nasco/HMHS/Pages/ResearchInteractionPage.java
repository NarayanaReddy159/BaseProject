package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings({"rawtypes","unchecked"})
public class ResearchInteractionPage extends BasePage {

	String excepionMessage = "";
	String taskNameXpath="//a[contains(text(),'%s')]";
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Add task')]")
	public WebElement addTask;
	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Filter')]")
	public WebElement filter;
	@FindBy(xpath = "//div[2]/div/div/div/div[2]/span/button/i")
	public WebElement HMHSOtherActions;
	@FindBy(xpath = "//span[contains(text(),'Exit Interaction')]")
	public WebElement HMHSExitInteraction;
	@FindBy(how = How.XPATH, using  = "//*[@id='e942eb82']")
	public WebElement comment;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		waitSleep(1500);
		switchToFrame("PegaGadget1Ifr");
		try{
			ExpectedConditions.visibilityOf(Submit);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail();
		}
		return ExpectedConditions.visibilityOf(Submit);
	}
	
	//TO Add task for Interaction Manager 
	public void addTask(String intentName) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick( add, "add Task");
			webElementClick( driver.findElement(By.xpath(String.format(taskNameXpath, intentName))),"task Name");
			webElementClick( addTask, "add Task");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTask method " + e);
			test.log(LogStatus.FAIL, "Error on addTask method " + e);
			Assert.fail();
		}
	}
	
	// HMHS Exit Interaction perform
	public void ExitInteraction(Hashtable<String, String> data) {
		try {
			waitSleep(4500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(HMHSOtherActions, "Other Actions");
			test.log(LogStatus.INFO, "Click on Other actions.");
			waitSleep(1500);
			webElementClick(HMHSExitInteraction, "Exit Interaction");
			test.log(LogStatus.INFO, "Click on the Exit Interaction screen.");
			webElementSendText(comment, data.get("Comments"), "Medicare ID");
			test.log(LogStatus.INFO, "Enter the exit interaction comments.");
			webElementClick(Submit, "Submit"); 	
		} catch (Exception e) {
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on click Exit Interaction method" + excepionMessage);
			test.log(LogStatus.FAIL, "Error on click Exit Interaction method " + e);
			Assert.fail();

		}
	}
	
	public ResearchInteractionPage opencreateFollowUpPage()
	{
		return (ResearchInteractionPage)openPage(ResearchInteractionPage.class);
	}
}


