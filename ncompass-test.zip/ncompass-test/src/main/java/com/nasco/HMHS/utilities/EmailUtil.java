package com.nasco.HMHS.utilities;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;

public class EmailUtil {

	public static void sendEmailWithAttachment(String reportPath, String Env_Subject, String overallStatus,
			String timestamp, String filename_attachment, String htmlContent, String extentPath,
			String Report_attachment) {
		// this will set host of server- you can change based on your
		// requirement
		RunTestNG_NCompass_HMHS.Config.put("mail.smtp.host", RunTestNG_NCompass_HMHS.Config.getProperty("SMTP"));

		RunTestNG_NCompass_HMHS.Config.put("mail.smtp.user", "lakshmi.karri@nasco.com");

		RunTestNG_NCompass_HMHS.Config.put("mail.smtp.starttls.enable", "true");

		// set the port of socket factory
		RunTestNG_NCompass_HMHS.Config.put("mail.smtp.socketFactory.port", "25");

		// set socket factory
		RunTestNG_NCompass_HMHS.Config.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

		RunTestNG_NCompass_HMHS.Config.put("mail.smtp.socketFactory.fallback", "true");

		// set the authentication to true
		RunTestNG_NCompass_HMHS.Config.put("mail.smtp.auth", "true");

		// set the port of SMTP server
		RunTestNG_NCompass_HMHS.Config.put("mail.smtp.port", "25");
		// This will handle the complete authentication
		Session session = Session.getDefaultInstance(RunTestNG_NCompass_HMHS.Config,
				// Session session =
				// Session.getInstance(RunTestNG_NCompass_HMHS.Config,
				new javax.mail.Authenticator() {

					protected javax.mail.PasswordAuthentication getPasswordAuthentication() {

						return new PasswordAuthentication(RunTestNG_NCompass_HMHS.Config.getProperty("Email_Username"),
								RunTestNG_NCompass_HMHS.Config.getProperty("Email_Password"));

					}

				});

		try {

			// Create object of MimeMessage class
			Message message = new MimeMessage(session);

			// Set the from address
			// message.setFrom(new InternetAddress("pranathi.kare@nasco.com"));
			message.setFrom(new InternetAddress(RunTestNG_NCompass_HMHS.Config.getProperty("Email_From")));
			// Set the recipient address
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(RunTestNG_NCompass_HMHS.Config.getProperty("Email_list")));
			message.setRecipients(Message.RecipientType.CC,
					InternetAddress.parse(RunTestNG_NCompass_HMHS.Config.getProperty("Email_CC_list")));

			// Add the subject link

			message.setSubject(
					RunTestNG_NCompass_HMHS.Config.getProperty("Email_Subject") + " in " + Env_Subject +" on - "+timestamp);

			// Create object to add multimedia type content
			BodyPart messageBodyPart1 = new MimeBodyPart();

			// Set the body of email

			/*
			 * messageBodyPart1.setText(prop.getProperty("Body_Text")+
			 * Env_Subject+" checkout execution results on"+timestamp);
			 */

			// set the body html table content

			messageBodyPart1.setContent(htmlContent, "text/html");

			// Create another object to add another content

			/*MimeBodyPart messageBodyPart2 = new MimeBodyPart();
			String filename = reportPath + "\\" + filename_attachment;
			String filename1 = filename_attachment;
			DataSource source = new FileDataSource(filename);
			messageBodyPart2.setDataHandler(new DataHandler(source));
			messageBodyPart2.setFileName(filename1);

			MimeBodyPart messageBodyPart3 = new MimeBodyPart();
			String Reportname = extentPath + Report_attachment;
			String Reportname1 = Report_attachment;
			DataSource source1 = new FileDataSource(Reportname);
			messageBodyPart3.setDataHandler(new DataHandler(source1));
			messageBodyPart3.setFileName(Reportname1);
*/
			// Create object of MimeMultipart class
			Multipart multipart = new MimeMultipart();

			// add body part 1
			multipart.addBodyPart(messageBodyPart1);

			// add body part 2
			//multipart.addBodyPart(messageBodyPart2);
			// add body part 3
		//	multipart.addBodyPart(messageBodyPart3);

			// set the content
			message.setContent(multipart);

			/* message.setContent(htmlContent,"text/html"); */

			// finally send the email
			Transport.send(message);

			// System.out.println("=====Email Sent=====");

		} catch (MessagingException e) {

			throw new RuntimeException(e);

		}

	}

}