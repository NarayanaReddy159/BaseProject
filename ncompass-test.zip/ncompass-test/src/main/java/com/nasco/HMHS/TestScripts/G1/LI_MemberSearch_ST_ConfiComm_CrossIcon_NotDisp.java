package com.nasco.HMHS.TestScripts.G1;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class LI_MemberSearch_ST_ConfiComm_CrossIcon_NotDisp extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void AUTC_LI_MemberSearch_ST_ConfiComm_CrossIcon_NotDisp(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		
		test=DriverManager.getExtentReport();
		log.info("Inside LI_MemberSearch_ST_ConfiComm_CrossIcon_NotDisp Search");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("LI_MemberSearch_ST_ConfiComm_CrossIcon_NotDisp - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("LI_MemberSearch_ST_ConfiComm_CrossIcon_NotDisp -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction=searchMember.getLIInteractionID();
		log.debug("Interaction id: "+interaction);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		searchMember.readMemberDetails(data.get("ExpectedMemberDetails"));
		log.debug("Reading member details");
		searchMember.HMHSConfCommImg( "PegaGadget1Ifr");
		log.debug("Confidential Communication details present");
		searchMember.ExitInteraction();
		searchMember.WrapUpSubmit( "Exit Interaction");
		
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "LI_MemberSearch_ST_ConfiComm_CrossIcon_NotDisp Completed");
		log.debug("LI_MemberSearch_ST_ConfiComm_CrossIcon_NotDisp Completed");
		quit();
		
	}
}
