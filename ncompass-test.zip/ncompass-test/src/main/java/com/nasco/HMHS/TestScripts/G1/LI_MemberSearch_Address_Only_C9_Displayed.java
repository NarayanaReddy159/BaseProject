package com.nasco.HMHS.TestScripts.G1;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class LI_MemberSearch_Address_Only_C9_Displayed extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void AUTC_LI_MemberSearch_Address_Only_C9_Displayed(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		
		test=DriverManager.getExtentReport();
		log.info("Inside LI_MemberSearch_Address_Only_C9_Displayed Search");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("LI_MemberSearch_Address_Only_C9_Displayed_Search - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("For LI_MemberSearch_Address_Only_C9_Displayed -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction=searchMember.getLIInteractionID();
		log.debug("Interaction id: "+interaction);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Address_Having_only_C9 Search Completed");
		searchMember.readMemberDetails(data.get("ExpectedMemberDetails"));
		log.debug("Reading Member Details for Multiple address Completed");
		searchMember.HMHSMouseHovAddr( data.get("ExpectedAdrDetails"), "PegaGadget1Ifr");
		log.debug("Reading member address tooltips details");
        
		searchMember.HMHSMouseHovFourAddr( data.get("ExpectedFourAddDetails"), "PegaGadget1Ifr");
		log.debug("Reading member four address lines tooltips details");
		searchMember.ExitInteraction();
		searchMember.WrapUpSubmit( "Exit Interaction");
		
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "HMHS_TC010_MemberSearch_MultiAddress_Contract_Search Completed");
		log.debug("HMHS_TC010_MemberSearch_MultiAddress_Contract_Search Completed");
		quit();
		
	}
}
