package com.nasco.HMHS.TestScripts.G2.ManageOtherCoverage;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.OtherActions;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Pages.WorkbasketPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC011_ManageOtherCoverage_RouteIntentToLastAssignedOperator extends BaseTest{
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC011_ManageOtherCoverage_RouteIntentToLastAssignedOperator(Hashtable<String, String> data) throws Exception {
		
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC011_ManageOtherCoverage_RouteIntentToLastAssignedOperator");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC011_ManageOtherCoverage_RouteIntentToLastAssignedOperator - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		log.debug("HMHS_TC002_Report_Vaildate_SLABreakdownofOpenServiceRequests -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username2")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed");
		test.log(LogStatus.INFO, "Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
		test.log(LogStatus.INFO, data.get("Fname") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(LogStatus.INFO, "Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(LogStatus.INFO, "Member Verified successfully.");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(LogStatus.INFO,"Add Intent "+data.get("Intent"));
        ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
       
		TOT.Createnew(data);
		log.debug("Validate the Create new tab");
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		
		WorkbasketPage Workbasket = homepage.openrecentWorkbasket();
		Workbasket.movetoWorkbasketPage();
		log.debug("Navigated to the Home-Workbasket Section");
		test.log(LogStatus.INFO, "Navigated to the Home-Workbasket Section");
		Workbasket.Workbasketcheck(data);
		Workbasket.sortandSelectIntent(intentID);
		System.out.println("Sorted and selected intent " + intentID + " from Workbasket tab ");
		log.debug("Sorted and selected intent " + intentID + " from Workbasket tab ");
		test.log(LogStatus.INFO, "Sorted and selected intent " + intentID + " from Workbasket tab ");
		Workbasket.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen ");
		Workbasket.contractInformation(data);
		log.debug("Check the contract Information.");
		Workbasket.Servicerequestreview("PegaGadget1Ifr", data);
		log.debug("Validate the Service request review Workbasket table");
		test.log(LogStatus.INFO, "Check the Service request review.");
		OtherActions otherActions=homepage.openOtherActions();
		otherActions.routeToTeamMember(data);
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login1 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage1 = login1.doLoginAsValidUser( 
					RunTestNG_NCompass_HMHS.Config.getProperty("username"),
					RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		//String intentID="TOT-369";
		WorkbasketPage Workbasket1 = homepage1.openrecentWorkbasket();
		RecentWorkPage recentWork = homepage1.openrecentWork();
		WorklistPage worklist= homepage1.openrecentWorklist();
		worklist.movetoWorklistPage();
		worklist.sortandSelectIntent( intentID);
		worklist.contractInformation(data);
		recentWork.Commentssummary("PegaGadget1Ifr", data);
		Workbasket1.RoutetoWorkbasket(data);
		Workbasket1.Createnew(data.get("TypeOfInq1"),data.get("Reason1"),data.get("Resolution1"),data.get("Comments"),data.get("Intent"));
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login2 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage2 = login2.doLoginAsValidUser( 
					RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
					RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		RecentWorkPage recentWork1 = homepage2.openrecentWork();
	    WorkbasketPage Workbasket2 = homepage2.openrecentWorkbasket();
		Workbasket2.movetoWorkbasketPage();
		log.debug("Navigated to the Home-Workbasket Section");
		test.log(LogStatus.INFO, "Navigated to the Home-Workbasket Section");
		Workbasket2.Workbasketcheck(data);
		Workbasket2.sortandSelectIntent(intentID);
		System.out.println("Sorted and selected intent " + intentID + " from Workbasket tab ");
		log.debug("Sorted and selected intent " + intentID + " from Workbasket tab ");
		test.log(LogStatus.INFO, "Sorted and selected intent " + intentID + " from Workbasket tab ");
		Workbasket2.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen ");
		Workbasket2.contractInformation(data);
		log.debug("Check the contract Information.");
		
	    Workbasket2.Routeintenttolastassignedoperator(data);
		log.debug("Check the Assigned operator.");
		recentWork1.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork ");
		recentWork1.sortandSelectIntent(intentID);
		System.out.println("Sorted and selected intent " + intentID + " from recent work tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
		recentWork1.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen ");
		recentWork1.contractInformation(data);
		log.debug("Validate to contract Information screen ");
		Workbasket2.vaildationsAssignedoperator("PegaGadget1Ifr",data);
		log.debug("Check the Assigned operator.");
		
		
	}	
	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_AUTC011_ManageOtherCoverage_RouteIntentToLastAssignedOperator Completed.");
		log.debug("HMHS_AUTC011_ManageOtherCoverage_RouteIntentToLastAssignedOperator Completed.");
		quit();
	}

}
