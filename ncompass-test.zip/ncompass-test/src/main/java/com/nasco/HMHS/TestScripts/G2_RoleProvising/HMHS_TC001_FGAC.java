package com.nasco.HMHS.TestScripts.G2_RoleProvising;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC001_FGAC extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC001_FGAC (Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC001_FGAC");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC001_FGAC - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC001_FGAC -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		test.log(LogStatus.INFO, "Member Search Completed");
		searchMember.FGAChovermessage(data.get("ExceptedRestrictedhover"));
		log.debug("FGAChovermessage Completed");
		test.log(LogStatus.INFO, "FGAChovermessage Completed");
		
		searchMember.FGACselectMemberAndNavigatebyRelationship(data.get("Relationship"),data.get("ExceptedError"));
		log.debug(data.get("Relationship") + "Selected from the search results and navigated to verify member page");
		test.log(LogStatus.INFO, data.get("Relationship") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(LogStatus.INFO, "Member Submit Completed.");
		searchMember.ExitInteraction();
		searchMember.WrapUpSubmit(data.get("comments"));
		log.debug("Click on the Exit Interaction screen.");
		test.log(LogStatus.INFO, "Click on the Exit Interaction screen.");

       	}
	@AfterMethod
	public void tearDown() 
	{	test.log(LogStatus.INFO, "HMHS_TC001_FGAC completed.");
		log.debug("HMHS_TC001_FGAC completed.");
		quit();
	}
}
