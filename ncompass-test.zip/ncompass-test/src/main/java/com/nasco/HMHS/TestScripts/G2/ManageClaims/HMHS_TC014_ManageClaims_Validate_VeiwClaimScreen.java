package com.nasco.HMHS.TestScripts.G2.ManageClaims;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.ManageClaimsPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC014_ManageClaims_Validate_VeiwClaimScreen extends BaseTest{

	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC014_ManageClaims_Validate_VeiwClaimScreen(Hashtable<String, String> data) throws Exception 
	
	{
		String methodName="HMHS_TC014_ManageClaims_Validate_VeiwClaimScreen";
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser :  " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username3"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username3") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username3")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
		log.debug("Add Intent "+data.get("Intent"));
		ManageClaimsPage manageClaim=InteractionManager.openManageClaims();
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		manageClaim.searchClaims(data);
		log.debug("Navigate to Search for claim screen.");
		test.log(LogStatus.INFO,"Navigate to Search for claim screen. ");
		manageClaim.AdjustClaim(data);
		log.debug("Select claim for claim screen.");
		test.log(LogStatus.INFO,"Select claim for claim screen. ");
	
		manageClaim.Viewclaimdetails(data);
		manageClaim.Claimimage(data);		
		manageClaim.TotalValuedetails(data);
		manageClaim.LineTableHeader(data);
		manageClaim.Expandedlinedetails(data);
		manageClaim.Procedurecode(data);
		manageClaim.Healthplancodedetails(data.get("HealthplancodedetailsHeaders"),data.get("Expected_Healthplancodedetails"));
		manageClaim.Reclasscode(data);
		manageClaim.Revenue(data);
		manageClaim.Healthplancodedetails1(data.get("HealthplancodedetailsHeaders1"),data.get("Expected_Healthplancodedetails1"));
		//manageClaim.Diagnosis(data);
		//manageClaim.Healthplancodedetails2(data.get("HealthplancodedetailsHeaders2"),data.get("Expected_Healthplancodedetails2"));
		manageClaim.Processinginformation(data);
		manageClaim.Benefits(data);
        manageClaim.Pricinginformation(data);
		manageClaim.Processinginformation_adjust(data);
		manageClaim.Adjustmentinformation(data);
		manageClaim.Providerdetails(data);
		//manageClaim.Facilitydetails(data);
		manageClaim.Referringproviderdetails(data);
		manageClaim.Claimdollars(data);
		manageClaim.Bankdetail(data);
		manageClaim.Paymentoffsetdetails(data);
		manageClaim.Otherinsurancedollars(data);
		manageClaim.Medicaredollars(data);
		manageClaim.ClaimEOBremittance(data);
		
		TOT.validateToolLinks(data);
		manageClaim.review();
		manageClaim.DetermineNextAction(data);
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		test.log(LogStatus.INFO,"Navigate to Wrap up screen");
		//String intentID="CLM-4442";
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork ");
		test.log(LogStatus.INFO,"Navigate to Wrap up screen");
		recentWork.sortandSelectIntent( intentID);
		System.out.println("Sorted and selected intent " + intentID + " from recent work tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
		test.log(LogStatus.INFO,"Sorted and selected intent " + intentID + " from recent work tab ");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen ");
		test.log(LogStatus.INFO,"Navigate to Interaction screen");
		recentWork.Reviewedclaims(data);
		log.debug("Navigate to Reviewed claims screen ");
		test.log(LogStatus.INFO,"Navigate to Reviewed claims screen");
	
	}
	
	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_TC014_ManageClaims_Validate_VeiwClaimScreen Completed.");
		log.debug("HMHS_TC014_ManageClaims_Validate_VeiwClaimScreen Completed.");
		quit();

	}
}
