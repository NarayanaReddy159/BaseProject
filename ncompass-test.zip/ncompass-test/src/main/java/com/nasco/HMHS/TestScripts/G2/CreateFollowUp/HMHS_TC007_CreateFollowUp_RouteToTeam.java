package com.nasco.HMHS.TestScripts.G2.CreateFollowUp;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.CreateFollowUpPage;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.WorkbasketPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC007_CreateFollowUp_RouteToTeam extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC007_CreateFollowUp_RouteToTeam (Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC007_CreateFollowUp_RouteToTeam");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC007_CreateFollowUp_RouteToTeam - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC007_CreateFollowUp_RouteToTeam -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Create Follow up");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        String intentID = searchMember.getIntentIDCF();
		log.debug("Intent id: " + intentID);
        CreateFollowUpPage FollowUp = homepage.CreateFollowUpIntent();
        FollowUp.CreateFollowUpIntent( intentID, data);
		log.debug("Navigate to Create Follow Up prior intent screen");
		InteractionManagerPage wraptask = searchMember.cancelIntent();
		wraptask.wrapUp(data.get("Comments"));
		log.debug("Wrapping up the intent");
		WorklistPage worklist = homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		log.debug("Navigated to the Worklist page ");
		worklist.sortandSelectIntent( intentID);
		System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
		worklist.IntentStatusWorklist(data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Intent Status checked.");
		worklist.OtherActionsRouteToTeam( intentID,data);
		log.debug("Successfully able to Save to worklist");
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetomyWorkLogout();
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login1 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		login1.doLoginAsValidUser( "vid9352","KfQt-ZsbN3@Hs7r");
		WorklistPage worklist1 = homepage.openrecentWorklist();
		worklist1.movetoWorklistPage();
		log.debug("Navigated to the Worklist page ");
		worklist1.sortandSelectIntent( intentID);
		System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
		worklist.OtherActionsRouteToTeamWB( intentID,data);
		log.debug("Successfully able to Save to worklist");
		WorkbasketPage WB = homepage.openrecentWorkbasket();
		WB.Workbasketcheck( data);
		worklist1.sortandSelectIntent( intentID);
		System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
	}

	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_TC007_CreateFollowUp_RouteToTeam completed.");
		log.debug("HMHS_TC007_CreateFollowUp_RouteToTeam completed.");
		quit();

	}
}
