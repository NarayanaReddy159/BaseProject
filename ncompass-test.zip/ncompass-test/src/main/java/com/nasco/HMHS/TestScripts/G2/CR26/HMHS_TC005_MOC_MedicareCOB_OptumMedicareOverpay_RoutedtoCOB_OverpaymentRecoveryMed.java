package com.nasco.HMHS.TestScripts.G2.CR26;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.utilities.DataProviders;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC005_MOC_MedicareCOB_OptumMedicareOverpay_RoutedtoCOB_OverpaymentRecoveryMed extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC005_MOC_MedicareCOB_OptumMedicareOverpay_RoutedtoCOB_OverpaymentRecoveryMed (Hashtable<String, String> data) throws Exception {
		validateskill("HMHS_AUTC005_MOC_MedicareCOB_OptumMedicareOverpay_RoutedtoCOB_OverpaymentRecoveryMed", data);
	}
 @AfterMethod
	public void tearDown() 
	{	test.log(LogStatus.INFO, "HMHS_TC005_MOC_MedicareCOB_OptumMedicareOverpay_RoutedtoCOB_OverpaymentRecoveryMed completed.");
		log.debug("HMHS_TC005_MOC_MedicareCOB_OptumMedicareOverpay_RoutedtoCOB_OverpaymentRecoveryMed completed.");
		quit();
	}
}
