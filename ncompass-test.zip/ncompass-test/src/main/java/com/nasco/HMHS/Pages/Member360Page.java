package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings({"rawtypes","unchecked"})
public class Member360Page extends BasePage {
	String contractXpathvalue="(//div[contains(@class,'flex content layout-content-inline_grid_triple  content-inline_grid_triple false sub_regions_wrapper')])//span[contains(text(),'%s')]/following::div[1]";
	String contractXpathvalue1="(//div[contains(@class,'flex content layout-content-inline_grid_triple  content-inline_grid_triple false sub_regions_wrapper')])//label[contains(text(),'%s')]/following::div[1]";
	String memberXpathvalue="//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple false sub_regions_wrapper')]//span[contains(text(),'%s')]/following::div[1]";
	//String groupXpathvalue="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple clearfix')])//span[contains(text(),'%s')]/following::div[1]";
	String groupXpathvalue="(//div[contains(@class,' flex content layout-content-inline_grid_quadruple  content-inline_grid_quadruple false')])//span[contains(text(),'%s')]/following::div[1]";
	String PhonenumberType="//label[contains(text(),'%s')]";
	String Icondetails="(//body/div[@id='PEGA_HARNESS']/form[1]/div[5]/div[1]/ul[1]/li[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1])//span[contains(text(),'%s')]/following::div[1]";
	 @FindBy(xpath = "//h3[contains(text(),'Contract') and contains(@id,'headerlabel')]")
	 public WebElement contractTab;
	@FindBy(xpath = "//*[@id='RULE_KEY']/div/div[1]/div/div[1]/div/div/div/span/a")
	public WebElement selectPolicy;
	@FindBy(xpath = "(//div[contains(@class,'content-item content-paragraph item-1')])[1]")
	public WebElement coverage;
	
	@FindBy(xpath = "//*[@class='interaction_header_title']")
	public WebElement name;
	@FindBy(xpath = "//*[@class='content-item content-field item-1 remove-top-spacing remove-left-spacing remove-bottom-spacing remove-right-spacing flex flex-row dataValueRead']")
	public WebElement role;
	@FindBy(xpath = "//span[contains(@class,'disclosure')]")
	public WebElement disclosure;
	@FindBy(xpath = "//span[@id='DisclosureDisplaySpan']")
	public WebElement messageDisclosure;
	@FindBy(xpath = "//span[contains(text(),'Research')]")
	public WebElement type;
	@FindBy(xpath = "(//*[@class='field-caption dataLabelForRead'])[1]")
	public WebElement InteractionID;
	@FindBy(xpath = "(//*[@class='field-item dataValueRead'])[1]")
	public WebElement LiveID;
	@FindBy(xpath = "(//div[contains(@class,'content-item content-label item-1 remove-all-spacing flex flex-row dataLabelRead cs_km_grid_header_dataLabelRead')])[1]")
	public WebElement contactinformation;
	@FindBy(xpath = "(//span[contains(@class,'field-caption dataLabelForRead')])[3]")
	public WebElement phonenumber;
	@FindBy(xpath = "(//span[contains(@class,'field-caption dataLabelForRead')])[4]")
	public WebElement extension;
	@FindBy(xpath = "//div[contains(text(),'Member information')]")
	public WebElement memberInformation;
	@FindBy(xpath = "//header/div[@id='RULE_KEY']/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]")
	public WebElement membername;
	@FindBy(xpath = "//header/div[@id='RULE_KEY']/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]")
	public WebElement membernameRI;
	@FindBy(xpath = "//header/div[@id='RULE_KEY']/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]")
	public WebElement dateofbrith;
	@FindBy(xpath = "//div[2]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]")
	public WebElement dateofbrithRI;
	@FindBy(xpath = "//header/div[@id='RULE_KEY']/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]")
	public WebElement umi;
	@FindBy(xpath = "//div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]")
	public WebElement umiRI;
	@FindBy(xpath = "(//div[contains(@class,'content-item content-field item-2 remove-all-spacing flex')])[2]")
	public WebElement gender;
	@FindBy(xpath = "//*[@id='poc0']")
	public WebElement alerttooltip;
	@FindBy(xpath = "//div[contains(text(),'ALERTS')]//following::a[1]")
	public WebElement alert;
	@FindBy(xpath = "//tr[contains(@id,'$PSearchWorksheet$ppxResults$l')]/td[2]/div/span/span")
	public WebElement Workid2;
	@FindBy(xpath = "//*[@id='1ca174df']")
	public WebElement Selectintentex;
	@FindBy(xpath = "//*[@id='$PpyFilterCriteria_SearchWorksheet_pxResults_WorksheetGrid_1$ppyColumnFilterCriteria$gCCN1$ppyUniqueValues$l1']/td[2]")
	public WebElement Workid1;
	@FindBy(xpath = "(//*[@id='pui_filter'])[9]")
	public WebElement idSortEX;
	@FindBy(xpath = "//*[@id='SinfoCloseIcon']")
	public WebElement Iconclose;
	@FindBy(xpath = "//button[contains(text(),'Close')]")
	public WebElement Close;
	@FindBy(xpath = "//div[contains(text(),'Law')]")
	public WebElement law;
	@FindBy(xpath = "//div[contains(text(),'ADHI')]")
	public WebElement adhi;
	@FindBy(xpath = "//span[contains(text(),'Reverification date')]")
	public WebElement Reverificationdate;
	@FindBy(xpath = "//span[contains(text(),'Other coverage')]")
	public WebElement Othercoverage;
	@FindBy(xpath = "//span[contains(text(),'Product codes')]")
	public WebElement productcodes;
	@FindBy(xpath = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy(xpath = "//*[contains(@id,'$PD_AdditionalMemberData_pa') and contains(@id,'pz$ppxResults$l1')]//td//span//i")
	public WebElement Icon;
    @FindBy(xpath = "//label[text()='Plan area']//following::a[contains(@name,'HCGeneralInfoSubSection_pyWorkPage.Policy_22')]")
	public WebElement area;
	@FindBy(xpath = "//label[contains(text(),'Enrollment source code')]//following::a[contains(@name,'HCGeneralInfoSubSection_pyWorkPage.Policy')]")
	public WebElement source;
	@FindBy(xpath = "//*[@id='poc0']")
	public WebElement TooltipConfComm;
	@FindBy(xpath = "//h2[contains(text(),'Spending account')]")
	public WebElement spendingaccount;
	@FindBy(xpath = "//h2[contains(text(),'Product information')]")
	public WebElement productinformationt;
	@FindBy(xpath = "//h2[contains(text(),'Addresses')]")
	public WebElement addresses;
	@FindBy(xpath = "//h2[contains(text(),'Members')]")
	public WebElement members;
	@FindBy(xpath = "//div[contains(text(),'ALERTS')]")
	public WebElement alerts;
	@FindBy(xpath = "//div[contains(text(),'ALERTS')]//following::span[1]")
	public WebElement cob;
	@FindBy(xpath = "//div[contains(text(),'ALERTS')]//following::span[2]")
	public WebElement unknown;
	@FindBy(xpath = "//h3[contains(text(),'Member') and contains(@id,'headerlabel')]")
	public WebElement Membertab;
	@FindBy(xpath = "//h2[contains(text(),'General information')]")
	public WebElement general;
	@FindBy(xpath = "(//span[contains(text(),'Date of birth')])[2]")
	public WebElement dateofbirth;
	@FindBy(xpath = "//label[contains(text(),'Extension')]//following::input[1]")
	public WebElement Extension;
	@FindBy(xpath = "(//span[contains(text(),'Member name')])[3]")
	public WebElement Member;
	@FindBy(xpath = "//span[@id='PegaRULESErrorFlag']")
	public WebElement Errormessage;
	@FindBy(xpath = "(//span[contains(text(),'Gender')])[2]")
	public WebElement genders;
	@FindBy(xpath = "(//label[contains(text(),'Phone number')])[2]//following::input[1]")
	public WebElement Phonenumber;
	@FindBy(xpath = "//span[contains(text(),'Other coverage')]")
	public WebElement Other;
	@FindBy(xpath = "//*[@id='RULE_KEY']/div/div/div/div[4]/div/div/div/div[2]/div/div/div/div[4]/div/div/span/a")
	public WebElement Edit;
	@FindBy(xpath = "//b[contains(text(),'Addresses')]")
	public WebElement Address;
	@FindBy(xpath = "//b[contains(text(),'Member preferences')]")
	public WebElement memberPreferences;
	@FindBy(xpath = "(//span[contains(text(),'Email')])[1]")
	public WebElement email;
	@FindBy(xpath = "(//span[contains(text(),'Email type')])[1]")
	public WebElement emailType;
	@FindBy(xpath = "(//span[contains(text(),'Registered on website')])")
	public WebElement Registered;
	@FindBy(xpath = "(//span[contains(text(),'Registered on website')])//following::div[1]")
	public WebElement website;
	@FindBy(xpath = "//h2[contains(text(),'Associated contacts list')]")
	public WebElement associatedcontactslist;
	@FindBy(xpath = "//h3[contains(text(),'Group') and contains(@id,'headerlabel')]")
	public WebElement Grouptab;
	@FindBy(xpath = "//h2[contains(text(),'Group information')]")
	public WebElement groupinformation;
	@FindBy(xpath = "//span[contains(text(),'Client name')]")
	public WebElement clientname;
	@FindBy(xpath = "//span[contains(text(),'Client number')]")
	public WebElement clientNumber;
	@FindBy(xpath = "//span[contains(text(),'BC/BS control plan')]")
	public WebElement controlplan;
	@FindBy(xpath = "//span[contains(text(),'Group status')]")
	public WebElement groupstatus;
	@FindBy(xpath = "//span[contains(text(),'Group name')]")
	public WebElement groupName;
	@FindBy(xpath = "( //span[contains(text(),'Group number')])[2]")
	public WebElement groupnumber;
	@FindBy(xpath = "//span[contains(text(),'Effective from')]")
	public WebElement effective;
	@FindBy(xpath = "(//*[@id='EXPAND-INNERDIV']/div/div/div/div/div/div[7]/div)[2]")
	public WebElement from;
	@FindBy(xpath = "//span[contains(text(),'Effective to')]")
	public WebElement effectiveto;
	@FindBy(xpath = "//*[@id='EXPAND-INNERDIV']/div/div/div/div/div/div[2]/div/div/div/div[3]/span")
	public WebElement canceled;
	@FindBy(xpath = "//span[contains(text(),'Account type')]")
	public WebElement accounttype;
	@FindBy(xpath = "(//span[contains(text(),'Business relationship')])[1]")
	public WebElement business;
	@FindBy(xpath = "//span[contains(text(),'Business relationship description')]")
	public WebElement description;
	@FindBy(xpath = "//span[contains(text(),'Group service level agreement')]")
	public WebElement groupService;
	@FindBy(xpath = "//span[contains(text(),'Customer service number')]")
	public WebElement customerservice;
	@FindBy(xpath = "//span[contains(text(),'ERISA')]")
	public WebElement ERISAs;
	@FindBy(xpath = "(//h2[contains(text(),'Product information')])[2]")
	public WebElement productinformation;
	@FindBy(xpath = "//h2[contains(text(),'Sales reps')]")
	public WebElement salesreps;
	@FindBy(xpath = "(//h2[contains(text(),'Addresses')])[2]")
	public WebElement groupaddresses;
	@FindBy(xpath = "//h3[contains(text(),'Interactions') and contains(@id,'headerlabel')]")
	public WebElement interactionsTab;
	@FindBy(xpath = "//b[contains(text(),'Recent interactions')]")
	public WebElement recentinteractions;
	@FindBy(xpath = "(//*[@id='pui_filter'])[2]")
	public WebElement idSort;
	@FindBy(how = How.XPATH, using  = "//input[@id='15f47c16']")
	public WebElement Selectintent;
	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	public WebElement applyBtn;
	@FindBy(how = How.XPATH, using  = "//*[@id='$PpyFilterCriteria_D_RecentInteraction_pxResults_CPMDisplayInteractions_1$ppyColumnFilterCriteria$gWorkID2$ppyUniqueValues$l1']/td[2]/label")
	public WebElement IntentId1;
	@FindBy(how = How.XPATH, using  = "//tr[contains(@id,'$PD_RecentInteraction_pa') and contains(@id,'pz$ppxResults$l')] //td[3]")
	public WebElement IntentId2;
	//@FindBy(how = How.XPATH, using  = "(//tr[@class='oddRow cellCont' and @pl_index='1'])[3]")
	//public WebElement SwitchToMember1;
	
    @FindBy(how = How.XPATH, using  = "(//input[@id='D_AdditionalMemberDataPpxResults1colWidthGBR']//following::tr)[2]")
	public WebElement SwitchToMember1;
			
	@FindBy(how = How.XPATH, using  = "//div[contains(text(),'You are already viewing the member selected.')]")
	public WebElement SwitchToOwnMsg;
//	@FindBy(how = How.XPATH, using  = "(//tr[@class='evenRow cellCont' and @pl_index='2'])[2]")
//	public WebElement SwitchToMember2;
	
	
	@FindBy(how = How.XPATH, using  = "(//input[@id='D_AdditionalMemberDataPpxResults1colWidthGBR']//following::tr)[3]")
	public WebElement SwitchToMember2;
			
	@FindBy(how = How.XPATH, using  = "//b[contains(text(),'External platform interactions')]")
	public WebElement externalplatform;

	@FindBy(how = How.XPATH, using  = "(//tr[@class='evenRow cellCont' and @pl_index='2'])[2]")
	public WebElement SwitchContract;
	
	@FindBy(how = How.XPATH, using  = "(//tr[@class='oddRow cellCont' and @pl_index='1'])[4]")
	public WebElement SwitchBackContract;
	
	@FindBy(how = How.XPATH, using  = "//b[contains(text(),'Recent interactions')]")
	public WebElement RecentInt;
	
	String excepionMessage;

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(contractTab);
	}
	
	
	public void contractTab_Policy(String Group  ){
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PD_Policies_pa') and contains(@id,'pz$ppxResults$l')]"));
			ele.size();
			String s = "//tr[contains(@id,'$PD_Policies_pa') and contains(@id,'pz$ppxResults$l%d')]";
			if(ele.size()>0)
			{
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				if (driver.findElement(By.xpath(s1 + "//td[2]")).getText().equals(Group)) {
					waitSleep(5000);
					webElementClick(
							driver.findElement(
									By.xpath(String.format("//span[contains(text(),'%s')]", Group))),
							"Group");
					waitSleep(5000);
					break;
				}
			  }
			}
			else{
				System.out.println("Not Matched");
			}
				
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on ViewBenefitsPriorIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on ViewBenefitsPriorIntent method " + e);
			Assert.fail();
		}
	}
	// Read Member Details for reading the details retrived from policy.
		public void contractTab_readMemberDetails( String Expectedpolicy,String expectedheader,String expectedResult) {
			String memberDetails = "";
			String header = "";
			try {
				//waitSleep(5000);
				switchToFrame("PegaGadget1Ifr");
				waitSleep(9000);
				String Selectpolicy= webElementReadText(selectPolicy);
				System.out.println(Selectpolicy);
				assertEquals(Expectedpolicy,Selectpolicy, "verify Policy");
				webElementClick(selectPolicy, "select Policy");
				/*String Coverage= */webElementReadText(coverage);
				List<WebElement> hr = driver.findElements(By.xpath("//p[contains(text(),'Coverage period')]/following::th")); 
				System.out.println(hr.size());
				if(hr.size()==0)
				{
					waitSleep(15000);
					hr = driver
							.findElements(By.xpath("//p[contains(text(),'Coverage period')]/following::th "));
					System.out.println(hr.size());
				}
				
				String h = "//p[contains(text(),'Coverage period')]/following::th";				
					List<WebElement> colums = driver.findElements(By.xpath(h ));
					for (int j = 0; j < colums.size(); j++) {
						if (j ==0) {
							header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
							
						} else {
							header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
							
						}
					}
				System.out.println(header);

				
				assertEquals(expectedheader, header, "Member Search Results");
				List<WebElement> ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PD_Policies_pa') and contains(@id,'pz$ppxResults$l')]"));
				System.out.println(ele.size());
				if(ele.size()>=1)
				{
					waitSleep(15000);
					ele = driver
							.findElements(By.xpath("//tr[contains(@id,'$PD_Policies_pa') and contains(@id,'pz$ppxResults$l')]"));
				//	System.out.println(ele.size());
					
				
				String s = "//tr[contains(@id,'$PD_Policies_pa') and contains(@id,'pz$ppxResults$l%d')]";
				
				for (int i = 0; i < ele.size(); i++) {
					String s1 = String.format(s, i + 1);
					String memdet = "";
					List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
					for (int j = 0; j < colums1.size(); j++) {
						if (j ==0) {
							memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
							
						} else {
							memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
						
						}
					}
					memberDetails = memberDetails + "," + memdet;
				}
				waitSleep(1000);
				memberDetails = memberDetails.substring(1, memberDetails.length());
				System.out.println(memberDetails);
			 assertEquals(expectedResult, memberDetails, "Member Search Results");
				}
				else{
					System.out.println("Table is empty");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				String excepionMessage = Arrays.toString(e.getStackTrace());
				BaseTest.log.error("Error on readMemberDetails method " + excepionMessage);
				test.log(LogStatus.FAIL, "Error on readMemberDetails method " + e);
				Assert.fail();
			}
		}

        public void contractTab_readContractDetails(String Expectedpolicy){
			try {
				//waitSleep(5000);
				switchToFrame("PegaGadget1Ifr");
				waitSleep(9000);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", selectPolicy);
				String Selectpolicy= webElementReadText(selectPolicy);
				System.out.println(Selectpolicy);
				assertEquals(Expectedpolicy,Selectpolicy, "verify Policy");
				
			} catch (Exception e) {
				e.printStackTrace();
				String excepionMessage = Arrays.toString(e.getStackTrace());
				BaseTest.log.error("Error on contractTab_readContractDetails method " + excepionMessage);
				test.log(LogStatus.FAIL, "Error on contractTab_readContractDetails method " + e);
				Assert.fail();
			}
		}
		
//Read the Interactionheader_details

public void Interactionheader_details ( String ExpectedinteractionDetails) {
		
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			String Name="Unknown customer";
			List<WebElement> names=driver.findElements(By.xpath("//*[@class='interaction_header_title']"));
			if(names.size()>0)
			{
				Name= webElementReadText(name);	
			}
			
			String Role= webElementReadText(role);
			String Disclosure= webElementReadText(disclosure);
			String MessageDisclosure=messageDisclosure.getAttribute("title").toString();
			System.out.println("text::"+ MessageDisclosure);

			String interactionID = webElementReadText(InteractionID)+"::"+webElementReadText(LiveID);
			System.out.println(interactionID);
			String interactionDetails= Name+"|"+Role+"|"+Disclosure+"|"+MessageDisclosure+"|"+interactionID.substring(0, 20);
			System.out.println(interactionDetails);
			assertEquals(ExpectedinteractionDetails,interactionDetails, "interaction Details");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on Interactionheader_details method " + e);
			test.log(LogStatus.FAIL, "Error on Interactionheader_details method " + e);
			Assert.fail();
		}
	}


//Read the Interactionheader_details

public void ResearchInteractionheader_details ( String ExpectedinteractionDetails) {
		
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			String Name="Unknown customer";
			List<WebElement> names=driver.findElements(By.xpath("//*[@class='interaction_header_title']"));
			if(names.size()>0)
			{
				Name= webElementReadText(name);	
			}
			String Type= webElementReadText(type);
			String interactionID = webElementReadText(InteractionID)+"::"+webElementReadText(LiveID);
			System.out.println(interactionID);
			String interactionDetails= Name+"|"+interactionID.substring(0, 18)+"|"+Type;
			System.out.println(interactionDetails);
			assertEquals(ExpectedinteractionDetails,interactionDetails, "interaction Details");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on Interactionheader_details method " + e);
			test.log(LogStatus.FAIL, "Error on Interactionheader_details method " + e);
			Assert.fail();
		}
	}



public void interactionHeader_AddContact( String Type,String ExceptedError,String ExceptErrorchar,String ExceptPhoneFormate) {
		
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			webElementClick(Edit, "Edit button");
			
			webElementClick( driver.findElement(By.xpath(String.format(PhonenumberType, Type))),"Phonenumber Type");
			waitSleep(1000);
			webElementSendText(Phonenumber,"12345" , "Phone number");
			webElementClick(Submit, "Submit Button");
			String ErrorIntPhone=webElementReadText(Errormessage);
			System.out.println(ErrorIntPhone);
			System.out.println(ExceptErrorchar);
			assertEquals(ExceptErrorchar,ErrorIntPhone, "Error Information");
			waitSleep(1000);
			Phonenumber.clear();
			webElementSendText(Phonenumber,"sreiene" , "Phone number");
			webElementClick(Submit, "Submit Button");
			waitSleep(2500);
			String ErrorcharPhone=webElementReadText(Errormessage);
			waitSleep(1000);
			assertEquals(ExceptErrorchar,ErrorcharPhone, "contact Information");
			waitSleep(1000);
			Phonenumber.clear();
			webElementSendText(Phonenumber,"1234567890" , "Phone number");
			waitSleep(1000);
			String PhoneFormate=Phonenumber.getAttribute("value");
			System.out.println(PhoneFormate);
			webElementSendText(Extension,"serytyu" , "Extension number");
			//assertEquals(ExceptPhoneFormate,PhoneFormate, "contact Information");
			webElementClick(Submit, "Submit Button");
			waitSleep(1000);
			String ErrorcharExtension=webElementReadText(Errormessage);
			webElementClick(Submit, "Submit Button");
			System.out.println(ExceptPhoneFormate);
			System.out.println(ErrorcharExtension);
			assertEquals(ExceptPhoneFormate,ErrorcharExtension, "contact Information");
			waitSleep(1000);
			Extension.clear();
			waitSleep(1000);
			webElementSendText(Extension,"1234" , "Extension number");
			webElementClick(Submit, "Submit Button");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on interactionHeader_AddContact method " + e);
			test.log(LogStatus.FAIL, "Error on interactionHeader_AddContact method " + e);
			Assert.fail();
		}
	}

public void SwitchMember() {
		
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			Actions actions = new Actions(driver);
			WebElement elementLocator = SwitchToMember1;
			test.log(LogStatus.INFO, "Check the message if you try to view same member.");
			actions.doubleClick(elementLocator).perform();
			waitSleep(2500);
			String ActualMessage = webElementReadText(SwitchToOwnMsg);
			String ExpectedMsg = "You are already viewing the member selected.";
			assertEquals(ActualMessage, ExpectedMsg, "Check the message when user try to switch with same member.");
			wait(1500);
	        webElementClick(Close,"Close the screen.");
	        wait(1500);
			WebElement elementLocator1 = SwitchToMember2;
			test.log(LogStatus.INFO, "Select the second member.");
			actions.doubleClick(elementLocator1).perform();
			waitSleep(2500);
			webElementClick(Submit, "Submit Button");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on SwitchMember method " + e);
			test.log(LogStatus.FAIL, "Error on SwitchMember method " + e);
			Assert.fail();
		}
	}



public void SwitchMemberConf() {
		
		try {
			switchToFrame("PegaGadget1Ifr");
	        wait(1500);
			Actions actions = new Actions(driver);
			WebElement elementLocator1 = SwitchToMember1;
			test.log(LogStatus.INFO, "Select the another member.");
			actions.doubleClick(elementLocator1).perform();
			waitSleep(2500);
			webElementClick(Submit, "Submit Button");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on SwitchMember method " + e);
			test.log(LogStatus.FAIL, "Error on SwitchMember method " + e);
			Assert.fail();
		}
	}

public void SwitchContract() {
	try {
		switchToFrame("PegaGadget1Ifr");
		waitSleep(1500);
		webElementClick(selectPolicy, "Open the policy.");
		waitSleep(1500);
		webElementClick(SwitchContract, "Select the second contract.");
		waitSleep(2500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on SwitchContract method " + e);
		test.log(LogStatus.FAIL, "Error on SwitchContract method " + e);
		Assert.fail();
	}
}


public void SwitchBackContract() {
	try {
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2500);
		webElementClick(selectPolicy, "Open the policy.");
		waitSleep(1500);
		webElementClick(SwitchBackContract, "Select the previous contract.");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on SwitchContract method " + e);
		test.log(LogStatus.FAIL, "Error on SwitchContract method " + e);
		Assert.fail();
	}
}

//Read the interactionHeader_contactInformation

public void interactionHeader_contactInformation ( String ExpectedcontactInformation) {
		String ContactInformation="";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
        List<WebElement> Contact= driver.findElements(By.xpath("//*[@id='RULE_KEY']/div/div/div/div[4]/div/div/div/div[2]"));
			

	        System.out.println(Contact.size());

	        for (WebElement webElement : Contact) {
	        	ContactInformation = webElement.getText();
	            System.out.println(ContactInformation);
	        }

			
			assertEquals(ExpectedcontactInformation,ContactInformation, "contact Information");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on interactionHeader_contactInformation method " + e);
			test.log(LogStatus.FAIL, "Error on interactionHeader_contactInformation method " + e);
			Assert.fail();
		}
	}
//Read the interactionHeader_contactInformation

public void interactionHeader_memberInformation ( String ExpectedmemberInformation) {
		
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			String MemberInformation= webElementReadText(memberInformation);
			String Membername= webElementReadText(membername);
			String UMI= webElementReadText(umi);
			String Dateofbrith= webElementReadText(dateofbrith).substring(0, 25);
			waitSleep(1000);
			System.out.println("Age::"+Dateofbrith);
			String Gender= webElementReadText(gender);
			String memberInformation=MemberInformation+"|"+Membername+"|"+UMI+"|"+Dateofbrith+"|"+Gender;
			System.out.println(memberInformation);
			assertEquals(ExpectedmemberInformation,memberInformation, "member Information");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on interactionHeader_memberInformation method " + e);
			test.log(LogStatus.FAIL, "Error on interactionHeader_memberInformation method " + e);
			Assert.fail();
		}
	}

//Read the interactionHeader_contactInformation

public void ResearchinteractionHeader_memberInformation ( String ExpectedmemberInformation) {
		
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			String MemberInformation= webElementReadText(memberInformation);
			String Membername= webElementReadText(membernameRI);
			String UMI= webElementReadText(umiRI);
			String Dateofbrith= webElementReadText(dateofbrithRI).substring(0, 25);
			waitSleep(1000);
			System.out.println("Age::"+Dateofbrith);
			String Gender= webElementReadText(gender);
			String memberInformation=MemberInformation+"|"+Membername+"|"+UMI+"|"+Dateofbrith+"|"+Gender;
			System.out.println(memberInformation);
			assertEquals(ExpectedmemberInformation,memberInformation, "member Information");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on interactionHeader_memberInformation method " + e);
			test.log(LogStatus.FAIL, "Error on interactionHeader_memberInformation method " + e);
			Assert.fail();
		}
	}

//Read the interactionHeader_ALERTS

public void interactionHeader_ALERTS ( String ExpectedALERTSInformation,String Alert,String ExceptedmessageMouseover) {
	 String ALERTSInformation="";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			List<WebElement> ALERTS= driver.findElements(By.xpath("//*[@id='RULE_KEY']/div/div/div/div[4]/div/div/div/div[4]"));
			

	        System.out.println(ALERTS.size());

	        for (WebElement webElement : ALERTS) {
	             ALERTSInformation = webElement.getText();
	            System.out.println(ALERTSInformation);
	        }
			
			assertEquals(ExpectedALERTSInformation,ALERTSInformation, "member Information");
			if(Alert.equals("Yes"))
			{
				String details=getTooltipMessage(alert, alerttooltip);
				System.out.println(details);
				assertEquals(ExceptedmessageMouseover,details, "message Mouseover");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on interactionHeader_ALERTS method " + e);
			test.log(LogStatus.FAIL, "Error on interactionHeader_ALERTS method " + e);
			Assert.fail();
		}
	}

//Read the contractTab_contractdetails

public void contractTab_contractdetails( String contractheader,String contractheader1,String Expectedcontractdetails, String expectedMessagearea,String expectedMessagesource ) {
	String contractdetails ="";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			//String header="Member name|Effective date|Cancel reason|Contract ID|Cancellation date|Paid to date|Group number|Plan area|Enrollment source code";
			

			contractdetails= getrowdata(contractheader, contractXpathvalue);
            waitSleep(4000);
            
            String contractdetails1= getrowdata(contractheader1, contractXpathvalue1);          
            System.out.println(contractdetails+"|"+contractdetails1);
            waitSleep(3500);
            String actualMessagearea=getTooltipMessage(area, TooltipConfComm);
			assertEquals(expectedMessagearea,actualMessagearea, "member Information");
			String actualMessagesource=getTooltipMessage(source, TooltipConfComm);
			assertEquals(expectedMessagesource,actualMessagesource, "member Information");		
			//assertEquals(Expectedcontractdetails,contractdetails+"|"+contractdetails1, "member Information");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on contractTab_contractdetails method " + e);
			test.log(LogStatus.FAIL, "Error on contractTab_contractdetails method " + e);
			Assert.fail();
		}
	}
// Read Member Details for reading the details contractTab_Spendingaccount from policy.

public void contractTab_Spendingaccount( String ExpectedSpendingaccount,String ExpectedSpendingheader) {
	String memberDetails = "";
	String header="";
	try {
		//waitSleep(5000);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(9000);
		String Spendingaccount= webElementReadText(spendingaccount);
		System.out.println(Spendingaccount);
		List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Spending account')]/following::table[contains(@class,'gridTable')][1]//tr//th ")); 
		System.out.println(hr.size());
		if(hr.size()==0)
		{
			waitSleep(15000);
			hr = driver
					.findElements(By.xpath("//h2[contains(text(),'Spending account')]/following::table[contains(@class,'gridTable')][1]//tr//th "));
			System.out.println(hr.size());
		}
		
		String h = "//h2[contains(text(),'Spending account')]/following::table[contains(@class,'gridTable')][1]//tr//th";				
			List<WebElement> colums = driver.findElements(By.xpath(h ));
			for (int j = 0; j < colums.size(); j++) {
				if (j ==0) {
					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
				} else {
					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
					
				}
			}
		System.out.println(header);

		assertEquals(ExpectedSpendingheader,header, "Spending header");

		
		List<WebElement> ele = driver
				.findElements(By.xpath("//h2[contains(text(),'Spending account')]/following::table[contains(@class,'gridTable')][1]//tr"));
		System.out.println(ele.size());
		
			
		
		String s = "//h2[contains(text(),'Spending account')]/following::table[contains(@class,'gridTable')][1]//tr[%d]";
		
		for (int i = 1; i < ele.size(); i++) {
			String s1 = String.format(s, i + 1);
			String memdet = "";
			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
			for (int j = 0; j < colums1.size(); j++) {
				if (j ==0) {
					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				} else {
					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				}
			}
			memberDetails = memberDetails + "," + memdet;
		}
		waitSleep(1000);
		memberDetails = memberDetails.substring(1, memberDetails.length());
		System.out.println(memberDetails);
		assertEquals(ExpectedSpendingaccount,memberDetails, "Spending account");;
		
		
}catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on contractTab_Spendingaccount method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on contractTab_Spendingaccount method " + e);
		Assert.fail();
	}
}

public void contractTab_Addresses( String ExpectedAddresses,String ExpectedAddressesheader,String expectedResult) {
	String memberDetails = "";
	String header="";
	try {
		//waitSleep(5000);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(9000);
		String Addresses= webElementReadText(addresses);
		System.out.println(Addresses);
		assertEquals(ExpectedAddresses,Addresses, "Addresses informationt");
		
		List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Addresses')]/following::table[contains(@class,'gridTable')][1]//tr/th ")); 
		System.out.println(hr.size());
		if(hr.size()==0)
		{
			waitSleep(15000);
			hr = driver
					.findElements(By.xpath("//h2[contains(text(),'Addresses')]/following::table[contains(@class,'gridTable')][1]//tr/th "));
			System.out.println(hr.size());
		}
		
		String h = "//h2[contains(text(),'Addresses')]/following::table[contains(@class,'gridTable')][1]//tr/th";				
			List<WebElement> colums = driver.findElements(By.xpath(h ));
			for (int j = 0; j < colums.size(); j++) {
				if (j ==0) {
					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
				} else {
					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
					
				}
			}
		System.out.println(header);

		assertEquals(ExpectedAddressesheader,header, "Addresses informationt");
		
		List<WebElement> ele = driver
				.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pPolicy$pSubscriberAddress$l')]"));
		System.out.println(ele.size());
		
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
				
			}
		String s = "//tr[contains(@id,'$PpyWorkPage$pPolicy$pSubscriberAddress$l%d')]";
		for (int i = 0; i < ele.size(); i++) {
			String s1 = String.format(s, i + 1);
			String memdet = "";
			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
			//System.out.println(colums1.size());
			for (int j = 0; j < colums1.size(); j++) {
				if (j ==0) {
					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				} else {
					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				}
			}
			memberDetails = memberDetails + "," + memdet;
		}
		waitSleep(1000);
		memberDetails = memberDetails.substring(1, memberDetails.length());
		System.out.println(memberDetails);
	 assertEquals(expectedResult, memberDetails, "Member Search Results");
		
		
		
}catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on contractTab_Addresses method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on contractTab_Addresses method " + e);
		Assert.fail();
	}
}

public void contractTab_Productinformationt( String ExpectedProductinformationt,String ExpectedProductheader) {
	String memberDetails = "";
	String header="";
	try {
		//waitSleep(5000);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(9000);
		String Productinformationt= webElementReadText(productinformationt);
		System.out.println(Productinformationt);
	
		
		List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Product information')]/following::table[contains(@class,'gridTable')][1]//tr/th ")); 
		System.out.println(hr.size());
		if(hr.size()==0)
		{
			waitSleep(15000);
			hr = driver
					.findElements(By.xpath("//h2[contains(text(),'Product information')]/following::table[contains(@class,'gridTable')][1]//tr/th "));
			System.out.println(hr.size());
		}
		
		String h = "//h2[contains(text(),'Product information')]/following::table[contains(@class,'gridTable')][1]//tr/th";				
			List<WebElement> colums = driver.findElements(By.xpath(h ));
			for (int j = 0; j < colums.size(); j++) {
				if (j ==0) {
					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
				} else {
					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
					
				}
			}
		System.out.println(header);

		assertEquals(ExpectedProductheader,header, "Product informationt");
		
		List<WebElement> ele = driver
				.findElements(By.xpath("//h2[contains(text(),'Product information')]/following::table[contains(@class,'gridTable')][1]//tr"));
		System.out.println(ele.size());
		
			waitSleep(15000);
//			ele = driver
//					.findElements(By.xpath("//h2[contains(text(),'Product information')]/following::table[contains(@class,'gridTable')][1]//tr[2]"));
//			
		String s = "//h2[contains(text(),'Product information')]/following::table[contains(@class,'gridTable')][1]//tr[%d]";
		for (int i = 1; i < ele.size(); i++) {
			String s1 = String.format(s, i + 1);
			String memdet = "";
			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
			for (int j = 0; j < colums1.size(); j++) {
				if (j ==0) {
					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				} else {
					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				}
			}
			memberDetails = memberDetails + "," + memdet;
		}
		waitSleep(1000);
		memberDetails = memberDetails.substring(1, memberDetails.length());
		System.out.println(memberDetails);
		assertEquals(ExpectedProductinformationt,memberDetails, "Product informationt");
		
		
		
}catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on contractTab_Productinformationt method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on contractTab_Productinformationt method " + e);
		Assert.fail();
	}
}

public void contractTab_Members( String ExpectedMembers,String ExpectedMembersheader,String expectedResult) {
	String memberDetails = "";
	String header="";
	try {
		//waitSleep(5000);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(9000);
		String Members= webElementReadText(members);
		System.out.println(Members);
		assertEquals(ExpectedMembers,Members, "Members informationt");
		
		List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Members')]/following::table[contains(@class,'gridTable')][1]//tr/th ")); 
		System.out.println(hr.size());
		if(hr.size()==0)
		{
			waitSleep(15000);
			hr = driver
					.findElements(By.xpath("//h2[contains(text(),'Members')]/following::table[contains(@class,'gridTable')][1]//tr/th "));
			System.out.println(hr.size());
		}
		
		String h = "//h2[contains(text(),'Members')]/following::table[contains(@class,'gridTable')][1]//tr/th";				
			List<WebElement> colums = driver.findElements(By.xpath(h ));
			for (int j = 0; j < colums.size(); j++) {
				if (j ==0) {
					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
				} else {
					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
					
				}
			}
		System.out.println(header);

		assertEquals(ExpectedMembersheader,header, "Members informationt");
		
		List<WebElement> ele = driver
				.findElements(By.xpath("//tr[contains(@id,'$PD_AdditionalMemberData_pa') and contains(@id,'pz$ppxResults$l')]"));
		System.out.println(ele.size());
		
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PD_AdditionalMemberData_pa') and contains(@id,'pz$ppxResults$l')]"));
				
			}
		String s = "//tr[contains(@id,'$PD_AdditionalMemberData_pa') and contains(@id,'pz$ppxResults$l%d')]";
		for (int i = 0; i < ele.size(); i++) {
			String s1 = String.format(s, i + 1);
			String memdet = "";
			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
			//System.out.println(colums1.size());
			for (int j = 0; j < colums1.size(); j++) {
				if (j ==0) {
					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				} else {
					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				}
			}
			memberDetails = memberDetails + "," + memdet;
		}
		waitSleep(1000);
		memberDetails = memberDetails.substring(1, memberDetails.length());
		System.out.println(memberDetails);
	//assertEquals(expectedResult, memberDetails, "Member Search Results");
		
		
		
}catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on contractTab_Members method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on contractTab_Members method " + e);
		Assert.fail();
	}
}
//Read the memberTab_Generalinformation

public void memberTab_Generalinformation ( String Memberheader,String expectedGeneralinformation) {
		
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			webElementClick(Membertab, "Member tab");
		    String General=webElementReadText(general);
		    String Dateofbirth=webElementReadText(dateofbirth);
		    String Membername=webElementReadText(Member);
		    
		    String Gender=webElementReadText(genders);
		    String Othercoverage=webElementReadText(Other);
		    String Generalinformation=General+"|"+Dateofbirth+"|"+Membername+"|"+Gender+"|"+Othercoverage;
		    
		    String Memberdetails= getrowdata(Memberheader, memberXpathvalue); 
		    System.out.println(Generalinformation+"::"+Memberdetails);
		    assertEquals(expectedGeneralinformation, Generalinformation+"::"+Memberdetails, "General informationh Results");

			
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on memberTab_Generalinformation method " + e);
			test.log(LogStatus.FAIL, "Error on memberTab_Generalinformation method " + e);
			Assert.fail();
		}
	}

public void memberTab_Address ( String ExpectedMembersaddressheader,String expectedResult) {
	String addressDetails = "";
	String header="";
	try {
		//waitSleep(5000);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(9000);
		String address= webElementReadText(Address);
		System.out.println(address);
		
		
		List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Addresses')]/following::table[contains(@class,'gridTable')][5]//tr//th ")); 
		System.out.println(hr.size());
		if(hr.size()==0)
		{
			waitSleep(15000);
			hr = driver
					.findElements(By.xpath("//h2[contains(text(),'Addresses')]/following::table[contains(@class,'gridTable')][5]//tr//th"));
			System.out.println(hr.size());
		}
		
		String h = "//h2[contains(text(),'Addresses')]/following::table[contains(@class,'gridTable')][5]//tr//th";				
			List<WebElement> colums = driver.findElements(By.xpath(h ));
			for (int j = 0; j < colums.size(); j++) {
				if (j ==0) {
					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
				} else {
					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
					
				}
			}
		System.out.println(header);
		assertEquals(ExpectedMembersaddressheader,header, "Members informationt");
		
		List<WebElement> ele = driver
				.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gMember$pAddress$l')]"));
		System.out.println(ele.size());
		
			
				
			
		String s = "//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gMember$pAddress$l%d')]";
		for (int i = 0; i < ele.size(); i++) {
			String s1 = String.format(s, i + 1);
			String memdet = "";
			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
			//System.out.println(colums1.size());
			for (int j = 0; j < colums1.size(); j++) {
				if (j ==0) {
					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				} else {
					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				}
			}
			addressDetails = addressDetails + "," + memdet;
		}
		waitSleep(1000);
		addressDetails = addressDetails.substring(1, addressDetails.length());
		System.out.println(addressDetails);
//	assertEquals(expectedResult, addressDetails, "Member Search Results");
		
			
		
}catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on memberTab_Address method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on memberTab_Address method " + e);
		Assert.fail();
	}
}

public void memberTab_Memberpreferences ( String ExpectedMemberpreferencesheader,String expectedResult,String preferencesdetail) {
	String Memberpreferencesdetail = "";
	String header="";
	try {
		//waitSleep(5000);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(9000);
		String Memberpreferences= webElementReadText(memberPreferences);
		System.out.println(Memberpreferences);
		
		
		List<WebElement> hr = driver.findElements(By.xpath("//b[contains(text(),'Member preferences')]/following::table[contains(@class,'gridTable')][2]//tr//th")); 
		System.out.println(hr.size());
		if(hr.size()==0)
		{
			waitSleep(15000);
			hr = driver
					.findElements(By.xpath("//b[contains(text(),'Member preferences')]/following::table[contains(@class,'gridTable')][2]//tr//th"));
			System.out.println(hr.size());
		}
		
		String h = "//b[contains(text(),'Member preferences')]/following::table[contains(@class,'gridTable')][2]//tr//th";				
			List<WebElement> colums = driver.findElements(By.xpath(h ));
			for (int j = 0; j < colums.size(); j++) {
				if (j ==0) {
					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
				} else {
					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
					
				}
			}
		System.out.println(header);

		assertEquals(ExpectedMemberpreferencesheader,header, "Members informationt");
		
		List<WebElement> ele = driver
				.findElements(By.xpath("//b[contains(text(),'Member preferences')]/following::table[contains(@class,'gridTable')][2]//tr"));
		System.out.println(ele.size());
		
			
				
			
		String s = "//b[contains(text(),'Member preferences')]/following::table[contains(@class,'gridTable')][2]//tr[%d]";
		for (int i = 1; i < ele.size(); i++) {
			String s1 = String.format(s, i + 1);
			String memdet = "";
			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
			//System.out.println(colums1.size());
			for (int j = 0; j < colums1.size(); j++) {
				if (j ==0) {
					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				} else {
					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				}
			}
			Memberpreferencesdetail = Memberpreferencesdetail + "," + memdet;
		}
		waitSleep(1000);
		Memberpreferencesdetail = Memberpreferencesdetail.substring(1, Memberpreferencesdetail.length());
		System.out.println(Memberpreferencesdetail);
	assertEquals(expectedResult, Memberpreferencesdetail, "Member Search Results");
		
	String Email= webElementReadText(email);
	String Emailtype= webElementReadText(emailType);
	String Registeredonwebsite= webElementReadText(Registered)+"::"+webElementReadText(website);
	String detail=Memberpreferences+"|"+Email+"|"+Emailtype+"|"+Registeredonwebsite;
	System.out.println(detail);
	assertEquals(preferencesdetail, detail, "Member Search Results");
	
	
	
		
}catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on memberTab_Memberpreferences method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on memberTab_Memberpreferences method " + e);
		Assert.fail();
	}
}

public void memberTab_Associatedcontactslist ( String ExpectedAssociatedcontactsheader,String expectedResult) {
	String Associatedcontacts = "";
	String header="";
	try {
		//waitSleep(5000);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(9000);
		String Associatedcontactslist= webElementReadText(associatedcontactslist);
		System.out.println(Associatedcontactslist);
		
		
		List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Associated contacts list')]/following::table[contains(@class,'gridTable')][2]//tr//th")); 
		System.out.println(hr.size());
		if(hr.size()==0)
		{
			waitSleep(15000);
			hr = driver
					.findElements(By.xpath("//h2[contains(text(),'Associated contacts list')]/following::table[contains(@class,'gridTable')][2]//tr//th"));
			System.out.println(hr.size());
		}
		
		String h = "//h2[contains(text(),'Associated contacts list')]/following::table[contains(@class,'gridTable')][2]//tr//th";				
			List<WebElement> colums = driver.findElements(By.xpath(h ));
			for (int j = 0; j < colums.size(); j++) {
				if (j ==0) {
					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
				} else {
					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
					
				}
			}
		System.out.println(header);

		assertEquals(ExpectedAssociatedcontactsheader,header, "Members informationt");
		
		List<WebElement> ele = driver
				.findElements(By.xpath("//h2[contains(text(),'Associated contacts list')]/following::table[contains(@class,'gridTable')][2]//tr"));
		System.out.println(ele.size());
		
			
				
			
		String s = "//h2[contains(text(),'Associated contacts list')]/following::table[contains(@class,'gridTable')][2]//tr[%d]";
		for (int i = 1; i < ele.size(); i++) {
			String s1 = String.format(s, i + 1);
			String memdet = "";
			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
			//System.out.println(colums1.size());
			for (int j = 0; j < colums1.size(); j++) {
				if (j ==0) {
					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				} else {
					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				}
			}
			Associatedcontacts = Associatedcontacts + "," + memdet;
		}
		waitSleep(1000);
		Associatedcontacts = Associatedcontacts.substring(1, Associatedcontacts.length());
		System.out.println(Associatedcontacts);
	assertEquals(expectedResult, Associatedcontacts, "Member Search Results");
		
	}catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on memberTab_Associatedcontactslist method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on memberTab_Associatedcontactslist method " + e);
		Assert.fail();
	}
}

public void groupTab_Generalinformation ( String Groupheader,String ExpectedGroupinformationdetails) {
		String groupdetails="";
		try {
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(9500);
			jsClick(Grouptab, "Group tab");
		    String Groupinformation=webElementReadText(groupinformation);
		    String Clientname=webElementReadText(clientname);
		    String Clientnumber=webElementReadText(clientNumber);
		    String BCBS=webElementReadText(controlplan);
		    String Groupstatus=webElementReadText(groupstatus);
		    String Groupname=webElementReadText(groupName);
		    String Groupnumber=webElementReadText(groupnumber);
		    waitSleep(4500);
		    String Effectivefrom=webElementReadText(effective);
		    String Effectiveto=webElementReadText(effectiveto);
		    String Canceled=webElementReadText(canceled);
		    String Accounttype=webElementReadText(accounttype);
		    String Business=webElementReadText(business );
		    String Description=webElementReadText(description);
		    String Groupservice=webElementReadText(groupService);
		    String Customerservice=webElementReadText(customerservice);
		    String ERISA=webElementReadText(ERISAs);


		   
			
		    String Groupinformationdetails=Groupinformation+"|"+Clientname+"|"+Clientnumber+"|"+BCBS+"|"+Groupstatus+"|"+Groupname+"|"+Groupnumber+"|"+Effectivefrom+"|"+Effectiveto
		    		+"|"+Canceled+"|"+Accounttype+"|"+Business+"|"+Description+"|"+Groupservice+"|"+Customerservice+"|"+ERISA;
			
			groupdetails= getrowdata(Groupheader, groupXpathvalue);
            waitSleep(4000);
            System.out.println(Groupinformationdetails+"::"+groupdetails);
            
		   
		    assertEquals(ExpectedGroupinformationdetails, Groupinformationdetails+"::"+groupdetails, "General informationh Results");

			
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on groupTab_Generalinformation method " + e);
			test.log(LogStatus.FAIL, "Error on groupTab_Generalinformation method " + e);
			Assert.fail();
		}
	}

public void groupTab_Productinformation ( String ExpectedProductinformationheader,String expectedResult) {
	String Productinformationdetails = "";
	String header="";
	try {
		//waitSleep(5000);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(9000);
		String Productinformation= webElementReadText(productinformation);
		System.out.println(Productinformation);
		
		
		List<WebElement> hr = driver.findElements(By.xpath("(//h2[contains(text(),'Product information')])[2]//following::table[3]//th")); 
		System.out.println(hr.size());
		if(hr.size()==0)
		{
			waitSleep(15000);
			hr = driver
					.findElements(By.xpath("(//h2[contains(text(),'Product information')])[2]//following::table[3]//th"));
			System.out.println(hr.size());
		}
		
		//String h = "(//h2[contains(text(),'Product information')]/following::table[contains(@class,'gridTable')])[15]//th";	
		String h = "(//h2[contains(text(),'Product information')])[2]//following::table[3]//th";	
			List<WebElement> colums = driver.findElements(By.xpath(h ));
			for (int j = 0; j < colums.size(); j++) {
				if (j ==0) {
					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
				} else {
					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
					
				}
			}
		System.out.println(header);

		assertEquals(ExpectedProductinformationheader,header, "Product information header");
		
		List<WebElement> ele = driver
				.findElements(By.xpath("(//h2[contains(text(),'Product information')])[2]//following::table[3]//tr"));
		System.out.println(ele.size());
		
			
				
			
		String s = "(//h2[contains(text(),'Product information')])[2]//following::table[3]//tr[%d]";
		for (int i = 1; i < ele.size(); i++) {
			String s1 = String.format(s, i + 1);
			String memdet = "";
			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
			//System.out.println(colums1.size());
			for (int j = 0; j < colums1.size(); j++) {
				if (j ==0) {
					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				} else {
					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				}
			}
			Productinformationdetails = Productinformationdetails + "," + memdet;
		}
		waitSleep(1000);
		Productinformationdetails = Productinformationdetails.substring(1, Productinformationdetails.length());
		System.out.println(Productinformationdetails);
	assertEquals(expectedResult, Productinformationdetails, "Member Search Results");
		
	}catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on groupTab_Productinformation method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on groupTab_Productinformation method " + e);
		Assert.fail();
	}
}

public void groupTab_Salesreps ( String ExpectedSalesrepsheader,String expectedResult) {
	String Salesrepsdetails = "";
	String header="";
	try {
		//waitSleep(5000);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(9000);
		String Salesreps= webElementReadText(salesreps);
		System.out.println(Salesreps);
		
		
		List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Sales reps')]/following::table[contains(@class,'gridTable')][2]//tr//th")); 
		System.out.println(hr.size());
		if(hr.size()==0)
		{
			waitSleep(15000);
			hr = driver
					.findElements(By.xpath("//h2[contains(text(),'Sales reps')]/following::table[contains(@class,'gridTable')][2]//tr//th"));
			System.out.println(hr.size());
		}
		
		String h = "//h2[contains(text(),'Sales reps')]/following::table[contains(@class,'gridTable')][2]//tr//th";				
			List<WebElement> colums = driver.findElements(By.xpath(h ));
			for (int j = 0; j < colums.size(); j++) {
				if (j ==0) {
					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
				} else {
					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					
					
				}
			}
		System.out.println(header);

		assertEquals(ExpectedSalesrepsheader,header, "Members informationt");
		
		List<WebElement> ele = driver
				.findElements(By.xpath("//h2[contains(text(),'Sales reps')]/following::table[contains(@class,'gridTable')][2]//tr"));
		System.out.println(ele.size());
		
			
				
			
		String s = "//h2[contains(text(),'Sales reps')]/following::table[contains(@class,'gridTable')][2]//tr[%d]";
		for (int i = 0; i < ele.size(); i++) {
			String s1 = String.format(s, i + 1);
			String memdet = "";
			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
			//System.out.println(colums1.size());
			for (int j = 0; j < colums1.size(); j++) {
				if (j ==0) {
					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				} else {
					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
				}
			}
			Salesrepsdetails = Salesrepsdetails + "," + memdet;
		}
		waitSleep(1000);
		Salesrepsdetails = Salesrepsdetails.substring(1, Salesrepsdetails.length());
		System.out.println(Salesrepsdetails);
	assertEquals(expectedResult, Salesrepsdetails, "Sales repsdetails Results");
		
	}catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on groupTab_Salesreps method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on groupTab_Salesreps method " + e);
		Assert.fail();
	}
}

public void groupTab_Addresses( String ExpectedAddresses,String ExpectedAddmemheader) {
		String header="";
		String Addressdetails="";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			String Addresses=webElementReadText(groupaddresses);
			assertEquals(ExpectedAddresses, Addresses, "Addresses");
			
			List<WebElement> hr = driver.findElements(By.xpath("(//h2[contains(text(),'Addresses')])[2]/following::table[contains(@class,'gridTable')][1]//th")); 
			if(hr.size()>= 0)
			{
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("(//h2[contains(text(),'Addresses')])[2]/following::table[contains(@class,'gridTable')][1]//th"));
				System.out.println(hr.size());
			}
			
			String h = "(//h2[contains(text(),'Addresses')])[2]/following::table[contains(@class,'gridTable')][1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h ));
			
				for (int j = 0; j < colums.size(); j++) {
					String tableheadervalue= driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
					System.out.println(tableheadervalue);
			
					if (!tableheadervalue.equals(""))
					{
						if (j ==0) {
							header = tableheadervalue;
							
						} else {
							header = header + "|" + tableheadervalue;
							
							
						}
	
					}
				}
			System.out.println(header);

			assertEquals(ExpectedAddmemheader,header, "Members Address informationt");
			
			List<WebElement> ele = driver
					.findElements(By.xpath("(//h2[contains(text(),'Addresses')])[2]/following::table[contains(@class,'gridTable')][1]//tr"));
			System.out.println(ele.size());
			
				
					
				
			String s = "(//h2[contains(text(),'Addresses')])[2]/following::table[contains(@class,'gridTable')][1]//tr[%d]";
			for (int i = 1; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				//System.out.println(colums1.size());
				for (int j = 0; j < colums1.size(); j++) {
					if (j ==0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				Addressdetails = Addressdetails + "," + memdet;
			}
			waitSleep(1000);
			Addressdetails = Addressdetails.substring(1, Addressdetails.length());
			System.out.println(Addressdetails);
		//assertEquals(expectedResult, Addressdetails, "Sales repsdetails Results");
			}
			else{
				System.out.println("Data is not present");
			}


		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on groupTab_Addresses method " + e);
			test.log(LogStatus.FAIL, "Error on groupTab_Addresses method " + e);
			Assert.fail();
		}
	}


public void interactionsTab_Recentinteractions( String Expectedinteractionsheader) {
	
	String header="";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			
			jsClick(interactionsTab, "interactions tab");
		    
		    String Recentinteractions=webElementReadText(recentinteractions);
		   
		   System.out.println(Recentinteractions);
			
			List<WebElement> hr = driver.findElements(By.xpath("(//b[contains(text(),'Recent interactions')]//following::table[contains(@class,'gridTable')])[1]//th")); 
			System.out.println(hr.size());
//			if(hr.size()==0)
//			{
//				waitSleep(15000);
//				hr = driver
//						.findElements(By.xpath("//b[contains(text(),'Recent interactions')]//following::table[contains(@class,'gridTable')][2]//tr//th"));
//				System.out.println(hr.size());
//			}
//			
			String h = "(//b[contains(text(),'Recent interactions')]//following::table[contains(@class,'gridTable')])[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h ));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
				header = header.substring(1, header.length());
			System.out.println(header);

			//assertEquals(Expectedinteractionsheader,header, "Interactions header");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
	}


public void interactionsTab_Research() {
	
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", interactionsTab);
			jsClick(interactionsTab, "interactions tab");
			String ActualHeadline = webElementReadText(RecentInt);
			String ExpectedHeadline = "Recent interactions";
			assertEquals(ActualHeadline, ExpectedHeadline, "Check for recent interactions.");
		}catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
	}


public void interactionsTab_sortandSelectIntent( ) {
	String intentid="";
	try {
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2500);
		//jsClick(interactionsTab, "interactions tab");
		waitSleep(5000);
		jsClick(idSort, "ID Sort");
		waitSleep(5000);
		intentid= webElementReadText(IntentId1);
		System.out.println(intentid);
		webElementClick(Selectintent, "Select intent");
		webElementClick(applyBtn, "Apply");
		List <WebElement> tableRows= driver.findElements(By.xpath("//tr[contains(@id,'$PD_RecentInteraction_pa') and contains(@id,'pz$ppxResults$l')]"));
		System.out.println(tableRows.size());
		waitSleep(2500);
		String intentid2= webElementReadText(IntentId2);
		System.out.println(intentid2);
		assertEquals(intentid, intentid2, "Intent verify");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on interactionsTab_sortandSelectIntent method " + e);
		test.log(LogStatus.FAIL, "Error on interactionsTab_sortandSelectIntent method " + e);
		Assert.fail();
	}
  }

public void interactionsTab_Externalplatform( String Expectedexternalplatformheader,String expectedResult) {
	
	String header="";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			
			jsClick(externalplatform, "Externalplatform tab");
		    
		    String Externalplatform=webElementReadText(externalplatform);
		   
		   System.out.println(Externalplatform);
			
		   externalplatform.click();
		   
			//List<WebElement> hr = driver.findElements(By.xpath("//b[contains(text(),'External platform interactions')]//following::table[contains(@class,'gridTable')][2]//tr//th")); 
			String h = "//b[contains(text(),'External platform interactions')]//following::table[contains(@class,'gridTable')][2]//tr//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h ));
				System.out.println(colums.size());
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
				header = header.substring(1, header.length());
			System.out.println(header);

			assertEquals(Expectedexternalplatformheader,header, "Interactions header");
						

			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on interactionsTab_Externalplatform method " + e);
			test.log(LogStatus.FAIL, "Error on interactionsTab_Externalplatform method " + e);
			Assert.fail();
		}
	}

public void interactionsTab_sortandSelectExternalplatform( ) {
	String Workid="";
	try {
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2500);
		//jsClick(interactionsTab, "interactions tab");
		waitSleep(5000);
		jsClick(idSortEX, "ID Sort");
		waitSleep(5000);
		Workid= webElementReadText(Workid1);
		System.out.println(Workid);
		webElementClick(Selectintentex, "Select intent");
		webElementClick(applyBtn, "Apply");
		List <WebElement> tableRows= driver.findElements(By.xpath("//*[@id='$PSearchWorksheet$ppxResults$l10']"));
		System.out.println(tableRows.size());
		waitSleep(2500);
		String workid2= webElementReadText(Workid2);
		System.out.println(workid2);
		assertEquals(Workid, workid2, "workid verify");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on interactionsTab_sortandSelectExternalplatform method " + e);
		test.log(LogStatus.FAIL, "Error on interactionsTab_sortandSelectExternalplatform method " + e);
		Assert.fail();
	}
  }

public void contractTab_MembersICON(String Headersdata,String Expectedicon ) {
	
	try {
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2500);
		jsClick(Icon, "Icon tab");
		waitSleep(5000);
		String Productcodes=webElementReadText(productcodes);
		String othercoverage=webElementReadText(Othercoverage);
		String reverificationdate=webElementReadText(Reverificationdate);
		String ADHI=webElementReadText(adhi);
		String LAW=webElementReadText(law);
		String codes=getrowdata(Headersdata, Icondetails);
		String icon=Productcodes+":"+codes+"|"+othercoverage+"|"+reverificationdate+"|"+ADHI+"|"+LAW;
		System.out.println(icon);
		waitSleep(5000);
		jsClick(Iconclose, "Icon tab");
		assertEquals(Expectedicon, icon, "icon details verify");
		
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on interactionsTab_sortandSelectExternalplatform method " + e);
		test.log(LogStatus.FAIL, "Error on interactionsTab_sortandSelectExternalplatform method " + e);
		Assert.fail();
	}
  }

public void disclosureLevel(Hashtable<String, String> data)
{
	try{
		waitSleep(2500);
		String disclosureLevelText=webElementReadText(disclosure, "Disclosure Level");
		System.out.println(disclosureLevelText);
		assertEquals(data.get("ExpectedDisclosure"), disclosureLevelText, "Disclosure Level");
		
	}catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on disclosureLevel method " + e);
		test.log(LogStatus.FAIL, "Error on disclosureLevel method " + e);
		Assert.fail();
	}
}
public void contractTab_DataMasking( String contractheader,String Expectedcontractdetails ) {
	String contractdetails ="";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			contractdetails= getrowdata(contractheader, contractXpathvalue);
          	
			assertEquals(Expectedcontractdetails,contractdetails, "member Information");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on contractTab_contractdetails method " + e);
			test.log(LogStatus.FAIL, "Error on contractTab_contractdetails method " + e);
			Assert.fail();
		}
	}

public void Member360_Tab(Hashtable<String, String> data) {
	
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			jsClick(Membertab, "Member tab");
			waitSleep(1500);
			//test.log(LogStatus.INFO, "Navigate to Member Tab .");
			jsClick(Grouptab, "Group tab");
			waitSleep(1500);
			//test.log(LogStatus.INFO, "Navigate to Group Tab .");
			jsClick(interactionsTab, "interactions tab");
			//test.log(LogStatus.INFO, "Navigate to interactions Tab .");
			waitSleep(1500);
			jsClick(Membertab, "Member tab");
			//test.log(LogStatus.INFO, "Navigate to Member Tab .");
			String Member360Tab=webElementReadText(contractTab)+"::"+webElementReadText(Membertab)+"::"+webElementReadText(Grouptab)+"::"+webElementReadText(interactionsTab);
			assertEquals(data.get("ExpectedMember360Tab"),Member360Tab, "Member360 Tab");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on contractTab_contractdetails method " + e);
			test.log(LogStatus.FAIL, "Error on contractTab_contractdetails method " + e);
			Assert.fail();
		}
	}

}
