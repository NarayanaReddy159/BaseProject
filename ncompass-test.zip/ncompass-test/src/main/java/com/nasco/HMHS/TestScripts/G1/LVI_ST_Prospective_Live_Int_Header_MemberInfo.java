package com.nasco.HMHS.TestScripts.G1;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class LVI_ST_Prospective_Live_Int_Header_MemberInfo extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void AUTC_LVI_ST_Prospective_Live_Int_Header_MemberInfo(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		
		test=DriverManager.getExtentReport();
		log.info("Inside LVI_ST_Prospective_Live_Int_Header_MemberInfo");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("LVI_ST_Prospective_Live_Int_Header_MemberInfo - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("LVI_ST_Prospective_Live_Int_Header_MemberInfo -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.movetoProsMem();
		searchMember.searchProsMemHead( data);		
		InteractionManagerPage interactionManager=searchMember.openInteractionPage();
		interactionManager.wrapUp("Testing");
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "LVI_ST_Prospective_Live_Int_Header_MemberInfo Completed");
		log.debug("LVI_ST_Prospective_Live_Int_Header_MemberInfo Completed");
		quit();
		
	}
}
