package com.nasco.HMHS.TestScripts.G1;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC009_MemberSearch_WrapUp_MemberNotFound extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G1DP")
	public void HMHS_AUTC009_MemberSearch_WrapUp_MemberNotFound(Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC009_MemberSearch_WrapUp_MemberNotFound Search");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC009_MemberSearch_WrapUp_MemberNotFound- Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC009_MemberSearch_WrapUp_MemberNotFound -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password"));

		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String intentID = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + intentID);
		test.log(LogStatus.INFO,"Interaction id: " + intentID);
		searchMember.WrapUp_MemberNotFound();
		log.debug("Moved to Wrap Up Member Not Found page.");
		test.log(LogStatus.INFO, "Moved to Wrap Up Member Not Found page.");
		searchMember.WrapUpMemNotFoundSubmit( data.get("Comments"),
				data.get("InteractionReason"));
		log.debug("Comments submitted.");
		test.log(LogStatus.INFO, "Comments submitted.");
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigate to the Recentwork.");
		test.log(LogStatus.INFO, "Navigate to the Recentwork.");
		recentWork.sortandSelectIntent( intentID);
		System.out.println("Navigate to selected intent " + intentID + " from recent work tab ");
		log.debug("Navigate to selected intent " + intentID + "from recent work tab.");
		test.log(LogStatus.INFO, "Navigate to selected intent " + intentID + "from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen.");
		test.log(LogStatus.INFO, "Navigate to Interaction screen.");
	}

	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_TC009_MemberSearch_WrapUp_MemberNotFound Completed");
		log.debug("HMHS_TC009_MemberSearch_WrapUp_MemberNotFound Completed");
		quit();

	}
}
