package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings({"rawtypes","unchecked"})
public class ViewTotalPage extends BasePage {

	String excepionMessage = "";
	String ScheduleappointmentXpath="//div[contains(@class,'flex  content  false layout-content-default content-default  clearfix ')]//span[contains(text(),'%s')]";
	String ScheduleappointmentXpath1="//div[contains(@class,'flex  content  false layout-content-default content-default  clearfix ')]//label[contains(text(),'%s')]";

	String Websitetoolsandinformation="(//div[contains(@class,'flex content layout-content-inline_grid_triple  content-inline_grid_triple clearfix')])[1]//span[contains(text(),'%s')]//following::div[1]";
	String WebsitegroupXpath="(//div[contains(@class,'flex content layout-content-inline_grid_triple  content-inline_grid_triple clearfix')])[2]//span[contains(text(),'%s')]//following::div[1]";
	String GroupheaderXpath="(//div[contains(@class,' flex content layout-content-inline_grid_triple  content-inline_grid_triple clearfix')])//span[contains(text(),'%s')]//following::div[1]"; 
	
	@FindBy(how = How.XPATH, using  = "//*[starts-with(@id,'$PpyFilterCriteria_PriorRequests_pxResults') and contains(@id,'$ppyColumnFilterCriteria$gWorkID2$ppyUniqueValues$l1')]//td[2]")
	public WebElement IntentId1;
	@FindBy(how = How.XPATH, using  = "//tr[contains(@id,'$PPriorRequests$ppxResults$l')]/td[2]")
	public WebElement IntentId2;
	
	//String IntentId1="//*[@id='$PpyFilterCriteria_PriorRequests_pxResults_PriorRequestsForShellIntents_2$ppyColumnFilterCriteria$gWorkID2$ppyUniqueValues$l1']/td[2]//label";
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Filter')]")
	public WebElement filter;
	@FindBy(how = How.XPATH, using  = "//span[@class='standard']")
	public WebElement IntentId;
	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	@FindBy(xpath = "(//*[@id='pui_filter'])[2]")
	public WebElement idSort;
	@FindBy(how = How.XPATH, using  = "//input[starts-with(@name,'$PpyFilterCriteria_PriorRequests_pxResults') and contains(@name,'$ppyColumnFilterCriteria$gWorkID2$ppyUniqueValues$l1$ppySelected') and @type='checkbox']")
	public WebElement Selectintent;
	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	public WebElement applyBtn;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pTypeofinquiry")
	public WebElement TypeOfInq;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pReason")
	public WebElement Reason;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pResolution")
	public WebElement Resolution;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pComments")
	public WebElement comment;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pNotes")
	public WebElement GSIcomment;
	
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'Supplemental tools')]")
	public WebElement toollinksTab;
	
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Supplemental tools')]")
	public WebElement FPRtoollinksTab;
	@FindBy(how = How.XPATH, using  = "//div[contains(text(),'If you')]")
	public WebElement toolTabMsg;
	String  toolLinks="//a[contains(@name,'Supplement') and contains(@name,'Tools_pyWorkPage')]";
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'View totals')]")
	public WebElement viewTotalsTab;
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'View benefits')]")
	public WebElement viewBenefitsTab;
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'View auth')]")
	public WebElement viewAuthTab;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Provider search')]")
	public WebElement provoderTab;
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'Manage other coverage')]")
	public WebElement ocvTab;
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'Manage checks')]")
	public WebElement mangeChecksTab;
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'Manage PCP')]")
	public WebElement mangePCPTab;
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'Create GSI')]")
	public WebElement GSITab;
	@FindBy(how = How.XPATH, using  = "(//h3[contains(text(),'Website support details')])[1]")
	public WebElement WebsitesupportTab;
	@FindBy(how = How.XPATH, using  = "//a[contains(text(),'CSR utility')]")
	public WebElement crsutility;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Registered on website')]")
	public WebElement Registeredonwebsite;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Registered on website')]//following::div[1]")
	public WebElement Membernotregistered;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Username')]")
	public WebElement Username;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Website account status')]")
	public WebElement Websiteaccountstatus;
	@FindBy(how = How.XPATH, using  = "(//label[contains(text(),'Website')])[2]")
	public WebElement Website;
	@FindBy(how = How.XPATH, using  = "(//label[contains(text(),'Website')])[2]//following::div[1]")
	public WebElement WebsiteValue;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'ID card group status code')]")
	public WebElement IDcardgroup;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Website group feature')]")
	public WebElement groupfeature;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Eligible for care cost estimator')]")
	public WebElement eligibleforcarecost;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Benefit book on portal')]")
	public WebElement benefitbookonportal;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Mobile app enabled')]")
	public WebElement mobileappenabled;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Plan progress available')]")
	public WebElement planprogressavailable;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Wellness program')]")
	public WebElement wellnessprogram;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Telemedicine')]")
	public WebElement Telemedicine;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Telemedicine indicator')]")
	public WebElement telemedicine;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Telemedicine indicator')]//following::div[1]")
	public WebElement indicator;
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'Group admin support details')]")
	public WebElement groupadminsupportdetails;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Group information')]")
	public WebElement groupinformation;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Client number')]")
	public WebElement clientnumber;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Client status')]")
	public WebElement clientstatus;
	@FindBy(how = How.XPATH, using  = "(//span[contains(text(),'Group number')])[1]")
	public WebElement groupnumber;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Group status')]")
	public WebElement groupstatus;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Registered admin users')]")
	public WebElement Registeredadminusers;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pInquiriesList$l1$pInquiryType")
	public WebElement WebsiteTypeOfInq;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pInquiriesList$l1$pInquiryReason")
	public WebElement WebsiteReason;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pInquiriesList$l1$pInquiryResolution")
	public WebElement WebsiteResolution;
	@FindBy(how = How.XPATH, using  = "//*[@id='$PpyWorkPage$pInquiriesList$l1']/td[4]/div/span/a")
	public WebElement addicon;
	@FindBy(how = How.XPATH, using  = "(//a[contains(@class,'iconDelete')])[2]")
	public WebElement deleteicon;
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'Schedule appointment') and contains(@id,'headerlabel')]")
	public WebElement ScheduleAppointmentTab;
	@FindBy(how = How.XPATH, using  = "//div[contains(text(),'User should able to submit only 20 appointments')]")
	public WebElement limtappointmentMessage;
	@FindBy(how = How.XPATH, using  = "//select[contains(@name,'$PpyWorkPage$pProviderDetailsList$l') and contains(@name,'$pAppOutcomeManual')]")
	public WebElement Appointmentoutcome;
	@FindBy(how = How.XPATH, using  = "//select[contains(@name,'$PpyWorkPage$pProviderDetailsList$l') and contains(@name,'$pAppReason')]")
	public WebElement Appointmentreason;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Provider name')]//following::input[1]")
	public WebElement Providername;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Type and specialty')]//following::input[1]")
	public WebElement Typeandspecialty;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Zip code')]//following::input[1]")
	public WebElement Zipcode;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'State')]//following::select[1]")
	public WebElement State;
	@FindBy (how = How.XPATH, using = "//label[contains(text(),'Yes')]")
	public WebElement Yes;
	@FindBy(how = How.XPATH, using = "(//button[contains(text(),'Add')])[2]")
	public WebElement addbutton;
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		//return ExpectedConditions.visibilityOf(driver.findElement(By.xpath(String.format(intentName, "View Totals"))));
		return ExpectedConditions.visibilityOf(add);
	} 
	public String getIntentID() 
	{	
		String intentid="";
		try{
			waitSleep(1000);
			switchToFrame("PegaGadget1Ifr");
			System.out.println( webElementReadText(IntentId));
			intentid= webElementReadText(IntentId);
			intentid= intentid.substring(1, intentid.length()-1);
			System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	public void ViewTotalPriorIntent(String expectedDefault,String expectedALLValues ){
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			Select Workstatus=new Select(driver.findElement(By.xpath("//*[@name='$PpyWorkPage$pStatusWork']")));
			//System.out.println(Workstatus.getFirstSelectedOption().getText());
			waitSleep(2500);
			Select Opendaterange=new Select(driver.findElement(By.xpath("//*[@name='$PpyWorkPage$pPriorReqDateRange']")));
			String Default = Workstatus.getFirstSelectedOption().getText()+"|"+Opendaterange.getFirstSelectedOption().getText();
			System.out.println(Default);
			assertEquals(expectedDefault, Default, "Member Search Results");
			String ALLValues = driver.findElement(By.xpath("//*[@name='$PpyWorkPage$pStatusWork']")).getText()+"|"+driver.findElement(By.xpath("//*[@name='$PpyWorkPage$pPriorReqDateRange']")).getText();
			System.out.println(ALLValues);
			assertEquals(expectedALLValues, ALLValues, "Member Search Results");
			webElementClick(filter,"filter");
			waitSleep(5000);
			
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on ViewBenefitsPriorIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on ViewBenefitsPriorIntent method " + e);
			Assert.fail();
		}
	}
	public void submitFPR(Hashtable<String, String> data)
	{
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2500);
		webElementSendText(comment, data.get("Comments"), "Comments");
		webElementClick(Submit, "Submit");
		wait(2500);
	}
	
	public void sortandSelectIntent( ) {
		String intentid="";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			jsClick(idSort, "ID Sort");
			waitSleep(5000);
			intentid= webElementReadText(IntentId1);
			System.out.println(intentid);
			webElementClick(Selectintent, "Select intent");
			webElementClick(applyBtn, "Apply");
			List <WebElement> tableRows= driver.findElements(By.xpath("//tr[contains(@id,'$PPriorRequests$ppxResults$l')]"));
			System.out.println(tableRows.size());
			waitSleep(2500);
			String intentid2= webElementReadText(IntentId2);
			System.out.println(intentid2);
			assertEquals(intentid, intentid2, "Intent verify");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
	}
	
	public void vaildationsDropdowns (Hashtable<String, String> data) {
			try {
				
				String expectedValues=getAlldropdownvalues(TypeOfInq, Reason, Resolution);
				assertEquals(expectedValues, data.get("AllDropdownValues"), "Type of Inquiry-Resons-Resolutions");
				
			} catch (Exception e) {
				e.printStackTrace();
				BaseTest.log.error("Error on vaildationsDropdowns method " + e);
				test.log(LogStatus.FAIL, "Error on vaildationsDropdowns method " + e);
				Assert.fail();
			}
		}
	
	public void vaildationsCreatenewFields ( String AllTypeofinq,Hashtable<String, String> data) {
		
		try {
			
			getAlldropdownvalues(TypeOfInq, Reason, Resolution);
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
	}
	public void Createnew(Hashtable<String, String> data) {
		
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			selectDropdownValueByVisibleText(TypeOfInq, data.get("TypeOfInq"), "Type Of Inquiry");
			wait(2500);
			selectDropdownValueByVisibleText(Reason, data.get("Reason"), "Reason");
			wait(2500);
			selectDropdownValueByVisibleText(Resolution, data.get("Resolution"), "Resolution");
			wait(2500);
			if(data.get("Intent").equals("Create GSI"))
			{
				webElementSendText(GSIcomment, data.get("Comments"), "Comments");
			}else{
				webElementSendText(comment, data.get("Comments"), "Comments");	
			}
			
			webElementClick(Submit, "Submit");
			wait(2500);
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
	}
	
	
	public void submitGSI()
	{
		try{
			wait(2500);
			webElementClick(Submit, "Submit");
			wait(2500);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on submitGSI method " + e);
			test.log(LogStatus.FAIL, "Error on submitGSI method " + e);
			Assert.fail();
		}
	}
	
	public void validateToolLinks(Hashtable<String, String> data)
	{
		try{
			if(data.get("Intent").equals("Find a Provider"))
			{
				webElementClick(FPRtoollinksTab, "Suppletools tab");	
			}else{
				webElementClick(toollinksTab, "Suppletools tab");	
			}
			
			String message=webElementReadText(toolTabMsg, "Tools tab message");
			assertEquals(message, data.get("ExpectedToollinksMessage"), "Tool tab message");
			List<WebElement> Links=driver.findElements(By.xpath(toolLinks));
			String toollinks="";
			for(int i=0;i<Links.size();i++)
			{
				if(i==0)
				{
					toollinks=Links.get(i).getText();
				}
				else{
					toollinks=toollinks+"|"+Links.get(i).getText();
				}
					
					
			}
			test.log(LogStatus.PASS, "Tool links: "+toollinks);
			BaseTest.log.debug("Tool links: "+toollinks);
			assertEquals(toollinks, data.get("ExpectedToolLinks"), "Tool links");
			if(data.get("Intent").equals("View Totals")){
				webElementClick(viewTotalsTab, "View Totals tab");	
			}else if(data.get("Intent").equals("View Benefits"))
			{
				webElementClick(viewBenefitsTab, "View Benefits tab");
			}else if(data.get("Intent").equals("Find a Provider"))
			{
				webElementClick(provoderTab, "Provider Search tab");
			}else if(data.get("Intent").equals("Manage Other Coverage"))
			{
				webElementClick(ocvTab, "Manage Other Coverage tab");
			}else if(data.get("Intent").equals("Manage Checks"))
			{
				webElementClick(mangeChecksTab, "Manage Checks tab");
			}else if(data.get("Intent").equals("Manage PCP"))
			{
				webElementClick(mangePCPTab, "Manage Checks tab");
			}else if(data.get("Intent").equals("Create GSI"))
			{
				webElementClick(GSITab, "Create GSI tab");
			}
			else if(data.get("Intent").equals("Website Support"))
			{
				wait(2500);
				webElementClick(WebsitesupportTab, "Website support details");
			}
			else if(data.get("Intent").equals("Schedule Appointment"))
			{
				wait(2500);
				webElementClick(ScheduleAppointmentTab, "Schedule Appointment");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateToolLinks method " + e);
			test.log(LogStatus.FAIL, "Error on validateToolLinks method " + e);
			Assert.fail();
		}
		
	}
	
	public void Websitesupportdetails(Hashtable<String, String> data)
	{
		try{
			wait(2500);
			//System.out.println(Memberregistered.getText());
			if (Registeredonwebsite.getText().equals("Member registered"))
			{
			try{
				String CRSutility =  crsutility.getText();
				assertEquals(CRSutility, data.get("ExpectedCRSutility"), "CSR utility");
			}catch(Exception e)
			{
			  System.out.println("Member not registered " + e);
				
			}
			}
			else
			{
				String membernotregistered=Membernotregistered.getText();
				assertEquals(membernotregistered, data.get("ExpectedRegisteredonwebsite"), "Member not registered");
			}
			
			String registeredonwebsite=webElementReadText(Registeredonwebsite);
			String username=webElementReadText(Username);
			String websiteaccountstatus=webElementReadText(Websiteaccountstatus);
			String website=webElementReadText(Website)+"::"+webElementReadText(WebsiteValue);
			String IDcardgroupstatus=webElementReadText(IDcardgroup);
			String Websitetoolsheaders=registeredonwebsite+":"+username+":"+websiteaccountstatus+":"+website+":"+IDcardgroupstatus;
			//System.out.println(Websitetoolsheaders);
			String Websitetools= Websitetoolsheaders+"::"+getrowdata(data.get("Websitetoolsandinformationheader"), Websitetoolsandinformation); 
			//System.out.println(Websitetools);
			assertEquals(Websitetools, data.get("ExpectedWebsitetools"), "Website tools");
			wait(2500);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Websitesupportdetails method " + e);
			test.log(LogStatus.FAIL, "Error on Websitesupportdetails method " + e);
			//Assert.fail();
		}
	}
	public void Websitegroupfeature(Hashtable<String, String> data)
	{
		try{
			wait(2500);
			String Groupfeatureheader=webElementReadText(groupfeature);
			String Eligibleforcarecost=webElementReadText(eligibleforcarecost);
			String Benefitbookonportal=webElementReadText(benefitbookonportal);
			String Mobileappenabled=webElementReadText(mobileappenabled);
			String Planprogressavailable=webElementReadText(planprogressavailable);
			String Websitegroupheader=Groupfeatureheader+":"+Eligibleforcarecost+":"+Benefitbookonportal+":"+Mobileappenabled+":"+Planprogressavailable;
			String Websitegroupfeatures=Websitegroupheader+"::"+getrowdata(data.get("Websitegroupheaders"),WebsitegroupXpath);
			wait(2500);
			System.out.println(Websitegroupfeatures);
			assertEquals(Websitegroupfeatures,data.get("ExpectedWebsitegroupfeature"),"Website group feature");
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Websitegroupfeature method " + e);
			test.log(LogStatus.FAIL, "Error on Websitegroupfeature method " + e);
			Assert.fail();
		}
	}
	public void Wellnessprogram(Hashtable<String, String> data)
	{
		String memberDetails = "";
		String header = "";
		try{
			wait(2500);
			String Wellnessprogramheader=webElementReadText(wellnessprogram);
			wait(2500);
			List<WebElement> hr = driver.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[1]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[1]//th"));
				System.out.println(hr.size());
			}
			
			String h = "(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(Wellnessprogramheader+":"+header);

			
			assertEquals(data.get("ExpectedWellnessheader"), Wellnessprogramheader+":"+header, "Wellness program header");
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l1')]"));
			//System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l1')]"));
				System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l1')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				memberDetails = memberDetails + "," + memdet;
			}
			waitSleep(1000);
			//memberDetails = memberDetails.substring(1, memberDetails.length());
			System.out.println(memberDetails);
			assertEquals(data.get("ExpectedWellness"), memberDetails, "Wellness program Value");

		
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Wellnessprogram method " + e);
			test.log(LogStatus.FAIL, "Error on Wellnessprogram method " + e);
			Assert.fail();
		}
	}
	public void Telemedicine(Hashtable<String, String> data)
	{
		String memberDetails = "";
		String header = "";
		try{
			wait(2500);
			String Telemedicineheader=webElementReadText(Telemedicine);
			String Telemedicine=webElementReadText(telemedicine);
			String Indicator=webElementReadText(indicator);
			String Telemedicineindicator=Telemedicineheader+"::"+Telemedicine+"::"+Indicator;
			//System.out.println(Telemedicineindicator);
			assertEquals(data.get("ExpectedTelemedicineindicator"), Telemedicineindicator, "Telemedicine indicator header");


			wait(2500);
			List<WebElement> hr = driver.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[2]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[2]//th"));
				System.out.println(hr.size());
			}
			
			String h = "(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h ));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(header);

			
			assertEquals(data.get("ExpectedTelemedicineheader"), header, "Telemedicine header");
			List<WebElement> ele = driver
					.findElements(By.xpath("//h2[contains(text(),'Telemedicine')]//following::tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l')]"));
			//System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//h2[contains(text(),'Telemedicine')]//following::tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l')]"));
				System.out.println(ele.size());
			}
			
			String s = "//h2[contains(text(),'Telemedicine')]//following::tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				memberDetails = memberDetails + "," + memdet;
			}
			waitSleep(1000);
			//memberDetails = memberDetails.substring(1, memberDetails.length());
			System.out.println(memberDetails);
			assertEquals(data.get("ExpectedTelemedicine"), memberDetails, "Telemedicine Value");
		
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Telemedicine method " + e);
			test.log(LogStatus.FAIL, "Error on Telemedicine method " + e);
			Assert.fail();
		}
	}
	public void Groupadminsupportdetails(Hashtable<String, String> data)
	{
		try{
			wait(2500);
			webElementClick(groupadminsupportdetails, "group adminsupport details");
			String Groupinformation=webElementReadText(groupinformation);
			String Clientnumber=webElementReadText(clientnumber);
			String Clientstatus=webElementReadText(clientstatus);
			String Groupnumber=webElementReadText(groupnumber);
			String Groupstatus=webElementReadText(groupstatus);

			String Groupinformationheader=Groupinformation+":"+Clientnumber+":"+Clientstatus+":"+Groupnumber+":"+Groupstatus;
			String Groupinformationvalue=Groupinformationheader+"::"+getrowdata(data.get("Groupheader"),GroupheaderXpath);
			wait(2500);
			System.out.println(Groupinformationvalue);
			assertEquals(Groupinformationvalue, data.get("ExpectedGroupinformationvalue"), "Group information value");
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Websitegroupfeature method " + e);
			test.log(LogStatus.FAIL, "Error on Websitegroupfeature method " + e);
			Assert.fail();
		}
	}
	public void Registeredadminusers(Hashtable<String, String> data)
	{
		String memberDetails = "";
		String header = "";
		try{
			wait(2500);
			String Registeredadminusersheader=webElementReadText(Registeredadminusers);
			System.out.println(Registeredadminusersheader);
			wait(2500);
			List<WebElement> hr = driver.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Embed-Address')])[1]//th")); 
			System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Embed-Address')])[1]//th"));
				System.out.println(hr.size());
			}
			
			String h = "(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Embed-Address')])[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h ));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			System.out.println(header);

			
			assertEquals(data.get("ExpectedRegisteredadminusersheader"), header, "Registered admin users header");
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pAddress$l')]"));
			//System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pAddress$l')]"));
				System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pAddress$l')][%d]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				memberDetails = memberDetails + "," + memdet;
			}
			waitSleep(1000);
			//memberDetails = memberDetails.substring(1, memberDetails.length());
			System.out.println(memberDetails);
			assertEquals(data.get("ExpectedRegisteredadminusersvalue"),memberDetails, "Registered admin users values");

		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Registeredadminusers method " + e);
			test.log(LogStatus.FAIL, "Error on Registeredadminusers method " + e);
			Assert.fail();
		}
	}
public void WebsiteCreatenew(Hashtable<String, String> data) {
		
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4500);
			selectDropdownValueByVisibleText(WebsiteTypeOfInq, data.get("TypeOfInq"), "Type Of Inquiry");
			wait(2500);
			selectDropdownValueByVisibleText(WebsiteReason, data.get("Reason"), "Reason");
			wait(2500);
			selectDropdownValueByVisibleText(WebsiteResolution, data.get("Resolution"), "Resolution");
			wait(2500);
			webElementClick(addicon, "Add icon");
//			selectDropdownValueByVisibleText(WebsiteTypeOfInq, data.get("TypeOfInq"), "Type Of Inquiry");
//			wait(2500);
//			selectDropdownValueByVisibleText(WebsiteReason, data.get("Reason"), "Reason");
//			wait(2500);
//			selectDropdownValueByVisibleText(WebsiteResolution, data.get("Resolution"), "Resolution");
			wait(3500);
			webElementClick(deleteicon, "Add icon");
			wait(2500);
			webElementSendText(comment, data.get("Comments"), "Comments");
			wait(500);
			webElementClick(Submit, "Submit");
			wait(2500);
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
	}
public void vaildationswebsiteDropdowns (Hashtable<String, String> data) {
	try {
		
		String expectedValues=getAlldropdownvalues(WebsiteTypeOfInq,WebsiteReason,WebsiteResolution);
		assertEquals(expectedValues, data.get("AllDropdownValues"), "Type of Inquiry-Resons-Resolutions");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on vaildationsDropdowns method " + e);
		test.log(LogStatus.FAIL, "Error on vaildationsDropdowns method " + e);
		Assert.fail();
	}
}

  public void vaildationswebsiteCreatenewFields ( String AllTypeofinq,Hashtable<String, String> data) {

		try {
			
			getAlldropdownvalues(WebsiteTypeOfInq, WebsiteReason, WebsiteResolution);
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
	}
  public void WebSiteSupport()
	{
		try{
			wait(2500);
			webElementClick(WebsitesupportTab, "Website support details");
			
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on submitGSI method " + e);
			test.log(LogStatus.FAIL, "Error on submitGSI method " + e);
			Assert.fail();
		}
	}
  public void Scheduleappointment_VaildateFields(Hashtable<String, String> data) {
	  
	  try {
		  String options="|";
		  String options1="|";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(5000);
			String VaildateFields=getrowdata(data.get("Headersdata"),ScheduleappointmentXpath);
			String VaildateFields1=getrowdata(data.get("Headersdata1"),ScheduleappointmentXpath1);
			String fields=VaildateFields+"|"+VaildateFields1;
			System.out.println(fields);
	        assertEquals(data.get("ExpectedFieldheader"), fields, "All fields");

			Select s = new Select(Appointmentoutcome);
		      // getting the list of options in the dropdown with getOptions()
		      List <WebElement> op = s.getOptions();
		      int size = op.size();
		      for(int i =0; i<size ; i++){
		    	  waitSleep(2000); 
		   
		         options=options+op.get(i).getText()+"|";  
		      
		      }
		      
		      System.out.println(options);
		     assertEquals(data.get("ExpectedAppointmentoutcome"), options, "Appointment outcome options");
			Select s1 = new Select(Appointmentreason);
			 List <WebElement> op1 = s1.getOptions();
		      int size1 = op1.size();
		      for(int i =0; i<size1 ; i++){
		    	  waitSleep(2000);
		         options1=options1+op1.get(i).getText()+"|";  
		      }
		      System.out.println(options1);
		      assertEquals(data.get("ExpectedAppointmentreason"), options1, "Appointment reason");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on selectMemberAndNavigatebyfname method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on selectMemberAndNavigatebyfname method " + e);
			Assert.fail();
		}
	}
  public void Scheduleappointment_Newappointment(Hashtable<String, String> data) {
		try {
			
			switchToFrame("PegaGadget1Ifr");
			waitSleep(5000);

			String s = "//button[contains(text(),'+ New appointment')]";
			for (int i = 0; i <= 18; i++) {

				
					if (driver.findElement(By.xpath(s )).getText().equals("+ New appointment")) {
						waitSleep(2000);
						webElementClick(
								driver.findElement(
										By.xpath(s)),"New appointment");
			
					}
			}
			String limtappointment=webElementReadText(limtappointmentMessage);
			assertEquals(data.get("ExpectedlimtappointmentMessage"), limtappointment, "limt appointment");
			waitSleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Scheduleappointment_Newappointment method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on Scheduleappointment_Newappointment method " + e);
			Assert.fail();
		}
  }
		public void Scheduleappointment_Deleteappointment() {
			try {
				
				switchToFrame("PegaGadget1Ifr");
				waitSleep(5000);

				String s = "//a[contains(@title,'Delete this row')]";
				for (int i = 0; i <= 18; i++) {

							waitSleep(3000);
							webElementClick(driver.findElement(By.xpath(s)),"Delete this row");
				
						
				}
				
				waitSleep(3000);
			} catch (Exception e) {
				e.printStackTrace();
				String excepionMessage = Arrays.toString(e.getStackTrace());
				BaseTest.log.error("Error on Scheduleappointment_Deleteappointment method " + excepionMessage);
				test.log(LogStatus.FAIL, "Error on Scheduleappointment_Deleteappointment method " + e);
				Assert.fail();
			}

	}
		public void Scheduleappointment_Createnew(Hashtable<String, String> data) {
			try {
				
				switchToFrame("PegaGadget1Ifr");
				waitSleep(5000);
				webElementSendText(Providername, data.get("Providername"), "Enter Providername");
				waitSleep(1500);
				webElementSendText(Typeandspecialty, data.get("Typeandspecialty"), "Enter Typeandspecialty");
				waitSleep(1500);
				webElementSendText(Zipcode, data.get("Zipcode"), "Enter Zip code");
				waitSleep(1500);
				selectDropdownValueByVisibleText(State, data.get("State"), "Select State");
				waitSleep(1500);
				selectDropdownValueByVisibleText(Appointmentoutcome, data.get("Appointmentoutcome"), "Appointment outcome(Required)");
				waitSleep(1500);
				selectDropdownValueByVisibleText(Appointmentreason, data.get("Appointmentreason"), "Appointment reason");
				waitSleep(1500);
				webElementClick(Submit, "Submit");
				waitSleep(1500);
				selectDropdownValueByVisibleText(State, data.get("State"), "Select State");
				waitSleep(1500);
				webElementSendText(comment, data.get("Comments"), "Comments");
				wait(500);
				webElementClick(Submit, "Submit");
				wait(2500);
			} catch (Exception e) {
				e.printStackTrace();
				String excepionMessage = Arrays.toString(e.getStackTrace());
				BaseTest.log.error("Error on Scheduleappointment_Createnew method " + excepionMessage);
				test.log(LogStatus.FAIL, "Error on Scheduleappointment_Createnew method " + e);
				Assert.fail();
			}

	}
		public void Createnew_Gsi(Hashtable<String, String> data) {
			
			try {
				switchToFrame("PegaGadget1Ifr");
				waitSleep(4500);
				selectDropdownValueByVisibleText(TypeOfInq, data.get("TypeOfInq"), "Type Of Inquiry");
				wait(2500);
				selectDropdownValueByVisibleText(Reason, data.get("Reason"), "Reason");
				wait(2500);
				selectDropdownValueByVisibleText(Resolution, data.get("Resolution"), "Resolution");
				wait(2500);
				webElementClick(Yes, "Yes");
			   webElementSendText(GSIcomment, data.get("Comments"), "Comments");
				
				
				webElementClick(Submit, "Submit");
				wait(2500);
				
			} catch (Exception e) {
				e.printStackTrace();
				BaseTest.log.error("Error on sortandSelectIntent method " + e);
				test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
				Assert.fail();
			}
		}
		
		public void selectClaim(Hashtable<String, String> data){
			try{
				List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l')]"));
				if(tableRows.size()>0)
				{
					for(int i=1;i<=tableRows.size();i++)
					{
						if(driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[5]//a")).getText().equals(data.get("ICN")))
						{
							WebElement reviewed=driver.findElement(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l"+i+"')]/td[1]//input[@type='checkbox']"));
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", reviewed);
							webElementClick(reviewed,"Reviewed");
							waitSleep(3500);
							webElementClick(addbutton, "addbutton");
							waitSleep(3500);
							webElementClick(Submit, "Submit");
							waitSleep(3500);
							break;
						}
					}
				}
				
			}catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on selectClaim method " + e);
				test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
				Assert.fail();
			}
		}
		
}


