package com.nasco.HMHS.TestScripts.G2.CreateFollowUp;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.utilities.DataProviders;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC009_CreateFollowUp_ScheduleAnotherFollowup extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC009_CreateFollowUp_ScheduleAnotherFollowup (Hashtable<String, String> data) throws Exception {
		createNewFollowup("HMHS_AUTC009_CreateFollowUp_ScheduleAnotherFollowup", data);

	}
	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_TC009_CreateFollowUp_ScheduleAnotherFollowup completed.");
		log.debug("HMHS_TC009_CreateFollowUp_ScheduleAnotherFollowup completed.");
		quit();
	}
}
