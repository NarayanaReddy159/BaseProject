package com.nasco.HMHS.TestScripts.G2.ResearchInteraction;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC008_ResearchInteraction_LandOnInteraction extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC008_ResearchInteraction_LandOnInteraction (Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC008_ResearchInteraction_LandOnInteraction");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC008_ResearchInteraction_LandOnInteraction - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC008_ResearchInteraction_LandOnInteraction -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSResearchInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		test.log(LogStatus.INFO,"Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page.");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.openInteractionPage();
		InteractionManager.openTask();	
		Member360Page mem360=homepage.Member360Page();
		log.debug("Navigate to Member 360 page.");
		InteractionManager.openTask();

		mem360.interactionsTab_Research();
        log.debug("Navigate to Interactions Tab.");
		test.log(LogStatus.INFO,"Navigate to Interactions Tab.");
		
		InteractionManager.addTask(data.get("Intent_1").toString());
        log.debug("Add Intent "+data.get("Intent_1"));
        test.log(LogStatus.INFO, "Add Intent "+data.get("Intent_1"));
       
        ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		test.log(LogStatus.INFO,"Intent id: " + intentID);
        
        InteractionManager.addTask(data.get("Intent_2").toString());
        log.debug("Add Intent "+data.get("Intent_2"));
        test.log(LogStatus.INFO, "Add Intent "+data.get("Intent_2"));
		
		String intentID1 = searchMember.getIntentIDWeb();
	    log.debug("Intent id: " + intentID1);
	    test.log(LogStatus.INFO,"Intent id: " + intentID1);

		//Perform End Research
		InteractionManager.EndResearchCancel();
		log.debug("Navigate to End Research screen.");
		test.log(LogStatus.INFO,"Navigate to End Research screen.");
		
		mem360.interactionsTab_Research();
        log.debug("Navigate to Interactions Tab.");
		test.log(LogStatus.INFO,"Navigate to Interactions Tab.");
		
		//Perform End Research
		InteractionManager.EndResearchOpen();
		log.debug("Navigate to End Research screen.");
		test.log(LogStatus.INFO,"Navigate to End Research screen.");		
		
		WorklistPage worklist = homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		log.debug("Navigated to the Worklist page.");
		test.log(LogStatus.INFO,"Navigated to the Worklist page.");
		worklist.sortandSelectIntent( intentID);
		System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(LogStatus.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		worklist.IntentStatusWorklist(data.get("IntentStatusWork"), "PegaGadget1Ifr");
		log.debug("Check the worklist Intent Status checked.");
		test.log(LogStatus.INFO,"Check the worklist Intent Status checked.");
		worklist.WorklistComments(intentID, data);
		log.debug("Enter the worklist comments and Submit.");
		test.log(LogStatus.INFO,"Enter the worklist comments and Submit.");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork.");
		test.log(LogStatus.INFO,"Navigated to the Recentwork.");
		recentWork.sortandSelectIntent( intentID);
		System.out.println("Sorted and selected interaction " + intentID + " from recent work tab.");
		log.debug("Sorted and selected interaction " + intentID + " from recent work tab.");
		test.log(LogStatus.INFO,"Sorted and selected interaction " + intentID + " from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(LogStatus.INFO,"Check the intent status.");
		recentWork.closeRecentwork();
		
		WorklistPage worklist1 = homepage.openrecentWorklist();
		worklist1.movetoWorklistPage();
		log.debug("Navigated to the Worklist page.");
		test.log(LogStatus.INFO,"Navigated to the Worklist page.");
		worklist1.sortandSelectIntent( intentID1);
		System.out.println("Sorted and selected intent " + intentID1 + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID1 + " from recent work tab.");
		test.log(LogStatus.INFO,"Sorted and selected intent " + intentID1 + " from recent work tab.");
		worklist1.IntentStatusWorklist(data.get("IntentStatusWork"), "PegaGadget1Ifr");
		log.debug("Check the worklist Intent Status checked.");
		test.log(LogStatus.INFO,"Check the worklist Intent Status checked.");
		worklist1.WorklistWeb();
		log.debug("Select the type of inq, Reason, Resolution.");
		test.log(LogStatus.INFO,"Select the type of inq, Reason, Resolution.");
		worklist1.WorklistComments(intentID1, data);
		log.debug("Enter the worklist comments and Submit.");
		test.log(LogStatus.INFO,"Enter the worklist comments and Submit.");
		
		
		RecentWorkPage recentWork1 = homepage.openrecentWork();
		recentWork1.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork.");
		test.log(LogStatus.INFO,"Navigated to the Recentwork.");
		recentWork1.sortandSelectIntent( intentID1);
		System.out.println("Sorted and selected interaction " + intentID1 + " from recent work tab.");
		log.debug("Sorted and selected interaction " + intentID1 + " from recent work tab.");
		test.log(LogStatus.INFO,"Sorted and selected interaction " + intentID1 + " from recent work tab.");
		recentWork1.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(LogStatus.INFO,"Check the intent status.");
		
	}

	@AfterMethod
	public void tearDown() {
		test.log(LogStatus.INFO, "HMHS_TC008_ResearchInteraction_LandOnInteraction completed.");
		log.debug("HMHS_TC008_ResearchInteraction_LandOnInteraction completed.");
		quit();

	}
}
