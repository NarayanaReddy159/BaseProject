package com.nasco.HMHS.TestScripts.G1;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class LI_Flow_LogOut extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void AUTC_LI_Flow_LogOut(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		
		test=DriverManager.getExtentReport();
		log.info("Inside LI_Flow_LogOut");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("LI_Flow_LogOut - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("LI_Flow_LogOut -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String intentID=searchMember.getLIInteractionID();
		log.debug("Interaction id: "+intentID);
		searchMember.ExitInteraction();
		log.debug("Moved to Exit Interaction page");
		searchMember.WrapUpSubmit( data.get("Comments"));
		log.debug("Comments submitted");
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetomyWorkLogout();
		log.debug("Able to log out from MyWork screen successsfully");

	}
	@AfterMethod
	public void tearDown() {
		test.log(LogStatus.INFO, "From My Work screen successfully able to logout (TRAIN00120413)");
		log.debug("From My Work screen successfully able to logout (TRAIN00120413)");
		quit();
		
	}
}
