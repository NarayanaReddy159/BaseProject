package com.nasco.HMHS.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.Setup.BasePage;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings("rawtypes")
public class LoginPage extends BasePage {

	// Log in page Fields
	// user Name text box
	@FindBy(id = "username")
	public WebElement txtUserName;
	// Password text box
	@FindBy(id = "password")
	public WebElement txtPassword;
	
	// submit-button
	@FindBy(xpath = "//form/div[4]/span/input")
	public WebElement btnLoginMO;

	@FindBy(id = "submit-button")
	public WebElement btnLoginDev;
	
	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;
	@FindBy(xpath = "(//a[@class='Header_nav'])[3]")
	public WebElement MenuDropdown;
	@FindBy(xpath = "//span[contains(text(),'Logout')]")
	public WebElement LogOut;

	// open login page
	@SuppressWarnings("unchecked")
	public LoginPage open(String url) {

		System.out.println("Page Opened" + url);
		BaseTest.log.info("Driver Initialized !!!");
		DriverManager.getDriver().navigate().to(url);
		BaseTest.log.info("Navigated to URL:" + url);
		test.log(LogStatus.INFO, "Navigated to URL:" + url);
		return (LoginPage) openPage(LoginPage.class);
	}

	
	public void Redirect(String url) {

		System.out.println("Page Opened" + url);
		BaseTest.log.info("Driver Initialized !!!");
		DriverManager.getDriver().navigate().to(url);
		BaseTest.log.info("Navigated to URL:" + url);
		test.log(LogStatus.INFO, "Navigated to URL:" + url);
	}
	
	// Login to application as valid user

	@SuppressWarnings("unchecked")
	public HomePage doLoginAsValidUser(String username,String password) {

		try {

			webElementSendText(txtUserName, username, "User Name");
			webElementSendText(txtPassword, password, "Password");
			if (RunTestNG_NCompass_HMHS.Config.getProperty("Environment").toString().equalsIgnoreCase("MO")) {
				webElementClick(btnLoginMO, "Login");
			} else if (RunTestNG_NCompass_HMHS.Config.getProperty("Environment").toString().equalsIgnoreCase("DEV")) {
				webElementClick(btnLoginDev, "Login");
			}
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on doLoginAsValidUser method " + e);
			test.log(LogStatus.FAIL, "Error on doLoginAsValidUser method " + e);
			Assert.fail();
		}

		return (HomePage) openPage(HomePage.class);
	}

	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txtPassword);
	}

}
