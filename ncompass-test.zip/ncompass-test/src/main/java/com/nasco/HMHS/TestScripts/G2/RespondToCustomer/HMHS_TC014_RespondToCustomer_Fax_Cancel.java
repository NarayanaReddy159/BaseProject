package com.nasco.HMHS.TestScripts.G2.RespondToCustomer;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.RespondToCustomerPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC014_RespondToCustomer_Fax_Cancel extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC014_RespondToCustomer_Fax_Cancel (Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC014_RespondToCustomer_Fax_Cancel");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC014_RespondToCustomer_Fax_Cancel - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC014_RespondToCustomer_Fax_Cancel -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed.");
		test.log(LogStatus.INFO,"MMember Search Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(LogStatus.INFO,"Member Submit Completed.");
		
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(LogStatus.INFO,"Member Verified successfully.");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(LogStatus.INFO,"Add Intent "+data.get("Intent"));
        
        String intentID = searchMember.getIntentID();
		log.debug("Intent id: " + intentID);
        RespondToCustomerPage RTC = homepage.RespondToCustomerIntentFax();
        RTC.RespondToCustomerIntentFaxID( intentID,data);
		log.debug("Navigate to Respond to Customer intent screen to add task against Fax method.");
		test.log(LogStatus.INFO,"Navigate to Respond to Customer intent screen to add task against Fax method.");
		
		InteractionManagerPage canceltask = searchMember.cancelIntent();
	    canceltask.cancelIntent( intentID,data);
		log.debug("to cancel the intent.");
		test.log(LogStatus.INFO,"to cancel the intent.");
		canceltask.wrapUp(data.get("Comments"));
		log.debug("Wrapping up the intent.");
		test.log(LogStatus.INFO,"Wrapping up the intent.");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Home-Recentwork Section");
		test.log(LogStatus.INFO,"Navigated to the Home-Recentwork Section");
		recentWork.sortandSelectIntent( intentID);
		System.out.println("Sorted and selected intent " + intentID + " from recent work tab.");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(LogStatus.INFO,"Check the intent status.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(LogStatus.INFO,"Check the intent status.");
	}
	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_TC014_RespondToCustomer_Fax_Cancel completed.");
		log.debug("HMHS_TC014_RespondToCustomer_Fax_Cancel completed.");
		quit();

	}
}
