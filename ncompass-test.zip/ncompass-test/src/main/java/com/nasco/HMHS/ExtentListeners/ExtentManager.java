package com.nasco.HMHS.ExtentListeners;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {
	private static ExtentReports extent;
	public static String fileName;
	public static String logFileName;

	public static ExtentReports getInstance() {

		if (extent == null) {
			Date d = new Date();
			fileName = "NCompass_HMHS_ExtentReport" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
			logFileName = System.getProperty("user.dir") + "src/test/resources/logs/Application"
					+ d.toString().replace(":", "_").replace(" ", "_") + ".log";
			extent = new ExtentReports(System.getProperty("user.dir")
					+ RunTestNG_NCompass_HMHS.Config.getProperty("EXTREPORT_LOC") + fileName, true,
					DisplayOrder.OLDEST_FIRST);
			extent.loadConfig(new File(
					System.getProperty("user.dir") + RunTestNG_NCompass_HMHS.Config.getProperty("EXTREPORTCONFIG")));
		}

		return extent;

	}
	public static String screenshotPath;
	public static String screenshotName;

	public static void captureScreenshot(String testCaseName) {

		File scrFile = ((TakesScreenshot) DriverManager.getDriver()).getScreenshotAs(OutputType.FILE);
		Date d = new Date();
		screenshotName = testCaseName + "_" + d.toString().replace(":", "_").replace(" ", "_") + ".jpg";
		try {
			FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")
					+ RunTestNG_NCompass_HMHS.Config.getProperty("EXTREPORT_LOC") + screenshotName));
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
}
