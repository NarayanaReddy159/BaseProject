package com.nasco.HMHS.TestScripts.G2.ManageClaims;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.ManageClaimsPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.OtherActions;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Pages.WorkbasketPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC006_ManageClaims_RouteToWorkbasket extends BaseTest{
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC006_ManageClaims_RouteToWorkbasket(Hashtable<String, String> data) throws Exception {
		
		String methodName="HMHS_AUTC004_ManageClaims_savetoworklis";
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser :  " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username4"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password4"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username4") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password4"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username4")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password4"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
		log.debug("Add Intent "+data.get("Intent"));
		ManageClaimsPage manageClaim=InteractionManager.openManageClaims();
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		test.log(LogStatus.INFO,"Intent id: " + intentID);
		manageClaim.searchClaims(data);
		log.debug("Navigate to Search for claim screen.");
		test.log(LogStatus.INFO,"Navigate to Search for claim screen. ");
		manageClaim.selectClaim(data);
		manageClaim.adjust();
		log.debug("User selected the claim screen.");
		test.log(LogStatus.INFO,"User selected the claim screen. ");
		OtherActions otherActions=homepage.openOtherActions();
		log.debug("Click on otherAction button.");
		test.log(LogStatus.INFO,"Click on otherAction button. ");
		otherActions.routeToWorkbasket(data);
		log.debug("Click on routeToWorkbasket button.");
		test.log(LogStatus.INFO,"Click on routeToWorkbasket button. ");
		InteractionManager.openTask();
		log.debug("Click on openTask button.");
		test.log(LogStatus.INFO,"Click on openTask button. ");
		
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		test.log(LogStatus.INFO,"Navigate to Wrap up screen. ");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		WorkbasketPage workbasket =homepage.openrecentWorkbasket();
		workbasket.movetoWorkbasketPage();
		log.debug("Click to WorkbasketPage screen");
		test.log(LogStatus.INFO,"Click to WorkbasketPage screen. ");
		workbasket.Workbasketcheck(data);
		log.debug("select the Workbasket");
		test.log(LogStatus.INFO,"select the Workbasket. ");
		workbasket.sortandSelectIntent(intentID);
		System.out.println("Sorted and selected intent " + intentID + " from workbasket tab ");
		log.debug("Sorted and selected intent " + intentID + " from workbasket tab ");
		test.log(LogStatus.INFO, "Sorted and selected intent " + intentID + " from workbasket tab ");
		recentWork.contractInformation(data);
		log.debug("Check the contract Information.");
		test.log(LogStatus.INFO, "Check the contract Information.");
		recentWork.Commentssummary("PegaGadget1Ifr", data);
		log.debug("Check the Comments summary.");
		test.log(LogStatus.INFO, "Check the Comments summary.");
		otherActions.cancelWork(data);
		log.debug("In worklist the intent is cancel the work.");
		test.log(LogStatus.INFO, "In worklist the intent is cancel the work.");
	}
	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_AUTC006_ManageClaims_RouteToWorkbasket Completed.");
		log.debug("HMHS_AUTC006_ManageClaims_RouteToWorkbasket Completed.");
		quit();
	}

}
