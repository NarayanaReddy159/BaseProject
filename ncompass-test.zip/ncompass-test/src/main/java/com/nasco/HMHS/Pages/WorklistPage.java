package com.nasco.HMHS.Pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings({"rawtypes","unchecked"})
public class WorklistPage extends BasePage {

	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	
	@FindBy(xpath = "//span[contains(text(),'Home')]")
	public WebElement Home;

	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;

	@FindBy(xpath = "//h3[contains(text(),'Recent work')]")
	public WebElement recentWork;

	@FindBy(xpath = "(//*[@id='pui_filter'])[2]")
	public WebElement idSort;
	@FindBy(xpath = "//input[@id='29595b80']")
	public WebElement searchID;
	@FindBy(xpath = "//input[@id='e726b0d0']")
	public WebElement VerifyDOB;
	
	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	public WebElement applyBtn;
	@FindBy(xpath = "//*[@id='$PpgRepPgSubSectionpyUserWorkListBB$ppxResults$l1']/td[2]/div/span/a")
	public WebElement intentclick;
	@FindBy(xpath = "//span[contains(text(),'Status')]//following::div[1]")
	public WebElement IntentStatus;
	@FindBy(xpath = "(//a[@class='Header_nav'])[3]")
	public WebElement MenuDropdown;
	@FindBy(xpath = "//span[contains(text(),'Logout')]")
	public WebElement LogOut;
	//@FindBy(xpath = "//h3[contains(text(),'Worklist')]")
	//@FindBy(xpath = "//div[5]/div[1]/h3/text()")
    //@FindBy(xpath= "//div[@class='header']//h3[contains(text(),'Worklist')]")
    //public WebElement worklist;
	
	@FindBy(xpath= "//h3[contains(text(),'Worklist')]")
	public WebElement worklist; 
	
	@FindBy(xpath = "//button[contains(text(),'+ Create new work')]")
	public WebElement CreateNewWork;
	
	@FindBy(xpath = "//select[@id='0b372c42']")
	public WebElement attempt;
	@FindBy(xpath = "//div[2]/div[1]/div[1]/div[1]/span[1]/img[1]")
	public WebElement SelectDate;
	@FindBy(xpath = "//a[contains(text(),'24')]")
	public WebElement SelectDay;
	@FindBy (how = How.XPATH, using = "//textarea[@id='ebea7f57']")
	public WebElement AttemptComments;
	@FindBy (how = How.XPATH, using = "//select[@id='StartTime']")
	public WebElement StartTime;
	@FindBy (how = How.XPATH, using = "//div[contains(text(),'Recommended number of callback attempts reached. Prior to selecting submit, navigate to the create new work button and select respond to customer to send correspondence.')]")
	public WebElement LimitMsgCheck;
	
	@FindBy(xpath = "//button[@title='Other actions']")
	public WebElement OtherActions;
	@FindBy(xpath = "//span[text()='Save to Worklist']")
	public WebElement SaveToWorklist;
	@FindBy(xpath = "//select[@id='8b0fe3a6']")
	public WebElement ReasonToPend;
	@FindBy (how = How.XPATH, using = "//textarea[@id='5e1978c7']")
	public WebElement Comments;
	@FindBy (how = How.XPATH, using = "//textarea[@name='$PpyWorkPage$pWrapUpComments']")
	public WebElement WorkComments;
	@FindBy (how = How.XPATH, using = "//textarea[@id='16914509']")
	public WebElement MsgComments;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Route to Team')]")
	public WebElement RouteToTeam;
	@FindBy(xpath = "//div[1]/div[1]/div[1]/span[1]/label[1]")
	public WebElement TeamMemWork;
	
	@FindBy(xpath = "//label[contains(text(),'Workbasket')]")
	public WebElement WorkBasket;
	@FindBy(xpath = "//input[@id='9c5eeb90']")
	public WebElement TransferTo;
	
	@FindBy(xpath = "//input[@id='d621496c']")
	public WebElement Operator;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Document Follow-Up Task Resolution')]")
	public WebElement GoBackFollowUp;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'+ Create new work')]")
	public WebElement CeateNewWork;
	@FindBy(how = How.XPATH, using = "//a//span[contains(text(),'Create Follow Up')]")
	public WebElement CreateFollowUp;
	@FindBy(how = How.XPATH, using = "//a//span[contains(text(),'Respond to Customer')]")
	public WebElement CreateRTC;
	@FindBy(how = How.XPATH, using = "//a//span[contains(text(),'Request ID Card')]")
	public WebElement CreateReqIDCard;
	@FindBy (how = How.XPATH, using = "//button[contains(text(),'Next')]")
	public WebElement Next;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'There is a limit of one ID card request allowed in')]")
	public WebElement WarningMsg1;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'You are requesting more than limit of 3 cards/sets')]")
	public WebElement WarningMsg3;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'The contract has a future cancellation date. Pleas')]")
	public WebElement WarningMsg5;
	@FindBy (how = How.XPATH, using = "//input[@id='80a4df31']")
	public WebElement WarningCheck1;
	@FindBy (how = How.XPATH, using = "//input[@id='ab898cf2']")
	public WebElement WarningCheck2;
	@FindBy(xpath = "//span[contains(text(),'Type of inquiry')]//following::span[1]")
	public WebElement typeofinquiry;
	@FindBy(xpath = "//span[contains(text(),'Reason')]//following::span[1]")
	public WebElement reason;
	@FindBy(xpath = "//span[contains(text(),'Resolution')]//following::span[1]")
	public WebElement resolution;
	@FindBy(xpath = "//label[contains(text(),'Resolve')]")
	public WebElement Resolve;
	@FindBy(xpath = "//select[@name='$PpyWorkPage$pInquiriesList$l1$pInquiryType']")
	public WebElement TypeofInq;
	@FindBy(xpath = "//select[@name='$PpyWorkPage$pInquiriesList$l1$pInquiryReason']")
	public WebElement Reason;
	@FindBy(xpath = "//select[@name='$PpyWorkPage$pInquiriesList$l1$pInquiryResolution']")
	public WebElement Resolution;
	
	public void movetoWorklistPage() throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			webElementClick(myWorkIcon, "My Work");
			waitSleep(2000);
			webElementClick(recentWork, "RecentWork tab");
			waitSleep(2000);
			webElementClick(worklist, "Worklist tab"); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Worklist method " + e);
			test.log(LogStatus.FAIL, "Error on Worklist method " + e);
			Assert.fail();
		}
	}	
	
	public void movetoHome() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget0Ifr");
			waitSleep(1500);
			webElementClick(Home, "Home");
			waitSleep(3000);
			webElementClick(myWorkIcon, "My Work");
			waitSleep(2000);
			webElementClick(recentWork, "RecentWork tab");
		} catch (Exception e) {
			BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
			test.log(LogStatus.FAIL, "Error on movetoRecentWorkPage method " + e);
			Assert.fail();
		}
	}

	// HMHS Sort and Select Intent
	public void sortandSelectIntent( String intentID) {
		try {
			switchToFrame("PegaGadget0Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(idSort));
			webElementClick(idSort, "ID Sort");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
			webElementSendText(searchID, intentID, "Search Intent");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(applyBtn));
			try{
				webElementClick(applyBtn, "Apply");
				waitSleep(3500);
				}
				catch(StaleElementReferenceException e){
					webElementClick(applyBtn, "Apply");
				}
			//waitForPageToLoad(ExpectedConditions.elementToBeClickable(intentclick));
			try{
				intentclick.click();
			//	webElementClick(intentclick, "Intent " + intentID);
				}
				catch(StaleElementReferenceException e){
					intentclick.click();
				//	webElementClick(intentclick, "Intent " + intentID);
				}
			waitSleep(2500);
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
	}
	
//Below method written for TC005_CreateFollowup_SaveToWorklist after opening intent on Worklist click on Other action.
	public void OtherActionsSaveToWorklist( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			webElementClick(OtherActions, "to click on Other Actions");
			wait(3000);
			webElementClick(SaveToWorklist, "Save To Worklist");
			wait(3000);
			selectDropdownValueByVisibleText(ReasonToPend, data.get("ReasonToPend"), "to select Reason to Pend");
			wait(1500);
			webElementSendText(Comments, data.get("comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsSaveToWorklist method " + e);
			test.log(LogStatus.FAIL, "Error on OtherActionsSaveToWorklist method " + e);
			Assert.fail();
		}
	}
	
	public void WorklistComments( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(2500);
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(Comments));
			webElementSendText(Comments, data.get("Worklistcomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorklistComments & then Submit it." + e);
			test.log(LogStatus.FAIL, "Error on WorklistComments & then Submit it." + e);
			Assert.fail();
		}
	}

	public void WorklistCommentsReqID( String intentID, Hashtable<String, String> data, String WarMsg1,String WarMsg5) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(Comments));
			webElementSendText(Comments, data.get("Worklistcomments"), "as Comments");
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			System.out.println("Land on Review ID Card Request page");
			wait(3500);
			try{
				WarningCheck1.click();
			}
			catch(Exception e1)
			{
				
			}
			 wait(1500);
			 try{
				 WarningCheck2.click();
				 wait(3000);
				}
				catch(Exception e){
				}
			  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Submit); 
			  webElementClick(Submit, "Submit");
			  wait(3000);
			  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Submit); 
			  webElementClick(Submit, "Submit");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorklistComments & then Submit it." + e);
			test.log(LogStatus.FAIL, "Error on WorklistComments & then Submit it." + e);
			Assert.fail();
		}
	}
	
	public void WorklistCommentsReqIDNoFut( String intentID, Hashtable<String, String> data, String WarMsg1,String WarMsg5) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(Comments));
			webElementSendText(Comments, data.get("Worklistcomments"), "as Comments");
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			System.out.println("Land on Review ID Card Request page");
			wait(2500);
			try{
				WarningCheck1.click();
				wait(1500);
				
			}catch(Exception e)
			{
				
			}
			 wait(1500);
			 try{
				 WarningCheck2.click();
				 wait(1500);
				}
				catch(Exception e){
				}
			  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Submit); 
			  webElementClick(Submit, "Submit");
			  wait(3000);
			  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Submit); 
			  webElementClick(Submit, "Submit");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorklistComments & then Submit it." + e);
			test.log(LogStatus.FAIL, "Error on WorklistComments & then Submit it." + e);
			Assert.fail();
		}
	}
	
	public void MSGWorklistComments( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(MsgComments));
			webElementSendText(MsgComments, data.get("Worklistcomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorklistComments & then Submit it." + e);
			test.log(LogStatus.FAIL, "Error on WorklistComments & then Submit it." + e);
			Assert.fail();
		}
	}
	
	public void OtherActionsRouteToTeam( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			webElementClick(OtherActions, "to click on Other Actions");
			wait(3000);
			webElementClick(RouteToTeam, "Save To Worklist");
			wait(1500);
			webElementClick(TeamMemWork, "to select the Team Member's Worklist");
			wait(2000);
			webElementSendText(Operator, data.get("Operator"), "to select another Operator");
			wait(1500);
			Operator.sendKeys(Keys.TAB);
			wait(2000);
			webElementSendText(Comments, data.get("Routecomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsSaveToWorklist method " + e);
			test.log(LogStatus.FAIL, "Error on OtherActionsSaveToWorklist method " + e);
			Assert.fail();
		}
	}

	public void OtherActionsRouteToTeamWB( String intentID, Hashtable<String, String> data) {
		try {
			wait(4000);
			switchToFrame("PegaGadget1Ifr");
			wait(2000);
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			webElementClick(OtherActions, "to click on Other Actions");
			wait(3000);
			webElementClick(RouteToTeam, "to Route To team");
			wait(1500);
			webElementClick(WorkBasket, "to select the Workbasket option to transfet the intent");
			wait(2000);
			webElementSendText(TransferTo, data.get("TransferWB"), "to select another Operator");
			wait(2000);
			webElementSendText(Comments, data.get("Routecomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsSaveToWorklist method " + e);
			test.log(LogStatus.FAIL, "Error on OtherActionsSaveToWorklist method " + e);
			Assert.fail();
		}
	}

	//From Worklist click on SaveToWorklist and again from SaveToWorklist go back to CreateFollowUp
		public void OtherActionsSaveToWorklistBack( String intentID, Hashtable<String, String> data) {
			try {
				switchToFrame("PegaGadget1Ifr");
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
				webElementClick(OtherActions, "to click on Other Actions");
				wait(1500);
				webElementClick(SaveToWorklist, "Save To Worklist");
				wait(1500);
				test.log(LogStatus.INFO, "User land on SaveToWorklist page");
				wait(1500);
				webElementClick(OtherActions, "to click on Other Actions");
				wait(1500);
				webElementClick(GoBackFollowUp, "to click on Document Follow-Up Task Resolution from Other actions to go back to Followup page");
				test.log(LogStatus.INFO, "Go Back to Create FollowUp page");
			} catch (Exception e) {
				e.printStackTrace();
				BaseTest.log.error("Error on OtherActionsSaveToWorklistBack method " + e);
				test.log(LogStatus.FAIL, "Error on OtherActionsSaveToWorklistBack method " + e);
				Assert.fail();
			}
		}
	
	//After opening intent on Worklist click on CreateNewWork
 public void CreateNewWork( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(CreateNewWork, "to Create New Work");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CreateNewWork method " + e);
		test.log(LogStatus.FAIL, "Error on CreateNewWork method " + e);
		Assert.fail();
	}
 }			
		
		
//To select the CreateFollowup Intent from +CreateNew Work list
 public void CreateNewWorkFollowup( String intentID, Hashtable<String, String> data) {
	try {
			switchToFrame("PegaGadget1Ifr");
			webElementClick(CreateFollowUp, "to select Create FollowUp");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on CreateNewWorkFollowup method " + e);
			test.log(LogStatus.FAIL, "Error on CreateNewWorkFollowup method " + e);
			Assert.fail();
		}
	 }		
				
//To select the CreateFollowup Intent from +CreateNew Work list
public void CreateNewWorkRTC( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(CreateRTC, "to select Respond To Customer");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CreateNewWorkRTC method " + e);
		test.log(LogStatus.FAIL, "Error on CreateNewWorkRTC method " + e);
		Assert.fail();
	}
}


//To select the CreateNewWorkReqID card Intent from +CreateNew Work list
public void CreateNewWorkReqIDCard( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(1500);
		webElementClick(CreateReqIDCard, "to select Request ID Card");
		wait(1500);
		//webElementClick(BackTab, "Go Back to previous intent");
		//wait(1500);
		//webElementSendText(WorkComments,data.get("Workcomments"), "Go Back to previous intent");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CreateNewWorkReqIDCard method " + e);
		test.log(LogStatus.FAIL, "Error on CreateNewWorkReqIDCard method " + e);
		Assert.fail();
	}
}

//Go to Home page
public void GoToHome( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(Home, "to Go to Home page");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CreateNewWorkRTC method " + e);
		test.log(LogStatus.FAIL, "Error on CreateNewWorkRTC method " + e);
		Assert.fail();
	}
}
	
		
		
//Below method written for TC005_CreateFollowup_SaveToWorklist after opening intent on Worklist click on Other action.
	public void FollowUpUnsuccessAttempt( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			//String month="Dec";
			String date="28";
			selectDropdownValueByVisibleText(attempt, data.get("followupUnsuccess"), "to select reason of followup");
			wait(2000);
			webElementClick(SelectDate, "to select the date");
			Thread.sleep(2000);
//				while(true)
//				{
//					wait(3500);
//					String text=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/span[1]/input[1]")).getText();
//					if(text.equals(month))
//					{
//						break;
//					}
//					else{
//					driver.findElement(By.xpath("//tbody/tr[1]/td[1]/span[1]/span[1]/button[1]")).click();
//					}
//				}
			wait(1500);
			driver.findElement(By.xpath("//tbody/tr/td/a[contains(text(),"+date+")]")).click();;
			//webElementClick(SelectDay, "to select the day");
			wait(1500);
			webElementSendText(AttemptComments, data.get("followupcomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActions method " + e);
			test.log(LogStatus.FAIL, "Error on OtherActions method " + e);
			Assert.fail();
		}
	}	

public void FollowUpAttemptSuccess( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			selectDropdownValueByVisibleText(attempt, data.get("followupSuccess"), "to select reason of followup");
			wait(2000);
			webElementSendText(AttemptComments, data.get("followupsuccesscomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActions method " + e);
			test.log(LogStatus.FAIL, "Error on OtherActions method " + e);
			Assert.fail();
		}
	}

		
//Below method written for TC005_CreateFollowup_SaveToWorklist after opening intent on Worklist click on Other action.
public void CallbackAttempt( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(VerifyDOB, "Verify DOB");
		wait(1000);
		selectDropdownValueByVisibleText(attempt, data.get("Resolution"), "to select reason of callback");
		try{
			wait(1000);
			webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
			catch(StaleElementReferenceException e){
				wait(1000);
				webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
		wait(1500);
		selectDropdownValueByVisibleText(StartTime, data.get("startTime"), "to select start time for callback");
		wait(1500);
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on OtherActions method " + e);
		test.log(LogStatus.FAIL, "Error on OtherActions method " + e);
		Assert.fail();
	}
}

public void CallbackAttemptSub( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(VerifyDOB, "Verify DOB");
		wait(1000);
		selectDropdownValueByVisibleText(attempt, data.get("Resolution"), "to select reason of callback");
		try{
			wait(1000);
			webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
			catch(StaleElementReferenceException e){
				wait(1000);
				webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
		wait(1500);
		selectDropdownValueByVisibleText(StartTime, data.get("startTime"), "to select start time for callback");
		wait(1500);
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on OtherActions method " + e);
		test.log(LogStatus.FAIL, "Error on OtherActions method " + e);
		Assert.fail();
	}
}

public void CallbackAttemptDiff( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(VerifyDOB, "Verify DOB");
		wait(1000);
		selectDropdownValueByVisibleText(attempt, data.get("Resolution"), "to select reason of callback");
		try{
			wait(1000);
			webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
			catch(StaleElementReferenceException e){
				wait(1000);
				webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
		wait(1500);
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on OtherActions method " + e);
		test.log(LogStatus.FAIL, "Error on OtherActions method " + e);
		Assert.fail();
	}
}

public void LimitMsg( String intentID, Hashtable<String, String> data,String LimitMsg) {
	try {
		switchToFrame("PegaGadget1Ifr");
		selectDropdownValueByVisibleText(attempt, data.get("Resolution"), "to select reason of callback");
		String ActualMessage = webElementReadText(LimitMsgCheck);
		//String ExpectedNotRegMsg = String.format(LimitMsg);
		 if (ActualMessage.contains(LimitMsg)) {
			test.log(LogStatus.PASS, "Recommended number of callback attempt message matched.");
			test.log(LogStatus.PASS,"Expected Message: "+' '+LimitMsg);
			test.log(LogStatus.PASS,"Actual Message: "+' '+ActualMessage);
		 } else {
			test.log(LogStatus.FAIL, "Recommended number of callback attempt message not matched.");
			test.log(LogStatus.PASS,"Expected Message: "+' '+LimitMsg);
			test.log(LogStatus.PASS,"Actual Message: "+' '+ActualMessage);
			Assert.fail();
		 }
		
		
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Recommended number of callback attempts reached  method " + e);
		test.log(LogStatus.FAIL, "Error on Recommended number of callback attempts reached method " + e);
		Assert.fail();
	}
}


// HMHS IntentStatus

public void IntentStatusWorklist( String IntStatus, String frame) {
try {
	wait(2500);
	switchToFrame(frame);
	String actualMessage = webElementReadText(IntentStatus);
	String expected = String.format(IntStatus);
	if (actualMessage.contains(expected)) {
		test.log(LogStatus.PASS, "Intent status is matched");
		test.log(LogStatus.PASS,"Actual Intent status is: "+' '+actualMessage);
		test.log(LogStatus.PASS,"Expected Intent status is: "+' '+expected);
	} else {
		test.log(LogStatus.FAIL, "Intent status is not matched");
		test.log(LogStatus.PASS,"Actual Intent status is: "+' '+actualMessage);
		test.log(LogStatus.PASS,"Expected Intent status is: "+' '+expected);
		Assert.fail();
	}
} catch (Exception e) {
	e.printStackTrace();
	String excepionMessage = Arrays.toString(e.getStackTrace());
	BaseTest.log.error("Error on IntentStatus method " + excepionMessage);
	test.log(LogStatus.FAIL, "Error on IntentStatus method " + e);
	Assert.fail();
}
}

// HMHS User will move to My Work and Recent Work page

public void movetomyWorkLogout() {
try {
	waitSleep(3000);
	switchToFrame("PegaGadget0Ifr");
	webElementClick(myWorkIcon, "My Work");
	waitSleep(2000);
	switchToDefault();
	webElementClick(MenuDropdown, "Menu Dropdown");
	waitSleep(3500);
	webElementClick(LogOut, "Log Out");
	driver.switchTo().alert().accept();

} catch (Exception e) {
	e.printStackTrace();
	BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
	test.log(LogStatus.FAIL, "Error on movetoRecentWorkPage method " + e);
	Assert.fail();
}
}

public void CreateNewWork(Hashtable<String, String> data) {
try {
	waitSleep(3000);
	switchToFrame("PegaGadget1Ifr");
	webElementClick(CreateNewWork, "Create New Work");
	waitSleep(2000);
	selectDropdownValueByVisibleText(CreateNewWork,data.get("CreateNewWork"), "Method of Response as Mail");
	wait(1500);
} catch (Exception e) {
	e.printStackTrace();
	BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
	test.log(LogStatus.FAIL, "Error on movetoRecentWorkPage method " + e);
	Assert.fail();
}
}

@Override
protected ExpectedCondition getPageLoadCondition() {
switchToFrame("PegaGadget0Ifr");
return ExpectedConditions.visibilityOf(myWorkIcon);
}

@FindBy(xpath = "//button[@title='Other actions']")
public WebElement otherActions;

@FindBy(xpath = "//span[contains(text(),'Cancel Work')]")
public WebElement cancelWork;

@FindBy(name = "$PpyWorkPage$pWrapUpComments")
public WebElement comments;

public void cancelWorkFortesting(int row)
{
	String intentid=webElementReadText(driver.findElement(By.xpath("//*[@id='$PpgRepPgSubSectionpyUserWorkListBB$ppxResults$l"+row+"']/td[2]/div/span/a")), "Intent ");
	String member=webElementReadText(driver.findElement(By.xpath("//*[@id='$PpgRepPgSubSectionpyUserWorkListBB$ppxResults$l1']/td[8]")), "Member ");
	System.out.println("Member: "+member);
	webElementClick(driver.findElement(By.xpath("//*[@id='$PpgRepPgSubSectionpyUserWorkListBB$ppxResults$l"+row+"']/td[2]/div/span/a")), "Intent ");
	switchToFrame("PegaGadget1Ifr");
	if(intentid.contains("FOL"))
	{
	selectDropdownValueByVisibleText(driver.findElement(By.name("$PpyWorkPage$pCallbackResolution")), 
			"Successful", "Attempt");
	waitSleep(2500);
	webElementSendText(driver.findElement(By.xpath("//label[text()='Comments']//following::textarea[1]")), "Test", "Comments");
	webElementClick(Submit, "Submit");
	}if(intentid.contains("LVI"))
	{
		if(!member.equals(""))
		{
			waitSleep(3500);
			webElementClick(driver.findElement(By.xpath("//i[contains(@name,'CPMInteractionDriver_D_Interaction') and @title='Wrap up']")), "Wrap Up");
			waitSleep(1500);
			webElementClick(driver.findElement(By.xpath("//div[contains(text(),'Submit')]//ancestor::button")), "Submit");
			waitSleep(1500);
		}else{
			webElementClick(otherActions, "Other Actions");
			waitSleep(1500);
			try{
				driver.findElement(By.xpath("//span[contains(text(),'Wrap Up, Member Not Found')]")).click();
				waitSleep(1500);
				selectDropdownValueByVisibleText(driver.findElement(By.name("$PpyWorkPage$pReasonForInteraction")), 
						"General Inquiry", "Attempt");
				waitSleep(1500);
			}
			catch(Exception e1)
			{
				driver.findElement(By.xpath("//span[contains(text(),'Wrap Up, Contact Not Verified')]")).click();
				waitSleep(1500);
			}
			
			webElementClick(Submit, "Submit");
		}
		
	}
	
	else{
		webElementClick(otherActions, "Other Actions");
		waitSleep(1500);
		webElementClick(cancelWork, "cancelWork");
		waitSleep(1000);
		webElementClick(Submit, "Submit");	
		waitSleep(3500);	
	}
}
public void contractInformation(Hashtable<String,String> data) 
{
	String Contractinformation ="";
	try{
		
		switchToFrame("PegaGadget1Ifr");
		List<String> headerRow= new ArrayList<String>();
        headerRow.add("Subscriber name");
        headerRow.add("Group number");
        headerRow.add("UMI");
        headerRow.add("Group name");
        


        ArrayList<String> rowData= new ArrayList<String>();
                                for(int j=0;j<headerRow.size();j++)
                                {											
                                rowData.add(driver.findElement(By.xpath("(//div[contains(@class,'layout-body clearfix layout-body clearfix')])[2]//span[contains(text(),'"+headerRow.get(j)+"')]/following::div[1]")).getText());
                                      if(j==0){
                                    	  Contractinformation=rowData.get(j);
                                      }else{
                                    	  Contractinformation=Contractinformation + "|" + rowData.get(j);
                                      }
                                }
                    
                          
                    
                    waitSleep(4000);
                    //rowData=AuthRows;
                    //AuthRows=AuthRows.substring(1,AuthRows.length());
                    System.out.println(Contractinformation);
                    System.out.println(data.get("Expected_details"));
                    assertEquals(data.get("Expected_details"), Contractinformation, "Contract information");
                  
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getIntentID method " + e);
		test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
		Assert.fail();
	}
}
public void Servicerequestreview(String frame,Hashtable<String,String> data) {
	try {
		wait(2500);
		switchToFrame(frame);
		String Typeofinquiry = webElementReadText(typeofinquiry);
		assertEquals(data.get("TypeOfInq"), Typeofinquiry, "Type of inquiry");
        String Reason = webElementReadText(reason);
        assertEquals(data.get("Reason"), Reason, "Reason");
        String Resolution = webElementReadText(resolution);
        assertEquals(data.get("Resolution"), Resolution, "Resolution");
        


	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Servicerequestreview method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on Servicerequestreview method " + e);
		Assert.fail();
	}
}

public void WorklistWeb() {
	try{
		switchToFrame("PegaGadget1Ifr");
		waitSleep(3500);
		try{
			Select type= new Select(TypeofInq);
			type.selectByIndex(1);
			wait(1500);
			Select reason= new Select(Reason);
			reason.selectByValue("Issue with registration");
			wait(1500);
			Select resolution= new Select(Resolution);
			resolution.selectByValue("Completed registration");
			wait(1500);
		}catch(StaleElementReferenceException e1)
		{
			Select type= new Select(TypeofInq);
			type.selectByIndex(1);
			wait(1500);
			Select reason= new Select(Reason);
			reason.selectByValue("Issue with registration");
			wait(1500);
			Select resolution= new Select(Resolution);
			resolution.selectByValue("Completed registration");
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on WorklistWeb method " + e);
		test.log(LogStatus.FAIL, "Error on WorklistWeb method " + e);
		Assert.fail();
	}
}


public void Resolve(Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(2500);
		webElementClick(Resolve, "Resolve the intant");
		wait(1500);
		webElementSendText(Comments, data.get("Comments"), "as Comments");
		wait(1500);
		
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Resolve." + e);
		test.log(LogStatus.FAIL, "Error on Resolve." + e);
		Assert.fail();
	}
}

public void interactionID(String intentID,String interactionID){
	try{
		String interactionIDxpath="//span[text()='%s']//following::a[(text()='%s') and contains(@name,'CPMGeneral')]";
		String interactionIDValue=String.format(interactionIDxpath, intentID,interactionID);
		System.out.println(interactionIDValue);
		switchToFrame("PegaGadget1Ifr");
		String interaction=driver.findElement(By.xpath(interactionIDValue)).getText();
		System.out.println(interaction);
		assertEquals(interactionID, interaction, "Interaction ID");
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on interactionID method " + e);
		test.log(LogStatus.FAIL, "Error on interactionID method " + e);
		Assert.fail();
	}
	
}


public void createNewFollowup(String intent)
{
	try{
		webElementClick(CeateNewWork, "CreateNewWork");
		if(intent.equals("Create Follow Up"))
		{
			driver.findElement(By.xpath("//a//span[contains(text(),'Create Follow-Up')]")).click();
		}else{
			webElementClick(CreateFollowUp, "Create Follow Up");	
		}
		
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on createNewFollowup method " + e);
		test.log(LogStatus.FAIL, "Error on createNewFollowup method " + e);
		Assert.fail();
	}
	
}

public void validateFollowuptask(String interactionID,String intentID)
{
	try{
		switchToFrame("PegaGadget2Ifr");
		String interactionIDxpath="//a[(text()='%s') and contains(@name,'CPMGeneral')]";
		String interactionValue=String.format(interactionIDxpath, interactionID);
		String interaction=driver.findElement(By.xpath(interactionValue)).getText();
		assertEquals(interactionID,interaction, "Interaction ID");
		String intent=intentID;
		driver.findElement(By.xpath("//h2[text()='Related intents']//following::th[2]//following::a[1]")).click();
		driver.findElement(By.xpath("//label[text()='Search text']//following::input[1]")).sendKeys(intentID);
		driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
		waitSleep(2500);
		
		if(driver.findElement(By.xpath("//input[contains(@name,'$PpyWorkPage$pSelectRelatedIntent$l') and @type='checkbox']")).isSelected())
		{
			 intent=driver.findElement(By.xpath("//tr[contains(@id,'$PpyWorkPage$pSelectRelatedIntent$l')]/td[2]")).getText();
		}
		assertEquals(intentID, intent, intentID+" is selected automation in folowup intent");
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on validateFollowuptask method " + e);
		test.log(LogStatus.FAIL, "Error on validateFollowuptask method " + e);
		Assert.fail();
	}
	
}

public void createNewWork(String intent)
{
	try{
		webElementClick(CeateNewWork, "CreateNewWork");
		if(intent.equals("Create Follow Up"))
		{
			intent="Create Follow-Up";
		}
		webElementClick(driver.findElement(By.xpath(String.format("//a//span[contains(text(),'%s')]",intent))),
				"New intent");
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on closeChildIntent method " + e);
		test.log(LogStatus.FAIL, "Error on closeChildIntent method " + e);
		Assert.fail();
	}
	
}


public void validateInteractionID(String interactionID)
{
	try{
		switchToFrame("PegaGadget2Ifr");
		String interactionIDxpath="//a[(text()='%s') and contains(@name,'CPMGeneral')]";
		String interactionValue=String.format(interactionIDxpath, interactionID);
		String interaction=driver.findElement(By.xpath(interactionValue)).getText();
		assertEquals(interactionID,interaction, "Interaction ID");
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on validateInteractionID method " + e);
		test.log(LogStatus.FAIL, "Error on validateInteractionID method " + e);
		Assert.fail();
	}
	
}

public String getChildintentid()
{
	String intentid="";
	try{
		switchToFrame("PegaGadget2Ifr");
		intentid= driver.findElement(By.xpath("//span[@class='heading_3']")).getText();
		test.log(LogStatus.INFO,"intentid");
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getChildintentid method " + e);
		test.log(LogStatus.FAIL, "Error on closeChildIntent method " + e);
		Assert.fail();
	}
	
	return intentid;
}

public void getChildHistory()
{
	try{
		driver.findElement(By.xpath("//label[@class='actionTitleBarLabelStyle']//following::i[1]")).click();
		String mainWindowHandle=driver.getWindowHandle();
		driver.findElement(By.xpath("//a//span[text()='View History']")).click();
		Set<String> allWindowHandles = driver.getWindowHandles();
	    Iterator<String> iterator = allWindowHandles.iterator();
	    String childHistory="";
	    // Here we will check if child window has other child windows and will fetch the heading of the child window
	    while (iterator.hasNext()) {
	        String ChildWindow = iterator.next();
	            if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
	            driver.switchTo().window(ChildWindow);
	            driver.switchTo().activeElement();
	            childHistory= driver.findElement(By.xpath("//span[contains(text(),'Created from')]")).getText();
	            driver.close();
	        }
	    }
		driver.switchTo().window(mainWindowHandle);
		System.out.println("Audit History:"+childHistory);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getChildHistory method " + e);
		test.log(LogStatus.FAIL, "Error on getChildHistory method " + e);
		Assert.fail();
	}
	
}

public void getParentHistory()
{
	try{
		switchToFrame("PegaGadget1Ifr");
		driver.findElement(By.xpath("//label[@class='actionTitleBarLabelStyle']//following::i[1]")).click();
		String mainWindowHandle=driver.getWindowHandle();
		driver.findElement(By.xpath("//a//span[text()='View History']")).click();
		Set<String> allWindowHandles = driver.getWindowHandles();
	    Iterator<String> iterator = allWindowHandles.iterator();
	    String childHistory="";
	    // Here we will check if child window has other child windows and will fetch the heading of the child window
	    while (iterator.hasNext()) {
	        String ChildWindow = iterator.next();
	            if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
	            driver.switchTo().window(ChildWindow);
	            driver.switchTo().activeElement();
	            childHistory= driver.findElement(By.xpath("//span[contains(text(),'New Intent')]")).getText();
	            driver.close();
	        }
	    }
		driver.switchTo().window(mainWindowHandle);
		System.out.println("Audit History:"+childHistory);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getParentHistory method " + e);
		test.log(LogStatus.FAIL, "Error on getParentHistory method " + e);
		Assert.fail();
	}
	switchToFrame("PegaGadget1Ifr");
	
}

public void closeChildIntent(String childIntent)
{
	try{
		driver.switchTo().defaultContent();
		System.out.println(String.format("//a[contains(text(),'%s')]//following::span[contains(@title,'Close Tab')]", childIntent));
		try{
			driver.findElement(By.xpath(String.format("//a[contains(text(),'%s')]//following::span[contains(@title,'Close Tab')]", childIntent))).click();
		}catch(Exception e1)
		{
			driver.findElement(By.xpath(String.format("//span[contains(text(),'%s')]//following::span[contains(@title,'Close Tab')]", childIntent))).click();
		}	
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on closeChildIntent method " + e);
		test.log(LogStatus.FAIL, "Error on closeChildIntent method " + e);
		Assert.fail();
	}
	
}

public void contractInformation(Hashtable<String,String> data, String frame) 
{
	String Contractinformation ="";
	try{
		
		switchToFrame(frame);
		List<String> headerRow= new ArrayList<String>();
        headerRow.add("Subscriber name");
        headerRow.add("Group number");
        headerRow.add("UMI");
        headerRow.add("Group name");
        


        ArrayList<String> rowData= new ArrayList<String>();
                                for(int j=0;j<headerRow.size();j++)
                                {											
                                rowData.add(driver.findElement(By.xpath("(//div[contains(@class,'layout-body clearfix layout-body clearfix')])[2]//span[contains(text(),'"+headerRow.get(j)+"')]/following::div[1]")).getText());
                                      if(j==0){
                                    	  Contractinformation=rowData.get(j);
                                      }else{
                                    	  Contractinformation=Contractinformation + "|" + rowData.get(j);
                                      }
                                }
                    
                          
                    
                    waitSleep(4000);
                    //rowData=AuthRows;
                    //AuthRows=AuthRows.substring(1,AuthRows.length());
                    System.out.println(Contractinformation);
                    System.out.println(data.get("Expected_details"));
                    assertEquals(data.get("Expected_details"), Contractinformation, "Contract information");
                  
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getIntentID method " + e);
		test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
		Assert.fail();
	}
}
}
