package com.nasco.HMHS.TestScripts.G1;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC008_MemberSearch_WrapUp_CallTransferred extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G1DP")
	public void HMHS_AUTC008_MemberSearch_WrapUp_CallTransferred(Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC008_MemberSearch_WrapUp_CallTransferred Search");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC008_MemberSearch_WrapUp_CallTransferred - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("For HMHS_TC008_MemberSearch_WrapUp_CallTransferred -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String intentID = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + intentID);
		test.log(LogStatus.INFO,"Interaction id: " + intentID);
		searchMember.WrapUp_CallTransferred();
		log.debug("WrapUp_CallTransferred screen.");
		test.log(LogStatus.INFO,"WrapUp_CallTransferred screen.");
		searchMember.WrapUpSubmit( data.get("Comments"));
		log.debug("Comments submitted");
		test.log(LogStatus.INFO,"Comments submitted");
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork.");
		test.log(LogStatus.INFO,"Navigated to the Recentwork.");
		recentWork.sortandSelectIntent( intentID);
		System.out.println("Sorted and selected intent " + intentID + " from recent work tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(LogStatus.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen.");
		test.log(LogStatus.INFO,"Navigate to Interaction screen.");
	}

	@AfterMethod
	public void tearDown() {
		test.log(LogStatus.INFO, "HMHS_TC008_MemberSearch_WrapUp_CallTransferred Completed");
		log.debug("HMHS_TC008_MemberSearch_WrapUp_CallTransferred Completed");
		quit();

	}
}
