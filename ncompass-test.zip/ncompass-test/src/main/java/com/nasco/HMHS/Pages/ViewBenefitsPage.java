package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings({"rawtypes","unchecked"})
public class ViewBenefitsPage extends BasePage {

	String excepionMessage = "";
	String taskNameXpath="//a[contains(text(),'%s')]";
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Add task')]")
	public WebElement addTask;
	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Filter')]")
	public WebElement filter;
	@FindBy(how = How.XPATH, using  = "//select[@id='6b455144']")
	public WebElement BENTypeOfInq;
	@FindBy(how = How.XPATH, using  = "//select[@id='ff608f01']")
	public WebElement BENReason;
	@FindBy(how = How.XPATH, using  = "//select[@id='df1e886c']")
	public WebElement BENResolution;

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(add);
	}
	//TO Add task for Interaction Manager 
	public void addTask(String intentName) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick( add, "add Task");
			webElementClick( driver.findElement(By.xpath(String.format(taskNameXpath, intentName))),"task Name");
			webElementClick( addTask, "add Task");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTask method " + e);
			test.log(LogStatus.FAIL, "Error on addTask method " + e);
			Assert.fail();
		}
	}
	
	public void ViewBenefitsPriorIntent(
			String memberSearchFname,Hashtable<String, String> data){
		try {
			switchToFrame("PegaGadget1Ifr");
			webElementClick(filter,"filter");
			waitSleep(5000);
			waitForElementsToVisible("//span[contains(text(),'VINCENT SAMSON')]");
			selectDropdownValueByVisibleText(BENTypeOfInq, data.get("BENTypeOfInq"), "Type Of Inquiry");
			wait(2500);
			selectDropdownValueByVisibleText(BENReason, data.get("BENReason"), "Reason");
			wait(2500);
			selectDropdownValueByVisibleText(BENResolution, data.get("BENResolution"), "Resolution");
			wait(2500);
			webElementClick(Submit, "Submit");
			
//			List<WebElement> ele = driver
//					.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
//			ele.size();
//			String s = "//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
//			for (int i = 0; i < ele.size(); i++) {
//				String s1 = String.format(s, i + 1);
//				if (driver.findElement(By.xpath(s1 + "//td[3]")).getText().equals(memberSearchFname)) {
//					webElementClick(
//							driver.findElement(
//									By.xpath(String.format("//span[contains(text(),'%s')]", memberSearchFname))),
//							"Member First Name");
//					break;
//				}
//			}
//			waitSleep(3000);
//			webElementClick(Submit, "Submit");
//			waitSleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on ViewBenefitsPriorIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on ViewBenefitsPriorIntent method " + e);
			Assert.fail();
		}
	}
	
	public ViewBenefitsPage opencreateFollowUpPage()
	{
		return (ViewBenefitsPage)openPage(ViewBenefitsPage.class);
	}
}


