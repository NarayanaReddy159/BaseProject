package com.nasco.HMHS.TestScripts.G2.ManageClaims;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.ManageClaimsPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.OtherActions;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC011_ManageClaims_fornotabletoAdjust  extends BaseTest{
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC011_ManageClaims_fornotabletoAdjust (Hashtable<String, String> data) throws Exception {
		
		String methodName="HMHS_AUTC004_ManageClaims_savetoworklis";
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser :  " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username3"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username3") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username3")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
		log.debug("Add Intent "+data.get("Intent"));
		ManageClaimsPage manageClaim=InteractionManager.openManageClaims();
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		test.log(LogStatus.INFO,"Intent id: " + intentID);
		manageClaim.searchClaims(data);
		log.debug("Navigate to Search for claim screen.");
		test.log(LogStatus.INFO,"Navigate to Search for claim screen. ");
		manageClaim.AdjustClaim(data);
		log.debug("Cilck on the adjust checkbox.");
		test.log(LogStatus.INFO,"Cilck on the adjust checkbox. ");
		manageClaim.adjust();
		log.debug("User selected the claim screen.");
		test.log(LogStatus.INFO,"User selected the claim screen. ");
		manageClaim.SelectotheractionOptions(data.get("Options"));
		log.debug("User able to select the Adjust option.");
		test.log(LogStatus.INFO,"User able to select the Adjust option.");
		manageClaim.Claimsselectedforadjustment(data);
		log.debug("Cilck on the Confirm Button.");
		test.log(LogStatus.INFO,"Cilck on the Confirm Button. ");
		manageClaim.Noteligibleforadjustment(data);
		log.debug("Validate the Error Message.");
		test.log(LogStatus.INFO,"Validate the Error Message. ");
		
		OtherActions otherActions=homepage.openOtherActions();
		log.debug("Click on otherAction button.");
		test.log(LogStatus.INFO,"Click on otherAction button. ");
		
		otherActions.cancelWork(data);
		log.debug("In worklist the intent is cancel the work.");
		test.log(LogStatus.INFO, "In worklist the intent is cancel the work.");
		
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		test.log(LogStatus.INFO,"Navigate to Wrap up screen. ");	
	}
	@AfterMethod
	public void tearDown() {

		test.log(LogStatus.INFO, "HMHS_AUTC011_ManageClaims_fornotabletoAdjust  Completed.");
		log.debug("HMHS_AUTC011_ManageClaims_fornotabletoAdjust  Completed.");
		quit();
	}

}
