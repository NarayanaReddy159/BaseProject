package com.nasco.HMHS.TestScripts.G2.CR26;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.utilities.DataProviders;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC007_MOC_CommercialCOB_BlueonBlueSameUMI_RoutedtoCOB_DECommercialCOB extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC007_MOC_CommercialCOB_BlueonBlueSameUMI_RoutedtoCOB_DECommercialCOB (Hashtable<String, String> data) throws Exception {
		validateskill("HMHS_AUTC007_MOC_CommercialCOB_BlueonBlueSameUMI_RoutedtoCOB_DECommercialCOB", data);
	}
 @AfterMethod
	public void tearDown() 
	{	test.log(LogStatus.INFO, "HMHS_TC007_MOC_CommercialCOB_BlueonBlueSameUMI_RoutedtoCOB_DECommercialCOB completed.");
		log.debug("HMHS_TC007_MOC_CommercialCOB_BlueonBlueSameUMI_RoutedtoCOB_DECommercialCOB completed.");
		quit();
	}
}
