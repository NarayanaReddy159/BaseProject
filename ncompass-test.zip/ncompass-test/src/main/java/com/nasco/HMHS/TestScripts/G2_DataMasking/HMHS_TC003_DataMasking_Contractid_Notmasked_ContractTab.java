package com.nasco.HMHS.TestScripts.G2_DataMasking;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC003_DataMasking_Contractid_Notmasked_ContractTab extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC003_DataMasking_Contractid_Notmasked_ContractTab (Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC003_DataMasking_Contractid_Notmasked_ContractTab");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC003_DataMasking_Contractid_Notmasked_ContractTab - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username3"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		log.debug("HMHS_TC003_DataMasking_Contractid_Notmasked_ContractTab -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username3") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		test.log(LogStatus.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username3")
				+ " and Password entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		test.log(LogStatus.INFO, "Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
		test.log(LogStatus.INFO, data.get("Fname") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(LogStatus.INFO, "Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(LogStatus.INFO, "Member Verified successfully.");
        Member360Page mem360=homepage.Member360Page();
		log.debug("Navigate to Member 360 page ");
		test.log(LogStatus.INFO, "Navigate to Member 360 page .");
		
        InteractionManager.openTask();
		mem360.contractTab_DataMasking(data.get("Contractheader"),data.get("Expectedcontractdetails"));
		log.debug("Navigate to contract Tab ");
		test.log(LogStatus.INFO, "Navigate to contract Tab .");
		
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		test.log(LogStatus.INFO, "Navigate to Wrap up screen.");
		
		
	}
	@AfterMethod
	public void tearDown() 
	{	test.log(LogStatus.INFO, "HMHS_TC003_DataMasking_Contractid_Notmasked_ContractTab completed.");
		log.debug("HMHS_TC003_DataMasking_Contractid_Notmasked_ContractTab completed.");
		quit();
	}
}
