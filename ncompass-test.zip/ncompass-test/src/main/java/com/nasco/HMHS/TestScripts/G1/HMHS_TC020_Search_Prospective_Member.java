package com.nasco.HMHS.TestScripts.G1;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC020_Search_Prospective_Member extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void HMHS_AUTC020_Search_Prospective_Member(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		
		test=DriverManager.getExtentReport();
		log.info("Inside TC020_Search_Prospective_Member");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("TC020_Search_Prospective_Member - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("TC020_Search_Prospective_Member -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.movetoProsMem();
		searchMember.HMHSPrsFieldsPresent( "PegaGadget1Ifr");
		log.debug("First Name Webelement present on Prospective Member screen.");
		test.log(LogStatus.INFO,"First Name Webelement present on Prospective Member screen.");
		log.debug("Pros Member Last Name Webelement present on Prospective Member screen");
		test.log(LogStatus.INFO,"Pros Member DOB Webelement present on Prospective Member screen.");
		log.debug("Pros Member DOB Webelement present on Prospective Member screen");
		test.log(LogStatus.INFO,"Pros Member DOB Webelement present on Prospective Member screen.");
		log.debug("prosMedicareNo Webelement not present before checkbox  of Capture new prospective member.");
		test.log(LogStatus.INFO,"prosMedicareNo Webelement not present before checkbox  of Capture new prospective member.");
		searchMember.searchProsMem( data);		
		log.debug("Prospective member search completed.");
		test.log(LogStatus.INFO,"Prospective member search completed.");
		InteractionManagerPage interactionManager=searchMember.openInteractionPage();
		interactionManager.wrapUp("Testing");
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC020_Search_Prospective_Member Completed");
		log.debug("AUTC020_Search_Prospective_Member Completed");
		quit();
		
	}
}
