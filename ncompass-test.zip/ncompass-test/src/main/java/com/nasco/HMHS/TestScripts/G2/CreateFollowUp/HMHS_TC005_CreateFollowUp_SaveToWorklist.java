package com.nasco.HMHS.TestScripts.G2.CreateFollowUp;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.utilities.DataProviders;
import com.relevantcodes.extentreports.LogStatus;

public class HMHS_TC005_CreateFollowUp_SaveToWorklist extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC005_CreateFollowUp_SaveToWorklist (Hashtable<String, String> data) throws Exception {
		saveToWorklist("HMHS_TC005_CreateFollowUp_SaveToWorklist", data);
	}

	@AfterMethod
	public void tearDown() {
		test.log(LogStatus.INFO, "HMHS_TC005_CreateFollowUp_SaveToWorklist completed.");
		log.debug("HMHS_TC005_CreateFollowUp_SaveToWorklist completed.");
		quit();

	}
}
