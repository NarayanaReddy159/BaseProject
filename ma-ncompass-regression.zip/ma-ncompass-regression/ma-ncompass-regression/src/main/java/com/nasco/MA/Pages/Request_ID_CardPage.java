package com.nasco.MA.Pages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class Request_ID_CardPage extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget2Ifr";
	String startDt="",endDt="";
	
	//@Override
	protected ExpectedCondition getPageLoadCondition() {
		//switchToFrame(frame1);
		switchToFrame(frame1);
		//return ExpectedConditions.visibilityOf(intentID);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
		
		
	}
		
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame(frame1);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, frame1, "Find A Provider", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	public void DocumentIDCardRequest(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame(frame);
			
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pGetMembers$l')]"));
			ele.size();
			String s="//tr[contains(@id,'$PpyWorkPage$pGetMembers$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[4]")).getText());
				
				if(driver.findElement(By.xpath(s1+"//td[4]")).getText().toUpperCase().contains(data.get("Fname")))
				
				{
					System.out.println("Entered if ");
					ClickWebelement("xpath", "("+s1+"//td[4]//preceding-sibling::td//input)[2]", data.get("Fname"));
					break;
				}
			} 
					       
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "temporaryaddress", true, frame, "", "Send to temporary address");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Attention", true, frame, data.get("Attention"), "Attention");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "name", true, frame, data.get("Name"), "name");

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "addressline1", true, frame, data.get("Address line 1"), "Address line 1");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, frame, data.get("City"), "city");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "State", true, frame, data.get("State"), "State");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Zipcode", true, frame, data.get("Zip_code"), "Zip code");

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comment", true, frame, "Adding Temporary Address", "comment");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "NextBtn1", true, frame, "", "next button");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "NextBtn", true, frame, "", "Next button");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning", true, frame, "", "Warning button");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit button");
			waitSleep(2000);

				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}
	public void ReviewIDCardRequest(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame(frame);
			String summary="";
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pCommentPage$pCommentsList$l1')]"));
		       String s="//tr[contains(@id,'$PpyWorkPage$pCommentPage$pCommentsList$l1')]";
		       for(int i=0;i<ele.size();i++)
		    {
			    String s1=String.format(s, i+1);
			    String memdet="";
			    List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
			    System.out.println(colums.size());
			     for(int j=0;j<colums.size();j++)
			    	
			{
				if(j==0)
				{
					System.out.println("action");
					memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
				}
				else{
					memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
				}
			}
			     summary=summary+","+memdet;	
		     }
				
			       System.out.println(summary);
			//assertEquals(data.get("Expected_summary"), summary, summary);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit button");
			waitSleep(3000);

				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on ReviewIDCardRequest method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on ReviewIDCardRequest method " + e);
			Assert.fail();
		}
		
	}

	public void validatePasswordProtectedError(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
		String s;
		try{
			
			switchToFrame(frame);
			
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pGetMembers$l')]"));
			ele.size();
			s="//tr[contains(@id,'$PpyWorkPage$pGetMembers$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[4]")).getText());
				
				if(driver.findElement(By.xpath(s1+"//td[4]")).getText().toUpperCase().contains(data.get("SubscriberFname")))
				
				{
					System.out.println("Entered if ");
					ClickWebelement("xpath", "("+s1+"//td[4]//preceding-sibling::td//input)[2]", data.get("SubscriberFname"));
					break;
				}
			} 
					       
			waitSleep(2000);
	
			List<WebElement> ele1= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pGetAddresses$l')]"));
			ele.size();
			s="//tr[contains(@id,'$PpyWorkPage$pGetAddresses$l%d')]";
			for(int i=0;i<ele1.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
				
				if(driver.findElement(By.xpath(s1+"//td[2]")).getText().toUpperCase().contains(data.get("Fname")))
				
				{
					System.out.println("Entered if ");
					ClickWebelement("xpath", "("+s1+"//td[2]//preceding-sibling::td//input)[2]", data.get("Fname"));
					break;
				}
			} 
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "NextBtn", true, frame, "", "Next button");
			waitSleep(2000);
			String actualErr=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ErrorMessage", true, frame, "", "Password Error Message");
			BaseTest.log.debug("Password Error Message populated as " + actualErr);
			test.log(LogStatus.PASS, "Password Error Message populated as " + actualErr);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validatePasswordProtectedError method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validatePasswordProtectedError method " + e);
			Assert.fail();
		}
		
	}
	
	public void cardGreatethan1(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame(frame);
			
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pGetMembers$l')]"));
			ele.size();
			String s="//tr[contains(@id,'$PpyWorkPage$pGetMembers$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[4]")).getText());
				
				if(driver.findElement(By.xpath(s1+"//td[4]")).getText().toUpperCase().contains(data.get("Fname")))
				
				{
					System.out.println("Entered if ");
					ClickWebelement("xpath", "("+s1+"//td[4]//preceding-sibling::td//input)[2]", data.get("Fname"));
					sendInputkeys("xpath",s1+"//td[11]//input", "2");
					break;
				}
			} 
					       
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "temporaryaddress", true, frame, "", "Send to temporary address");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Attention", true, frame, data.get("Attention"), "Attention");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "name", true, frame, data.get("Name"), "name");

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "addressline1", true, frame, data.get("Address line 1"), "Address line 1");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, frame, data.get("City"), "city");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "State", true, frame, data.get("State"), "State");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Zipcode", true, frame, data.get("Zip_code"), "Zip code");

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comment", true, frame, "Adding Temporary Address", "comment");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "next", true, frame, "", "next button");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning", true, frame, "", "Warning button");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit button");


				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}

	public void unSelectSubscriber(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
		String s;
		try{
			
			switchToFrame(frame);
			
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pGetMembers$l')]"));
			ele.size();
			s="//tr[contains(@id,'$PpyWorkPage$pGetMembers$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[4]")).getText());
				
				if(driver.findElement(By.xpath(s1+"//td[4]")).getText().toUpperCase().contains(data.get("SubscriberFname")))
				
				{
					System.out.println("Entered if ");
					ClickWebelement("xpath", "("+s1+"//td[4]//preceding-sibling::td//input)[2]", data.get("SubscriberFname"));
					break;
				}
			} 
					       
			waitSleep(2000);
	
			BaseTest.log.debug("Un select the subscriber ");
			test.log(LogStatus.INFO, "Un select the subscriber ");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on unSelectSubscriber method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on unSelectSubscriber method " + e);
			Assert.fail();
		}
		
	}

	public void validateStatusAndAssignTo(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame(frame);
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Status", true, frame, data.get("Expected_Status"), "Status");
			assertEquals(data.get("Expected_Status"), actualStatus, "Status");

			String actualAssignedTo=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AssignedTo", true, frame, data.get("AssignedTo"), "Assigned To");
			assertEquals(data.get("AssignedTo"), actualAssignedTo, "Assigned To");

			}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateStatusAndAssignTo method " + e);
			test.log(LogStatus.FAIL, "Error on validateStatusAndAssignTo method " + e);
			Assert.fail();
		}
	}
	
	public void clickSubmit(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit button");
			waitSleep(3000);
			}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
	
	public void resolveIntent(String pageLocatorsPath,String pageFiledsPath,String comments,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Resolve", true, frame, "Resolve", "Resolve");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "CommentsWB", true, frame, comments, "Comments");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitWB", true, frame, "", "Submit button");

			
			waitSleep(3000);
			}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
	
	public void validateStatus(String pageLocatorsPath,String pageFiledsPath,String status,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame(frame);
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Status", true, frame, status, "Status");
			assertEquals(status, actualStatus, "Status");

			}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateStatusAndAssignTo method " + e);
			test.log(LogStatus.FAIL, "Error on validateStatusAndAssignTo method " + e);
			Assert.fail();
		}
	}
	
	public void validateMessage(String pageLocatorsPath,String pageFiledsPath,String message,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame(frame);
			String actualMessage=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "CanceledMessage", true, frame, message, "Canceled Message");
			assertEquals(message, actualMessage, "Message");

			}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateMessage method " + e);
			test.log(LogStatus.FAIL, "Error on validateMessage method " + e);
			Assert.fail();
		}
	}

	public String getInactiveIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame(frame1);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "InactveIntentID", true, frame1, "Find A Provider", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	public void RequestTemporaryEligibi(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "requestTemporary", true, frame, "", "Request Temporary Eligibi...");
			waitSleep(2500);
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pPolicy$pMembers$l1')]"));
			ele.size();
			String s="//tr[contains(@id,'$PpyWorkPage$pPolicy$pMembers$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
				
				if(driver.findElement(By.xpath(s1+"//td[2]")).getText().toUpperCase().contains(data.get("Fname")))
				
				{
					System.out.println("Entered if ");
					waitSleep(5000);
					ClickWebelement("xpath", s1, data.get("Fname"));
					waitSleep(3000);
					break;
				}
			} 
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(5000);
			
			
			}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
	public void clickOtherActions(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{	
			pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActions", true, "PegaGadget2Ifr", "", "Other Actions");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on clickOtherActions method " + e);
			test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
			Assert.fail();
		}
	}
	
	public void closeIntenet(String pageLocatorsPath,String pageFiledsPath,String intentid) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\REQUEST_ID_CARDPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\REQUEST_ID_CARDPageFields.properties";
		waitSleep(3000);
		//switchToFrame("PegaGadget1Ifr");
		switchToDefault();
		try{
			WebElement ele = driver.findElement(By.xpath("//a[contains(text(),'"+intentid+"')]//following::div[1]//span//a"));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", ele);
			waitSleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
}


