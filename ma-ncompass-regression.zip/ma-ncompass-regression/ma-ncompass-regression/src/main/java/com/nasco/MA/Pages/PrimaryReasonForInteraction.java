package com.nasco.MA.Pages;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class PrimaryReasonForInteraction extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget4Ifr";
	String startDt="",endDt="";
	
		//@Override
	protected ExpectedCondition getPageLoadCondition() {
//		switchToFrame(frame1);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
		
	}
		
	
	public void validateInformation(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\PrimaryReasonForInteractionPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\PrimaryReasonForInteractionPageFields.properties";
			waitSleep(4000);
			switchToFrame(frame);
			
			if (driver.findElement(By.xpath("//a[contains(text(),'Export')]")).isDisplayed()) {
				BaseTest.log.info("Import is displayed");
				test.log(LogStatus.PASS, "Import is displayed");
			} else {
				BaseTest.log.error("Export is not displayed");
				test.log(LogStatus.FAIL, "Export is not displayed");
				Assert.fail();
			}
			
			if (driver.findElement(By.xpath("//a[contains(text(),'Import')]")).isDisplayed()) {
				BaseTest.log.info("Export is displayed");
				test.log(LogStatus.PASS, "Export is displayed");
			} else {
				BaseTest.log.error("Export is not displayed");
				test.log(LogStatus.FAIL, "Export is not displayed");
				Assert.fail();
			}
			
			if (driver.findElement(By.xpath("//a[contains(text(),'Add record')]")).isDisplayed()) {
				BaseTest.log.info("Add reocrd is displayed");
				test.log(LogStatus.PASS, "Add reocrd is displayed");
			} else {
				BaseTest.log.error("Add reocrd is not displayed");
				test.log(LogStatus.FAIL, "Add reocrd is not displayed");
				Assert.fail();
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateInformation method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateInformation method " + e);
			Assert.fail();
		}
	 }

	public void createPrimaryReason(String pageLocatorsPath,String pageFiledsPath,String frame,String primaryreson) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\PrimaryReasonForInteractionPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\PrimaryReasonForInteractionPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Addrecord", true, frame, "Add record", "Add record");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PrimaryReason", true, frame, primaryreson, "Primary Reason");
			waitSleep(2000);
			Actions action = new Actions(driver);
			action.moveByOffset(1000, 700).click().perform();
		  
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Table", true, frame, "Table", "Click outside");
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createPrimaryReason method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createPrimaryReason method " + e);
			Assert.fail();
		}
	 }
	
	public void deletePrimaryReason(String pageLocatorsPath, String pageFiledsPath,String frame,String primaryreson)   
	{
		
		try{//tr[contains(@id,'$PpyVirtualRecordEditorREResultPage') and contains(@id,'$ppxResults$l3')]
			waitSleep(2000);
			switchToFrame(frame);
			List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'$PpyVirtualRecordEditorREResultPage')]"));
			System.out.println("tablerows "+tablerows.size());
			String s="(//tr[contains(@id,'$PpyVirtualRecordEditorREResultPage') and contains(@id,'$ppxResults$l%d')]";  
			for(int i=0;i<tablerows.size();i++)
			{ 
				String s1=String.format(s, i+1);
				System.out.println("s1:::"+"("+s1+")//td[1])[1]/div");
				System.out.println("categ "+driver.findElement(By.xpath("("+s1+")//td[1])[1]/div")).getText());
				String primary=driver.findElement(By.xpath("("+s1+")//td[1])[1]/div")).getText();
				if( primary.equalsIgnoreCase(primaryreson))
				{
					driver.findElement(By.xpath("("+s1+")//td[2])[1]/div//a")).click();
					BaseTest.log.info("Delete PrimaryReason reocrd of "+primaryreson );
					test.log(LogStatus.INFO, "Delete PrimaryReason reocrd of "+primaryreson);
					break;
				}
			}	
			waitSleep(2000);
		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on deletePrimaryReason method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on deletePrimaryReason method " + e);
			Assert.fail();
		}
		
	}
	
	public void validateRefresh(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\PrimaryReasonForInteractionPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\PrimaryReasonForInteractionPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
		
			if (driver.findElement(By.xpath("//div[contains(text(),'Refresh')]")).isDisplayed()) {
				BaseTest.log.info("Refresh button is displayed");
				test.log(LogStatus.PASS, "Refresh button is displayed");
			} else {
				BaseTest.log.error("Refresh button is not displayed");
				test.log(LogStatus.FAIL, "Refresh button is not displayed");
				Assert.fail();
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createPrimaryReason method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createPrimaryReason method " + e);
			Assert.fail();
		}
	 }

}
