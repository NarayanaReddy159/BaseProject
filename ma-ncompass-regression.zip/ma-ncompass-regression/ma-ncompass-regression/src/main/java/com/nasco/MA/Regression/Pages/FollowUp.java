package com.nasco.MA.Regression.Pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;




@SuppressWarnings("rawtypes")
public class FollowUp extends BasePage {

	@FindBy(xpath="//label[@id='pyActionLabel']//following::span[1]")
	public WebElement intentID;
	
	String excepionMessage="";
	//pushing from branch
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget2Ifr");
		return ExpectedConditions.visibilityOf(intentID);
	}
	
	
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "Create Follow Up", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
		
	public void create_FollowUp_Now(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "followUpNow", true, "PegaGadget2Ifr", "", "Follow Up Now");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget2Ifr", data.get("Comments"), "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_BEN_Quote_Benefit method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_BEN_Quote_Benefit method " + e);
			Assert.fail();

		}
	}
	
	public void validateFollowUpNow(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			Date dt = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			String strDate= formatter.format(dt);
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", data.get("Expected_Status"), "Status");
			assertEquals(data.get("Expected_Status"), actualStatus, "Status");
			
			String actualContact=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "contact", true, "PegaGadget1Ifr", data.get("Expected_Contact"), "Contact");
			assertEquals(data.get("Expected_Contact"), actualContact, "Contact");

			String actualChannel=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "channel", true, "PegaGadget1Ifr", data.get("Expected_Channel"), "Channel");
			assertEquals(data.get("Expected_Channel"), actualChannel, "Channel");

			String actualCreateOperator=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "createOperator", true, "PegaGadget1Ifr", data.get("Expected_CreateOperator"), "Create Operator");
			assertEquals(data.get("Expected_CreateOperator"), actualCreateOperator, "Create Operator");

			String actualResolveOperator=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "creationDate", true, "PegaGadget1Ifr", "", "Creation Date");
			assertContains(strDate, actualResolveOperator, "Creation Date");

			String actualCategory=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "resolveDate", true, "PegaGadget1Ifr", "", "Resolve Date");
			assertContains(strDate, actualCategory, "Resolve date");

			String actualSubCategory=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "taskComments", true, "PegaGadget1Ifr", data.get("Expected_Comments"), "Comments");
			assertEquals(data.get("Expected_Comments"), actualSubCategory, "Comments");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateFollowUpNow method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateFollowUpNow method " + e);
			Assert.fail();
		}
	}
	
	public void create_FollowUpScheduled(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "followUpScheduled", true, "PegaGadget2Ifr", "", "Follow Up Scheduled");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget2Ifr", "Comments", "comments");
			/*WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);*/
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_FollowUpScheduled method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_FollowUpScheduled method " + e);
			Assert.fail();

		}
	}
	
	public void relatedIntent(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			waitForElementsToVisible("//tr[@id='$PpyWorkPage$pSelectRelatedIntent$l1']");
			test.log(LogStatus.PASS, "Related Intents present");
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on relatedIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on relatedIntent method " + e);
			Assert.fail();

		}
	}
	
	public void cancelFollowUp(String pageLocatorsPath,String pageFiledsPath)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActions", true, "PegaGadget2Ifr", "", "Other Actions");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "cancelWork", true, "PegaGadget2Ifr", "Cancel work", "Cancel Work");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "cancelCommnets", true, "PegaGadget2Ifr", "Cancel Work", "Commnets");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, "PegaGadget2Ifr", "", "Submit");
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on relatedIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on relatedIntent method " + e);
			Assert.fail();

		}
	}
	public void create_FollowUp_Scheduled(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "followUpScheduled", true, "PegaGadget2Ifr", "", "Follow Up Scheduled");
			String scheduledDate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "endDate", true, "PegaGadget1Ifr", "", "Scheduled Date");
			validateScheduledDate(scheduledDate);
			//WebElementAction("type",pageLocatorsPath, pageFiledsPath, "endDate", true, "PegaGadget2Ifr", data.get("ScheduleEndDate"), "End Date");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget2Ifr", data.get("Comments"), "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(4500);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_BEN_Quote_Benefit method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_BEN_Quote_Benefit method " + e);
			Assert.fail();

		}
	}
	@SuppressWarnings("unused")
	public void validateScheduledDate(String scheduledDate){
		
		boolean isScheduledDateOnWeekend = false;
		boolean isScheduledDateEmpty = false;
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
//		pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
//		pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";

		try { 
//		String scheduledDate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "endDate", true, "PegaGadget1Ifr", "", "Scheduled Date");
		if (scheduledDate!=null && !scheduledDate.isEmpty()){
			isScheduledDateOnWeekend = validateDateOnWeekend(scheduledDate);
			BaseTest.log.info("Scheduled Date Captured and Validated." );
			test.log(LogStatus.INFO, "Scheduled Date Captured and Validated.");
//			if(isScheduledDateOnWeekend){
//				BaseTest.log.error("Default Scheduled Date on Weekend");
//				test.log(LogStatus.FAIL, "Default Scheduled Date on Weekend");
//				}
//			} else{
//				isScheduledDateEmpty=true;
//				BaseTest.log.error("Default Scheduled Date is Empty");
//				test.log(LogStatus.FAIL, "Default Scheduled Date is Empty");
		}

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getScheduledDate method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getScheduledDate method " + e);
			Assert.fail();

		}
	}
	
	private boolean validateDateOnWeekend(String schDate){
		
		boolean matchValue=false;
		
		try{
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy h:mm a");
			Date scheduledDate = (Date)df.parse(schDate); 
			Calendar cl=Calendar.getInstance();
			cl.setTime(scheduledDate);
			if(cl.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY || cl.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY){
				matchValue=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return matchValue;
	}
	
	public void FollowUp_Attempt(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data, String followupAttempt)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "followUpAttempt", true, "PegaGadget1Ifr", followupAttempt, "Follow Up Scheduled");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsReschedule", true, "PegaGadget1Ifr", data.get("Comments"), "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(4500);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_FollowUp_Attempt method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_FollowUp_Attempt method " + e);
			Assert.fail();

		}
	}
	
	
	public void calcualteSLA(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			String endDate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "EndDateRecentwork", true, frame, "", "End date");
			
			
			String goal=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ServiceIntentGoal", true, frame, "", "Service Intent Goal");
			String deadLine=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ServiceIntentDeadline", true, frame, "", "Service Intent Deadline");
			String format = "MM/dd/yyyy hh:mm a";
			 
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			Date creDt = sdf.parse(endDate);
			Date goalDt = sdf.parse(goal);
			Date deadLineDt = sdf.parse(deadLine);
			long diff = deadLineDt.getTime() - creDt.getTime();
			long diff1 = goalDt.getTime() - creDt.getTime();
			int diffhrs = (int) (diff / (60 * 60 * 1000));
			//System.out.println("endDate::"+endDate);
			//System.out.println("goal::"+goal);
			//System.out.println("deadLine::"+deadLine);
			//System.out.println("difference between Hours: " + diffhrs);
			if (diffhrs==24){
				BaseTest.log.debug("Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be " + diffhrs+" hrs");
				test.log(LogStatus.INFO, "Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be " + diffhrs+" hrs");
			} else {
				BaseTest.log.error("Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be 24 hrs");
				test.log(LogStatus.FAIL, "Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be 24 hrs");
				Assert.fail("Difference should be 24 hrs but the value is "+diffhrs);
			}
			
			int diffh = (int) (diff1 / (60 *60 * 1000));
			//System.out.println("difference between Hours: " + diffh);
 
			if (diffh==2){
				BaseTest.log.debug("Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be " + diffh+" hrs");
				test.log(LogStatus.INFO, "Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be " +diffh+" hrs");
			} else {
				BaseTest.log.error("Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be 24 hrs");
				test.log(LogStatus.FAIL, "Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be 24 hrs");
				Assert.fail("Difference should be 24 hrs but the value is "+diffh);
			}
			
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on WrapUpOpenIntent method " + e);
			test.log(LogStatus.FAIL, "Error on WrapUpOpenIntent method " + e);
			Assert.fail();
		}
	 }


	public void clickCreateNewWork_ViewAuthorization(String pageLocatorsPath,String pageFiledsPath, String frame){
		pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
		waitSleep(1000);
		try {
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CreatenewWork", true, frame, "Create new work", "Create new work");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ViewAuthorization", true, frame, "View Authorizations", "View Authorization");
			
			waitSleep(2000);
			
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CloseViewAuth", true, frame, "Close", "Close View Authorization");
//			waitSleep(3000);

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickCreateNewWork_ViewAuthorization method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickCreateNewWork_ViewAuthorization method " + e);
			Assert.fail();

		}

	}
	
	public void FollowUp_Attempt(String pageLocatorsPath,String pageFiledsPath, String comments, String followupAttempt,String frame)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame(frame);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "followUpAttempt", true, frame, followupAttempt, "Follow Up Scheduled");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsReschedule", true, frame, comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, frame, "", "Submit");
			waitSleep(4500);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on FollowUp_Attempt method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on FollowUp_Attempt method " + e);
			Assert.fail();

		}
	}

	public String getViewAuthIntentID(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{	
		String intentid="";
		String[] intId=null;
		try{
			waitSleep(2000);
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			switchToDefault();
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ViewAuthId", false, "", "View Authorizations", "View Authorization Intent ID");
			intId = intentid.split(" ");
			//System.out.println("View Auth Id "+intId[2]);
			test.log(LogStatus.INFO, "View Authorization Intent ID:"+intId[2]);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getViewAuthIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getViewAuthIntentID method " + e);
			Assert.fail();
		}
		return intId[2];
	}
	
	public void closeViewAuth(String pageLocatorsPath,String pageFiledsPath, String frame){
		pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
		waitSleep(1000);
		try {
			switchToFrame(frame);
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CloseViewAuth", true, frame, "Close", "Close View Authorization");
			waitSleep(3000);

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on closeViewAuth method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on closeViewAuth method " + e);
			Assert.fail();

		}

	}
	
	public void takeOwnership(String pageLocatorsPath,String pageFiledsPath,String comments,String frame1)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame1);
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "TransferComments", true, frame1, comments, "Transfer Comments");
			waitSleep(1000);
	
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "TakeOwnership", true, frame1, "", "Take Ownership");
			waitSleep(2000);
			waitOnIE(3000);
			Alert alert = driver.switchTo().alert();
			alert.accept();
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on takeOwnership method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on takeOwnership method " + e);
			Assert.fail();

		}

	}
	
	public void closeOnDocResolution(String pageLocatorsPath,String pageFiledsPath, String frame){
		pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
		waitSleep(1000);
		try {
			switchToFrame(frame);
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CloseBtn", true, frame, "Close", "Close View Authorization");
			waitSleep(3000);

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on closeViewAuth method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on closeViewAuth method " + e);
			Assert.fail();

		}

	}
	
	public void clickCreateNewWork_CreateFollowup(String pageLocatorsPath,String pageFiledsPath, String frame){
		pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
		waitSleep(1000);
		try {
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CreatenewWork", true, frame, "Create new work", "Create new work");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CNCreateFollowUp", true, frame, "Create Follow Up", "Create Follow Up");
			
			waitSleep(2000);
			
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CloseViewAuth", true, frame, "Close", "Close View Authorization");
//			waitSleep(3000);

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickCreateNewWork_ViewAuthorization method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickCreateNewWork_ViewAuthorization method " + e);
			Assert.fail();

		}

	}
	
	public void validateDefaultSelectedIntent(String pageLocatorsPath, String pageFiledsPath,String frame,String intentId)   
	{
		
		try{
			switchToFrame(frame);
			List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage')]"));
			//System.out.println("tablerows "+tablerows.size());
			String s="(//tr[contains(@id,'$PpyWorkPage$pSelectRelatedIntent$l')])[%d]";  
			for(int i=0;i<tablerows.size();i++)
			{ 
				String s1=String.format(s, i+1);
				//System.out.println("s1"+s1);
				//System.out.println("intent id "+driver.findElement(By.xpath(s1+"//td[3]//a")).getText());
				if( (driver.findElement(By.xpath(s1+"//td[3]//a")).getText()).equalsIgnoreCase(intentId) ) 
				{
					if (driver.findElement(By.xpath(s1+"//td[1]//input[2]")).isSelected()) {
						BaseTest.log.info("By default selected the intent as  "+intentId );
						test.log(LogStatus.INFO, "By default selected the intent as  "+intentId );
	
						break;
					}
				}
			}	
			waitSleep(2000);
		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateDefaultSelectedIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateDefaultSelectedIntent method " + e);
			Assert.fail();
		}
		
	}

	public void clickScheduledOnHarmess(String pageLocatorsPath,String pageFiledsPath, String frame)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SchedulePerformHarness", true, frame, "Scheduled", "Follow Up Scheduled");
			//WebElementAction("type",pageLocatorsPath, pageFiledsPath, "endDate", true, "PegaGadget2Ifr", data.get("ScheduleEndDate"), "End Date");
			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickScheduledOnHarmess method " + excepionMessage);
			Assert.fail();

		}
	}
	
	public String Followup_SLA(String pageLocatorsPath,String pageFiledsPath,String fieldValue,String logname,String frame, String identifierName)
	{
		String text="";
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame(frame);
			text=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, fieldValue, true, frame, identifierName,logname );
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Followup_SLA method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on Followup_SLA method " + e);
			Assert.fail();

		}
		return text;
	}
	public void FollowUp_History(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "history", true, "PegaGadget1Ifr", "", "History");
			
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				driver.switchTo().window(childWindow);
				//System.out.println(driver.switchTo().window(childWindow).getTitle());
				String auditLog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "historyAudit", false, "", "", "History Audit");
				waitSleep(1000);
				//System.out.println(auditLog);
				assertEquals(data.get("ExpectedHistoryAudit"), auditLog, "Audit log");
				driver.close();
				}
			}
			driver.switchTo().window(mainWindow);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_FollowUp_Attempt method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_FollowUp_Attempt method " + e);
			Assert.fail();

		}
	}
	
	public void closeFollowup(String pageLocatorsPath,String pageFiledsPath)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToDefault();
			WebElementAction("Click",pageLocatorsPath, pageFiledsPath, "close", false, "", "", "close");
			waitSleep(3000);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on closeFollowup method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on closeFollowup method " + e);
			Assert.fail();

		}
	}
	
	public void createNewWork(String pageLocatorsPath,String pageFiledsPath, String newWork)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("Click",pageLocatorsPath, pageFiledsPath, "newWork", true, "PegaGadget1Ifr", "", "Create new work");
			waitSleep(1500);
			WebElementAction("Click",pageLocatorsPath, pageFiledsPath, "createWork", true, "PegaGadget1Ifr", newWork, newWork);
			waitSleep(3500);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createNewWork method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createNewWork method " + e);
			Assert.fail();

		}
	}
	
	public void validateNewWork(String pageLocatorsPath,String pageFiledsPath, String intentID)
	{
		try {
				pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
				waitSleep(3000);
				switchToFrame("PegaGadget2Ifr");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "followUpScheduled", true, "PegaGadget2Ifr", "", "Follow Up Scheduled");
				if(driver.findElement(By.xpath("//*[@id='pySelected1']")).isSelected())
				{
					test.log(LogStatus.PASS, "Releated intent selected");
					if(driver.findElement(By.xpath("//*[@id='$PpyWorkPage$pSelectRelatedIntent$l1']/td[3]/div")).getText().equals(intentID))
					{
						test.log(LogStatus.PASS, "Releated intent "+intentID+" selected");
					}
				}else{
					test.log(LogStatus.FAIL, "Releated intent not selected");
					Assert.fail();
				}
		} 
		catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createNewWork method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createNewWork method " + e);
			Assert.fail();

		}
	}
	
	
	public void verifyCommentsLog(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			String rowXpaths="//tr[contains(@id,'$PpyWorkPage$pCommentPage$pCommentsList$l')]";
			List<WebElement> commentsRows= driver.findElements(By.xpath(rowXpaths));
			String rowxpath="//tr[contains(@id,'$PpyWorkPage$pCommentPage$pCommentsList$l%d')]";
			boolean comments=true;
			for(int i=1;i<=commentsRows.size();i++)
			{
				String s=String.format(rowxpath, i);
				if(driver.findElement(By.xpath(s+"//td[2]")).getText().equals(data.get("Comments")))
				{
					comments=true;
				}
				else{
					comments=false;
				}
			}
			
			if(comments)
			{
				test.log(LogStatus.PASS, "Comments log displaying with data comments added by the operator");
			}
					
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on verifyCommentsLog method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on verifyCommentsLog method " + e);
			Assert.fail();

		}
	}
	public void clickRelatedintent(String pageLocatorsPath,String pageFiledsPath, String intentid)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("Click",pageLocatorsPath, pageFiledsPath, "relatedIntent", true, "PegaGadget1Ifr", intentid, "Related intent");
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickRelatedintent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickRelatedintent method " + e);
			Assert.fail();

		}
	}
	
	public void takeOwnership(String pageLocatorsPath,String pageFiledsPath)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("Click",pageLocatorsPath, pageFiledsPath, "takeOwnerShip", true, "PegaGadget2Ifr", "", "Take OwnerShip");
			waitSleep(3000);
			Alert alert = driver.switchTo().alert();
			alert.accept();
			waitSleep(3000);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on takeOwnership method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on takeOwnership method " + e);
			Assert.fail();

		}
	}
	
	public void takeOwnership(String pageLocatorsPath,String pageFiledsPath,String Comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ownerShipComments", true, "PegaGadget2Ifr", Comments, "Take OwnerShip");
			WebElementAction("Click",pageLocatorsPath, pageFiledsPath, "ownershipBtn", true, "PegaGadget2Ifr", "", "Take OwnerShip");
			waitSleep(3000);
			Alert alert = driver.switchTo().alert();
			alert.accept();
			waitSleep(3000);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on takeOwnership method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on takeOwnership method " + e);
			Assert.fail();

		}
	}
	
	public void FollowUp_Attempt(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data, String followupAttempt,String frame)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(3000);
			switchToFrame(frame);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "followUpAttempt", true, frame, followupAttempt, "Follow Up Scheduled");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsReschedule", true, frame, data.get("Comments"), "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, frame, "", "Submit");
			waitSleep(4500);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_FollowUp_Attempt method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_FollowUp_Attempt method " + e);
			Assert.fail();

		}
	}
	
	public void logout()
	{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//a[contains(text(),'New')]//following::a[2]")).click();
		waitSleep(500);
		driver.findElement(By.xpath("//span[contains(text(),'Logout')]")).click();
		waitSleep(500);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		waitSleep(2500);
	}
}
