package com.nasco.MA.Pages;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class AlertsPage extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget2Ifr";
	String startDt="",endDt="";
	
		//@Override
	protected ExpectedCondition getPageLoadCondition() {
//		switchToFrame(frame1);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
		
	}
		
	
	public void validateInformation(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\AlertsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\AlertsPageFields.properties";
			waitSleep(4000);
			switchToFrame(frame);
			
			if (driver.findElement(By.xpath("//a[contains(text(),'Export')]")).isDisplayed()) {
				BaseTest.log.info("Import is displayed");
				test.log(LogStatus.PASS, "Import is displayed");
			} else {
				BaseTest.log.error("Export is not displayed");
				test.log(LogStatus.FAIL, "Export is not displayed");
				Assert.fail();
			}
			
			if (driver.findElement(By.xpath("//a[contains(text(),'Import')]")).isDisplayed()) {
				BaseTest.log.info("Export is displayed");
				test.log(LogStatus.PASS, "Export is displayed");
			} else {
				BaseTest.log.error("Export is not displayed");
				test.log(LogStatus.FAIL, "Export is not displayed");
				Assert.fail();
			}
			
			if (driver.findElement(By.xpath("//a[contains(text(),'Add record')]")).isDisplayed()) {
				BaseTest.log.info("Add reocrd is displayed");
				test.log(LogStatus.PASS, "Add reocrd is displayed");
			} else {
				BaseTest.log.error("Add reocrd is not displayed");
				test.log(LogStatus.FAIL, "Add reocrd is not displayed");
				Assert.fail();
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_BEN_Quote_Benefit method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateInformation method " + e);
			Assert.fail();
		}
	 }

	public void createAlert(String pageLocatorsPath,String pageFiledsPath,String frame,String category, String criticality,String level, String referenceid, String subject,String description) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\AlertsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\AlertsPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Addrecord", true, frame, "Add record", "Add record");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Category", true, frame, category, "Category");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Criticality", true, frame, criticality, "Criticality");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Level", true, frame, level, "Level");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Referenceid", true, frame, referenceid, "Reference id");
			
			String format = "MM/dd/yyyy hh:mm a";
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			Date dt = new Date();
			String newdate = sdf.format(dt);
			
			System.out.println("date::"+newdate);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "StartDate", true, frame, newdate, "StartDate");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Subject", true, frame, subject, "Subject");
			waitSleep(1000);
	
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Description", true, frame, description, "Description");
	
			//clickOnPage();
			Actions action = new Actions(driver);
			action.moveByOffset(1000, 700).click().perform();
		  
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "TableFor", true, frame, "Table for", "Click outside");
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_BEN_Quote_Benefit method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateInformation method " + e);
			Assert.fail();
		}
	 }
	
	public void deleteAlert(String pageLocatorsPath, String pageFiledsPath,String frame,String category, String criticality,String level, String referenceid, String subject,String description )   
	{
		
		try{
			switchToFrame(frame);
			List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'$PpyVirtualRecordEditorREResultPage')]"));
			System.out.println("tablerows "+tablerows.size());
			//String s="//tr[contains(@id,'$PpyVirtualRecordEditorREResultPage112907$ppxResults$l%d')]";
			String s="(//tr[contains(@id,'$PpyVirtualRecordEditorREResultPage')])[%d]";  ////tr[@id='$PpyVirtualRecordEditorREResultPage112907$ppxResults$l1' ]
			//tr[@id='$PpyVirtualRecordEditorREResultPage131525$ppxResults$ll%d')]
			//for(int i=0;i<tablerows.size();i++)
			for(int i=tablerows.size()-1;i>0;i--)
			{ //((//tr[contains(@id,'$PpyVirtualRecordEditorREResultPage')][1])//td[1])[1]/div
				String s1=String.format(s, i+1);
				System.out.println("s1"+s1);
				System.out.println("categ "+driver.findElement(By.xpath("(("+s1+")//td[1])[1]/div")).getText());
				//List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
				if( (driver.findElement(By.xpath("(("+s1+")//td[1])[1]/div")).getText()).equalsIgnoreCase(category) &
					(driver.findElement(By.xpath("(("+s1+")//td[2])[1]/div")).getText()).equalsIgnoreCase(criticality) &
					(driver.findElement(By.xpath("(("+s1+")//td[3])[1]/div")).getText()).equalsIgnoreCase(level) &
					(driver.findElement(By.xpath("(("+s1+")//td[4])[1]/div")).getText()).equalsIgnoreCase(referenceid) &
					(driver.findElement(By.xpath("(("+s1+")//td[10])[1]/div")).getText()).equalsIgnoreCase(subject) &
					(driver.findElement(By.xpath("(("+s1+")//td[11])[1]/div")).getText()).equalsIgnoreCase(description) ) 
				{
					driver.findElement(By.xpath("(("+s1+")//td[13])[1]/div//a")).click();
					BaseTest.log.info("Delete Alert reocrd of "+referenceid );
					test.log(LogStatus.INFO, "Delete Alert reocrd of "+referenceid);

					break;
				}
			}	
			waitSleep(2000);
		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateCodesDetails method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateCodesDetails method " + e);
			Assert.fail();
		}
		
	}
}
