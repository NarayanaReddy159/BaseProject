package com.nasco.MA.Pages;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class Manager_toolsPage extends BasePage {

	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	String excepionMessage = "";

	public String frame1="PegaGadget1Ifr";
	
	
	//@Override
	protected ExpectedCondition getPageLoadCondition() {
		//switchToFrame(frame1);
		switchToFrame(frame1);
		return ExpectedConditions.visibilityOf(frame);
	}
	public void movetoManagetooltab(String pageLocatorsPath,String pageFiledsPath,String frame0) throws Exception
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Manager_toolsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Manager_toolsPageFields.properties";
			waitSleep(3000);
			switchToFrame(frame0);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "managetool", true, frame0, "", "Managetool tab");
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_PSA method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
			Assert.fail();
		}
	}
		public void movetoTranfer(String pageLocatorsPath,String pageFiledsPath,String frame0) throws Exception
		{
			try{
				pageLocatorsPath= pageLocatorsPath+"\\Manager_toolsPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Manager_toolsPageFields.properties";
				waitSleep(3000);
				switchToFrame(frame0);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "tranfer", true, frame0, "", "Tranfer tab");
							}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on createGSI_PSA method " + e);
				test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
				Assert.fail();
			}
	}
	
		public void filterAssignments(String pageLocatorsPath,String pageFiledsPath,String frame1) throws Exception
		{
			try{
				pageLocatorsPath= pageLocatorsPath+"\\Manager_toolsPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Manager_toolsPageFields.properties";
				waitSleep(3000);
				
				switchToFrame(frame1);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleticon", true, frame1, "", "workGroup delete");
				waitSleep(1500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleticon", true, frame1, "", "Workbasket delete");
				waitSleep(1500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleticon", true, frame1, "", "workstatus delete");
				waitSleep(1500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "filterAssignments", true, frame1, "", "filter Assignments");
				waitSleep(1500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "checkbox", true, frame1, "", "select first");
				

//				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectaction", true, frame1, "", "select action");
//				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "transferselect", true, frame1,"", "transferselect");
//
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on createGSI_PSA method " + e);
				test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
				Assert.fail();
			}
	}	
		
		public void selectaction(String pageLocatorsPath,String pageFiledsPath,String frame1,String transferto,String Operator,Hashtable<String,String> data) throws Exception
		{
			try{
				pageLocatorsPath= pageLocatorsPath+"\\Manager_toolsPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Manager_toolsPageFields.properties";
				waitSleep(3000);
				
				switchToFrame(frame1);

				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectaction", true, frame1, "", "select action");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "transferselect", true, frame1,"", "transferselect");

				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "auditnote", true, frame1,"Audit note" , "Operator");

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "transferto", true, frame1, transferto , "transferto");
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Operator", true, frame1,Operator , "Operator");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "simtmacsr", true, frame1,Operator, "simtmacsr");
				waitSleep(2000);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "auditnote", true, frame1,"Audit note" , "Operator");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ok", true, frame1,"", "OK button");
	            String transfered=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "transfered", true, frame1,"", "transfered successfully");
                System.out.println(transfered);
                assertEquals(data.get("Expected_transfered"), transfered, "Transfered Successfully");


			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on createGSI_PSA method " + e);
				test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
				Assert.fail();
			}
	}	
		
		public void selectIntent(String pageLocatorsPath, String pageFiledsPath,String intentId,String frame1)   
		{
			
			try{
				pageLocatorsPath= pageLocatorsPath+"\\Manager_toolsPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Manager_toolsPageFields.properties";
				waitSleep(3000);
				switchToFrame(frame1);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CreateDate", true, frame1, "Create date", "Create date");
				waitSleep(2000);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SortCreateDate", true, frame1, "Create date", "Sort Create date");
				waitSleep(3000);
//				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SortCreateDate", true, frame1, "Create date", "Sort Create date");
//				waitSleep(3000);
				List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'$PpyBulkProcessReport$ppxResults$l')]"));
				String s="//tr[contains(@id,'$PpyBulkProcessReport$ppxResults$l%d')]";
				
				for(int i=0;i<tablerows.size();i++)
				{
					String s1=String.format(s, i+1);
					List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
					
					if(driver.findElement(By.xpath(s1+"//td[3]")).getText().equalsIgnoreCase(intentId))
						{
							driver.findElement(By.xpath(s1+"//td[1]//input[2]")).click();
							break;
						}
				}
				waitSleep(1000);
		
			} catch(Exception e)
			{
				e.printStackTrace();
				excepionMessage = Arrays.toString(e.getStackTrace());
				BaseTest.log.error("Error on selectIntent method " + excepionMessage);
				test.log(LogStatus.FAIL, "Error on selectIntent method " + e);
				Assert.fail();
			}
			
		}

		public void filterAssignmentsDetails(String pageLocatorsPath,String pageFiledsPath,String frame1) throws Exception
		{
			try{
				pageLocatorsPath= pageLocatorsPath+"\\Manager_toolsPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Manager_toolsPageFields.properties";
				waitSleep(3000);
				
				switchToFrame(frame1);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleticon", true, frame1, "", "workGroup delete");
				waitSleep(1500);

				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleticon", true, frame1, "", "Workbasket delete");
				waitSleep(15000);

				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleticon", true, frame1, "", "workstatus delete");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "filterAssignments", true, frame1, "", "filter Assignments");
				waitSleep(1500);
				}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on createGSI_PSA method " + e);
				test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
				Assert.fail();
			}
	}	
}
