package com.nasco.MA.Regression.Pages;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.nasco.MA.Regression.Base.BaseTest;
import com.nasco.MA.Regression.Setup.BasePage;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;
@SuppressWarnings("rawtypes")
public class WorkbasketPage extends BasePage{

	
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	
	@FindBy(xpath = "//a[contains(text(),'My Work')]")
	public WebElement myWork;
	
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		switchToFrame("PegaGadget0Ifr");
		return ExpectedConditions.visibilityOf(myWork);
	}
	
	
	public void movetoWorkbasketPage(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			waitOnIE(3500);
			switchToFrame("PegaGadget0Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "workbasket", true, "PegaGadget0Ifr", "", "Workbasket tab");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on movetoWorkbasketPage method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on movetoWorkbasketPage method " + e);
			Assert.fail();
		}
		
	}
	
	
	public void selectWorkbasket(String pageLocatorsPath,String pageFiledsPath, String workbasket) {
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			switchToFrame("PegaGadget0Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "workbasketSelect", true, "PegaGadget0Ifr", workbasket, "Workbaskets");
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to select workbasket as "+workbasket);
			BaseTest.log.error(excepionMessage);
			test.log(LogStatus.FAIL, "Not able to select workbasket as "+workbasket);
			test.log(LogStatus.FAIL,e);
			Assert.fail();
		}
	}
	
	public void sortandSelectIntent(String pageLocatorsPath,String pageFiledsPath, String intentId) {
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			switchToFrame("PegaGadget0Ifr");
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "idSort", true, "PegaGadget0Ifr", "", "ID Sort");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchID", true, "PegaGadget0Ifr", intentId, "Search intent");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "applyBtn", true, "PegaGadget0Ifr", "", "Apply");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "intentclick", true, "PegaGadget0Ifr", intentId, "Intent "+intentId);
			waitSleep(2500);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to select intent id as  "+intentId);
			BaseTest.log.error(excepionMessage);
			test.log(LogStatus.FAIL, "Not able to select intent id as "+intentId);
			test.log(LogStatus.FAIL,e);
			Assert.fail();
		
	}
	}

	public void resolve_ProcessGSI_ValidateGSIResponse(String pageLocatorsPath,String pageFiledsPath)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(3000);
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			
			//Validation
			String actualMessage = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Message", true, "PegaGadget1Ifr", "", "Message");
			assertEquals("Please be sure to post authorization for two visits.",actualMessage,"Message");
			String actualAddedClaims = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AddedClaims", true, "PegaGadget1Ifr", "", "AddedClaims");
			assertEquals("Added Claims",actualAddedClaims,"Added Claims");
			String actualAdjust = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Adjust", true, "PegaGadget1Ifr", "", "Adjust");
			assertEquals("Adjust",actualAdjust, "Adjust");
//			String actualResponse = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Response", true, "PegaGadget1Ifr", "", "Response");
//			assertEquals("Resolve",actualResponse, "Response");
				
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ClaimResults", true, "PegaGadget1Ifr", "", "Claim Results");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments_resolve_ProcessGSI", true, "PegaGadget1Ifr", "Testing", "Comments");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit_Resolve", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(3000);
		} catch (Exception e){
            e.printStackTrace();
            String excepionMessage = Arrays.toString(e.getStackTrace());
            BaseTest.log.error("Error on resolve_ProcessGSI_ValidateGSIResponse method " + excepionMessage);
            test.log(LogStatus.FAIL, "Error on resolve_ProcessGSI_ValidateGSIResponse method " + e);
            Assert.fail();

        }
		
	}
	
		
	public void readWorkbasketNoRecord(String pageLocatorsPath,String pageFiledsPath, String intentId,String expectedResult)
	{
		String Details="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			switchToFrame("PegaGadget0Ifr");
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "idSort", true, "PegaGadget0Ifr", "", "ID Sort");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchID", true, "PegaGadget0Ifr", intentId, "Search intent");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "applyBtn", true, "PegaGadget0Ifr", "", "Apply");
			
			Details = driver.findElement(By.xpath("//*[contains(text(),'No items for the filters applied')]")).getText();
			System.out.println(Details);
			assertEquals(expectedResult, Details, "Workbasket No Details Message");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on readWorkbasketNoRecord method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on readWorkbasketNoRecord method " + e);
			Assert.fail();
		}
	}
	
	public void workbasketvalidateStatus(String pageLocatorsPath,String pageFiledsPath,String expectedStatus) throws Exception
	{
		
		String text="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			text=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", "", "Status Intent ID");
			waitSleep(2500);
			System.out.println("Status:"+text);
			assertEquals(expectedStatus, text, "Expected_Status");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");
			waitSleep(2500);
			//return text;
	}
	catch(Exception e)
	{
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on workbasketvalidateStatus method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on workbasketvalidateStatus method " + e);
		Assert.fail();
	}
		
	}
	
	public void resolveCLM(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "responseComments", true, "PegaGadget1Ifr", "Resolving Intent","Comments");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "responseresolve", true, "PegaGadget1Ifr", "responseResolve", "Response Resolve");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitResponse", true, "PegaGadget1Ifr", "","Submit");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on resolveCLM method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on resolveCLM method " + e);
			Assert.fail();
			}
		
		}

	public void workbasketvalidateAssign(String pageLocatorsPath,String pageFiledsPath,String expectedStatus) throws Exception
	{
		
		String text="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			text=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Assignto", true, "PegaGadget1Ifr", "", "Status Intent ID");
			waitSleep(2500);
			System.out.println("Status:"+text);
			assertEquals(expectedStatus, text, "Expected_Assignto");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");
			waitSleep(2500);
			//return text;
	}
	catch(Exception e)
	{
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on workbasketvalidateStatus method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on workbasketvalidateStatus method " + e);
		Assert.fail();
	}
		
	}
	
	public void createnewwork(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createnewwork", true, "PegaGadget1Ifr", "createnewwork", "createnewwork");
			waitSleep(2000);
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createnewwork method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createnewwork method " + e);
			Assert.fail();
			}
		
		}
	public void Createcorrespondence(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Createcorrespondenceno", true, "PegaGadget1Ifr", "Createcorrespondence", "Createcorrespondence");
					waitSleep(2000);
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Createcorrespondence method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on Createcorrespondence method " + e);
			Assert.fail();
			}
		
		}
	
	public void Pendforadditionalwork(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Pendforadditionalwork", true, "PegaGadget1Ifr", "Pendforadditionalwork", "Pendforadditionalwork");
			waitOnIE(3500);
		//	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments_resolve_ProcessGSI", true, "PegaGadget1Ifr", "Testing","Comments_resolve_ProcessGSI");
			waitSleep(1000);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "submit", "submit");

			waitSleep(2000);
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Pendforadditionalwork method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on Pendforadditionalwork method " + e);
			Assert.fail();
			}
		
		}
	public void Routetooriginatingoperator(String pageLocatorsPath,String pageFiledsPath,String operatorID) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Routetooriginatingoperator", true, "PegaGadget1Ifr", "Route to originating operator("+operatorID+")", "Routetooriginatingoperator");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments_Adjust", true, "PegaGadget1Ifr", "Adjustclaim Testing","Comments_Adjust");
			waitSleep(1000);		
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submitbutton", true, "PegaGadget1Ifr", "Submit", "submit");
			waitSleep(2000);
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Routetooriginatingoperator method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on Routetooriginatingoperator method " + e);
			Assert.fail();
			}
		
		}
	public void Adjustclaim(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Adjustclaim", true, "PegaGadget1Ifr", "Adjust claim", "Adjustclaim");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Finalreasontoadjust", true, "PegaGadget1Ifr", data.get("Finalreasontoadjust"), "Finalreasontoadjust");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments_Adjust", true, "PegaGadget1Ifr", "Adjustclaim Testing","Comments_Adjust");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submitbutton", true, "PegaGadget1Ifr", "Submit", "submit");

		
			waitSleep(2000);
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Adjustclaim method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on Adjustclaim method " + e);
			Assert.fail();
			}
		
		}
	public void RTOfollowup(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RTOfollowup", true, "PegaGadget1Ifr", "Adjust claim", "RTOfollowup");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Finalreasontoadjust", true, "PegaGadget1Ifr", data.get("Finalreasontoadjust"), "Finalreasontoadjust");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments_Adjust", true, "PegaGadget1Ifr", "Adjustclaim Testing","Comments_Adjust");
			waitSleep(1000);
			
		
			waitSleep(2000);
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RTOfollowup method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on RTOfollowup method " + e);
			Assert.fail();
			}
		
		}
	public void clickOtherActions(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{	
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActions", true, "PegaGadget1Ifr", "", "Other Actions");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOtherActions method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
			Assert.fail();
		}
	}
	public void cancel(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{	
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "cancelwork", true, "PegaGadget1Ifr", "", "cancel work");

			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submitbutton", true, "PegaGadget1Ifr", "Submit", "submit");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on cancel method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on cancel method " + e);
			Assert.fail();
		}
	}
	
	public void getWorkbaskets(String pageLocatorsPath,String pageFiledsPath,String expectedWorkbasket)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget0Ifr");
			Select workbasket=new Select (driver.findElement(By.id("PropertyForParameters")));
			List<WebElement> options=workbasket.getOptions();
			for (int i=1;i<options.size();i++)
			{
				if(options.get(i).getText().equals(expectedWorkbasket))
				{
					test.log(LogStatus.INFO, "Work Basket "+expectedWorkbasket+" available to operator");
				}else{
					test.log(LogStatus.INFO, "Work Basket "+expectedWorkbasket+" not available to operator");
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getWorkbaskets method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getWorkbaskets method " + e);
			Assert.fail();
		}
	}
	
	
	public void getWorkbasketsValidate(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			String actual_str1 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Status_ReviewHarness",true, "PegaGadget1Ifr", "", "Status_ReviewHarness");
			String actual_str2 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"MemberID_ReviewHarness",true, "PegaGadget1Ifr", "", "MemberID_ReviewHarness");
			String actual_str3 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"AssignedTo_ReviewHarness",true, "PegaGadget1Ifr", "", "AssignedTo_ReviewHarness");
			String actual_str4 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Channel_ReviewHarness",true, "PegaGadget1Ifr", "", "Channel_ReviewHarness");
			String actual_str5 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"CreateOperator_ReviewHarness",true, "PegaGadget1Ifr", "", "CreateOperator_ReviewHarness");
			 
			String  actual_str_con = actual_str1 + "|" + actual_str2 + "|" + actual_str3 + "|" + actual_str4 + "|" + actual_str5;
			assertEquals(data.get("ReviewHarnessExpectedResults"),actual_str_con,"Valdiate Expected Results");
			waitSleep(2500);
			WebElementAction("SelectbyText",pageLocatorsPath, pageFiledsPath,"Response",true, "PegaGadget1Ifr", "Resolve", "Response");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath,"Comments_resolve_ProcessGSI",true, "PegaGadget1Ifr", "Test", "Resolve Comments");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath,"Submit_Resolve1",true, "PegaGadget1Ifr", "", "Resolve Submit Button");
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getWorkbasketsValidate method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getWorkbasketsValidate method " + e);
			Assert.fail();
		}
	}
	
	public void RoutetoclaimWorkbasket(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RoutetoClaimWorkbasket", true, "PegaGadget1Ifr", "Route intent to claim workbasket", "Routetooriginatingoperator");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments_Adjust", true, "PegaGadget1Ifr", "Adjustclaim Testing","Comments_Adjust");
			waitSleep(1000);		
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submitbutton", true, "PegaGadget1Ifr", "Submit", "submit");
			waitSleep(2000);
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RoutetoclaimWorkbasket method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on RoutetoclaimWorkbasket method " + e);
			Assert.fail();
			}
		
		}
	
	public void RouteforFollowup(String pageLocatorsPath,String pageFiledsPath,String comments,String enddate) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RouteforFollowup", true, "PegaGadget1Ifr", "Route for follow up", "Route for follow up");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments", true, "PegaGadget1Ifr", comments,"Comments_Adjust");
			waitSleep(2000);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Enddate", true, "PegaGadget1Ifr", enddate	, "End date");
			waitSleep(2000);
			waitSleep(1000);		
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submitbutton", true, "PegaGadget1Ifr", "Submit", "submit");
			waitSleep(2000);
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RouteforFollowup method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on RouteforFollowup method " + e);
			Assert.fail();
			}
		
		}

}
