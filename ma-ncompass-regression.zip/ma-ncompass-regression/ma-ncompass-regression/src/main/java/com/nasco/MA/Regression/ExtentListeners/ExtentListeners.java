package com.nasco.MA.Regression.ExtentListeners;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.ThreadContext;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.nasco.MA.Regression.Run.RunTestNG_NCompass_MA;
import com.nasco.MA.Regression.utilities.DriverManager;
import com.nasco.MA.Regression.utilities.EmailHTMLBuilder;
import com.nasco.MA.Regression.utilities.EmailHTMLBuilder_Body;
import com.nasco.MA.Regression.utilities.EmailUtil;
import com.nasco.MA.Regression.utilities.ExcelReader;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentListeners implements ITestListener {

	static Date d = new Date();
	static String fileName = "Extent_" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
	int passCount_R4=0, failCount_R4=0, passCount_R3=0,failCount_R3=0,passCount_R2=0,failCount_R2=0,passCount_R1,failCount_R1=0;
	int passMOCcnt=0,passMOAcnt=0,passR1cnt=0;
	int failMOCcnt=0,failMOAcnt=0,failR1cnt=0;
	Map<String,List<String>> results = new HashMap<String,List<String>>();
	String status="";
	String reportFileName = "MA NCompass Automation Execution Report.xlsx";
	String	reportFilePath=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("ReportFile")+reportFileName;
	String extentFilepath=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("EXTREPORT_LOC");
	public String timeStamp = new SimpleDateFormat("MM/dd/yyyy-HH:mm:ss").format(Calendar.getInstance().getTime());
	//public String timeStamp_email= timeStamp+"IST";
	public String timeStamp_email= timeStamp;
	EmailHTMLBuilder htmlbuilder_Summary=new EmailHTMLBuilder();
	EmailHTMLBuilder_Body htmlbuilder=new EmailHTMLBuilder_Body();
	DecimalFormat df = new DecimalFormat("###.##");
	static ExcelReader excel=null;
	String path1 = reportFileName.replace(".xlsx", "")+d.toString().replace(":", "_").replace(" ", "_")+".xlsx";
	String reportFilePath1=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("ReportFile")+path1;
	// private static ExtentReports extent =
	// ExtentManageraven.createInstance(System.getProperty("user.dir")+"\\reports\\"+fileName);
	private static ExtentReports extent = ExtentManager.getInstance();
	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();
	
	int	passRCEcnt=0, passBENcnt=0,passFOLcnt=0,passMBIcnt=0,passCHKcnt=0,passCLMcnt=0,passGSIcnt=0,passUPMcnt=0,passIDCcnt=0,passPUPcnt=0,passOUTcnt=0;
	int passOCVcnt=0,passRTCcnt=0,passAUTcnt=0,passCLRcnt=0,passASIcnt=0,passCCMcnt=0,passFPRcnt=0,passALMcnt=0,passPCPcnt=0,passTOTcnt=0,passSCHcnt=0,otherPassCnt=0;

	int failRCEcnt=0,failBENcnt=0,failFOLcnt=0,failMBIcnt=0,failCHKcnt=0,failCLMcnt=0,failGSIcnt=0,failUPMcnt=0,failIDCcnt=0,failPUPcnt=0,failOUTcnt=0;
	int failOCVcnt=0,failRTCcnt=0,failAUTcnt=0,failCLRcnt=0,failASIcnt=0,failCCMcnt=0,failFPRcnt=0,failALMcnt=0,failPCPcnt=0,failTOTcnt=0,failSCHcnt=0,otherFailCnt=0;


	public void onTestStart(ITestResult result) {

		// ExtentTest test = extent.startTest(result.getTestClass().getName()+"
		// @TestCase : "+result.getMethod().getMethodName());
		ExtentTest test = extent.startTest("TestCase : " + result.getMethod().getMethodName());
//		ThreadContext.put("id", UUID.randomUUID().toString());


		DriverManager.setExtentReport(test);
		//testReport.set(test);
		testReport.set(DriverManager.getExtentReport());
	
		ThreadContext.put("id", result.getMethod().getMethodName());
//		System.setProperty("id", result.getMethod().getMethodName());
//		BaseTest.log.debug(result.getTestClass().getName()+" Started");
		//System.out.println("config"+RunTestNG_NCompass_MA.Config.getProperty("EXTREPORT_LOC"));
		
	}

	public void onTestSuccess(ITestResult result) {

		String methodName = result.getMethod().getMethodName();
		// String logText="<b>"+"TEST CASE:- "+ methodName.toUpperCase()+ "
		// PASSED"+"</b>";
		// Markup m=MarkupHelper.createLabel(logText, ExtentColor.GREEN);
		// testReport.get().pass(m);
		testReport.get().log(LogStatus.PASS, methodName + " Test Case Passed");
		passedTCsCounts(result);
		resultStatus(result,methodName, "Pass");
		getdetailreport(result,methodName, "Pass");
		extent.endTest(testReport.get());
		ThreadContext.clearMap();
	}

	public void onTestFailure(ITestResult result) {

		String excepionMessage = Arrays.toString(result.getThrowable().getStackTrace());
		// testReport.get().log(LogStatus.FAIL,"<details>" + "<summary>" + "<b>"
		// + "<font color=" + "red>" + "Exception Occured:Click to see"
		// + "</font>" + "</b >" + "</summary>" +excepionMessage.replaceAll(",",
		// "<br>")+"</details>"+" \n");
		if (!excepionMessage.isEmpty())
			testReport.get().log(LogStatus.FAIL, excepionMessage);
		String methodName = result.getMethod().getMethodName();
		////System.out.println(excepionMessage);
		////System.out.println(result.getThrowable().getStackTrace());
		try {
			ExtentManager.captureScreenshot(methodName);
			/*String base64Screenshot = "data:image/png;base64,"+((TakesScreenshot)DriverManager.getDriver()).
	                getScreenshotAs(OutputType.BASE64);
	 
	        //Extentreports log and screenshot operations for failed tests.
			testReport.get().log(LogStatus.FAIL,"Test Failed Screenshot",
			testReport.get().addBase64ScreenShot(base64Screenshot));*/
			
			
			//System.out.println("screen Name::"+ExtentManager.screenshotName);
			testReport.get().log(LogStatus.FAIL, ExtentManager.screenshotName +
//					"<b>" + "<font color=" + "red>" + "Screenshot of failure" + "</font>" + "</b>",
					testReport.get().addScreenCapture(ExtentManager.screenshotName));
		} catch (Exception e) {
			e.printStackTrace();
		}
		testReport.get().log(LogStatus.FAIL, methodName + " Test Case Failed");
		failedTCsCounts(result);
		resultStatus(result,methodName, "Fail");
		getdetailreport(result,methodName, "Fail");
		extent.endTest(testReport.get());
		ThreadContext.clearMap();
	}

	public void onTestSkipped(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		// String logText="<b>"+"Test Case:- "+ methodName+ " Skipped"+"</b>";
		// Markup m=MarkupHelper.createLabel(logText, ExtentColor.YELLOW);
		// testReport.get().skip(m);
		testReport.get().log(LogStatus.SKIP, methodName + " Test Case Skipped");
		extent.endTest(testReport.get());
		ThreadContext.clearMap();
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub

	}

	public void onStart(ITestContext context) {
		extent.addSystemInfo("Environment", RunTestNG_NCompass_MA.Config.getProperty("Environment"));
	}

	public void onFinish(ITestContext context) {
		Object[][] arrayCounts = RunTestNG_NCompass_MA.getCountsObj();
			
	
		if (extent != null) {
//			extent.addSystemInfo(arrayCounts[0][0]+" Release", "Total Tcs:"+arrayCounts[0][1]+" Executed Tcs:"+arrayCounts[0][2]+" Passed Tcs:"+passCount_R1+" Failed Tcs:"+failCount_R1);
//			extent.addSystemInfo(arrayCounts[1][0]+" Release", "Total Tcs:"+arrayCounts[1][1]+" Executed Tcs:"+arrayCounts[1][2]+" Passed Tcs:"+passCount_R2+" Failed Tcs:"+failCount_R2);
//			extent.addSystemInfo(arrayCounts[2][0]+" Release", "Total Tcs:"+arrayCounts[2][1]+" Executed Tcs:"+arrayCounts[2][2]+" Passed Tcs:"+passCount_R3+" Failed Tcs:"+failCount_R3);
//			extent.addSystemInfo(arrayCounts[3][0]+" Release", "Total Tcs:"+arrayCounts[3][1]+" Executed Tcs:"+arrayCounts[3][2]+" Passed Tcs:"+passCount_R4+" Failed Tcs:"+failCount_R4);
//			extent.addSystemInfo("Releases(R1+R2+R3+R4)", "Summary Report");
			
			int totalTcsCnt = Integer.parseInt(arrayCounts[0][1].toString())+Integer.parseInt(arrayCounts[1][1].toString())+Integer.parseInt(arrayCounts[2][1].toString())+Integer.parseInt(arrayCounts[3][1].toString());
//			int excutedTcsCnt=	Integer.parseInt(arrayCounts[0][2].toString())+Integer.parseInt(arrayCounts[1][2].toString())+Integer.parseInt(arrayCounts[2][2].toString())+Integer.parseInt(arrayCounts[3][2].toString());
//			int passedTcsCnt = passCount_R1+passCount_R2+passCount_R3+passCount_R4;
//			int failedTcsCnt = failCount_R1+failCount_R2+failCount_R3+failCount_R4;
//			//System.out.println("R1+R2+R3+R4 Releases Total Tcs:"+totalTcsCnt+" Executed Tcs:"+excutedTcsCnt+" Passed Tcs:"+passedTcsCnt+" Failed Tcs:"+failedTcsCnt);
			int excTcCount=context.getSuite().getAllMethods().size();
	        int passedCount=context.getPassedTests().size();
	        int failedCount=context.getFailedTests().size();
	       
//	        extent.addSystemInfo("R1+R2+R3+R4", "Total Tcs:"+totalTcsCnt+" Executed Tcs:"+excTcCount+" Passed Tcs:"+passedCount+" Failed Tcs:"+failedCount);
//	        extent.addSystemInfo("Summary Report", "IntentWise");
//	        extent.addSystemInfo("Request Cost Estimate", "REC- Passed Tcs:"+passRCEcnt+" Failed TCs:"+failRCEcnt);
//	        extent.addSystemInfo("Manage Other Actions", "MOA- Passed Tcs:"+passMOAcnt+" Failed TCs:"+failMOAcnt);
//	        extent.addSystemInfo("Manage Other Ocverage", "OCV- Passed Tcs:"+passMOCcnt+" Failed TCs:"+failMOCcnt);
//
			extent.flush();
			
		       //String path=RunTestNG_NCompass_MA.Config.getProperty("EXTREPORT_LOC");
				//String path=RunTestNG_NCompass_MA.Config.getProperty("ReportFile");
          		String path=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("ReportFile");
		        String filename_Attachment=ExtentManager.fileName;
		        //System.out.println("filename_Attachment::"+filename_Attachment);
		        String suiteStatus_Subject;
		        
		        
		        /****************/
		        
		        printMap(results);
		        /****************/
		        
//		        if (RunTestNG_NCompass_MA.Config.getProperty("Browser").equalsIgnoreCase("Chrome"))
//		        	reportfile = RunTestNG_NCompass_MA.Config.getProperty("ReportFile_Chrome");
//		       else if (RunTestNG_NCompass_MA.Config.getProperty("Browser").equalsIgnoreCase("IE"))
//		    	   excel = new ExcelReader(RunTestNG_NCompass_MA.Config.getProperty("ReportFile_IE"));
		        
		        if(status.equalsIgnoreCase(""))
		        {
		        	suiteStatus_Subject= "PASS";
		        }
		        else suiteStatus_Subject= "FAIL";
		        
		        String Env_Subject=null;
//		        String url="https://nascobpm-mo.nasco.bluesnet.net/ncompass_mass/PRServlet/";
		        Env_Subject=RunTestNG_NCompass_MA.Config.getProperty("Environment");
//		        if(RunTestNG_NCompass_MA.Config.getProperty("URL").equalsIgnoreCase(url))
//		        {
//		        	Env_Subject="MO";
//		        }
//		        else  Env_Subject="PROD";
		        
		        String header_content=RunTestNG_NCompass_MA.Config.getProperty("Body_Text")+Env_Subject+" execution summary of "+RunTestNG_NCompass_MA.Config.getProperty("Browser").toUpperCase() +" on "+timeStamp_email;
		        
		        /*String timeStamp = new SimpleDateFormat("MM/dd/yyyy-HH:mm:ss-").format(Calendar.getInstance().getTime());*/
		        /*String timeStamp_email= timeStamp+"EST";*/
//		        String timeStamp1 = new SimpleDateFormat("MM/dd/yyyy-HH:mm:ss-Z").format(Calendar.getInstance().getTime());
//		        //System.out.println("timeStamp1"+timeStamp1);
		        //htmlbuilder.appendFooter();
		        
		        double passpercentage= (double)(passedCount*100)/excTcCount;
		        String passPercent=df.format(passpercentage);
		        double failpercentage= (double) (failedCount*100)/excTcCount;
		        String failPercent=df.format(failpercentage);
		        
		        htmlbuilder_Summary.appendSummary_Header(header_content);
		        htmlbuilder_Summary.appendSummary("MA-NCompass-Regression", totalTcsCnt,excTcCount, passedCount, failedCount, totalTcsCnt-excTcCount,passPercent, failPercent);
		        
		        htmlbuilder_Summary.appendSummary_HeaderReleaseWise("Release Wise Summary Report");
		        htmlbuilder_Summary.appendSummary_ReleaseWise(arrayCounts[0][0].toString(), Integer.parseInt(arrayCounts[0][1].toString()), Integer.parseInt(arrayCounts[0][2].toString()), passCount_R1, failCount_R1,Integer.parseInt(arrayCounts[0][1].toString()) - Integer.parseInt(arrayCounts[0][2].toString()),Integer.parseInt(arrayCounts[0][3].toString()));
		        htmlbuilder_Summary.appendSummary_ReleaseWise(arrayCounts[1][0].toString(), Integer.parseInt(arrayCounts[1][1].toString()), Integer.parseInt(arrayCounts[1][2].toString()), passCount_R2, failCount_R2,Integer.parseInt(arrayCounts[1][1].toString()) - Integer.parseInt(arrayCounts[1][2].toString()),Integer.parseInt(arrayCounts[1][3].toString()));
		        htmlbuilder_Summary.appendSummary_ReleaseWise(arrayCounts[2][0].toString(), Integer.parseInt(arrayCounts[2][1].toString()), Integer.parseInt(arrayCounts[2][2].toString()), passCount_R3, failCount_R3,Integer.parseInt(arrayCounts[2][1].toString()) - Integer.parseInt(arrayCounts[2][2].toString()),Integer.parseInt(arrayCounts[2][3].toString()));
		        htmlbuilder_Summary.appendSummary_ReleaseWise(arrayCounts[3][0].toString(), Integer.parseInt(arrayCounts[3][1].toString()), Integer.parseInt(arrayCounts[3][2].toString()), passCount_R4, failCount_R4,Integer.parseInt(arrayCounts[3][1].toString()) - Integer.parseInt(arrayCounts[3][2].toString()),Integer.parseInt(arrayCounts[3][3].toString()));
		        int releasetot = Integer.parseInt(arrayCounts[0][1].toString()) + Integer.parseInt(arrayCounts[1][1].toString())+Integer.parseInt(arrayCounts[2][1].toString())+Integer.parseInt(arrayCounts[3][1].toString());
		        int releaseExecured = Integer.parseInt(arrayCounts[0][2].toString()) + Integer.parseInt(arrayCounts[1][2].toString()) + Integer.parseInt(arrayCounts[2][2].toString()) + Integer.parseInt(arrayCounts[3][2].toString());
		        int releasePassed = passCount_R1 + passCount_R2 + passCount_R3 +passCount_R4;
		        int releaseFailed = failCount_R1 + failCount_R2 + failCount_R3 +failCount_R4;
		        int releaseSkipped = Integer.parseInt(arrayCounts[0][1].toString()) - Integer.parseInt(arrayCounts[0][2].toString()) + Integer.parseInt(arrayCounts[1][1].toString()) - Integer.parseInt(arrayCounts[1][2].toString()) + Integer.parseInt(arrayCounts[2][1].toString()) - Integer.parseInt(arrayCounts[2][2].toString()) +Integer.parseInt(arrayCounts[3][1].toString()) - Integer.parseInt(arrayCounts[3][2].toString());
		        int releaseWarnings= Integer.parseInt(arrayCounts[0][3].toString())+Integer.parseInt(arrayCounts[1][3].toString())+Integer.parseInt(arrayCounts[2][3].toString())+Integer.parseInt(arrayCounts[3][3].toString());
		        htmlbuilder_Summary.appendSummary_ReleaseWise("Total",releasetot,releaseExecured,releasePassed,releaseFailed,releaseSkipped,releaseWarnings);
		        htmlbuilder_Summary.append_closebody();
		        
		        htmlbuilder_Summary.appendSummary_HeaderIntentWise("Intent Wise Summary Report");
		        htmlbuilder_Summary.appendSummary_IntentWise("Create Benefits", passBENcnt, failBENcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Manage Billing", passMBIcnt, failMBIcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Create Follow Up", passFOLcnt, failFOLcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Manage Checks", passCHKcnt, failCHKcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Manage Claims", passCLMcnt, failCLMcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Create GSI", passGSIcnt, failGSIcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Update Member", passUPMcnt, failUPMcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Request ID Cards", passIDCcnt, failIDCcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("MANAGE PCP/POC", passPUPcnt, failPUPcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Make Outbound call", passOUTcnt, failOUTcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Manage Other Coverage", passOCVcnt, failOCVcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Respond To Customer", passRTCcnt, failRTCcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Request Cost Estimate", passRCEcnt, failRCEcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("View Authorization", passAUTcnt, failAUTcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Request Chat Letter", passCLRcnt, failCLRcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Associate Service", passASIcnt, failASIcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Coordinate Care Management", passCCMcnt, failCCMcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Find a Provider", passFPRcnt, failFPRcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Manage Alerts", passALMcnt, failALMcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("MANAGE PCP", passPCPcnt, failPCPcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("View Totals", passTOTcnt, failTOTcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Schedule Appointment", passSCHcnt, failSCHcnt);
		        htmlbuilder_Summary.appendSummary_IntentWise("Non Intent related", otherPassCnt, otherFailCnt);
		        int intentPassed =passRCEcnt+ passBENcnt+passFOLcnt+passMBIcnt+passCHKcnt+passCLMcnt+passGSIcnt+passUPMcnt+passIDCcnt+passPUPcnt+passOUTcnt+passOCVcnt+passRTCcnt+passAUTcnt+passCLRcnt+passASIcnt+passCCMcnt+passFPRcnt+passALMcnt+passPCPcnt+passTOTcnt+passSCHcnt+otherPassCnt;
		        int intentFailed=failRCEcnt+failBENcnt+failFOLcnt+failMBIcnt+failCHKcnt+failCLMcnt+failGSIcnt+failUPMcnt+failIDCcnt+failPUPcnt+failOUTcnt+failOCVcnt+failRTCcnt+failAUTcnt+failCLRcnt+failASIcnt+failCCMcnt+failFPRcnt+failALMcnt+failPCPcnt+failTOTcnt+failSCHcnt+otherFailCnt;
		        htmlbuilder_Summary.appendSummary_IntentWise("Total",intentPassed,intentFailed);
		        htmlbuilder_Summary.append_closebody();
		        
		        
		        
		        String htmlcontent=htmlbuilder_Summary.sb.toString();
		        
		        ////System.out.println("htmlcontent:::::"+htmlcontent);
		        //launching the extent report at the end
		        
		       /*try {
		        	  Desktop desktop = java.awt.Desktop.getDesktop();
		        	  File f = new File(path);
		        	  URI u = f.toURI();
		        	  desktop.browse(u);
		        	} catch (Exception e) {
		        	  e.printStackTrace();
		        	}*/
		        //System.out.println("reportFilePath1:::"+reportFilePath1);
		        //System.out.println("path1:::"+path1);
		        //System.out.println("path:::"+path);
		        //System.out.println("report file::::"+extentFilepath+filename_Attachment);
		        refereshExcel();
		       //Sending Email after the execution(Need to pass parameters to send to email method)
		 
		        EmailUtil.sendEmailWithAttachment(path,Env_Subject,suiteStatus_Subject, timeStamp_email,path1, htmlcontent,extentFilepath,filename_Attachment);
		       
		     //EmailUtil.sendEmailWithAttachment(path,Env_Subject,suiteStatus_Subject, timeStamp_email,path1, htmlcontent);
		     
          	 //EmailUtil.sendEmailWithAttachment(path,Env_Subject,suiteStatus_Subject, timeStamp_email,reportFilePath1, htmlcontent);

		}

	}

	public void passedTCsCounts(ITestResult result){
		if (result.getTestClass().getName().contains("R4"))
			passCount_R4++;
		else if (result.getTestClass().getName().contains("R3"))
			passCount_R3++;
		else if (result.getTestClass().getName().contains("R2"))
			passCount_R2++;
		else if (result.getTestClass().getName().contains("R1"))
			passCount_R1++;
		
		if (result.getMethod().getMethodName().contains("RCE"))
			passRCEcnt++;
		else if (result.getMethod().getMethodName().contains("BEN"))
			passBENcnt++;
		else if (result.getMethod().getMethodName().contains("FOL"))
			passFOLcnt++;
		else if (result.getTestClass().getName().contains("MBI"))
			passMBIcnt++;
		else if (result.getTestClass().getName().contains("CHK"))
			passCHKcnt++;
		else if (result.getTestClass().getName().contains("CLM"))
			passCLMcnt++;
		else if (result.getTestClass().getName().contains("GSI"))
			passGSIcnt++;
		else if (result.getTestClass().getName().contains("UPM"))
			passUPMcnt++;
		else if (result.getTestClass().getName().contains("IDC"))
			passIDCcnt++;
		else if (result.getTestClass().getName().contains("PUP"))
			passPUPcnt++;
		else if (result.getTestClass().getName().contains("OUT"))
			passOUTcnt++;
		else if (result.getTestClass().getName().contains("OCV"))
			passOCVcnt++;
		else if (result.getTestClass().getName().contains("RTC"))
			passRTCcnt++;
		else if (result.getTestClass().getName().contains("AUT"))
			passAUTcnt++;
		else if (result.getTestClass().getName().contains("CLR"))
			passCLRcnt++;
		else if (result.getTestClass().getName().contains("ASI"))
			passASIcnt++;
		else if (result.getTestClass().getName().contains("CCM"))
			passCCMcnt++;
		else if (result.getTestClass().getName().contains("FPR"))
			passFPRcnt++;
		else if (result.getTestClass().getName().contains("ALM"))
			passALMcnt++;
		else if (result.getTestClass().getName().contains("PCP"))
			passPCPcnt++;
		else if (result.getTestClass().getName().contains("TOT"))
			passTOTcnt++;
		else if (result.getTestClass().getName().contains("SCH"))
			passSCHcnt++;
		else 
			otherPassCnt++;


		
	}
	
	public void failedTCsCounts(ITestResult result){
		if (result.getTestClass().getName().contains("R4"))
			failCount_R4++;
		else if (result.getTestClass().getName().contains("R3"))
			failCount_R3++;
		else if (result.getTestClass().getName().contains("R2"))
			failCount_R2++;
		else if (result.getTestClass().getName().contains("R1"))
			failCount_R1++;
		
		if (result.getMethod().getMethodName().contains("RCE"))
			failRCEcnt++;
		else if (result.getMethod().getMethodName().contains("BEN"))
			failBENcnt++;
		else if (result.getMethod().getMethodName().contains("FOL"))
			failFOLcnt++;
		else if (result.getTestClass().getName().contains("MBI"))
			failMBIcnt++;
		else if (result.getTestClass().getName().contains("CHK"))
			failCHKcnt++;
		else if (result.getTestClass().getName().contains("CLM"))
			failCLMcnt++;
		else if (result.getTestClass().getName().contains("GSI"))
			failGSIcnt++;
		else if (result.getTestClass().getName().contains("UPM"))
			failUPMcnt++;
		else if (result.getTestClass().getName().contains("IDC"))
			failIDCcnt++;
		else if (result.getTestClass().getName().contains("PUP"))
			failPUPcnt++;
		else if (result.getTestClass().getName().contains("OUT"))
			failOUTcnt++;
		else if (result.getTestClass().getName().contains("OCV"))
			failOCVcnt++;
		else if (result.getTestClass().getName().contains("RTC"))
			failRTCcnt++;
		else if (result.getTestClass().getName().contains("AUT"))
			failAUTcnt++;
		else if (result.getTestClass().getName().contains("CLR"))
			failCLRcnt++;
		else if (result.getTestClass().getName().contains("ASI"))
			failASIcnt++;
		else if (result.getTestClass().getName().contains("CCM"))
			failCCMcnt++;
		else if (result.getTestClass().getName().contains("FPR"))
			failFPRcnt++;
		else if (result.getTestClass().getName().contains("ALM"))
			failALMcnt++;
		else if (result.getTestClass().getName().contains("PCP"))
			failPCPcnt++;
		else if (result.getTestClass().getName().contains("TOT"))
			failTOTcnt++;
		else if (result.getTestClass().getName().contains("SCH"))
			failSCHcnt++;
		else 
			otherFailCnt++;
	}
	
	public void resultStatus(ITestResult result,String tcname, String tcstatus)
	{
		List<String> values = new ArrayList<String>();
		values.add(0, result.getTestClass().getName());
		values.add(1, tcname);
		values.add(2, tcstatus);
		results.put(tcname,values);
	}
	
	public void printMap(Map<String,List<String>> results)
	{
		for (String name: results.keySet()){
            String key = name.toString();
            //System.out.println("*************");
            //System.out.println("Key: "+key);
            List<String> value = results.get(name); 
            //System.out.println("*************"+value.size());
            String result= value.get(0);
            String tcname=value.get(1);
            String tcstatus=value.get(2);
            //System.out.println("Result: "+result);
            //System.out.println("tcname: "+tcname);
            //System.out.println("tcstatus: "+tcstatus);
            updatedetailreport(result, tcname, tcstatus);
		} 
	}
	
	public void updatedetailreport(String result,String tcname, String tcstatus) {
		int rowNum=0;
		
       String pathLoc=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("EXTREPORT_LOC");
       String reportLoc=pathLoc+ExtentManager.fileName;
       excel = new ExcelReader(reportFilePath);
       if (RunTestNG_NCompass_MA.Config.getProperty("Browser").equalsIgnoreCase("Chrome")){
			if (result.contains("R4")){
				rowNum = excel.getCellRowNum("R4", "TestCases", tcname);
				excel.setCellData("R4", "Chrome Execution Status", rowNum, tcstatus);
				excel.setCellData("R4", "Chrome Report File Name", rowNum, reportLoc);
			} else if (result.contains("R3")){
				rowNum = excel.getCellRowNum("R3", "TestCases", tcname);
				//System.out.println("rowNum::::"+rowNum);
				excel.setCellData("R3", "Chrome Execution Status", rowNum, tcstatus);
				excel.setCellData("R3", "Chrome Report File Name", rowNum, reportLoc);
			} else if (result.contains("R2")){
				rowNum = excel.getCellRowNum("R2", "TestCases", tcname);
				excel.setCellData("R2", "Chrome Execution Status", rowNum, tcstatus);
				excel.setCellData("R2", "Chrome Report File Name", rowNum, reportLoc);
			} else if (result.contains("R1")){
				rowNum = excel.getCellRowNum("R1", "TestCases", tcname);
				excel.setCellData("R1", "Chrome Execution Status", rowNum, tcstatus);
				excel.setCellData("R1", "Chrome Report File Name", rowNum, reportLoc);
			}
       } else if (RunTestNG_NCompass_MA.Config.getProperty("Browser").equalsIgnoreCase("ie")){
			if (result.contains("R4")){
				rowNum = excel.getCellRowNum("R4", "TestCases", tcname);
				excel.setCellData("R4", "IE Execution Status", rowNum, tcstatus);
				excel.setCellData("R4", "IE Report File Name", rowNum, reportLoc);
			} else if (result.contains("R3")){
				rowNum = excel.getCellRowNum("R3", "TestCases", tcname);
				//System.out.println("rowNum::::"+rowNum);
				excel.setCellData("R3", "IE Execution Status", rowNum, tcstatus);
				excel.setCellData("R3", "IE Report File Name", rowNum, reportLoc);
			} else if (result.contains("R2")){
				rowNum = excel.getCellRowNum("R2", "TestCases", tcname);
				excel.setCellData("R2", "IE Execution Status", rowNum, tcstatus);
				excel.setCellData("R2", "IE Report File Name", rowNum, reportLoc);
			} else if (result.contains("R1")){
				rowNum = excel.getCellRowNum("R1", "TestCases", tcname);
				excel.setCellData("R1", "IE Execution Status", rowNum, tcstatus);
				excel.setCellData("R1", "IE Report File Name", rowNum, reportLoc);
			}
       } 
	}

	
	public void getdetailreport(ITestResult result,String tcname, String tcstatus) {
		 /* int rowNum=0;
		
     String pathLoc=RunTestNG_NCompass_MA.Config.getProperty("EXTREPORT_LOC");
       String reportLoc=pathLoc+ExtentManager.fileName;
       excel = new ExcelReader(reportFilePath);
       if (RunTestNG_NCompass_MA.Config.getProperty("Browser").equalsIgnoreCase("Chrome")){
			if (result.getTestClass().getName().contains("R4")){
				rowNum = excel.getCellRowNum("R4", "TestCases", tcname);
				excel.setCellData("R4", "Chrome Execution Status", rowNum, tcstatus);
				excel.setCellData("R4", "Chrome Report File Name", rowNum, reportLoc);
			} else if (result.getTestClass().getName().contains("R3")){
				rowNum = excel.getCellRowNum("R3", "TestCases", tcname);
				//System.out.println("rowNum::::"+rowNum);
				excel.setCellData("R3", "Chrome Execution Status", rowNum, tcstatus);
				excel.setCellData("R3", "Chrome Report File Name", rowNum, reportLoc);
			} else if (result.getTestClass().getName().contains("R2")){
				rowNum = excel.getCellRowNum("R2", "TestCases", tcname);
				excel.setCellData("R2", "Chrome Execution Status", rowNum, tcstatus);
				excel.setCellData("R2", "Chrome Report File Name", rowNum, reportLoc);
			} else if (result.getTestClass().getName().contains("R1")){
				rowNum = excel.getCellRowNum("R1", "TestCases", tcname);
				excel.setCellData("R1", "Chrome Execution Status", rowNum, tcstatus);
				excel.setCellData("R1", "Chrome Report File Name", rowNum, reportLoc);
			}
       } else if (RunTestNG_NCompass_MA.Config.getProperty("Browser").equalsIgnoreCase("ie")){
			if (result.getTestClass().getName().contains("R4")){
				rowNum = excel.getCellRowNum("R4", "TestCases", tcname);
				excel.setCellData("R4", "IE Execution Status", rowNum, tcstatus);
				excel.setCellData("R4", "IE Report File Name", rowNum, reportLoc);
			} else if (result.getTestClass().getName().contains("R3")){
				rowNum = excel.getCellRowNum("R3", "TestCases", tcname);
				//System.out.println("rowNum::::"+rowNum);
				excel.setCellData("R3", "IE Execution Status", rowNum, tcstatus);
				excel.setCellData("R3", "IE Report File Name", rowNum, reportLoc);
			} else if (result.getTestClass().getName().contains("R2")){
				rowNum = excel.getCellRowNum("R2", "TestCases", tcname);
				excel.setCellData("R2", "IE Execution Status", rowNum, tcstatus);
				excel.setCellData("R2", "IE Report File Name", rowNum, reportLoc);
			} else if (result.getTestClass().getName().contains("R1")){
				rowNum = excel.getCellRowNum("R1", "TestCases", tcname);
				excel.setCellData("R1", "IE Execution Status", rowNum, tcstatus);
				excel.setCellData("R1", "IE Report File Name", rowNum, reportLoc);
			}
       } */
	}
	
	@SuppressWarnings("unused")
	public void refereshExcel(){
		FileInputStream excelFile;
		
		
		try {
			excelFile = new FileInputStream(new File(reportFilePath));
			XSSFWorkbook excelWorkbook = new XSSFWorkbook(excelFile);
	        XSSFSheet excelSheet = excelWorkbook.getSheet("Execution Summary Report");
	        XSSFFormulaEvaluator.evaluateAllFormulaCells(excelWorkbook);
	        excelFile.close();
	        FileOutputStream outExcelFile =new FileOutputStream(new File(reportFilePath));
	        excelWorkbook.write(outExcelFile);
	        outExcelFile.close();
	        FileOutputStream outExcelFile1 =new FileOutputStream(new File(reportFilePath1));
	        excelWorkbook.write(outExcelFile1);
	        outExcelFile.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block   
			e.printStackTrace();
		}
       

	}
}
