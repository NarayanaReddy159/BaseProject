package com.nasco.MA.Pages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class Find_A_ProviderPage extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget2Ifr";
	String startDt="",endDt="";
	
	//@Override
	protected ExpectedCondition getPageLoadCondition() {
		//switchToFrame(frame1);
		switchToFrame(frame1);
		//return ExpectedConditions.visibilityOf(intentID);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
		
		
	}
		
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Find_A_ProviderPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Find_A_ProviderPageFields.properties";
			switchToFrame(frame1);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, frame1, "Find A Provider", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	public void Searchcriteria(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Find_A_ProviderPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Find_A_ProviderPageFields.properties";
			switchToFrame(frame);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "providerlastname", true, frame, data.get("Provider last name"), "provider last name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, frame, data.get("City"), "City");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, frame, data.get("State"), "State");
						
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "search", true, frame, "Search", "search button");

			waitSleep(3000);
                 
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}
	public void searchresults(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Find_A_ProviderPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Find_A_ProviderPageFields.properties";
			switchToFrame(frame);
			
		String searchresults="";
		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PAppProviderList$ppxResults$l1')]"));
	       String s="//tr[contains(@id,'$PAppProviderList$ppxResults$l1')]";
	       for(int i=0;i<ele.size();i++)
	    {
		    String s1=String.format(s, i+1);
		    String memdet="";
		    List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
		    System.out.println(colums.size());
		     for(int j=0;j<colums.size();j++)
		    	
		{
			if(j==0)
			{
				System.out.println("action");
				memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
			}
			else{
				memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
			}
		}
		     searchresults=searchresults+","+memdet;	
	     }
			
		       System.out.println(searchresults);
		       assertEquals(data.get("Expected_details"), searchresults, "search results");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectmember", true, frame, "", "select member");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "add", true, frame, "", "add button");

			waitSleep(3000);
                 
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}

	
	public void Selectedproviders(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Find_A_ProviderPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Find_A_ProviderPageFields.properties";
			switchToFrame(frame);
			
		String Selectedproviders="";
		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pSelectedProviderslist$l1')]"));
	       String s="//tr[contains(@id,'$PpyWorkPage$pSelectedProviderslist$l1')]";
	       for(int i=0;i<ele.size();i++)
	    {
		    String s1=String.format(s, i+1);
		    String memdet="";
		    List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
		    System.out.println(colums.size());
		     for(int j=0;j<colums.size();j++)
		    	
		{
			if(j==0)
			{
				System.out.println("action");
				memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
			}
			else{
				memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
			}
		}
		     Selectedproviders=Selectedproviders+","+memdet;	
	     }
			
		       System.out.println(Selectedproviders);
		       
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comment", true, frame, "Search sucessfully", "comment");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "Submit", "submit");
			waitSleep(2000);

				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}


	}


