package com.nasco.MA.Pages;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;

@SuppressWarnings("rawtypes")
public class Member360Page extends BasePage {
	
	@FindBy(xpath = "(//h3[contains(text(),'Contract')])[2]")
	public WebElement contractTab;

	String excepionMessage;

	

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(contractTab);
	}


	
	public void getHeaderDetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
				pageLocatorsPath= pageLocatorsPath+"\\Member360PageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Member360PageFields.properties";
				waitSleep(5000);
				switchToDefault();
				String title=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "headerTitle", false, "", "", "Title");
				//String Memberinfocus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Memberinfocus", false, "", "", "Member in focus");
				String Gender=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Gender", false, "", "", "Gender");
				String DOB=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "DOB", false, "", "", "DOB");
				String Email=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Email", false, "", "", "Email");
				String actualValue=title+"|"+Gender+"|"+DOB+"|"+Email;
				System.out.println("actualValue: "+actualValue);
				assertEquals(data.get("ExpectedHeader"), actualValue, "Member 360 Header Details");
				//assertCompare(data.get("ExpectedHeader"), actualValue, "Member 360 Header Details");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getHeaderDetails method " + e);
			test.log(LogStatus.FAIL, "Error on getHeaderDetails method " + e);
			Assert.fail();
		}
		
	}
	
	public void getProsHeaderDetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Member360PageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Member360PageFields.properties";
			waitSleep(3500);
			switchToDefault();
			String Memberinfocus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Memberinfocus", false, "", "", "Member in focus");
			String DOB=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "DOB", false, "", "", "DOB");
			String actualValue=Memberinfocus+"|"+DOB;
			System.out.println("actualValue: "+actualValue);
			assertEquals(data.get("ExpectedHeader"), actualValue, "Member 360 Header Details");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getProsHeaderDetails method " + e);
			test.log(LogStatus.FAIL, "Error on getProsHeaderDetails method " + e);
			Assert.fail();
		}
	}

	
	
	public void getContractDetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			Properties pageLocatorsprop = new Properties();
			pageLocatorsPath= pageLocatorsPath+"\\Member360PageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Member360PageFields.properties";
			FileInputStream LocatorsIn= new FileInputStream(pageLocatorsPath);
			pageLocatorsprop.load(LocatorsIn);
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			String Subscribername=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Subscribername", true, "PegaGadget1Ifr", "", "Subscriber name");
			String Groupname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Groupname", true, "PegaGadget1Ifr", "", "Group name");
			String Anniversarydate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Anniversarydate", true, "PegaGadget1Ifr", "", "Anniversary date");
			String contractType=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "contractType", true, "PegaGadget1Ifr", "", "contract Type");
			String Planname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Planname", true, "PegaGadget1Ifr", "", "Plan name");
			String Effectivedate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Effectivedate", true, "PegaGadget1Ifr", "", "Effective date");
			String Originaleffectivedate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Originaleffectivedate", true, "PegaGadget1Ifr", "", "Original effective date");
			String Personalspendingaccount=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Personalspendingaccount", true, "PegaGadget1Ifr", "", "Personal spending account");
			
			String actual=Subscribername+"|"+Groupname+"|"+Anniversarydate+"|"+contractType+"|"+
					Planname+"|"+Effectivedate+"|"+Originaleffectivedate+"|"+Personalspendingaccount;
			System.out.println("actual Contract Details: "+actual);
			assertEquals(data.get("ExpectedContractDetails"), actual, "Contract Details");
			
			String memberDetails=readTableData(pageLocatorsprop.getProperty("MembersRowWebElementvalue"), "//tr[contains(@id,'$PD_MemberData_pa') and contains(@id,'ppxResults$l%d')]");
			assertEquals(data.get("ExpectedMemberDetails"), memberDetails, "Member Details");
			/*WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Vendors", true, "PegaGadget1Ifr", "", "Vendors");
			waitSleep(2000);
			memberDetails=readTableData(pageLocatorsprop.getProperty("VendorsRowWebElementvalue"), "//tr[contains(@id,'$PpyWorkPage$pVendorDetails$l%d')]");
			assertEquals(data.get("ExpectedVendorDetails"), memberDetails, "Vendor Details");*/
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getContractDetails method " + e);
			test.log(LogStatus.FAIL, "Error on getContractDetails method " + e);
			Assert.fail();
		}
		
	}
	
	public void getMemberDetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_PSA method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
			Assert.fail();
		}
		
	}
	
	public void getGroupDetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Member360PageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Member360PageFields.properties";
			
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Grouptab", true, "PegaGadget1Ifr", "", "Group tab");
			waitSleep(1500);
			String Accountname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Accountname", true, "PegaGadget1Ifr", "", "Account name");
			String Accountnumber=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Accountnumber", true, "PegaGadget1Ifr", "", "Account number");
			String Groupnumber=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Groupnumber", true, "PegaGadget1Ifr", "", "Group number");
			String Groupname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Groupname", true, "PegaGadget1Ifr", "", "Group name");
			String MembersEdgegroup=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "MembersEdgegroup", true, "PegaGadget1Ifr", "", "Members Edge group");
			String PlanName=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "PlanName", true, "PegaGadget1Ifr", "", "Plan Name");
			String LEGcode=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "LEGcode", true, "PegaGadget1Ifr", "", "LEG code");
			String Coverageprefix=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Coverageprefix", true, "PegaGadget1Ifr", "", "Coverage prefix");
			String Groupstatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Groupstatus", true, "PegaGadget1Ifr", "", "Group status");
			
			String actual=Accountname+"|"+Accountnumber+"|"+Groupnumber+"|"+Groupname+"|"+MembersEdgegroup+
					"|"+PlanName+"|"+LEGcode+"|"+Coverageprefix+"|"+Groupstatus;
		
			System.out.println("actual: "+actual);
			
			assertEquals(data.get("ExpectedGroupDetails"), actual, "Group Details");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getGroupDetails method " + e);
			test.log(LogStatus.FAIL, "Error on getGroupDetails method " + e);
			Assert.fail();
		}
		
	}
	
	public void getInteractions(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			Properties pageLocatorsprop = new Properties();
			pageLocatorsPath= pageLocatorsPath+"\\Member360PageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Member360PageFields.properties";
			FileInputStream LocatorsIn= new FileInputStream(pageLocatorsPath);
			pageLocatorsprop.load(LocatorsIn);
			
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "interactiontab", true, "PegaGadget1Ifr", "", "interaction tab");
			waitSleep(1500);
			String actual=getListitemstext(pageLocatorsprop.getProperty("recentInteractionsWebElementvalue"));
			System.out.println("recentInteractionsWebElementvalue: "+actual);
			assertCompare(data.get("ExpectedRecentInteractionsHeader"),actual,"Recent Interactions");
			actual=getListitemstext(pageLocatorsprop.getProperty("BlueserveconnectWebElementvalue"));
			System.out.println("BlueserveconnectWebElementvalue: "+actual);
			assertCompare(data.get("ExpectedWorkitemsHeader"), actual, "Blueserve connect");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "workSheets", true, "PegaGadget1Ifr", "", "work Sheets");
			actual=getListitemstext(pageLocatorsprop.getProperty("workitemsWebElementvalue"));
			System.out.println("workitemsWebElementvalue: "+actual);
			assertCompare(data.get("ExpectedWorksheetsHeader"), actual, "worksheets");
			waitSleep(3500);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getInteractions method " + e);
			test.log(LogStatus.FAIL, "Error on getInteractions method " + e);
			Assert.fail();
		}
		
	}
	
	public void verifyContract(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Member360PageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Member360PageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "searchByDate", true, "PegaGadget1Ifr", "", "search By Date");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchFrom", true, "PegaGadget1Ifr", data.get("ContractSrchStartDate"), "search From Date");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchTo", true, "PegaGadget1Ifr", data.get("ContractSrchEndDate"), "search To Date");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Gobtn", true, "PegaGadget1Ifr", "", "Go");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contractLink", true, "PegaGadget1Ifr", data.get("ContractID"), "contract Link");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on verifyContract method " + e);
			test.log(LogStatus.FAIL, "Error on verifyContract method " + e);
			Assert.fail();
		}
			
	}
	
	public void switchMember(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Member360PageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Member360PageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PD_MemberData_pa') and contains(@id,'ppxResults$l')]"));
			System.out.println(ele.size());
			String s="//tr[contains(@id,'$PD_MemberData_pa') and contains(@id,'ppxResults$l%d')]";
			for(int i=0;i<=ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member id:"+driver.findElement(By.xpath(s1+"//td[3]")).getText());
				if(driver.findElement(By.xpath(s1+"//td[3]")).getText().equals(data.get("SwitchMemberName")))
				{
					doubleClickWebelement("xpath", "//span[contains(text(),'%s')]", data.get("SwitchMemberName"));
					System.out.println("performed click action");
					waitSleep(3500);
					break;
				}
			}
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMember method " + e);
			test.log(LogStatus.FAIL, "Error on switchMember method " + e);
			Assert.fail();
		}
	}
	
	public void switchMemberPrivacy(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Member360PageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Member360PageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget2Ifr");
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PD_MemberData_pa') and contains(@id,'ppxResults$l')]"));
			System.out.println(ele.size());
			String s="//tr[contains(@id,'$PD_MemberData_pa') and contains(@id,'ppxResults$l%d')]";
			for(int i=0;i<=ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member id:"+driver.findElement(By.xpath(s1+"//td[3]")).getText());
				if(driver.findElement(By.xpath(s1+"//td[3]")).getText().equals(data.get("SwitchMemberName")))
				{
					doubleClickWebelement("xpath", s1, data.get("SwitchMemberName"));
					System.out.println("performed click action");
					break;
				}
			}
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Error on switchMemberPrivacy method " + e);
			Assert.fail();
		}
		
	}
	
	public void validateViewAlerts(String pageLocatorsPath,String pageFiledsPath,String alertDesc){
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Member360PageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Member360PageFields.properties";
			waitSleep(1500);
			switchToDefault();
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ViewAlertsbtn", false, "", "", "View Alerts");
			waitSleep(1000);
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PD_Interaction_pa') and contains(@id,'pMbr360AlertsNotVerified$l')]"));
			System.out.println(ele.size());
			String s="//tr[contains(@id,'$PD_Interaction_pa') and contains(@id,'pMbr360AlertsNotVerified$l%d')]";
			for(int i=0;i<=ele.size();i++)
			{
				String s1=String.format(s, i+1);
				String actAlertDesc =driver.findElement(By.xpath(s1+"//td[3]//span")).getText();
				System.out.println("alertDesc:"+driver.findElement(By.xpath(s1+"//td[3]//span")).getText());
			
				if(actAlertDesc.equals(alertDesc))
				{
					assertEquals(alertDesc, actAlertDesc, "Alert Description");
					break;
				}
			}
	
			

		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateCodesDetails method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateViewAlerts method " + e);
			Assert.fail();
		}
		
	}
	
	public void assertCompare(String expected, String actual, String logname)
	{
		if(expected.contains(actual))
		{
			test.log(LogStatus.INFO, "Expected Value: " + expected);
			test.log(LogStatus.INFO, "Actual Value: " + actual);
			test.log(LogStatus.PASS, "Actual and excepted values are matched for "+logname);
		}
		else{
			test.log(LogStatus.INFO, "Expected Value: " + expected);
			test.log(LogStatus.INFO, "Actual Value: " + actual);
			test.log(LogStatus.FAIL, "Actual and excepted values are not matched for "+logname);
			Assert.fail();
		}
	}
}		
