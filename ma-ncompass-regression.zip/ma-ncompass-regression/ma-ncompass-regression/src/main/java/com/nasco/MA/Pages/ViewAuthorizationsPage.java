package com.nasco.MA.Pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;




public class ViewAuthorizationsPage extends BasePage {

	@FindBy(xpath="//label[@id='pyActionLabel']//following::span[1]")
	public WebElement intentID;
	public String frame1="PegaGadget2Ifr";

	String excepionMessage="";
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget2Ifr");
		//return ExpectedConditions.visibilityOf(intentID);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
	}
	
	public int countofRows()
	{
		int count=0;
		switchToFrame("PegaGadget2Ifr");
		waitSleep(3000);
		List<WebElement> rowsCount=driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pHCAuthResults$l')]"));
		if(rowsCount!=null)
			count=rowsCount.size();
		return count;
	}
	
	public void clickonAuth()
	{
		driver.findElement(By.xpath("//*[@id='$PpyWorkPage$pHCAuthResults$l1']/td[1]/span")).click();
	}
	
	
	public void closeintentwithNotes(String pageLocatorsPath,String pageFiledsPath, String comments){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewAuthorizationsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewAuthorizationsPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget2Ifr", comments, "View Authorization Comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closebutton", true, "PegaGadget2Ifr", comments, "View Authorization Close");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on  closeintentwithNotes method " + e);
			test.log(LogStatus.FAIL, "Error on  closeintentwithNotes method " + e);
			Assert.fail();
		}
	}
	public void readAuthRows(String pageLocatorsPath,String pageFiledsPath, String expectedResult) throws Exception
	{
		String AuthRows="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewAuthorizationsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewAuthorizationsPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitSleep(9000);
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pHCAuthResults$l')]"));
			String s="//tr[contains(@id,'$PpyWorkPage$pHCAuthResults$l%d')][1]";
			if(ele.size()==0){
				ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pHCAuthResults$l')][1]"));
				s="//tr[contains(@id,'$PpyWorkPage$pHCAuthResults$l%d')][1]";
			}
			System.out.println("WebElements Rows  :::::::::::::::::::::::::::::::::::::" + ele.size());
			
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				String memdet="";
				List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
				System.out.println("Columns :"+ colums.size());
				for(int j=2;j<colums.size()-2;j++)
				{
					if(j==2)
					{
						memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
					else{
						memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
				}
				AuthRows=AuthRows+","+memdet;	
			}
			waitSleep(4000);
			AuthRows=AuthRows.substring(1,AuthRows.length());
			System.out.println(AuthRows);
			assertEquals(expectedResult, AuthRows, "Authorizations Rows");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on readAuthRows method " + e);
			test.log(LogStatus.FAIL, "Error on readAuthRows method " + e);
			Assert.fail();
		}
		
	}
	
	public void readAuthDetails(String pageLocatorsPath,String pageFiledsPath, String expectedResult) throws Exception
	{
		String AuthRows="";
		try{
			List<String> headerRow= new ArrayList<String>();
			headerRow.add("Date of birth");
			headerRow.add("Relationship");
			headerRow.add("Gender");
			headerRow.add("First date of service");
			headerRow.add("Last date of service");
			headerRow.add("Length of authorization");
			headerRow.add("Date entered");
			headerRow.add("Total approved units");
			headerRow.add("Units used");
			headerRow.add("Remaining units");
			headerRow.add("Servicing facility");
			headerRow.add("Servicing provider");
			headerRow.add("Servicing provider type and speciality");
			headerRow.add("Servicing provider NPI");
			headerRow.add("Primary risk component");
			headerRow.add("Secondary risk component");
			headerRow.add("Source");
			headerRow.add("Referring provider NPI");
			headerRow.add("Referring provider type and specialty");
			headerRow.add("Referring business entity");
			headerRow.add("Referring business entity NPI");
			pageLocatorsPath= pageLocatorsPath+"\\ViewAuthorizationsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewAuthorizationsPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitSleep(9000);
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pHCAuthResults$l')]"));
			String s="//tr[contains(@id,'$PpyWorkPage$pHCAuthResults$l%d')][1]";
			if(ele.size()==0){
				ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pHCAuthResults$l')][1]"));
				s="//tr[contains(@id,'$PpyWorkPage$pHCAuthResults$l%d')][1]";
			}
			System.out.println("WebElements Rows  :::::::::::::::::::::::::::::::::::::" + ele.size());
			
			for(int i=0;i<1;i++)
			{
				String s1=String.format(s, i+1);
				//String memdet="";
				//List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
				//System.out.println("Columns :"+ colums.size());
				driver.findElement(By.xpath(s1+"//td[2]")).click();
				waitSleep(2000);
				driver.findElement(By.xpath(s1+"//td[1]")).click();
				ArrayList<String> rowData= new ArrayList<String>();
				for(int j=0;j<headerRow.size();j++)
				{
					rowData.add(driver.findElement(By.xpath("//div[@id='rowDetail$PpyWorkPage$pHCAuthResults$l1']//following::span[contains(text(),'"+headerRow.get(j)+"')]/following::span[1]")).getText());
					if(j==0){
						AuthRows=rowData.get(j);
					}else{
					AuthRows=AuthRows + "|" + rowData.get(j);
					}
				}
					
			}
					
			waitSleep(4000);
			//rowData=AuthRows;
			AuthRows=AuthRows.substring(1,AuthRows.length());
			System.out.println(AuthRows);
			assertEquals(expectedResult, AuthRows, "Authorizations Rows Details");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on readAuthDetails method " + e);
			test.log(LogStatus.FAIL, "Error on readAuthDetails method " + e);
			Assert.fail();
		}
		
	}
	public void readAuthDetailsRecentWork(String pageLocatorsPath,String pageFiledsPath, String expectedResult) throws Exception
	{
		String AuthRows="";
		try{
			List<String> headerRow= new ArrayList<String>();
			headerRow.add("Date of birth");
			headerRow.add("Relationship");
			headerRow.add("Gender");
			headerRow.add("First date of service");
			headerRow.add("Last date of service");
			headerRow.add("Length of authorization");
			headerRow.add("Date entered");
			headerRow.add("Total approved units");
			headerRow.add("Units used");
			headerRow.add("Remaining units");
			headerRow.add("Servicing facility");
			headerRow.add("Servicing provider");
			headerRow.add("Servicing provider type and speciality");
			headerRow.add("Servicing provider NPI");
			headerRow.add("Primary risk component");
			headerRow.add("Secondary risk component");
			headerRow.add("Source");
			headerRow.add("Referring provider NPI");
			headerRow.add("Referring provider type and specialty");
			headerRow.add("Referring business entity");
			headerRow.add("Referring business entity NPI");
			pageLocatorsPath= pageLocatorsPath+"\\ViewAuthorizationsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewAuthorizationsPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			driver.findElement(By.xpath("//*[@id='$PpgRepPgSubSectionCPMReviewCasesInInteractionBB$ppxResults$l1']/td[3]/div/span/a")).click();
			waitSleep(9000);
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
				if(!mainWindow.equals(childWindow)){
						driver.switchTo().window(childWindow);
						System.out.println(driver.switchTo().window(childWindow).getTitle());
						List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PLinkReview$pHCAuthResults$l')]"));
						String s="//tr[contains(@id,'$PLinkReview$pHCAuthResults$l%d')][1]";
						if(ele.size()==0){
								ele= driver.findElements(By.xpath("//tr[contains(@id,'$PLinkReview$pHCAuthResults$l')][1]"));
								s="//tr[contains(@id,'$PLinkReview$pHCAuthResults$l%d')][1]";
						}
						System.out.println("WebElements Rows  :::::::::::::::::::::::::::::::::::::" + ele.size());
			
						for(int i=0;i<1;i++)
						{
							String s1=String.format(s, i+1);
							//String memdet="";
							//List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
							//System.out.println("Columns :"+ colums.size());
							//driver.findElement(By.xpath(s1+"//td[2]")).click();
							//driver.findElement(By.xpath(s1+"//td[1]")).click();
							ArrayList<String> rowData= new ArrayList<String>();
							for(int j=0;j<headerRow.size();j++)
							{
								rowData.add(driver.findElement(By.xpath("//div[@id='rowDetail$PLinkReview$pHCAuthResults$l1']//following::span[contains(text(),'"+headerRow.get(j)+"')]/following::span[1]")).getText());
								if(j==0){
									AuthRows=rowData.get(j);
								}else{
									AuthRows=AuthRows + "|" + rowData.get(j);
								}
							}
					
						}
					
					waitSleep(4000);
					//rowData=AuthRows;
					AuthRows=AuthRows.substring(1,AuthRows.length());
					System.out.println(AuthRows);
					assertEquals(expectedResult, AuthRows, "Authorizations Rows Details");
					driver.findElement(By.xpath("//button[@title='Close this item']")).click();
					//driver.close();
				}
				
			}
			driver.switchTo().window(mainWindow);		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on readAuthDetailsRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on readAuthDetailsRecentWork method " + e);
			Assert.fail();
		}
		
	}
	
	public String getResolveDate(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{	
		String resolvedateid="";
		try{
			waitSleep(2000);
			pageLocatorsPath= pageLocatorsPath+"\\ViewAuthorizationsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewAuthorizationsPageFields.properties";
			switchToFrame(frame);
			resolvedateid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ResolveDate", true, frame, "", "ResolveDate");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getResolveDate method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getResolveDate method " + e);
			Assert.fail();
		}
		return resolvedateid;
	}
	
	public void closeViewAuth(String pageLocatorsPath,String pageFiledsPath, String frame){
		pageLocatorsPath= pageLocatorsPath+"\\ViewAuthorizationsPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ViewAuthorizationsPageFields.properties";
		waitSleep(1000);
		try {
			switchToFrame(frame);
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CloseViewAuth", true, frame, "Close", "Close View Authorization");
			waitSleep(3000);

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on closeViewAuth method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on closeViewAuth method " + e);
			Assert.fail();

		}

	}

	public void clickCreateNewWork_RTC(String pageLocatorsPath,String pageFiledsPath, String frame){
		pageLocatorsPath= pageLocatorsPath+"\\ViewAuthorizationsPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ViewAuthorizationsPageFields.properties";
		waitSleep(1000);
		try {
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CreatenewWork", true, frame, "Create new work", "Create new work");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RespondtoCustomer", true, frame, "Respond To Customer", "Respond to Customer");
			
			waitSleep(2000);
			
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CloseViewAuth", true, frame, "Close", "Close View Authorization");
//			waitSleep(3000);

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickCreateNewWork_ViewAuthorization method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickCreateNewWork_ViewAuthorization method " + e);
			Assert.fail();

		}

	}

}

