package com.nasco.MA.Pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;




public class ManageClaimPageIntend extends BasePage {

	@FindBy(xpath="//label[@id='pyActionLabel']//following::span[1]")
	public WebElement intentID;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget2Ifr");
		return ExpectedConditions.visibilityOf(intentID);

	}
	public void performroutetoclaimresearch(String pageLocatorsPath,String pageFiledsPath,String researchreason,String CommentsRoute) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RouteClaimResearch", true, "PegaGadget2Ifr", "", "route to claimresearch");
			waitSleep(3500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "researchreason", true, "PegaGadget2Ifr", researchreason, "research reason");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "CommentsRoute", true, "PegaGadget2Ifr", CommentsRoute, "Comments Route");		
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "researchreason", true, "PegaGadget2Ifr", researchreason, "research reason");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on routetoCOB method " + e);
			test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
			Assert.fail();
		}
		
	}
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "Search For Claim", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	public void pendingCLM(String pageLocatorsPath,String pageFiledsPath,String enddate,String responseComments) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "responsepending", true, "PegaGadget1Ifr", "Pend for Additional Information", "Response Pending");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "enddate", true, "PegaGadget1Ifr", enddate, "End date");
			waitSleep(2000);

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "responseComments", true, "PegaGadget1Ifr", responseComments ,"Comments");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitResponse", true, "PegaGadget1Ifr", "","Submit");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on resolveMOC method " + e);
			test.log(LogStatus.FAIL, "Error on resolveMOC method " + e);
			Assert.fail();
		}
		
	}
public void resolveCLM(String pageLocatorsPath,String pageFiledsPath) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
		switchToFrame("PegaGadget1Ifr");
		waitSleep(3000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "responseComments", true, "PegaGadget1Ifr", "Resolving Intent","Comments");
		waitSleep(1500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "responseresolve", true, "PegaGadget1Ifr", "responseResolve", "Response Resolve");
		waitSleep(1500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitResponse", true, "PegaGadget1Ifr", "","Submit");
		waitSleep(3000);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on resolveMOC method " + e);
		test.log(LogStatus.FAIL, "Error on resolveMOC method " + e);
		Assert.fail();
		}
	
	}
public void routetoclaimworkbasket(String pageLocatorsPath,String pageFiledsPath) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
		switchToFrame("PegaGadget1Ifr");
		waitSleep(3000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "responseComments", true, "PegaGadget1Ifr", "Route to claim workbasket","Comments");
		waitSleep(1000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "routetoclaimworkbasket", true, "PegaGadget1Ifr", "route to claimworkbasket", "Response Resolve");

		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitResponse", true, "PegaGadget1Ifr", "","Submit");
		waitSleep(3000);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on resolveMOC method " + e);
		test.log(LogStatus.FAIL, "Error on resolveMOC method " + e);
		Assert.fail();
		}
	
	}
public void Pendingerror(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		String Errors=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Errors", true, "PegaGadget1Ifr", data.get("ExpectedErrors"), "Errors message");
		System.out.println(Errors);


	
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void SearchforClaim(String pageLocatorsPath,String pageFiledsPath) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "searchforClaim", true, "PegaGadget2Ifr", "", "Search for Claim");
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void viewClaimDetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		String claimdetail=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "claimdetail", true, "PegaGadget2Ifr", "", "Claim detail ");
		String PrefixSubIDExtent=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "prefixSubIDExtent", true, "PegaGadget2Ifr", "", "prefix SubID Extent ");
		String Firstdate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "firstdate", true, "PegaGadget2Ifr", "", "First date of service ");
		String Lastdate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "lastdate", true, "PegaGadget2Ifr", "", "Last date ");
		String Claimtype=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "claimtype", true, "PegaGadget2Ifr", "", "Claim type");
		String providername=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "providername", true, "PegaGadget2Ifr", "", "provider name ");
		String  providerID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "providerID", true, "PegaGadget2Ifr", "", " provider ID ");
		String providerNPI=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "providerNPI", true, "PegaGadget2Ifr", "", "provider NPI");
		String NASCOgroupnumber=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "nascogroup", true, "PegaGadget2Ifr", "", "NASCO group number ");
		String  Name=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "name", true, "PegaGadget2Ifr", "", "Patient name");
		String PatientDOB=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "dob", true, "PegaGadget2Ifr", "", "Patient DOB");
		String Patientgender=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "gender", true, "PegaGadget2Ifr", "", "Patient gender");
		String Patientrelationship=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "relationship", true, "PegaGadget2Ifr", "", "Patient relationship ");
		String  Groupnumber=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "groupnumber", true, "PegaGadget2Ifr", "", " Group number");
		String Numberoflines=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "lines", true, "PegaGadget2Ifr", "", "Number of lines");
		String  Payee=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Payee", true, "PegaGadget2Ifr", "", "Payee");
		String Totalchargeamount=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "chargeamount", true, "PegaGadget2Ifr", "", "Total charge amount");
		String Totalallowedamount=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "allowedamount", true, "PegaGadget2Ifr", "", "Total allowed amount");
		String Totalpaidamount=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "paidamount", true, "PegaGadget2Ifr", "", "Total paid amount ");
		String  Totaldeductible=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "deductible", true, "PegaGadget2Ifr", "", " Total deductible");
		String Totalcoinsurance=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "coinsurance", true, "PegaGadget2Ifr", "", "Total coinsurance");
		String Totalcopayment=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "copayment", true, "PegaGadget2Ifr", "", "Total copayment");
		String  Totalmemberliability=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "liability", true, "PegaGadget2Ifr", "", " Total member liability");
        
          String Result=claimdetail+"|"+PrefixSubIDExtent+"|"+Firstdate+"|"+Lastdate+"|"+Claimtype+"|"+providername+"|"+providerID+"|"+providerNPI+"|"+NASCOgroupnumber+"|"+Name+"|"+PatientDOB+"|"+Patientgender+"|"+Patientrelationship+"|"+Groupnumber+"|"+Numberoflines+"|"+Payee+"|"+Totalchargeamount+"|"+Totalallowedamount+"|"+Totalpaidamount+"|"+Totaldeductible+"|"+Totalcoinsurance+"|"+Totalcopayment+"|"+Totalmemberliability ;
          
          System.out.println(Result);
          assertEquals(data.get("ExpectedResult"), Result , "Details");
          
				
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void linedetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		String linedetails="";
		List<WebElement> ele= driver.findElements(By.xpath("(//table[@prim_page='pyWorkPage']//tr)[1]//th"));
       String s="(//table[@prim_page='pyWorkPage']//tr)[1]//th";
       for(int i=1;i<=18;i++)
    {
	    String s1="//table[@prim_page='pyWorkPage']//tr";
	    String memdet="";
	    List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
	     for(int j=0;j<18;j++)
	{
		if(j==0)
		{
			memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
		else{
			memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
	}
	     linedetails=linedetails+","+memdet;	
     }
       linedetails=linedetails.substring(1,linedetails.length());
		System.out.println(linedetails);
		waitSleep(1000);
		assertEquals(data.get("Expected_linedetails"), linedetails, "Member Search Results");
				
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void viewBenefits(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "viewBenefits", true, "PegaGadget2Ifr", "", "view Benefits");
		switchToFrame("PegaGadget3Ifr");
		String  MemberID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "memberID", true, "PegaGadget2Ifr", "", "Member ID");
		String  Accountnumber=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "accountnumber", true, "PegaGadget2Ifr", "", "Account number");
		String  Accountname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "accountname", true, "PegaGadget2Ifr", "", "Account name");
		String  Groupnumber=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "groupnumber", true, "PegaGadget2Ifr", "", " Group number");
		String  Groupname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "groupname", true, "PegaGadget2Ifr", "", "Group name");
		String  Planname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "planname", true, "PegaGadget2Ifr", "", "Plan name");
		String  Coveragepackagecode=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "coveragepackagecode", true, "PegaGadget2Ifr", "", "Coverage package code");
		String  Coveragepackagecodeprefix=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "packagecodeprefix", true, "PegaGadget2Ifr", "", "Coverage package code prefix");
		String  MCCcompliant=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "compliant", true, "PegaGadget2Ifr", "", "MCC compliant");
        String viewBenefits=MemberID+"|"+Accountnumber+"|"+Accountname+"|"+Groupnumber+"|"+Groupname+"|"+Planname+"|"+Coveragepackagecode+"|"+Coveragepackagecodeprefix+"|"+MCCcompliant;
		System.out.println(viewBenefits);
		assertEquals(data.get("ExpectedviewBenefits"),viewBenefits,"View Benefits Results");
		
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "quoteabenefitNO", true, "PegaGadget2Ifr", "", "quoteabenefitNO");

		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget2Ifr", "","Submit");
		waitSleep(3000);

	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void routetoclaimresearchPSA(String pageLocatorsPath,String pageFiledsPath,String researchreason,String PSA,String CommentsRoute) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RouteClaimResearch", true, "PegaGadget2Ifr", "", "route to claimresearch");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "researchreason", true, "PegaGadget2Ifr", researchreason, "research reason");
		waitSleep(2500);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "CommentsRoute", true, "PegaGadget2Ifr", CommentsRoute, "Comments Route");		
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "researchreason", true, "PegaGadget2Ifr", researchreason, "research reason");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "personalspendingaccount", true, "PegaGadget2Ifr", PSA, "Personal spending account");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget2Ifr", "", "Submit");
		waitSleep(2500);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void routetoclaimresearchVendor(String pageLocatorsPath,String pageFiledsPath,String researchreason,String Vendor,String CommentsRoute) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RouteClaimResearch", true, "PegaGadget2Ifr", "", "route to claimresearch");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "researchreason", true, "PegaGadget2Ifr", researchreason, "research reason");
		waitSleep(2500);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "CommentsRoute", true, "PegaGadget2Ifr", CommentsRoute, "Comments Route");		
		waitSleep(1500);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "researchreason", true, "PegaGadget2Ifr", researchreason, "research reason");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Vendor", true, "PegaGadget2Ifr", Vendor, "Personal spending account");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget2Ifr", "", "Submit");
		waitSleep(3500);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void followUpPendingWork(String pageLocatorsPath,String pageFiledsPath,String reasontopend,String commentsPending) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "pendingWork", true, "PegaGadget2Ifr", "", "route to pendingWork");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsPending", true, "PegaGadget2Ifr", commentsPending, "comments Pending");		
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "reasontopend", true, "PegaGadget2Ifr", reasontopend, "research reason");
		waitSleep(3000);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		System.out.println(dateFormat.format(date));
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Enddate", true, "PegaGadget1Ifr",dateFormat.format(date), "End date");

		//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SaveButton", true, "PegaGadget2Ifr", "", "Save");
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void determineNextAction(String pageLocatorsPath,String pageFiledsPath) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SaveButton", true, "PegaGadget2Ifr", "", "SaveButton");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "determinenextaction", true, "PegaGadget2Ifr", "", "determine next action");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget2Ifr", "", "Submit");
		waitSleep(3500);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void history(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(2500);
	switchToFrame("PegaGadget1Ifr");
	try {

	String parentWindow=driver.getWindowHandle();
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
	waitSleep(2000);
	for (String windowHandle : driver.getWindowHandles())
	{
		if(!parentWindow.equals(windowHandle)){
			 driver.switchTo().window(windowHandle);
			 System.out.println("Switched to"+windowHandle);
		}
		System.out.println(windowHandle);
		
	}
	
	switchToDefault();
	String AuditLog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AuditLog", true, "PegaGadget1Ifr", "", "Audit Log");
	System.out.println(AuditLog);
	//assertEquals(AuditLog, data.get("AuditLog"), "Audit Log");
	assertContains(data.get("AuditLog"), AuditLog, "Audit Log");

	driver.close();
	driver.switchTo().window(parentWindow);
	
	
	
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();


		
	}



}
public void retrievePendingWork(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(2500);
	switchToFrame("PegaGadget1Ifr");
	try {
		String abjcomments=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "abjcomments", true, "PegaGadget1Ifr", "", "abj comments ");
		assertEquals(abjcomments, data.get("Comments"), "comments");

		String operatorname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "operatorname", true, "PegaGadget1Ifr", "", "operator name");
		assertEquals(operatorname, data.get("Expected_Operatorname"), "operator name");
		waitSleep(2000);

		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "claimicon", true, "PegaGadget1Ifr", "", "claim icon");

		String claimnumber=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "claimdetail", true, "PegaGadget1Ifr", "", "claim number ");
		assertEquals(claimnumber, data.get("ClaimNumber"), "Claim Number");
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();


	}



}
public void adjustclaim_Resolve(String pageLocatorsPath,String pageFiledsPath) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(2500);
	switchToFrame("PegaGadget1Ifr");
	try {
		
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "claimadjustment", true, "PegaGadget1Ifr", "", "claim adjustment");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "pendtheclaim", true, "PegaGadget1Ifr", "", "pend the claim");
		waitSleep(2500);
		WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "confirmAndClose", true, "PegaGadget1Ifr", "", "confirm And Close");

		
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();


	}
}

public void CreateFollowUp(String pageLocatorsPath,String pageFiledsPath) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(4000);
	switchToFrame("PegaGadget1Ifr");
	try {
		
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createnewwork", true, "PegaGadget1Ifr", "", "create new work");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createFollowUp", true, "PegaGadget1Ifr", "", "pend the claim");
		waitSleep(2500);
		switchToFrame("PegaGadget2Ifr");
		System.out.println("frame");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "followuptask", true, "PegaGadget2Ifr", "", "follow-up task");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsFollowUp", true, "PegaGadget2Ifr","Create Follow Up", "Create Follow Up comments");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget2Ifr", "", "Submit");

		
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();


	}



}
public void adjustclaim(String pageLocatorsPath,String pageFiledsPath) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(2500);
	switchToFrame("PegaGadget2Ifr");
	try {
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Adjust", true, "PegaGadget2Ifr", "", "Adjust Claim");
	waitSleep(2000);

	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "confirm", true, "PegaGadget2Ifr", "", "Adjust Claim confirm");
	waitSleep(2500);
	
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();
	}

}
public void adjustclaimdetail(String pageLocatorsPath,String pageFiledsPath,String frame,String Expectedadjustdetails,Hashtable<String,String> data) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(2500);
	switchToFrame(frame);
	  String adjustdetails1= "";
	try {
	
	String ccn=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ccn", true, frame, "", "CCN/ICNf");
	String  MemberID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "memberID", true, frame, "", "Member ID");
	String Contacttype=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "contacttype", true, frame, "", "Contact type");
	String  Name=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "name", true, frame, "", "Patient name");
	String  Groupname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "groupname", true, frame, "", "Group name");
    String Firstdate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "firstdate", true, frame, "", "First date of service ");
	String Lastdate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "lastdate", true, frame, "", "Last date ");
	String  Chargedamount=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "chargedamount", true, frame, "", "Charged amount");
    adjustdetails1=ccn+"|"+MemberID+"|"+Contacttype+"|"+Name+"|"+Groupname+"|"+Firstdate+"|"+Lastdate+"|"+Chargedamount;
	System.out.println(adjustdetails1);
	
	assertEquals(Expectedadjustdetails,adjustdetails1,"adjust");

	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();
	}

}
public void savetoworklist(String pageLocatorsPath,String pageFiledsPath) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(2500);
	switchToFrame("PegaGadget2Ifr");
	try {
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "savetoworklist", true, "PegaGadget2Ifr", "", "save to worklist");
	waitSleep(2500);
	
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();
	}

}
public void viewClaimDetails(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame(frame);
		String claimdetail=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "claimdetail", true, frame, "", "Claim detail ");
		String PrefixSubIDExtent=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "prefixSubIDExtent", true, frame, "", "prefix SubID Extent ");
		String Firstdate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "firstdate", true, frame, "", "First date of service ");
		String Lastdate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "lastdate", true, frame, "", "Last date ");
		String Claimtype=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "claimtype", true, frame, "", "Claim type");
		String providername=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "providername", true, frame, "", "provider name ");
		String  providerID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "providerID", true, frame, "", " provider ID ");
		String providerNPI=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "providerNPI", true, frame, "", "provider NPI");
		String NASCOgroupnumber=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "nascogroup", true, frame, "", "NASCO group number ");
		String  Name=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "name", true, frame, "", "Patient name");
		String PatientDOB=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "dob", true, frame, "", "Patient DOB");
		String Patientgender=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "gender", true, frame, "", "Patient gender");
		String Patientrelationship=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "relationship", true, frame, "", "Patient relationship ");
		String  Groupnumber=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "groupnumber", true, frame, "", " Group number");
		String Numberoflines=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "lines", true, frame, "", "Number of lines");
		String  Payee=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Payee", true, frame, "", "Payee");
		String Totalchargeamount=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "chargeamount", true, frame, "", "Total charge amount");
		String Totalallowedamount=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "allowedamount", true, frame, "", "Total allowed amount");
		String Totalpaidamount=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "paidamount", true, frame, "", "Total paid amount ");
		String  Totaldeductible=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "deductible", true, frame, "", " Total deductible");
		String Totalcoinsurance=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "coinsurance", true, frame, "", "Total coinsurance");
		String Totalcopayment=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "copayment", true, frame, "", "Total copayment");
		String  Totalmemberliability=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "liability", true, frame, "", " Total member liability");
        
          String Result=claimdetail+"|"+PrefixSubIDExtent+"|"+Firstdate+"|"+Lastdate+"|"+Claimtype+"|"+providername+"|"+providerID+"|"+providerNPI+"|"+NASCOgroupnumber+"|"+Name+"|"+PatientDOB+"|"+Patientgender+"|"+Patientrelationship+"|"+Groupnumber+"|"+Numberoflines+"|"+Payee+"|"+Totalchargeamount+"|"+Totalallowedamount+"|"+Totalpaidamount+"|"+Totaldeductible+"|"+Totalcoinsurance+"|"+Totalcopayment+"|"+Totalmemberliability ;
          
          System.out.println(Result);
          assertEquals(data.get("ExpectedResult"), Result , "Details");
          
				
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on routetoCOB method " + e);
		test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
		Assert.fail();
	}
	
}
public void search_Claimselect(String pageLocatorsPath,String pageFiledsPath,String DateSearchOptions,String fdos,String ldos,String claim,Hashtable<String,String> data) throws Exception
{
	pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
	waitSleep(3000);
	switchToFrame("PegaGadget2Ifr");
	String summary="";
	waitSleep(2000);
	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", DateSearchOptions, "DateSearch Options");
	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", fdos, "First date of serviceRequired");
 	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", ldos, "Last date of service");
 	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
 	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "providername", true, "PegaGadget2Ifr", claim, "Provider name");
	waitSleep(4000);
	WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
 	waitSleep(2000);
 	List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1')]"));
    String s="//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1')]";
    for(int i=0;i<ele.size();i++)
 {
	    String s1=String.format(s, i+1);
	    String memdet="";
	    List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
	    System.out.println(colums.size());
	     for(int j=0;j<colums.size();j++)
	    	
	{
		if(j==0)
		{
			System.out.println("action");
			memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
		else{
			memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
	}
	     summary=summary+","+memdet;	
  }
		
	       System.out.println(summary);
	assertEquals(data.get("Expected_details"), summary, summary);

	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "reviewed", true, "PegaGadget2Ifr", "", "Reviewed");
	waitSleep(2000);
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
	waitSleep(5000);
  }

public void ViewClaimStatement(String pageLocatorsPath,String pageFiledsPath) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(4000);
	switchToFrame("PegaGadget2Ifr");
	try {
		
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ViewClaimStatement", true, "PegaGadget2Ifr", "", "ViewClaimStatement BUTTON");
				
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();


	}

}
public void LaunchRTC(String pageLocatorsPath,String pageFiledsPath) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(4000);
	switchToFrame("PegaGadget2Ifr");
	try {
		
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "LaunchRTC", true, "PegaGadget2Ifr", "", "LaunchRTC BUTTON");
				
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();


	}

}
public String getIntentID(String pageLocatorsPath,String pageFiledsPath,String frame1) 
{	
	String intentid="";
	try{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		switchToFrame(frame1);
		waitSleep(4000);
		intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, frame1, "Select Customer Response Type", "Intent ID");
		intentid= intentid.substring(1, intentid.length()-1);
		System.out.println(intentid);
		test.log(LogStatus.INFO, "Intent ID:"+intentid);
//		Select s=new Select(driver.findElement(By.xpath("")));
//		s.getFirstSelectedOption().getText();
	}
	catch(Exception e)
	{
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on getIntentID method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
		Assert.fail();
	}
	return intentid;
}
public void search_Claimselect(String pageLocatorsPath,String pageFiledsPath,String DateSearchOptions,String fdos,String ldos,String claim) throws Exception
{
	pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
	waitSleep(3000);
	switchToFrame("PegaGadget2Ifr");
	String summary="";
	waitSleep(2000);
	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", DateSearchOptions, "DateSearch Options");
	waitSleep(2000);
	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", fdos, "First date of serviceRequired");
 	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", ldos, "Last date of service");
 	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
 	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", claim, "Claim Number");
	waitSleep(4000);
	WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
 	waitSleep(2000);
}
 
public void claimdetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) throws Exception
{
	pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
	waitSleep(3000);
	switchToFrame("PegaGadget2Ifr");
	String summary="";
	waitSleep(2000);
 
    List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1')]"));
    String s="//tr[contains(@id,'$PHCMemberClaims$ppxResults$l1')]";
    for(int i=0;i<ele.size();i++)
 {
	    String s1=String.format(s, i+1);
	    String memdet="";
	    List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
	    System.out.println(colums.size());
	     for(int j=0;j<colums.size();j++)
	    	
	{
		if(j==0)
		{
			System.out.println("action");
			memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
		else{
			memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
	}
	     summary=summary+","+memdet;	
  }
		
	       System.out.println(summary);
	assertEquals(data.get("Expected_details"), summary, summary);

	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "reviewed", true, "PegaGadget2Ifr", "", "Reviewed");
	waitSleep(2000);
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
	waitSleep(5000);
  }

public void claimstatus(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) throws Exception
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(3000);
	switchToFrame("PegaGadget2Ifr");
	String summary="";
	waitSleep(2000);
 
   
	String claim=WebElementAction("readtext",pageLocatorsPath, pageFiledsPath, "claimstatus", true, "PegaGadget2Ifr", "", "claim status");
	waitSleep(2000);
	assertEquals(data.get("Excepted_claimstatus"), claim, "claim Statu");
	
}




public void ValidateOtherActions(String pageLocatorsPath,String pageFiledsPath)
{
	
	try {
		switchToDefault();
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		waitSleep(2000);
		String SelectAnotherClaim = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "SelectAnotherClaim", true, "PegaGadget2Ifr", "", "SelectAnotherClaim");
		assertEquals("Select Another Claim",SelectAnotherClaim, "SelectAnotherClaim");
		String SearchForClaim = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "SearchForClaim", true, "PegaGadget2Ifr", "", "SearchForClaim");
		assertEquals("Search for Claim",SearchForClaim, "SearchForClaim");
		String ViewBenefits = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ViewBenefits", true, "PegaGadget2Ifr", "", "ViewBenefits");
		assertEquals("View benefits",ViewBenefits, "ViewBenefits");
		String ManageChecks = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ManageChecks", true, "PegaGadget2Ifr", "", "ManageChecks");
		assertEquals("Manage checks",ManageChecks, "ManageChecks");
		waitSleep(3000);
		
	 } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on  ValidateOtherActions method " + e);
            test.log(LogStatus.FAIL, "Error on  ValidateOtherActions method " + e);
            Assert.fail();

        }
	}
public String getIntentIDCLM(String pageLocatorsPath,String pageFiledsPath) 
{	
	String intentid="";
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		switchToFrame("PegaGadget2Ifr");
		intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionIDCLM", true, "PegaGadget2Ifr", "Search for Claim", "Intent ID");
		intentid= intentid.substring(1, intentid.length()-1);
		System.out.println(intentid);
		test.log(LogStatus.INFO, "Intent ID:"+intentid);
		waitSleep(5000);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getIntentID method " + e);
		test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
		Assert.fail();
	}
	return intentid;
}
public void searchClaim(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data) throws Exception
{
	pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
	waitSleep(3000);
	switchToFrame("PegaGadget2Ifr");
	
	waitSleep(2000);
	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", data.get("DateSearchOptions"), "DateSearch Options");
	waitSleep(2000);
 	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
	waitSleep(2000);

 	if(null != data.get("ClaimNumber1") && !data.get("ClaimNumber1").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", data.get("ClaimNumber1"), "Claim Number");
	}
 	
 	if(null != data.get("providerName") && !data.get("providerName").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "providerName", true, "PegaGadget2Ifr", data.get("providerName"), "providerName");
	}
 	
 	if(null != data.get("NASCOproviderID") && !data.get("NASCOproviderID").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "NASCOproviderID", true, "PegaGadget2Ifr", data.get("NASCOproviderID"), "NASCOproviderID");
	}
 	
 	if(null != data.get("claimType") && !data.get("claimType").isEmpty())
	{
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimType", true, "PegaGadget2Ifr", data.get("claimType"), "claimType");
	}
 	
 	if(null != data.get("claimTypeValue") && !data.get("claimTypeValue").isEmpty())
	{
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimTypeValue", true, "PegaGadget2Ifr", data.get("claimTypeValue"), "claimTypeValue");
	}
 	
 	if(null != data.get("checkNumber") && !data.get("checkNumber").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "checkNumber", true, "PegaGadget2Ifr", data.get("checkNumber"), "checkNumber");
	}
 	
 	if(null != data.get("payee") && !data.get("payee").isEmpty())
	{
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "payee", true, "PegaGadget2Ifr", data.get("payee"), "payee");
	}
 	
 	if(null != data.get("procedureCode") && !data.get("procedureCode").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "procedureCode", true, "PegaGadget2Ifr", data.get("procedureCode"), "procedureCode");
	}
 	
 	if(null != data.get("diagnosisCode") && !data.get("diagnosisCode").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "diagnosisCode", true, "PegaGadget2Ifr", data.get("diagnosisCode"), "diagnosisCode");
	}
 	
 	if(null != data.get("diagnosisClass") && !data.get("diagnosisClass").isEmpty())
	{
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "diagnosisClass", true, "PegaGadget2Ifr", data.get("diagnosisClass"), "diagnosisClass");
	}
 	
 	if(null != data.get("requestNumber") && !data.get("requestNumber").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "requestNumber", true, "PegaGadget2Ifr", data.get("requestNumber"), "requestNumber");
	}
 	
 	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "additionalSearch", true, "PegaGadget2Ifr", "Additional search criteria", "additionalSearch");
	
 	if(null != data.get("totalAmt") && !data.get("totalAmt").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "totalAmt", true, "PegaGadget2Ifr", data.get("totalAmt"), "totalAmt");
	}
 	
 	if(null != data.get("hcpcs") && !data.get("hcpcs").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "hcpcs", true, "PegaGadget2Ifr", data.get("hcpcs"), "hcpcs");
	}
 	
 	if(null != data.get("nationalProviderID") && !data.get("nationalProviderID").isEmpty())
	{
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "nationalProviderID", true, "PegaGadget2Ifr", data.get("nationalProviderID"), "nationalProviderID");
	}
 	
 	
	WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "SubmitButton");
 	waitSleep(2000);
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Filterbymember", true, "PegaGadget2Ifr", "", "Filter by member");
	waitSleep(2000);
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Apply", true, "PegaGadget2Ifr", "", "Apply");
	waitSleep(2000);
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "reviewed", true, "PegaGadget2Ifr", "", "Reviewed");
    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
	waitSleep(5000);

 
}
public String getIntentIDcialm(String pageLocatorsPath,String pageFiledsPath) 
{	
	String intentid="";
	try{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		switchToFrame("PegaGadget2Ifr");
		intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "Search for Claim", "Intent ID");
		intentid= intentid.substring(1, intentid.length()-1);
		System.out.println(intentid);
		test.log(LogStatus.INFO, "Intent ID:"+intentid);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getIntentID method " + e);
		test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
		Assert.fail();
	}
	return intentid;
}
public void adjustclaimreason(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(2500);
	switchToFrame(frame);
	try {
	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Reasontoadjust", true, frame, data.get("Reasontoadjust"), "Reasontoadjust");
	waitSleep(2500);
	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Processinginstructions", true, frame, data.get("Processinginstructions"), "Processinginstructions");

	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, frame, "", "Submit Button");
	waitSleep(2500);

	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();
	}

}
public void AdjustComplexClaim(String pageLocatorsPath,String pageFiledsPath,String frame) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(2500);
	switchToFrame(frame);
	try {
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Routetoworkbasket", true, frame, "Route intent to claim workbasket", "Routetoworkbasket");
	waitSleep(3500);
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ReceiveBillNo", true, frame, "", "ReceiveBillNo");

	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, frame, "", "Submit Button");
	waitSleep(2500);

	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();
	}

}
public void ServiceException(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
{
	pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
	waitSleep(2500);
	switchToFrame("PegaGadget2Ifr");
	try {
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ServiceException", true, "PegaGadget2Ifr", "", "Service Exception");
	waitSleep(3500);
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ReceiveBillNo", true, "PegaGadget2Ifr", "", "ReceiveBillNo");
	waitSleep(2500);
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "exceptionyes", true, "PegaGadget2Ifr", "", "Continue to proceed with exception?");
	waitSleep(2500);
	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "reimbursement", true, "PegaGadget2Ifr", "", "Is this a fitness or weight loss reimbursement?");
	waitSleep(2500);

	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Serviceexception", true, "PegaGadget2Ifr",data.get("Serviceexception"), "Serviceexception");
	waitSleep(2500);
	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Benefittoapply", true, "PegaGadget2Ifr", data.get("Benefittoapply"), "Processinginstructions");
	waitSleep(2500);
	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Benefitnarrative", true, "PegaGadget2Ifr", data.get("Benefitnarrative"), "Benefit narrative");
	waitSleep(2500);

	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
	waitSleep(2500);
	
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
        Assert.fail();
	}

}

public void serviceException(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "serviceException", true, "PegaGadget2Ifr", "", "Service Exception");
		waitSleep(3000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "receivebill", true, "PegaGadget2Ifr", "", "Received bill No");		
		waitSleep(3000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "processedException", true, "PegaGadget2Ifr", "", "Processed Exception Yes");
		waitSleep(3000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "weightLoss", true, "PegaGadget2Ifr", "", "Weight Loss No");
		waitSleep(3000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "exceptionScenario", true, "PegaGadget2Ifr", data.get("ExceptionScenario"), "Exception Scenario");
		waitSleep(3000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "benefitToApply", true, "PegaGadget2Ifr", data.get("BenefitToApply"), "Benefit to apply");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "benefitNarrative", true, "PegaGadget2Ifr", data.get("BenefitNarrative"), "benefit Narrative");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "exceptionComments", true, "PegaGadget2Ifr", data.get("ExceptionComments"), "Comments");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit");
		waitSleep(3500);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on serviceException method " + e);
		test.log(LogStatus.FAIL, "Error on serviceException method " + e);
		Assert.fail();
	}
}

public void deniedServiceException(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget1Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deniedServiceException", true, "PegaGadget1Ifr", "Denied", "Denied");
		waitSleep(3000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "exceptionComments", true, "PegaGadget1Ifr", data.get("ExceptionComments"), "Comments");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget1Ifr", "", "Submit");
		waitSleep(3000);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on deniedServiceException method " + e);
		test.log(LogStatus.FAIL, "Error on deniedServiceException method " + e);
		Assert.fail();
	}
}

public void denieServiceException(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deniedServiceException", true, "PegaGadget2Ifr", "Denied", "Denied");
		waitSleep(3000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "exceptionComments", true, "PegaGadge2Ifr", data.get("ExceptionComments"), "Comments");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit");
		waitSleep(3000);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on deniedServiceException method " + e);
		test.log(LogStatus.FAIL, "Error on deniedServiceException method " + e);
		Assert.fail();
	}
}


public void approvedServiceException(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget1Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "approveServiceException", true, "PegaGadget1Ifr", "Approved", "Approved");
		waitSleep(3000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "associateApproval", true, "PegaGadget1Ifr", "Associate", "Associate");
		waitSleep(1500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "managerApproval", true, "PegaGadget1Ifr", "Manager", "Manager");
		waitSleep(1500);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "asscoaitetextbox", true, "PegaGadget1Ifr", data.get("ExceptionComments"), "Associate Approval");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "managerinput", true, "PegaGadget1Ifr", data.get("ExceptionComments"), "Manger Approval");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "exceptionComments", true, "PegaGadget1Ifr", data.get("ExceptionComments"), "Comments");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget1Ifr", "", "Submit");
		waitSleep(3000);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on approvedServiceException method " + e);
		test.log(LogStatus.FAIL, "Error on approvedServiceException method " + e);
		Assert.fail();
	}
}

public void approveServiceException(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "approveServiceException", true, "PegaGadget2Ifr", "Approved", "Approved");
		waitSleep(3000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "associateApproval", true, "PegaGadget2Ifr", "Associate", "Associate");
		waitSleep(1000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "managerApprove", true, "PegaGadget2Ifr", "Manager", "Manager");
		waitSleep(1000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "asscoaitetextbox", true, "PegaGadget2Ifr", data.get("ExceptionComments"), "Associate Approval");
		waitSleep(1000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "managerinput", true, "PegaGadget2Ifr", data.get("ExceptionComments"), "Manger Approval");
		waitSleep(1000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "exceptionComments", true, "PegaGadget2Ifr", data.get("ExceptionComments"), "Comments");
		waitSleep(1000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit");
		waitSleep(3000);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on approvedServiceException method " + e);
		test.log(LogStatus.FAIL, "Error on approvedServiceException method " + e);
		Assert.fail();
	}
}


public void search_OnlyClaim(String pageLocatorsPath,String pageFiledsPath,String claim) throws Exception
{
	pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
	waitSleep(3000);
	switchToFrame("PegaGadget2Ifr");
	String summary="";
	try {
		waitSleep(2000);
	//	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", DateSearchOptions, "DateSearch Options");
	//	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", fdos, "First date of serviceRequired");
	// 	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", ldos, "Last date of service");
	 	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
	 	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", claim, "Claim Number");
		waitSleep(4000);
		WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
	 	waitSleep(2000);
	}catch(Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on search_OnlyClaim method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on search_OnlyClaim method " + e);
		Assert.fail();
	}

}
public void selectMeber(String pageLocatorsPath,String pageFiledsPath,String firstname) throws Exception
{//$PClaimMembers$ppxResults$l1
	pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";

	switchToFrame("PegaGadget2Ifr");
	waitSleep(2000);
	try {
	    List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'PClaimMembers$ppxResults$l')]"));
	    String s="(//tr[contains(@id,'PClaimMembers$ppxResults$l')])[%d]";
	    
		for(int i=0;i<tablerows.size();i++)
		{ 
			String s1=String.format(s, i+1);
			System.out.println("s1"+s1);
			System.out.println("Member Name "+driver.findElement(By.xpath(s1+"//td[3]//span")).getText());
			if( (driver.findElement(By.xpath(s1+"//td[3]//span")).getText()).contains(firstname) ) 
			{
				if (driver.findElement(By.xpath(s1+"//td[1]//input[2]")).isSelected()) {
					BaseTest.log.info("By default selected the Meber  "+firstname );
					test.log(LogStatus.INFO, "By default selected the Member  "+firstname );
	
					break;
				} else {
					driver.findElement(By.xpath(s1+"//td[1]//input[2]")).click();
					waitSleep(2000);
					BaseTest.log.info("Selected the Meber  "+firstname );
					test.log(LogStatus.INFO, "Selected the Meber  "+firstname );
	
					break;
				}
			}
		}	
		//waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Apply", true, "PegaGadget2Ifr", "", "Apply");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "reviewed", true, "PegaGadget2Ifr", "", "Reviewed");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
		waitSleep(5000);

	}catch(Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on selectMeber method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on selectMeber method " + e);
		Assert.fail();
	}
}

public void search_Claimselect(String pageLocatorsPath,String pageFiledsPath,String DateSearchOptions,String fdos,String ldos) throws Exception
{
	pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
	pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
	waitSleep(3000);
	switchToFrame("PegaGadget2Ifr");
	String summary="";
	waitSleep(2000);
	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", DateSearchOptions, "DateSearch Options");
	waitSleep(2000);
	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", fdos, "First date of serviceRequired");
 	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", ldos, "Last date of service");
 	waitSleep(2000);
 	WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
 	waitSleep(2000);
}

}
