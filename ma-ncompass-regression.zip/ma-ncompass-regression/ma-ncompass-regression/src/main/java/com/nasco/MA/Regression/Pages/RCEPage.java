package com.nasco.MA.Regression.Pages;

import java.util.Hashtable;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings("rawtypes")
public class RCEPage extends BasePage {
	
	@FindBy(xpath="//label[@id='pyActionLabel']//following::span[1]")
	public WebElement intentID;
	
	public void clickSuplimentTools(String pageLocatorsPath,String pageFiledsPath,String expectedToollink) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "splToolstab", true, "PegaGadget2Ifr", "Supplemental Tools", "Supplemental Tools");
			String actualToolLink=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "toolLink", true, "PegaGadget2Ifr", "Find a Doctor Cost Estimator", "Find a Doctor Cost Estimator");
			assertEquals(expectedToollink, actualToolLink, "Supplement Tools Link URl");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on clickSuplimentTools method " + e);
			test.log(LogStatus.FAIL, "Error on clickSuplimentTools method " + e);
			Assert.fail();
		}
	}
	
	
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			
			switchToFrame("PegaGadget2Ifr");
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "Document Cost Estimate Request", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	
	public String getGSIIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			
			switchToFrame("PegaGadget2Ifr");
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "GSI", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	 
	 
	public void sendtoResearch(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "written", true, "PegaGadget2Ifr", "Written", "Written");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "memeberContact", true, "PegaGadget2Ifr", "Mail", "Member Prefered Contact");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "facility", true, "PegaGadget2Ifr", "Facility", "Facility");
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, "PegaGadget2Ifr", "MA", "State");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(4500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on sendtoResearch method " + e);
			test.log(LogStatus.FAIL, "Error on sendtoResearch method " + e);
			Assert.fail();
		}
		
	}
	
	
		
	public void sendRCEtoPricing(String actualStatus,String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			String expectedStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", "Status", "Status");
			assertEquals(expectedStatus, actualStatus, "Status");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "sendtoPricing", true, "PegaGadget1Ifr", "Send to pricing", "Send to pricing");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on sendRCEtoPricing method " + e);
			test.log(LogStatus.FAIL, "Error on sendRCEtoPricing method " + e);
			Assert.fail();
		}
		
	}
	
		
	public void resolvePricing(String actualStatus,String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			String expectedStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", "Status", "Status");
			assertEquals(expectedStatus, actualStatus, "Status");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "sendtoPricing", true, "PegaGadget1Ifr", "Resolve", "Resolve");
			waitSleep(500);
			waitOnIE(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(3000);
			waitOnIE(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(2500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on resolvePricing method " + e);
			test.log(LogStatus.FAIL, "Error on resolvePricing method " + e);
			Assert.fail();
		}
		
		
	}
	
	public void sendtoResearchEmail(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "written", true, "PegaGadget2Ifr", "Written", "Written");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "memeberContact", true, "PegaGadget2Ifr", "Email", "Member Prefered Contact");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "facility", true, "PegaGadget2Ifr", "Facility", "Facility");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, "PegaGadget2Ifr", "MA", "State");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(4500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on sendtoResearch method " + e);
			test.log(LogStatus.FAIL, "Error on sendtoResearch method " + e);
			Assert.fail();
		}
		
	}
	
	
	public void createRCE(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "written", true, "PegaGadget2Ifr", "Written", "Written");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "memeberContact", true, "PegaGadget2Ifr", data.get("MemeberContact"), "Member Prefered Contact");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "serviceProvider", true, "PegaGadget2Ifr", data.get("Provider"), "Service Provider");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "facility", true, "PegaGadget2Ifr", data.get("Facility"), "Facility");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "StreetAddress", true, "PegaGadget2Ifr", data.get("StreetAddress"), "StreetAddress");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, "PegaGadget2Ifr", data.get("City"), "city");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, "PegaGadget2Ifr", data.get("State"), "State");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ZipCode", true, "PegaGadget2Ifr", data.get("Zipcode"), "Zipcode");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addItem", true, "PegaGadget2Ifr","Add item", "addItem");
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "codetype", true, "PegaGadget2Ifr", data.get("CodeType"), "CodeType");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "code", true, "PegaGadget2Ifr", data.get("Code"), "Code");
			waitSleep(3000);
			//WebElementAction("type",pageLocatorsPath, pageFiledsPath, "descriptionOfService", true, "PegaGadget2Ifr", data.get("DescriptionOfService"), "descriptionOfService");
			waitSleep(4000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget2Ifr", data.get("Comments"), "comments");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(5500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createRCE method " + e);
			test.log(LogStatus.FAIL, "Error on createRCE method " + e);
			Assert.fail();
		}
		
	}
	
	public void updateRCEPricing(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "allowedAmount", true, "PegaGadget1Ifr", data.get("allowedAmount"), "allowedAmount");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget1Ifr", "", "allowedAmount");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "coPayment", true, "PegaGadget1Ifr", data.get("coPayment"), "coPayment");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget1Ifr", "", "coPayment");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "coInsurance", true, "PegaGadget1Ifr", data.get("coInsurance"), "coInsurance");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget1Ifr", "", "coInsurance");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "deductible", true, "PegaGadget1Ifr", data.get("deductible"), "deductible");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget1Ifr", "", "sendtopricing");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "sendtoPricing", true, "PegaGadget1Ifr", "", "Send to Pricing");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "rceComments", true, "PegaGadget1Ifr", data.get("Comments"), "Comments");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(3000);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on updateRCEPricing method " + e);
			test.log(LogStatus.FAIL, "Error on updateRCEPricing method " + e);
			Assert.fail();
		}
		
	}
	
	public void updateRCEProviderOUTReachSuccess(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "OutreachToProvider", true, "PegaGadget1Ifr", "", "OutreachAttempt");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "OutreachAttempt", true, "PegaGadget1Ifr", "Successful", "OutreachAttempt");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(3000);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on updateRCEProviderOUTReachSuccess method " + e);
			test.log(LogStatus.FAIL, "Error on updateRCEProviderOUTReachSuccess method " + e);
			Assert.fail();
		}
		
	}
	
	public void cancelRCE(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget2Ifr");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherAction", true, "PegaGadget2Ifr", "", "other Actions");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "cancelWork", true, "PegaGadget2Ifr", "", "Cancel RCE Work");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget2Ifr", "Automation Testing", "Cancel RCE Work");
			waitSleep(3000);
			waitOnIE(3000);
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE1", true, "PegaGadget2Ifr", "Submit", "Submit");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRCE", true, "PegaGadget2Ifr", "Submit", "Submit");
			waitSleep(3000);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on cancelRCE method " + e);
			test.log(LogStatus.FAIL, "Error on cancelRCE method " + e);
			Assert.fail();
		}
		
	}
	
	
	public void UpdateMember_SavetoWorklist(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RCEPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RCEPageFields.properties";
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget2Ifr");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherAction", true, "PegaGadget2Ifr", "", "other Actions");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SavetoWorklist", true, "PegaGadget2Ifr", "Save to worklist", "SavetoWorklist");
			waitSleep(3000);
//			WebElementAction("selectbyText",pageLocatorsPath, pageFiledsPath, "ReasonToPendDropdown", true, "PegaGadget2Ifr", "Additional Research", "ReasonToPendDropdown");
//			waitSleep(3000);
//			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget2Ifr", "Automation Testing", "save to worklist comments");
//			waitSleep(3000);
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, "PegaGadget2Ifr", "", "Submit");
//			waitSleep(3000);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on UpdateMember_SavetoWorklist method " + e);
			test.log(LogStatus.FAIL, "Error on UpdateMember_SavetoWorklist method " + e);
			Assert.fail();
		}
		
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		switchToFrame("PegaGadget2Ifr");
		return ExpectedConditions.visibilityOf(intentID);
	}


	

}
