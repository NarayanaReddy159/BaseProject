package com.nasco.MA.Regression.Pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;




@SuppressWarnings("rawtypes")
public class GSIPage extends BasePage {

	@FindBy(xpath="//label[@id='pyActionLabel']//following::span[1]")
	public WebElement intentID;
	
	String exceptionMessage="";
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget2Ifr");
		return ExpectedConditions.visibilityOf(intentID);
	}
	

	public void createGSI_ProviderOccurance(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String comments) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "grievanceLetterNo", true, "PegaGadget2Ifr", "", "Grievance Letter");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "popUpClose", true, "PegaGadget2Ifr", "", "Grievance Letter");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addClaimsNo", true, "PegaGadget2Ifr", "", "Add Claims");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_ProviderOccurance method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_ProviderOccurance method " + e);
			Assert.fail();
		}
	}
	public void createGSI_RequestType(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String Oralrequesttype,String comments)
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		try {
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
		waitSleep(2000);

		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
		waitSleep(3000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Oralrequesttype", true, "PegaGadget2Ifr", Oralrequesttype, "Oral requesttype");
	
        WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");		
        WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "No", "Submit");		

		}catch (Exception e) {
	    e.printStackTrace();
	    BaseTest.log.error("Error on createMANAGECLAIM method " + e);
	    test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
	    Assert.fail();
	}

}
	
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitOnIE(2000);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "Create GSI", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	 	
	public void validateRecentWork(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", data.get("Expected_Status"), "Status");
			assertEquals(data.get("Expected_Status"), actualStatus, "Status");

			String actualMeberid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "memberId", true, "PegaGadget1Ifr", data.get("Expected_MemberID"), "Member Id");
			assertEquals(data.get("Expected_MemberID"), actualMeberid, "Member ID");

			String actualChannel=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "channel", true, "PegaGadget1Ifr", data.get("Expected_Channel"), "Channel");
			assertEquals(data.get("Expected_Channel"), actualChannel, "Channel");

			String actualCreateOperator=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "createOperator", true, "PegaGadget1Ifr", data.get("Expected_CreateOperator"), "Create Operator");
			assertEquals(data.get("Expected_CreateOperator"), actualCreateOperator, "Create Operator");

			String actualResolveOperator=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "resolveOperator", true, "PegaGadget1Ifr", data.get("Expected_ResolveOperator"), "Resolve Operator");
			assertEquals(data.get("Expected_ResolveOperator"), actualResolveOperator, "Resolve Operator");

			String actualCategory=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "categoryReviewHarness", true, "PegaGadget1Ifr", data.get("Expected_Category"), "Category");
			assertEquals(data.get("Expected_Category"), actualCategory, "Category");

			String actualSubCategory=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "subCategoryReviewHarness", true, "PegaGadget1Ifr", data.get("Expected_Subcategory"), "Sub Category");
			assertEquals(data.get("Expected_Subcategory"), actualSubCategory, "Sub Category");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
			}
	
	public void createGSI_PSA(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(4500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1000);
			waitOnIE(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addClaimsNo", true, "PegaGadget2Ifr", "", "Add Claims as No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(4500);
		} catch (Exception e){
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_PSA method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
			Assert.fail();

		}
	}
	
	public void createGSI_CliamsYes(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(4500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addClaimsYes", true, "PegaGadget2Ifr", "", "Add Claims as Yes");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_CliamsYes method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_CliamsYes method " + e);
			Assert.fail();

		}
	}
	
	
	public void search_SelectClaim(String pageLocatorsPath,String pageFiledsPath,String DateSearchOptions,String fdos,String ldos,String claim) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		
		waitSleep(2000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", DateSearchOptions, "DateSearch Options");
		waitSleep(2000);
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", fdos, "First date of serviceRequired");
     	
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", ldos, "Last date of service");
     	
     	
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
	
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", claim, "Claim Number");
		waitSleep(4000);
		

     	WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SearchButton", true, "PegaGadget2Ifr", "", "Search");
     	waitSleep(3000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Filterbymember", true, "PegaGadget2Ifr", "", "Filter by member");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Apply", true, "PegaGadget2Ifr", "", "Apply");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Add", true, "PegaGadget2Ifr", "", "Add");
		

    	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
		waitSleep(2000);

		
	}
	public void ValidateIntentStatusOnWorkbasket(String pageLocatorsPath,String pageFiledsPath,String status)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", status, "Status");
			assertEquals(status, actualStatus, "Status");
		} catch (Exception e){
			e.printStackTrace();
			BaseTest.log.error("Not able to validate the status on workbasket as "+status);
			BaseTest.log.error(e);
			test.log(LogStatus.FAIL, "Not able to validate the status on workbasket as "+status);
			test.log(LogStatus.FAIL,e);
			Assert.fail();
			
		}
	}
	
	
	public void ProcessGSI_ManageClaims_NoClaims(String pageLocatorsPath,String pageFiledsPath,String fname,String category,String subCategory,String symptoms,String facility,String name,String street,String city,String state,String zip,String comments) 
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(1000);
			waitOnIE(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1500);
			
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pMemberCoverageMembers$l')]"));
			ele.size();
			String s="//tr[contains(@id,'$PpyWorkPage$pMemberCoverageMembers$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				//System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
				
				if(driver.findElement(By.xpath(s1+"//td[2]")).getText().toUpperCase().contains(fname))
				
				{
					//System.out.println("Entered if ");
					ClickWebelement("xpath", "("+s1+"//td[2]//preceding-sibling::td//input)[2]", fname);
					break;
				}
			} 
			
			
		//	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "membersResult", true, "PegaGadget2Ifr", "", "Member Results");
			waitSleep(2500);
	        WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "NoUrgentCare", true, "PegaGadget2Ifr", "", "Urgentcare Authorization No");
	    	waitSleep(500);
	
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "symptoms", true, "PegaGadget2Ifr", symptoms, "Symptoms or diagnosis");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "facility", true, "PegaGadget2Ifr", facility, "Facility name");
	     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "name", true, "PegaGadget2Ifr", name , "Name");
	     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "street", true, "PegaGadget2Ifr", street , "Street Name");
	     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, "PegaGadget2Ifr", city , "city Name");
	     	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, "PegaGadget2Ifr", state , "state Name");
	     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "zip", true, "PegaGadget2Ifr", zip , "Zip code");
	//     	waitSleep(1000);
	//        WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "urgentCareNo", true, "PegaGadget2Ifr", "", "urgentcareauthorization No");
	//    	waitSleep(500);
	
	        WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");		
	        WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");		
		
	        waitSleep(2000);
		} catch (Exception e){
			exceptionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_PSA method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
			Assert.fail();

		}
    	
	}

	public void resolve_ProcessGSI(String pageLocatorsPath,String pageFiledsPath,String comments ) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ClaimResultGSI", true, "PegaGadget2Ifr", "", "ClaimResultGSI");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");		
	        WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRecent", true, "PegaGadget2Ifr", "", "Submit");	
			waitSleep(3500);
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on resolve_ProcessGSI method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on resolve_ProcessGSI method " + e);
			Assert.fail();

		}
		
	}
	
	public void resolve_ProcessGSI_WithoutClaim(String pageLocatorsPath,String pageFiledsPath,String comments ) 
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget1Ifr", comments, "comments");		
	        WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRecent", true, "PegaGadget1Ifr", "", "Submit");	
			waitSleep(4500);
		} catch (Exception e){
			exceptionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_PSA method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + exceptionMessage);
			Assert.fail();

		}
	}
	
	public void clickOtherActions(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitOnIE(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "OtherActions", true, "PegaGadget2Ifr", "", "Other Actions");
			test.log(LogStatus.INFO, "clicked Other Actions");
		} catch (Exception e){
            e.printStackTrace();
            exceptionMessage = Arrays.toString(e.getStackTrace());
            BaseTest.log.error("Error on clickOtherActions method" + exceptionMessage);
            test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
            Assert.fail();

		}
	}
	
	
	public void clicksavetoWorklist(String pageLocatorsPath,String pageFiledsPath, String comments) throws Exception
	{
		try {
			switchToDefault();
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitSleep(5000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments_SavetoWorklist", true, "PegaGadget2Ifr",comments, "Comments");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "savetoWorklist", true, "PegaGadget2Ifr", "Save to worklist", "save to Worklist");
        } catch (Exception e){
            e.printStackTrace();
            exceptionMessage = Arrays.toString(e.getStackTrace());
            BaseTest.log.error("Error on clicksavetoWorklist method " + exceptionMessage);
            test.log(LogStatus.FAIL, "Error on cclicksavetoWorklist method " + e);
            Assert.fail();

      }
	}
	
	public void validateOtherActions(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(2500);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "clmotheractions", true, "PegaGadget1Ifr", "", "Other Actions");
		
		String adjustment=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "otheroptions", true, "PegaGadget1Ifr", data.get("ExpectedAdjustment"), "Adjustment");
		String clmResearch=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "otheroptions", true, "PegaGadget1Ifr", data.get("ExpectedClmResearch"), "Research");
		String addWork=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "otheroptions", true, "PegaGadget1Ifr", data.get("ExpectedAddWork"), "Pending Additional Work");
	
		assertEquals(data.get("ExpectedAdjustment"), adjustment, "Adjustment");
		assertEquals(data.get("ExpectedClmResearch"), clmResearch, "Research");
		assertEquals(data.get("ExpectedAddWork"), addWork, "Pending Additional Work");
		waitSleep(2500);
	}
	public void ProcessGSI_ManageClaims(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String symptoms,String facility,String name,String street,String city,String state,String zip,String comments) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
		waitSleep(2500);
		waitOnIE(2500);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
		waitSleep(3000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "membersResult", true, "PegaGadget2Ifr", "", "Member Results");
		waitSleep(1500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "urgentCare", true, "PegaGadget2Ifr", "", "urgentcareauthorization Yes");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "symptoms", true, "PegaGadget2Ifr", symptoms, "Symptoms or diagnosis");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "facility", true, "PegaGadget2Ifr", facility, "Facility name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "name", true, "PegaGadget2Ifr", name , "Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "street", true, "PegaGadget2Ifr", street , "Street Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, "PegaGadget2Ifr", city , "city Name");
     	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, "PegaGadget2Ifr", state , "state Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "zip", true, "PegaGadget2Ifr", zip , "Zip code");
       	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");		
        WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "No", "Submit");		
    	waitSleep(2000);
    	
	}
	public void ProcessGSI_ManageClaims(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String fname,String symptoms,String facility,String name,String street,String city,String state,String zip,String comments) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
		waitSleep(2500);
		waitOnIE(2500);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
		waitSleep(3000);
	
		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pMemberCoverageMembers$l')]"));
		ele.size();
		String s="//tr[contains(@id,'$PpyWorkPage$pMemberCoverageMembers$l%d')]";
		for(int i=0;i<ele.size();i++)
		{
			String s1=String.format(s, i+1);
			//System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
			
      if(driver.findElement(By.xpath(s1+"//td[2]")).getText().toUpperCase().contains(fname))
			
			{
				//System.out.println("Entered if ");
				ClickWebelement("xpath", "("+s1+"//td[2]//preceding-sibling::td//input)[2]", fname);
				break;
			}
		}   
		waitSleep(1000);
		//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "membersResult", true, "PegaGadget2Ifr", "", "Member Results");
		waitSleep(1500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "urgentCare", true, "PegaGadget2Ifr", "", "urgentcareauthorization Yes");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "symptoms", true, "PegaGadget2Ifr", symptoms, "Symptoms or diagnosis");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "facility", true, "PegaGadget2Ifr", facility, "Facility name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "name", true, "PegaGadget2Ifr", name , "Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "street", true, "PegaGadget2Ifr", street , "Street Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, "PegaGadget2Ifr", city , "city Name");
     	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, "PegaGadget2Ifr", state , "state Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "zip", true, "PegaGadget2Ifr", zip , "Zip code");
       	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");		
        WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "No", "Submit");		
    	waitSleep(2000);
    	
	}
	
	public void searchClaim(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		
		waitSleep(2000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", data.get("DateSearchOptions"), "DateSearch Options");
		waitSleep(2000);
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", data.get("FDOS"), "First date of serviceRequired");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", data.get("LDOS"), "Last date of service");
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
	
     	if(null != data.get("ClaimNumber") && !data.get("ClaimNumber").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", data.get("ClaimNumber"), "Claim Number");
		}
     	
     	if(null != data.get("providerName") && !data.get("providerName").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "providerName", true, "PegaGadget2Ifr", data.get("providerName"), "providerName");
		}
     	
     	if(null != data.get("NASCOproviderID") && !data.get("NASCOproviderID").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "NASCOproviderID", true, "PegaGadget2Ifr", data.get("NASCOproviderID"), "NASCOproviderID");
		}
     	
     	if(null != data.get("claimType") && !data.get("claimType").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimType", true, "PegaGadget2Ifr", data.get("claimType"), "claimType");
		}
     	
     	if(null != data.get("claimTypeValue") && !data.get("claimTypeValue").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimTypeValue", true, "PegaGadget2Ifr", data.get("claimTypeValue"), "claimTypeValue");
		}
     	
     	if(null != data.get("checkNumber") && !data.get("checkNumber").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "checkNumber", true, "PegaGadget2Ifr", data.get("checkNumber"), "checkNumber");
		}
     	
     	if(null != data.get("payee") && !data.get("payee").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "payee", true, "PegaGadget2Ifr", data.get("payee"), "payee");
		}
     	
     	if(null != data.get("procedureCode") && !data.get("procedureCode").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "procedureCode", true, "PegaGadget2Ifr", data.get("procedureCode"), "procedureCode");
		}
     	
     	if(null != data.get("diagnosisCode") && !data.get("diagnosisCode").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "diagnosisCode", true, "PegaGadget2Ifr", data.get("diagnosisCode"), "diagnosisCode");
		}
     	
     	if(null != data.get("diagnosisClass") && !data.get("diagnosisClass").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "diagnosisClass", true, "PegaGadget2Ifr", data.get("diagnosisClass"), "diagnosisClass");
		}
     	
     	if(null != data.get("requestNumber") && !data.get("requestNumber").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "requestNumber", true, "PegaGadget2Ifr", data.get("requestNumber"), "requestNumber");
		}
     	
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "additionalSearch", true, "PegaGadget2Ifr", "Additional search criteria", "additionalSearch");
		
     	if(null != data.get("totalAmt") && !data.get("totalAmt").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "totalAmt", true, "PegaGadget2Ifr", data.get("totalAmt"), "totalAmt");
		}
     	
     	if(null != data.get("hcpcs") && !data.get("hcpcs").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "hcpcs", true, "PegaGadget2Ifr", data.get("hcpcs"), "hcpcs");
		}
     	
     	if(null != data.get("nationalProviderID") && !data.get("nationalProviderID").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "nationalProviderID", true, "PegaGadget2Ifr", data.get("nationalProviderID"), "nationalProviderID");
		}
     	
     	
		WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SearchButton", true, "PegaGadget2Ifr", "", "Search");
     	waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Filterbymember", true, "PegaGadget2Ifr", "", "Filter by member");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Apply", true, "PegaGadget2Ifr", "", "Apply");
		waitSleep(2000);
		waitOnIE(3500);
		String noofclaims=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "noofclaims", true, "PegaGadget2Ifr", "", "noofclaims");
		int claimsCount=Integer.valueOf(noofclaims);
		//System.out.println("claimsCount: "+claimsCount);
		if(claimsCount==0)
		{
			test.log(LogStatus.INFO, "No claims found for current search criteria");
		}
		else{
			
			assertEquals(data.get("claimsCount"), noofclaims, "claims Count");
			
		}
	}
	
	public void createGSI_TranslationReq(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String language,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(4500);
			waitOnIE(4500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "language", true, "PegaGadget2Ifr", language, "Language");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addClaimsNo", true, "PegaGadget2Ifr", "", "Add Claims as No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(3500);
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_PSA method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
			Assert.fail();

		}
	}

	public void createGSI_Grievancestatus(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String statusOfApeeal,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(2500);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "statusOfAppeal", true, "PegaGadget2Ifr", statusOfApeeal, "Language");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addClaimsNo", true, "PegaGadget2Ifr", "", "Add Claims as No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_PSA method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
			Assert.fail();

		}
	}
	
	public void validateRecentWorkInfo(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", data.get("Expected_Status"), "Status");
			assertEquals(data.get("Expected_Status"), actualStatus, "Status");
			
			String actualContact=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "contact", true, "PegaGadget1Ifr", data.get("Expected_Contact"), "Contact");
			assertEquals(data.get("Expected_Contact"), actualContact, "Contact");

			String actualChannel=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "channel", true, "PegaGadget1Ifr", data.get("Expected_Channel"), "Channel");
			assertEquals(data.get("Expected_Channel"), actualChannel, "Channel");

			String actualCreateOperator=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "createOperator", true, "PegaGadget1Ifr", data.get("Expected_CreateOperator"), "Create Operator");
			assertEquals(data.get("Expected_CreateOperator"), actualCreateOperator, "Create Operator");

			String actualCategory=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "categoryReviewHarness", true, "PegaGadget1Ifr", data.get("Expected_Category"), "Category");
			assertEquals(data.get("Expected_Category"), actualCategory, "Category");

			String actualSubCategory=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "subCategoryReviewHarness", true, "PegaGadget1Ifr", data.get("Expected_Subcategory"), "Sub Category");
			assertEquals(data.get("Expected_Subcategory"), actualSubCategory, "Sub Category");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
	
	public void ProcessGSI_PCPNotMA_NoClaims(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String MemberPCPState,String fname,String symptoms,String facility,String name,String street,String city,String state,String zip,String comments) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
		waitSleep(2500);
		waitOnIE(2000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
		waitSleep(3000);
		
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "memberPCPstate", true, "PegaGadget2Ifr", MemberPCPState , "Member PCP state Name");
	
		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pMemberCoverageMembers$l')]"));
		ele.size();
		String s="//tr[contains(@id,'$PpyWorkPage$pMemberCoverageMembers$l%d')]";
		for(int i=0;i<ele.size();i++)
		{
			String s1=String.format(s, i+1);
			//System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
			
      if(driver.findElement(By.xpath(s1+"//td[2]")).getText().toUpperCase().contains(fname))
			
			{
				//System.out.println("Entered if ");
				ClickWebelement("xpath", "("+s1+"//td[2]//preceding-sibling::td//input)[2]", fname);
				break;
			}
		}   
		waitSleep(1000);
		//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "membersResult", true, "PegaGadget2Ifr", "", "Member Results");
		waitSleep(1500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "urgentCare", true, "PegaGadget2Ifr", "", "urgentcareauthorization Yes");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "symptoms", true, "PegaGadget2Ifr", symptoms, "Symptoms or diagnosis");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "facility", true, "PegaGadget2Ifr", facility, "Facility name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "name", true, "PegaGadget2Ifr", name , "Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "street", true, "PegaGadget2Ifr", street , "Street Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, "PegaGadget2Ifr", city , "city Name");
     	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, "PegaGadget2Ifr", state , "state Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "zip", true, "PegaGadget2Ifr", zip , "Zip code");
       	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");		
       	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Deniedclaimno", true, "PegaGadget2Ifr", "", "Add Claims as No");
       	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "No", "Submit");		
    	waitSleep(2000);
    	
	}
	
	public void ProcessGSI_PCPNotMA_AddClaims(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String MemberPCPState,String fname,String symptoms,String facility,String name,String street,String city,String state,String zip,String comments) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
		waitSleep(2500);
		waitOnIE(2000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
		waitSleep(3000);
		
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "memberPCPstate", true, "PegaGadget2Ifr", MemberPCPState , "Member PCP state Name");
	
		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pMemberCoverageMembers$l')]"));
		ele.size();
		String s="//tr[contains(@id,'$PpyWorkPage$pMemberCoverageMembers$l%d')]";
		for(int i=0;i<ele.size();i++)
		{
			String s1=String.format(s, i+1);
			//System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
			
      if(driver.findElement(By.xpath(s1+"//td[2]")).getText().toUpperCase().contains(fname))
			
			{
				//System.out.println("Entered if ");
				ClickWebelement("xpath", "("+s1+"//td[2]//preceding-sibling::td//input)[2]", fname);
				break;
			}
		}   
		waitSleep(1000);
		//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "membersResult", true, "PegaGadget2Ifr", "", "Member Results");
		waitSleep(1500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "urgentCare", true, "PegaGadget2Ifr", "", "urgentcareauthorization Yes");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "symptoms", true, "PegaGadget2Ifr", symptoms, "Symptoms or diagnosis");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "facility", true, "PegaGadget2Ifr", facility, "Facility name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "name", true, "PegaGadget2Ifr", name , "Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "street", true, "PegaGadget2Ifr", street , "Street Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, "PegaGadget2Ifr", city , "city Name");
     	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, "PegaGadget2Ifr", state , "state Name");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "zip", true, "PegaGadget2Ifr", zip , "Zip code");
       	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");		
       	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addClaimsYes", true, "PegaGadget2Ifr", "", "Add Claims as Yes");
       	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "No", "Submit");		
    	waitSleep(2000);
    	
	}
	
	public void searchManageClaim(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		
		waitSleep(2000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", data.get("DateSearchOptions"), "DateSearch Options");
		waitSleep(2000);
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", data.get("FDOS"), "First date of serviceRequired");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", data.get("LDOS"), "Last date of service");
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
	
     	if(null != data.get("ClaimNumber") && !data.get("ClaimNumber").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", data.get("ClaimNumber"), "Claim Number");
		}
     	
     	if(null != data.get("providerName") && !data.get("providerName").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "providerName", true, "PegaGadget2Ifr", data.get("providerName"), "providerName");
		}
     	
     	if(null != data.get("NASCOproviderID") && !data.get("NASCOproviderID").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "NASCOproviderID", true, "PegaGadget2Ifr", data.get("NASCOproviderID"), "NASCOproviderID");
		}
     	
     	if(null != data.get("claimType") && !data.get("claimType").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimType", true, "PegaGadget2Ifr", data.get("claimType"), "claimType");
		}
     	
     	if(null != data.get("claimTypeValue") && !data.get("claimTypeValue").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimTypeValue", true, "PegaGadget2Ifr", data.get("claimTypeValue"), "claimTypeValue");
		}
     	
     	if(null != data.get("checkNumber") && !data.get("checkNumber").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "checkNumber", true, "PegaGadget2Ifr", data.get("checkNumber"), "checkNumber");
		}
     	
     	if(null != data.get("payee") && !data.get("payee").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "payee", true, "PegaGadget2Ifr", data.get("payee"), "payee");
		}
     	
     	if(null != data.get("procedureCode") && !data.get("procedureCode").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "procedureCode", true, "PegaGadget2Ifr", data.get("procedureCode"), "procedureCode");
		}
     	
     	if(null != data.get("diagnosisCode") && !data.get("diagnosisCode").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "diagnosisCode", true, "PegaGadget2Ifr", data.get("diagnosisCode"), "diagnosisCode");
		}
     	
     	if(null != data.get("diagnosisClass") && !data.get("diagnosisClass").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "diagnosisClass", true, "PegaGadget2Ifr", data.get("diagnosisClass"), "diagnosisClass");
		}
     	
     	if(null != data.get("requestNumber") && !data.get("requestNumber").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "requestNumber", true, "PegaGadget2Ifr", data.get("requestNumber"), "requestNumber");
		}
     	
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "additionalSearch", true, "PegaGadget2Ifr", "Additional search criteria", "additionalSearch");
		
     	if(null != data.get("totalAmt") && !data.get("totalAmt").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "totalAmt", true, "PegaGadget2Ifr", data.get("totalAmt"), "totalAmt");
		}
     	
     	if(null != data.get("hcpcs") && !data.get("hcpcs").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "hcpcs", true, "PegaGadget2Ifr", data.get("hcpcs"), "hcpcs");
		}
     	
     	if(null != data.get("nationalProviderID") && !data.get("nationalProviderID").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "nationalProviderID", true, "PegaGadget2Ifr", data.get("nationalProviderID"), "nationalProviderID");
		}
     	
     	
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit");
     	waitSleep(2000);
		String noofclaims=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "noofclaims", true, "PegaGadget2Ifr", "", "noofclaims");
		int claimsCount=Integer.valueOf(noofclaims);
		//System.out.println("claimsCount: "+claimsCount);
		if(claimsCount==0)
		{
			test.log(LogStatus.INFO, "No claims found for current search criteria");
		}
		else{
			
			assertEquals(data.get("claimsCount"), noofclaims, "claims Count");
			
		}
    }
	
	public void getOptions(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			Select options= new Select(driver.findElement(By.id("DateSearchOptions")));
			List<WebElement> dropdownValues=options.getOptions();
			//test.log(LogStatus.PASS, "Date search options");
			String searchOptions="|";
			for(int i=1;i<dropdownValues.size();i++)
			{
				//System.out.println(dropdownValues.get(i).getText());
				//test.log(LogStatus.PASS, dropdownValues.get(i).getText());
				searchOptions=searchOptions+dropdownValues.get(i).getText()+"|";
			}
			//System.out.println(searchOptions);
			assertEquals(data.get("ExpectedOptions"), searchOptions, "Search Options");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getOptions method " + e);
			test.log(LogStatus.FAIL, "Error on getOptions method " + e);
			Assert.fail();
		}
		
	}
	public void search_Claimselect(String pageLocatorsPath,String pageFiledsPath,String DateSearchOptions,String fdos,String ldos,String claim) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		
		waitSleep(2000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", DateSearchOptions, "DateSearch Options");
		waitSleep(2000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", fdos, "First date of serviceRequired");
		waitSleep(2000);
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", ldos, "Last date of service");
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", claim, "Claim Number");
		waitSleep(4000);
		WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
     	waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "reviewed", true, "PegaGadget2Ifr", "", "Reviewed");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
		waitSleep(5000);
	}
	
	public void claim_reviewed(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "reviewedComments", true, "PegaGadget2Ifr", "Testing", "Comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Reviewed", true, "PegaGadget2Ifr", "", "Reviewed");	
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "nextActionNo", true, "PegaGadget2Ifr", "No", "next Action No");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
			waitSleep(1500);
		}
		catch(Exception e)
		{
			
		}
		
	}
	
	public void createGSI_ProviderOccuranceAccesstocare(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String prvname, String prvId, String prnPhone, String prvAdd, String comments) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(4500);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ProviderNameOnProviderOccu", true, "PegaGadget2Ifr", prvname, "Provider name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Providerid", true, "PegaGadget2Ifr", prvId, "Provider Id");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ProviderPhone", true, "PegaGadget2Ifr", prnPhone, "Provide phone number");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ProviderAddress", true, "PegaGadget2Ifr", prvAdd, "Provide Address");
			
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addClaimsNo", true, "PegaGadget2Ifr", "", "Add Claims");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(4500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_ProviderOccurance method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_ProviderOccurance method " + e);
			Assert.fail();
		}
	}
	public void search_Claimselect(String pageLocatorsPath,String pageFiledsPath,String DateSearchOptions,String claim) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		
		waitSleep(2000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", DateSearchOptions, "DateSearch Options");
		
     	
     	
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
	
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", claim, "Claim Number");
		waitSleep(4000);
		

     	WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
     	waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "reviewed", true, "PegaGadget2Ifr", "", "Reviewed");
		

    	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
		waitSleep(5000);

		
	}
	
	public void createGSI_Dialogue(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", data.get("Category"), "Category");
			waitSleep(3000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", data.get("SubCategory"), "Sub Category");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_Dialogue method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_Dialogue method " + e);
			Assert.fail();
		}
	}
	
	public void createGSI_Taxforms(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String requestType,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(2000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Oralrequesttype", true, "PegaGadget2Ifr", requestType, "RequestType");

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_PSA method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
			Assert.fail();

		}
	}
	
	public void createGSI_Taxforms_Correction(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String requestType,String requesttaxyear,String methodofresponse,String recipienttype,String emailAddr,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(1000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Oralrequesttype", true, "PegaGadget2Ifr", requestType, "RequestType");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddingmembersCorrChk", true, "PegaGadget2Ifr", "Adding members", "Adding members");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "DateofbirthCorrChk", true, "PegaGadget2Ifr", "Date of birth", "DateofbirthCorrChk");
//			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Recipienttype", true, "PegaGadget2Ifr", recipienttype, "Recipient type");
//			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "EmailAddr", true, "PegaGadget2Ifr", emailAddr, "EmailAddr");
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddMethodofresponse", true, "PegaGadget2Ifr", "Add", "Add Method of response");
			createGSI_Email_MethodOfResponce(pageLocatorsPath,pageFiledsPath,requesttaxyear,methodofresponse,recipienttype,emailAddr);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
	    	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(3000);
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Taxforms_Correction method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Taxforms_Correction method " + e);
			Assert.fail();

		}
	}
	
	public void createGSI_Email_MethodOfResponce(String pageLocatorsPath,String pageFiledsPath,String requesttaxyear,String methodofresponse, String recipienttype,String emailAddr)
	{
		try {
			waitSleep(2000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Requesttaxyear", true, "PegaGadget2Ifr", requesttaxyear, "Request tax year");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Methodofresponse", true, "PegaGadget2Ifr", methodofresponse, "Method of response");
			waitSleep(3000);
			//WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Recipienttype", true, "PegaGadget2Ifr", recipienttype, "Recipient type");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "EmailAddr", true, "PegaGadget2Ifr", emailAddr, "EmailAddr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddMethodofresponse", true, "PegaGadget2Ifr", "Add", "Add Method of response");
			
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Email_MethodOfResponce method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Email_MethodOfResponce method " + e);
			Assert.fail();

		}
	}
	
	public void createGSI_Fax_MethodOfResponce(String pageLocatorsPath,String pageFiledsPath,String requesttaxyear1,String methodofresponse1,String recipienttypeFax,String faxNumber)
	{
		try {
			waitSleep(3500);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Requesttaxyear", true, "PegaGadget2Ifr", requesttaxyear1, "Request tax year");
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Methodofresponse", true, "PegaGadget2Ifr", methodofresponse1, "Method of response");
			waitSleep(3500);
			/*WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "RecipienttypeFax", true, "PegaGadget2Ifr", recipienttypeFax, "Recipient type Fax");
			//System.out.println("Recipientfaxnumber:::"+faxNumber);
			waitSleep(2000);
			*/WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Recipientfaxnumber", true, "PegaGadget2Ifr", faxNumber, "Recipient faxn umber");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddMethodofresponse", true, "PegaGadget2Ifr", "Add", "Add Method of response");
			
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Email_MethodOfResponce method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Email_MethodOfResponce method " + e);
			Assert.fail();

		}
	}
	
	public void createGSI_Taxforms_Correction_Withtwo(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String requestType,String requesttaxyear,String methodofresponse,String recipienttype,String emailAddr,String requesttaxyear1,String methodofresponse1,String recipienttypeFax,String faxNumber,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(1000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Oralrequesttype", true, "PegaGadget2Ifr", requestType, "RequestType");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddingmembersCorrChk", true, "PegaGadget2Ifr", "Adding members", "Adding members");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "DateofbirthCorrChk", true, "PegaGadget2Ifr", "Date of birth", "DateofbirthCorrChk");
			waitSleep(1000);
			createGSI_Email_MethodOfResponce(pageLocatorsPath,pageFiledsPath,requesttaxyear,methodofresponse,recipienttype,emailAddr);
			createGSI_Fax_MethodOfResponce(pageLocatorsPath,pageFiledsPath,requesttaxyear1,methodofresponse1,recipienttypeFax,faxNumber);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(4500);
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Taxforms_Correction_Withtwo method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Taxforms_Correction_Withtwo method " + e);
			Assert.fail();

		}
	}
	
	public void ValidateAssignedToOnWorkbasket(String pageLocatorsPath,String pageFiledsPath,String assignedTo)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			String actualAssignedTo=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AssignedTo", true, "PegaGadget1Ifr", assignedTo, "Assigned To");
			assertEquals(assignedTo, actualAssignedTo, "assigned To");
		} catch (Exception e){
			e.printStackTrace();
			BaseTest.log.error("Not able to validate the status on workbasket as "+assignedTo);
			BaseTest.log.error(e);
			test.log(LogStatus.FAIL, "Not able to validate the status on workbasket as "+assignedTo);
			test.log(LogStatus.FAIL,e);
			Assert.fail();
			
		}
	}
	
	public void createGSI_Taxforms_ValidateAddButton(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String requestType,String requesttaxyear,String methodofresponse,String recipienttype,String emailAddr,String requesttaxyear1,String methodofresponse1,String recipienttypeFax,String faxNumber,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(1000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Oralrequesttype", true, "PegaGadget2Ifr", requestType, "RequestType");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddingmembersCorrChk", true, "PegaGadget2Ifr", "Adding members", "Adding members");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "DateofbirthCorrChk", true, "PegaGadget2Ifr", "Date of birth", "DateofbirthCorrChk");
			waitSleep(1000);
			createGSI_Email_MethodOfResponce(pageLocatorsPath,pageFiledsPath,requesttaxyear,methodofresponse,recipienttype,emailAddr);
			createGSI_Fax_ValidateAdd(pageLocatorsPath,pageFiledsPath,requesttaxyear1,methodofresponse1,recipienttypeFax,faxNumber);
			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Taxforms_Correction_Withtwo method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Taxforms_Correction_Withtwo method " + e);
			Assert.fail();

		}
	}

	public void createGSI_Fax_ValidateAdd(String pageLocatorsPath,String pageFiledsPath,String requesttaxyear1,String methodofresponse1,String recipienttypeFax,String faxNumber)
	{
		try {
			waitSleep(2000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Requesttaxyear", true, "PegaGadget2Ifr", requesttaxyear1, "Request tax year");
			waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Methodofresponse", true, "PegaGadget2Ifr", methodofresponse1, "Method of response");
			waitSleep(2000);
			if (!driver.findElement(By.xpath("//button[contains(text(),'Add')]")).isEnabled()){
				BaseTest.log.debug("The add button is disabled");
				test.log(LogStatus.PASS, "The add button is disabled");
			}
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Email_MethodOfResponce method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Email_MethodOfResponce method " + e);
			Assert.fail();

		}
	}
	
	public void clickCorrespondenceOnWB(String pageLocatorsPath,String pageFiledsPath,String comments,String frame)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, frame, comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Createcorrespondence", true, frame, "Create correspondence", "Create correspondence");
			//WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, frame, comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CorrespondenceSubmit", true, frame, "", "Submit");
			waitSleep(3000);
		} catch (Exception e){
			e.printStackTrace();
			BaseTest.log.error("Error on clickCorrespondenceOnWB method");
			BaseTest.log.error(e);
			test.log(LogStatus.FAIL, "Error on clickCorrespondenceOnWB method");
			test.log(LogStatus.FAIL,e);
			Assert.fail();
			
		}
	}
	
	public void validatestatusAfterCorresp(String pageLocatorsPath,String pageFiledsPath,String status, String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame(frame);
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, frame, status, "Status");
			assertEquals(status, actualStatus, "Status");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}

	public void createGSI_Taxforms_DifferentYears(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String requestType,String requesttaxyear,String methodofresponse,String recipienttype,String emailAddr,String requesttaxyear1,String methodofresponse1,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(1000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Oralrequesttype", true, "PegaGadget2Ifr", requestType, "RequestType");
			waitSleep(1000);
			waitOnIE(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddingmembersCorrChk", true, "PegaGadget2Ifr", "Adding members", "Adding members");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "DateofbirthCorrChk", true, "PegaGadget2Ifr", "Date of birth", "DateofbirthCorrChk");
			waitSleep(1000);
			createGSI_Email_MethodOfResponce(pageLocatorsPath,pageFiledsPath,requesttaxyear,methodofresponse,recipienttype,emailAddr);
			createGSI_Email_MethodOfResponce(pageLocatorsPath,pageFiledsPath,requesttaxyear1,methodofresponse1,recipienttype,emailAddr);
//			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Requesttaxyear", true, "PegaGadget2Ifr", requesttaxyear, "Request tax year");
//			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Methodofresponse", true, "PegaGadget2Ifr", methodofresponse, "Method of response");
//			waitSleep(2000);
//			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Recipienttype", true, "PegaGadget2Ifr", recipienttype, "Recipient type");
//			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "EmailAddr", true, "PegaGadget2Ifr", emailAddr, "EmailAddr");
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddMethodofresponse", true, "PegaGadget2Ifr", "Add", "Add Method of response");
			
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Taxforms_Correction_Withtwo method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Taxforms_Correction_Withtwo method " + e);
			Assert.fail();

		}
	}
	public void createGSI_VerifyMember(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String CheckNumber, String CheckStatus, String Comments) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "CheckNumber", true, "PegaGadget2Ifr", CheckNumber, "Check Number");
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			//System.out.println(dateFormat.format(date));

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Checkdate", true, "PegaGadget2Ifr", dateFormat.format(date), "Check date");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CheckStatus", true, "PegaGadget2Ifr", CheckStatus, "Check Status");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", Comments, "Comments");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CheckStatus", true, "PegaGadget2Ifr", CheckStatus, "Check Status");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_ProviderOccurance method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_ProviderOccurance method " + e);
			Assert.fail();
		}
	}
	public void resolveCLM(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "responseComments", true, "PegaGadget1Ifr", "Resolving Intent","Comments");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "responseresolve", true, "PegaGadget1Ifr", "responseResolve", "Response Resolve");
			waitSleep(3000);
			WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "submit", true, "PegaGadget1Ifr", "","Submit");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on resolveMOC method " + e);
			test.log(LogStatus.FAIL, "Error on resolveMOC method " + e);
			Assert.fail();
			}
		
		}


	public void createGSI_Treasury(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String CheckNumber, String CheckStatus, String Comments) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "CheckNumber", true, "PegaGadget2Ifr", CheckNumber, "Check Number");
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			//System.out.println(dateFormat.format(date));

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Checkdate", true, "PegaGadget2Ifr", dateFormat.format(date), "Check date");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CheckStatus", true, "PegaGadget2Ifr", CheckStatus, "Check Status");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", Comments, "Comments");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CheckStatus", true, "PegaGadget2Ifr", CheckStatus, "Check Status");
		   	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addClaimsYes", true, "PegaGadget2Ifr", "", "Add Claims as Yes");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_ProviderOccurance method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_ProviderOccurance method " + e);
			Assert.fail();
		}
	}
	public void searchClaim(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data,String frame) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame(frame);
		
		waitSleep(2000);
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", data.get("DateSearchOptions"), "DateSearch Options");
		waitSleep(2000);
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", data.get("FDOS"), "First date of serviceRequired");
     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", data.get("LDOS"), "Last date of service");
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
	
     	if(null != data.get("ClaimNumber") && !data.get("ClaimNumber").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", data.get("ClaimNumber"), "Claim Number");
		}
     	
     	if(null != data.get("providerName") && !data.get("providerName").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "providerName", true, "PegaGadget2Ifr", data.get("providerName"), "providerName");
		}
     	
     	if(null != data.get("NASCOproviderID") && !data.get("NASCOproviderID").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "NASCOproviderID", true, "PegaGadget2Ifr", data.get("NASCOproviderID"), "NASCOproviderID");
		}
     	
     	if(null != data.get("claimType") && !data.get("claimType").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimType", true, "PegaGadget2Ifr", data.get("claimType"), "claimType");
		}
     	
     	if(null != data.get("claimTypeValue") && !data.get("claimTypeValue").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimTypeValue", true, "PegaGadget2Ifr", data.get("claimTypeValue"), "claimTypeValue");
		}
     	
     	if(null != data.get("checkNumber") && !data.get("checkNumber").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "checkNumber", true, "PegaGadget2Ifr", data.get("checkNumber"), "checkNumber");
		}
     	
     	if(null != data.get("payee") && !data.get("payee").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "payee", true, "PegaGadget2Ifr", data.get("payee"), "payee");
		}
     	
     	if(null != data.get("procedureCode") && !data.get("procedureCode").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "procedureCode", true, "PegaGadget2Ifr", data.get("procedureCode"), "procedureCode");
		}
     	
     	if(null != data.get("diagnosisCode") && !data.get("diagnosisCode").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "diagnosisCode", true, "PegaGadget2Ifr", data.get("diagnosisCode"), "diagnosisCode");
		}
     	
     	if(null != data.get("diagnosisClass") && !data.get("diagnosisClass").isEmpty())
		{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "diagnosisClass", true, "PegaGadget2Ifr", data.get("diagnosisClass"), "diagnosisClass");
		}
     	
     	if(null != data.get("requestNumber") && !data.get("requestNumber").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "requestNumber", true, "PegaGadget2Ifr", data.get("requestNumber"), "requestNumber");
		}
     	
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "additionalSearch", true, "PegaGadget2Ifr", "Additional search criteria", "additionalSearch");
		
     	if(null != data.get("totalAmt") && !data.get("totalAmt").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "totalAmt", true, "PegaGadget2Ifr", data.get("totalAmt"), "totalAmt");
		}
     	
     	if(null != data.get("hcpcs") && !data.get("hcpcs").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "hcpcs", true, "PegaGadget2Ifr", data.get("hcpcs"), "hcpcs");
		}
     	
     	if(null != data.get("nationalProviderID") && !data.get("nationalProviderID").isEmpty())
		{
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "nationalProviderID", true, "PegaGadget2Ifr", data.get("nationalProviderID"), "nationalProviderID");
		}
     	
     	waitOnIE(2000);
		WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SearchButtongsi", true, "PegaGadget2Ifr", "", "Search");
     	waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Filterbymember", true, "PegaGadget2Ifr", "", "Filter by member");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Apply", true, "PegaGadget2Ifr", "", "Apply");
		waitSleep(2000);
		String noofclaims=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "noofclaims", true, "PegaGadget2Ifr", "", "noofclaims");
		int claimsCount=Integer.valueOf(noofclaims);
		//System.out.println("claimsCount: "+claimsCount);
		if(claimsCount==0)
		{
			test.log(LogStatus.INFO, "No claims found for current search criteria");
		}
		else{
			
			assertEquals(data.get("claimsCount"), noofclaims, "claims Count");
			
		}
		 
	}
	
	public void Claim_details(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			String parentWindow=driver.getWindowHandle();
			waitOnIE(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "claimnumber", true, "PegaGadget2Ifr", data.get("Claimnumber"), "claimnumber");
			waitSleep(2000);
			waitOnIE(4000);
			for (String windowHandle : driver.getWindowHandles())
			{
				if(!parentWindow.equals(windowHandle)){
					 driver.switchTo().window(windowHandle);
					 //System.out.println("Switched to"+windowHandle);
				}
				//System.out.println(windowHandle);
				
			}
			
			switchToDefault();
			String Primarydiagnosiscode=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Primarydiagnosiscode", true, "PegaGadget2Ifr", "", "Audit Log");
			//System.out.println(Primarydiagnosiscode);
			assertEquals(Primarydiagnosiscode, data.get("diagnosisCode"), "diagnosis Code");

			driver.close();
			driver.switchTo().window(parentWindow);
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
			waitSleep(3000);

	}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_ProviderOccurance method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_ProviderOccurance method " + e);
			Assert.fail();
		}
	}
	public void createGSI_Taxforms_duplicate(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String requestType,String requesttaxyear1,String methodofresponse1,String recipienttypeFax,String faxNumber,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(1000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Oralrequesttype", true, "PegaGadget2Ifr", requestType, "RequestType");
			waitSleep(2000);
			createGSI_Fax_MethodOfResponce(pageLocatorsPath,pageFiledsPath,requesttaxyear1,methodofresponse1,recipienttypeFax,faxNumber);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(3000);
		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Taxforms_Correction method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Taxforms_Correction method " + e);
			Assert.fail();

		}
	}
	public void createGSI_Taxforms_Createfollowup(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(1000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(1000);
			} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Taxforms_Correction_Withtwo method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Taxforms_Correction_Withtwo method " + e);
			Assert.fail();

		}
	}
	public void create_gsi(String pageLocatorsPath,String pageFiledsPath) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CreateGSI", true, "PegaGadgetIfr", "Create GSI", "Create GSI");
				}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}
	public void createGSI_Taxforms_Correction(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String requestType,String requesttaxyear,String methodofresponse,String emailAddr,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget2Ifr", category, "Category");
			waitSleep(1000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", subCategory, "Sub Category");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Oralrequesttype", true, "PegaGadget2Ifr", requestType, "RequestType");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddingmembersCorrChk", true, "PegaGadget2Ifr", "Adding members", "Adding members");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "DateofbirthCorrChk", true, "PegaGadget2Ifr", "Date of birth", "DateofbirthCorrChk");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Requesttaxyear", true, "PegaGadget2Ifr", requesttaxyear, "Request tax year");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Methodofresponse", true, "PegaGadget2Ifr", methodofresponse, "Method of response");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "EmailAddr", true, "PegaGadget2Ifr", emailAddr, "EmailAddr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddMethodofresponse", true, "PegaGadget2Ifr", "Add", "Add Method of response");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget2Ifr", comments, "comments");
			waitOnIE(2000);
			waitSleep(2000);

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
			waitOnIE(2000);

		} catch (Exception e){
			e.printStackTrace();
			exceptionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createGSI_Taxforms_Correction method " + exceptionMessage);
			test.log(LogStatus.FAIL, "Error on createGSI_Taxforms_Correction method " + e);
			Assert.fail();

		}
	}
	
	public void selectClaim(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(1500);
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectClaim", true, "PegaGadget2Ifr", "", "Select Claim");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectClaim method " + e);
			test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
			Assert.fail();
		}
	}
	
	public void movetoOtherActions(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "clmotheractions", true, "PegaGadget2Ifr", "", "Other Actions");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectClaim method " + e);
			test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
			Assert.fail();
		}
	}
	
	public void cancelWork(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherOptions", true, "PegaGadget2Ifr", "Cancel work", "Cancel Work");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "reviewedComments", true, "PegaGadget2Ifr", "Cancel work", "Cancel Work");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "Cancel work", "Submit");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectClaim method " + e);
			test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
			Assert.fail();
		}
	}
	
	public String getOptions(String pageLocatorsPath,String pageFiledsPath,String fieldValue,String logname,String frame, String identifierName)
	{
		String text="";
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame(frame);
			text=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, fieldValue, true, frame, identifierName,logname );
			test.log(LogStatus.PASS, "Operator has access to "+logname);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Followup_SLA method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on Followup_SLA method " + e);
			Assert.fail();

		}
		return text;
	}
	
	public void search_Claimselect(String pageLocatorsPath,String pageFiledsPath,String claim) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget2Ifr");
		
		waitSleep(2000);
     	
     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
	
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", claim, "Claim Number");
		waitSleep(4000);
		

     	WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
     	waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "reviewed", true, "PegaGadget2Ifr", "", "Reviewed");
		

    	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit Button");
		waitSleep(5000);

		
	}
	

}

