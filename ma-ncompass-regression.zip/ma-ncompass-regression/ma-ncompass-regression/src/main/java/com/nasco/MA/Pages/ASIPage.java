package com.nasco.MA.Pages;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;

@SuppressWarnings("rawtypes")
public class ASIPage extends BasePage{

String excepionMessage="";
	
	public String frame1="PegaGadget2Ifr";
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
	}

	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3500);
			switchToFrame("PegaGadget2Ifr");
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "Create GSI", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	
	public void movetoOtherActions(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActions", true, "PegaGadget2Ifr", "", "Other Actions");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectClaim method " + e);
			test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
			Assert.fail();
		}
	}
	
	public void movetoSelectSI(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otheroptions", true, "PegaGadget2Ifr", "Select Service Intent", "Select Service Intent");
			waitSleep(1500);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on movetoSelectSI method " + e);
			test.log(LogStatus.FAIL, "Error on movetoSelectSI method " + e);
			Assert.fail();
		}
	}
	
	public void movetoDissociateSI(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "dissociatelink", true, "PegaGadget2Ifr", "Dissociate Service Intent", "Dissociate Service Intent");
			waitSleep(1500);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectClaim method " + e);
			test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
			Assert.fail();
		}
	}
	
	public void status(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			String status=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", "", "Status");
			waitSleep(1500);
			assertEquals(data.get("ExpectedStatus"), status, "Status");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on status method " + e);
			test.log(LogStatus.FAIL, "Error on status method " + e);
			Assert.fail();
		}
	}
	public void diassociate(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "dissociateComments", true, "PegaGadget2Ifr", "Dissociate", "Cancel Work");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "Cancel work", "Submit");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectClaim method " + e);
			test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
			Assert.fail();
		}
	}
	public void cancelWork(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otheroptions", true, "PegaGadget2Ifr", "Cancel work", "Cancel Work");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "reviewedComments", true, "PegaGadget2Ifr", "Cancel work", "Cancel Work");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "Cancel work", "Submit");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectClaim method " + e);
			test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
			Assert.fail();
		}
	}
	
	public void selectIntent(String pageLocatorsPath,String pageFiledsPath,String intenetID)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "asilinkedintent", true, "PegaGadget2Ifr", intenetID, "Select Intent");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "Cancel work", "Submit");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on selectIntent method " + e);
			Assert.fail();
		}
	}
	
	public void selectASIIntent(String pageLocatorsPath,String pageFiledsPath,String intenetID)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "asiintentLink", true, "PegaGadget2Ifr", intenetID, "Select Intent");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "Cancel work", "Submit");
			waitSleep(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on selectIntent method " + e);
			Assert.fail();
		}
	}
	
	public void auditDissociateSI(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "historyBtn", true, "PegaGadget1Ifr", "", "History");
			waitSleep(1500);
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				driver.switchTo().window(childWindow);
				System.out.println(driver.switchTo().window(childWindow).getTitle());
				switchToDefault();
				waitSleep(3500);
				String auditLog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "dissociateAudit", false, "", "", "Audit History");
				waitSleep(1000);
				System.out.println(auditLog);
				//assertEquals(data.get("ExpectedHistory"), auditLog, "Audit log");
				driver.close();
				}
			}
			driver.switchTo().window(mainWindow);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on auditLogASIlinked method " + e);
			test.log(LogStatus.FAIL, "Error on auditLogASIlinked method " + e);
			Assert.fail();
		}
	}
	public void auditLogASIlinked(String pageLocatorsPath,String pageFiledsPath,String intent, String intnet1)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "historyBtn", true, "PegaGadget1Ifr", "", "History");
			waitSleep(1500);
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				driver.switchTo().window(childWindow);
				System.out.println(driver.switchTo().window(childWindow).getTitle());
				switchToDefault();
				waitSleep(2500);
				/*String auditLog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "linkedasiAudit", false, "", "", "Audit History");
				waitSleep(1000);
				System.out.println(auditLog);
				String expeted="Service intent %s is associated to service intent";
				expeted=String.format(expeted, intent);
				expeted=expeted+" %s.";
				expeted=String.format(expeted, intnet1);
				System.out.println("Expected: "+expeted);
				System.out.println("Actual: "+auditLog);
				assertEquals(expeted, auditLog, "Audit log");*/
				driver.close();
				}
			}
			driver.switchTo().window(mainWindow);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on auditLogASIlinked method " + e);
			test.log(LogStatus.FAIL, "Error on auditLogASIlinked method " + e);
			Assert.fail();
		}
	}
	
	public void validateASIScreen(String pageLocatorsPath,String pageFiledsPath,String intenetID)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ASIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ASIPageFields.properties";
			waitSleep(1500);
			String selctedIntent=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "selectedSI", true, "PegaGadget2Ifr", intenetID, "Select Intent");
			assertEquals(intenetID, selctedIntent, "Selected Intent");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateASIScreen method " + e);
			test.log(LogStatus.FAIL, "Error on validateASIScreen method " + e);
			Assert.fail();
		}
	}
}
