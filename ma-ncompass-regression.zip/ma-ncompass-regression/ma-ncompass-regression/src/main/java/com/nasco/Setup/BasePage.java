package com.nasco.Setup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public abstract class BasePage<T> {

	protected WebDriver driver;
	protected ExtentTest test;

	private long LOAD_TIMEOUT = 120;
	protected WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), LOAD_TIMEOUT);

	public BasePage() {
		this.driver = DriverManager.getDriver();
		this.test = DriverManager.getExtentReport();
	}

	// @SuppressWarnings({ "rawtypes", "unchecked" })
	public T openPage(Class<T> clazz) {
		T page = null;
		try {
			driver = DriverManager.getDriver();
			wait = new WebDriverWait(DriverManager.getDriver(), LOAD_TIMEOUT);
			page = PageFactory.initElements(driver, clazz);
			String frame = "PegaGadget0Ifr";
			ExpectedCondition pageLoadCondition = ((BasePage) page).getPageLoadCondition();
			waitForPageToLoad(pageLoadCondition);
		} catch (NoSuchElementException e) {
			throw new IllegalStateException(String.format("This is not the %s page", clazz.getSimpleName()));
		}
		return page;
	}

	private void waitForPageToLoad(ExpectedCondition<T> pageLoadCondition) {
		WebDriverWait wait = new WebDriverWait(driver, LOAD_TIMEOUT);
		wait.until(pageLoadCondition);
	}
	
	protected  abstract ExpectedCondition<T> getPageLoadCondition();
	//protected abstract ExpectedCondition<T> getPageLoadCondition(String frame);
	
	
	//protected abstract ExpectedCondition<T> getPageLoadCondition(String frameName);
	public String WebElementAction(String action, String pageLocatorsPath, String pageFiledsPath, String Fieldproperty,
			boolean framePresent, String frame, String fieldValue, String logname) throws Exception {
		String text = "";
		Properties pageLocatorsprop = new Properties();
		Properties pageFieldsprop = new Properties();
		System.out.println(pageFiledsPath);
		FileInputStream FiledsIn = new FileInputStream(pageFiledsPath);
		pageFieldsprop.load(FiledsIn);
		try {
			System.out.println("Fieldproperty: " + Fieldproperty);
			System.out.println("Fieldproperty: " + pageFieldsprop.getProperty(Fieldproperty));
			String fieldProperty = pageFieldsprop.getProperty(Fieldproperty);
			findWebElement(pageLocatorsPath, pageFieldsprop.getProperty(Fieldproperty), Fieldproperty, false, frame);
			FiledsIn.close();
			FileInputStream locatorIn = new FileInputStream(pageLocatorsPath);
			pageLocatorsprop.load(locatorIn);
			String locatorTypeIdentifier = Fieldproperty + "WebElementtype";
			String locatorValueIdentifier = Fieldproperty + "WebElementvalue";
			System.out.println("locatorTypeIdentifier###" + locatorTypeIdentifier);
			System.out.println("locatorValueIdentifier**" + locatorValueIdentifier);
			try {
				waitForElementToVisible(locatorTypeIdentifier,locatorValueIdentifier,logname);
				waitForElementNotToStale(locatorTypeIdentifier,locatorValueIdentifier,logname);

				if (action.equalsIgnoreCase("type")) {
					System.out.println("Entered type: " + action);
					sendInputkeys(pageLocatorsprop.getProperty(locatorTypeIdentifier),
							pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
					BaseTest.log.debug("Successfully entered data '" + fieldValue + "' in text field " + logname);
					test.log(LogStatus.INFO, "Successfully entered data '" + fieldValue + "' in text field " + logname);
				}else if (action.equalsIgnoreCase("clear")) {
					System.out.println("Entered type: " + action);
					clearkeys(pageLocatorsprop.getProperty(locatorTypeIdentifier),
							pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
					BaseTest.log.debug("Successfully entered data '" + fieldValue + "' in text field " + logname);
					test.log(LogStatus.INFO, "Successfully entered data '" + fieldValue + "' in text field " + logname);
				} else if (action.equalsIgnoreCase("click")) {
					ClickWebelement(pageLocatorsprop.getProperty(locatorTypeIdentifier),
							pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
					System.out.println("@@@@@read Text locatorTypeIdentifier:"
							+ pageLocatorsprop.getProperty(locatorTypeIdentifier));
					System.out.println(
							"######read Text locatorTypevalue:" + pageLocatorsprop.getProperty(locatorValueIdentifier));
					BaseTest.log.debug("Successfully clicked " + logname);
					test.log(LogStatus.INFO, "Successfully clicked " + logname);
				} else if (action.equalsIgnoreCase("jsClick")) {
					jsClickWebelement(pageLocatorsprop.getProperty(locatorTypeIdentifier),
							pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
					System.out.println("@@@@@read Text locatorTypeIdentifier:"
							+ pageLocatorsprop.getProperty(locatorTypeIdentifier));
					System.out.println(
							"######read Text locatorTypevalue:" + pageLocatorsprop.getProperty(locatorValueIdentifier));
					BaseTest.log.debug("Successfully clicked " + logname);
					test.log(LogStatus.INFO, "Successfully clicked " + logname);

				} else if (action.equalsIgnoreCase("selectbytext")) {
					Selectbytext(pageLocatorsprop.getProperty(locatorTypeIdentifier),
							pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
					BaseTest.log.debug("Successfully selected text '" + fieldValue + "' in dropdown " + logname);
					test.log(LogStatus.INFO, "Successfully selected text '" + fieldValue + "' in dropdown " + logname);
				} else if (action.equalsIgnoreCase("readText")) {
					text = readText(pageLocatorsprop.getProperty(locatorTypeIdentifier),
							pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
					BaseTest.log.debug(logname + " text is :" + text);
					test.log(LogStatus.INFO, logname + " text is :" + text);
				} else if (action.equalsIgnoreCase("getAttribteValue")) {
					text = getAttributeValue(pageLocatorsprop.getProperty(locatorTypeIdentifier),
							pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
					BaseTest.log.debug(logname + " text is :" + text);
					test.log(LogStatus.INFO, logname + " text is :" + text);
				} else if (action.equalsIgnoreCase("doubleClick")) {
					doubleClickWebelement(pageLocatorsprop.getProperty(locatorTypeIdentifier),
							pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
					BaseTest.log.debug("Successfully double clicked " + logname);
					test.log(LogStatus.INFO, "Successfully double clicked " + logname);
				} else if (action.equalsIgnoreCase("pressTab")) { 
					pressTab(pageLocatorsprop.getProperty(locatorTypeIdentifier),
							pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
					BaseTest.log.debug("Successfully pressed Tab on " + logname);
					test.log(LogStatus.INFO, "Successfully Pressed Tab on " + logname);
				}

				locatorIn.close();

			} catch (Exception e) {
				//e.printStackTrace();
				System.out.println("*****************" + fieldProperty);
				if (!fieldProperty.equalsIgnoreCase("static")) {
					System.out.println("Entered if");
					FileOutputStream out = new FileOutputStream(pageLocatorsPath);
					pageLocatorsprop.setProperty(locatorTypeIdentifier, "");
					pageLocatorsprop.setProperty(locatorValueIdentifier, "");
					pageLocatorsprop.store(out, null);
					out.close();
					FiledsIn = new FileInputStream(pageFiledsPath);
					pageFieldsprop.load(FiledsIn);
					findWebElement(pageLocatorsPath, pageFieldsprop.getProperty(Fieldproperty), Fieldproperty, false,
							frame);
					FiledsIn.close();
					locatorIn = new FileInputStream(pageLocatorsPath);
					pageLocatorsprop.load(locatorIn);
					locatorTypeIdentifier = Fieldproperty + "WebElementtype";
					locatorValueIdentifier = Fieldproperty + "WebElementvalue";
					System.out.println("locatorTypeIdentifier:=" + locatorTypeIdentifier);
					System.out.println("locatorValueIdentifier:=" + locatorValueIdentifier);

					try {
						if (action.equalsIgnoreCase("type")) {
							sendInputkeys(pageLocatorsprop.getProperty(locatorTypeIdentifier),
									pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
							BaseTest.log.debug("Successfully entered data '" + fieldValue + "' in text field " + logname);
							test.log(LogStatus.INFO,
									"Successfully entered data '" + fieldValue + "' in text field " + logname);
						} else if (action.equalsIgnoreCase("click")) {
							ClickWebelement(pageLocatorsprop.getProperty(locatorTypeIdentifier),
									pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
							BaseTest.log.debug("Successfully clicked " + logname);
							test.log(LogStatus.INFO, "Successfully clicked " + logname);
						} else if (action.equalsIgnoreCase("jsClick")) {
								jsClickWebelement(pageLocatorsprop.getProperty(locatorTypeIdentifier),
										pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
								BaseTest.log.debug("Successfully clicked " + logname);
								test.log(LogStatus.INFO, "Successfully clicked " + logname);
						} else if (action.equalsIgnoreCase("selectbytext")) {
							Selectbytext(pageLocatorsprop.getProperty(locatorTypeIdentifier),
									pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
							BaseTest.log.debug("Successfully selected text '" + fieldValue + "' in dropdown " + logname);
							test.log(LogStatus.INFO,
									"Successfully selected text '" + fieldValue + "' in dropdown " + logname);
						} else if (action.equalsIgnoreCase("readText")) {
							text = readText(pageLocatorsprop.getProperty(locatorTypeIdentifier),
									pageLocatorsprop.getProperty(locatorValueIdentifier), fieldValue);
							BaseTest.log.debug(logname + " text is :" + text);
							test.log(LogStatus.INFO, logname + " text is :" + text);
						} else if (action.equalsIgnoreCase("doubleClick")) {
							doubleClickWebelement(locatorTypeIdentifier, locatorValueIdentifier, fieldValue);
							BaseTest.log.debug("Successfully double clicked " + logname);
							test.log(LogStatus.INFO, "Successfully double clicked " + logname);
						}
						locatorIn.close();
					} catch (Exception e1) {
						FileOutputStream out1 = new FileOutputStream(pageLocatorsPath);
						pageLocatorsprop.setProperty(locatorTypeIdentifier, "");
						pageLocatorsprop.setProperty(locatorValueIdentifier, "");
						pageLocatorsprop.store(out1, null);
						out1.close();
						if (action.equalsIgnoreCase("type")) {
							BaseTest.log.debug("unable to enter data '" + fieldValue + "' in text field " + logname);
							test.log(LogStatus.INFO,
									"unable to enter data '" + fieldValue + "' in text field " + logname);
						} else if (action.equalsIgnoreCase("click")) {
							BaseTest.log.debug("Unable to click " + logname);
							test.log(LogStatus.INFO, "Unable to click " + logname);
						} else if (action.equalsIgnoreCase("jsclick")) {
							BaseTest.log.debug("Unable to click through js" + logname);
							test.log(LogStatus.INFO, "Unable to click through js" + logname);
						} else if (action.equalsIgnoreCase("selectbytext")) {
							BaseTest.log.debug("Unable to select text '" + fieldValue + "' in dropdown " + logname);
							test.log(LogStatus.INFO,
									"Unable to select text '" + fieldValue + "' in dropdown " + logname);
						} else if (action.equalsIgnoreCase("readText")) {
							BaseTest.log.debug(logname + " Not able to get text");
							test.log(LogStatus.INFO, logname + " Not able to get text");
						} else if (action.equalsIgnoreCase("doubleClick")) {
							BaseTest.log.debug("Unable to double click " + logname);
							test.log(LogStatus.INFO, "Unable to double click " + logname);
						}
						locatorIn.close();
						String excepionMessage = Arrays.toString(e.getStackTrace());
						e.printStackTrace();
						BaseTest.log.error(excepionMessage);
						test.log(LogStatus.FAIL, e);
						Assert.fail();

					}

				} else {
					BaseTest.log.debug("Not able to find the static element for "+logname);
					test.log(LogStatus.ERROR, "Not able to find the static element for "+logname);
					String excepionMessage = Arrays.toString(e.getStackTrace());
					e.printStackTrace();
					BaseTest.log.error(excepionMessage);
					test.log(LogStatus.FAIL, e);
					Assert.fail();
				}

			}

		} catch (Exception er) {
			FiledsIn.close();
			er.printStackTrace();
			Assert.fail();
		}

		return text;
	}

//	public void sendInputkeys(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
//		wait = new WebDriverWait(driver, 15);
//		System.out.println("locatorTypeIdentifier:" + locatorTypeIdentifier);
//		if (locatorTypeIdentifier.equals("id")) {
//			System.out.println("entered id");
//			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id(locatorValueIdentifier))))
//					.clear();
//			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id(locatorValueIdentifier))))
//					.sendKeys(fieldValue);
//
//		} else if (locatorTypeIdentifier.equals("name")) {
//			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.name(locatorValueIdentifier))))
//					.clear();
//			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.name(locatorValueIdentifier))))
//					.sendKeys(fieldValue);
//
//		}
//		if (locatorTypeIdentifier.equals("xpath")) {
//			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(locatorValueIdentifier))))
//					.clear();
//			wait.until(ExpectedConditions.elementToBeClickable(
//					driver.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))))
//					.sendKeys(fieldValue);
//
//		}
//	}
	
	public void sendInputkeys(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
		wait = new WebDriverWait(driver, 30);
		System.out.println("locatorTypeIdentifier:" + locatorTypeIdentifier);
		try {
			if (locatorTypeIdentifier.equals("id")) {
				System.out.println("entered id");
				wait.until(ExpectedConditions.elementToBeClickable(By.id(locatorValueIdentifier)))
						.clear();
				wait.until(ExpectedConditions.elementToBeClickable(By.id(locatorValueIdentifier)))
						.sendKeys(fieldValue);
	
			} else if (locatorTypeIdentifier.equals("name")) {
				wait.until(ExpectedConditions.elementToBeClickable(By.name(locatorValueIdentifier)))
						.clear();
				wait.until(ExpectedConditions.elementToBeClickable(By.name(locatorValueIdentifier)))
						.sendKeys(fieldValue);
	
			}
			if (locatorTypeIdentifier.equals("xpath")) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValueIdentifier)))
						.clear();
				wait.until(ExpectedConditions.elementToBeClickable(
						By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":"))))
						.sendKeys(fieldValue);
	
			}
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to enter value on  element " + fieldValue + " Locator "+locatorValueIdentifier);
					BaseTest.log.error("Error Message"+		excepionMessage);
			test.log(LogStatus.FAIL, "Not able to Click Web element " + fieldValue + " Locator "+ locatorValueIdentifier);
			test.log(LogStatus.FAIL,e);
			Assert.fail();

		}
	} 

	public void clearkeys(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
		wait = new WebDriverWait(driver, 30);
		System.out.println("locatorTypeIdentifier:" + locatorTypeIdentifier);
		try {
			if (locatorTypeIdentifier.equals("id")) {
				//System.out.println("entered id");
				wait.until(ExpectedConditions.elementToBeClickable(By.id(locatorValueIdentifier)))
						.clear();
			} else if (locatorTypeIdentifier.equals("name")) {
				wait.until(ExpectedConditions.elementToBeClickable(By.name(locatorValueIdentifier)))
						.clear();
			}
			if (locatorTypeIdentifier.equals("xpath")) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValueIdentifier)))
						.clear();
		
			}
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to clear an element " + fieldValue + " Locator "+locatorValueIdentifier);
					BaseTest.log.error("Error Message"+	excepionMessage);
			test.log(LogStatus.FAIL, "Not able to clear an element " + fieldValue + " Locator "+ locatorValueIdentifier);
			test.log(LogStatus.FAIL,e);
			Assert.fail();

		}
	}
	
//	public void ClickWebelement(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
//		if (locatorTypeIdentifier.equals("id")) {
//			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id(locatorValueIdentifier))))
//					.click();
//		} else if (locatorTypeIdentifier.equals("name")) {
//			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.name(locatorValueIdentifier))))
//					.click();
//		}
//		if (locatorTypeIdentifier.equals("xpath")) {
//			wait.until(ExpectedConditions.elementToBeClickable(
//					driver.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))))
//					.click();
//		}
//	}

	public void ClickWebelement(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
		try {
			if (locatorTypeIdentifier.equals("id")) {
				wait.until(ExpectedConditions.elementToBeClickable(By.id(locatorValueIdentifier)));
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id(locatorValueIdentifier))))
				.click();
			} else if (locatorTypeIdentifier.equals("name")) {
				wait.until(ExpectedConditions.elementToBeClickable(By.name(locatorValueIdentifier)));
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.name(locatorValueIdentifier))))
				.click();;
			}
			if (locatorTypeIdentifier.equals("xpath")) {
				System.out.println("fieldValue"+fieldValue);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":"))));
						
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))))
				.click();
			}
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to click an element " + fieldValue + " Locator "+locatorValueIdentifier);
					BaseTest.log.error("Error Message"+	excepionMessage);
			test.log(LogStatus.FAIL, "Not able to click an element " + fieldValue + " Locator "+ locatorValueIdentifier);
			test.log(LogStatus.FAIL,e);
			Assert.fail();

		}

	}
	public void doubleClickWebelement(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
		Actions action = new Actions(driver);
		try {
			if (locatorTypeIdentifier.equals("id")) {
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id(locatorValueIdentifier))));
				action.doubleClick(driver.findElement(By.id(locatorValueIdentifier))).perform();
			} else if (locatorTypeIdentifier.equals("name")) {
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.name(locatorValueIdentifier))));
				action.doubleClick(driver.findElement(By.name(locatorValueIdentifier))).perform();
			}
			if (locatorTypeIdentifier.equals("xpath")) {
				wait.until(ExpectedConditions.elementToBeClickable(driver
						.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))));
				action.doubleClick(
						driver.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":"))))
						.perform();
			}
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to double click an element " + fieldValue + " Locator "+locatorValueIdentifier);
					BaseTest.log.error("Error Message"+	excepionMessage);
			test.log(LogStatus.FAIL, "Not able to double click an element " + fieldValue + " Locator "+ locatorValueIdentifier);
			test.log(LogStatus.FAIL,e);
			Assert.fail();

		}
	}

//	public void Selectbytext(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
//		wait = new WebDriverWait(driver, LOAD_TIMEOUT);
//		if (locatorTypeIdentifier.equals("id")) {
//			Select dropDown = new Select(driver.findElement(By.id(locatorValueIdentifier)));
//			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id(locatorValueIdentifier))));
//			dropDown.selectByVisibleText(fieldValue);
//		} else if (locatorTypeIdentifier.equals("name")) {
//			Select dropDown = new Select(driver.findElement(By.name(locatorValueIdentifier)));
//			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.name(locatorValueIdentifier))));
//			dropDown.selectByVisibleText(fieldValue);
//		}
//		if (locatorTypeIdentifier.equals("xpath")) {
//			Select dropDown = new Select(driver.findElement(By.xpath(locatorValueIdentifier)));
//			wait.until(ExpectedConditions.elementToBeClickable(driver
//					.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))));
//			dropDown.selectByVisibleText(fieldValue);
//		}
//	}
	
	public void Selectbytext(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
		wait = new WebDriverWait(driver, LOAD_TIMEOUT);
		try {
			if (locatorTypeIdentifier.equals("id")) {
				wait.until(ExpectedConditions.elementToBeClickable(By.id(locatorValueIdentifier)));
				Select dropDown = new Select(driver.findElement(By.id(locatorValueIdentifier)));	
				dropDown.selectByVisibleText(fieldValue);
			} else if (locatorTypeIdentifier.equals("name")) {
				wait.until(ExpectedConditions.elementToBeClickable(By.name(locatorValueIdentifier)));
				Select dropDown = new Select(driver.findElement(By.name(locatorValueIdentifier)));
				dropDown.selectByVisibleText(fieldValue);
			}
			if (locatorTypeIdentifier.equals("xpath")) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":"))));
				Select dropDown = new Select(driver.findElement(By.xpath(locatorValueIdentifier)));
				dropDown.selectByVisibleText(fieldValue);
			}

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to select an element " + fieldValue + " Locator "+locatorValueIdentifier);
					BaseTest.log.error("Error Message"+	excepionMessage);
			test.log(LogStatus.FAIL, "Not able to select an element " + fieldValue + " Locator "+ locatorValueIdentifier);
			test.log(LogStatus.FAIL,e);
			Assert.fail();

		}
	}

	public String readText(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
		String text = "";
		this.driver = DriverManager.getDriver();
		wait = new WebDriverWait(DriverManager.getDriver(), LOAD_TIMEOUT);
		try {
			if (locatorTypeIdentifier.equals("id")) {
				text = driver.findElement(By.id(locatorValueIdentifier)).getText();
			} else if (locatorTypeIdentifier.equals("name")) {
				text = driver.findElement(By.name(locatorValueIdentifier)).getText();
			} else if (locatorTypeIdentifier.equals("xpath")) {
				text = driver.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))
						.getText();
			}
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to read text from an element " + fieldValue + " Locator "+locatorValueIdentifier);
					BaseTest.log.error("Error Message"+	excepionMessage);
			test.log(LogStatus.FAIL, "Not able to read text from  an element " + fieldValue + " Locator "+ locatorValueIdentifier);
			test.log(LogStatus.FAIL,e);
			Assert.fail();

		}
		return text;
	}

	public String getAttributeValue(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
		String text = "";
		this.driver = DriverManager.getDriver();
		wait = new WebDriverWait(DriverManager.getDriver(), LOAD_TIMEOUT);
		try {
			if (locatorTypeIdentifier.equals("id")) {
				text = driver.findElement(By.id(locatorValueIdentifier)).getAttribute("value");
			} else if (locatorTypeIdentifier.equals("name")) {
				text = driver.findElement(By.name(locatorValueIdentifier)).getAttribute("value");
			}
			if (locatorTypeIdentifier.equals("xpath")) {
				text = driver.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))
						.getAttribute("value");
			}
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to get attribute value of an element " + fieldValue + " Locator "+locatorValueIdentifier);
					BaseTest.log.error("Error Message"+	excepionMessage);
			test.log(LogStatus.FAIL, "Not able to get attribute value of an element " + fieldValue + " Locator "+ locatorValueIdentifier);
			test.log(LogStatus.FAIL,e);
			Assert.fail();

		}
		return text;
	}

	public void waitSleep(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void switchToDefault() {
		driver.switchTo().defaultContent();
	}

	public void switchToFrame(String frame) {
		driver.switchTo().defaultContent().switchTo().frame(frame);
	}

	public void assertEquals(String expected, String actual, String logname) {
		try {
			Assert.assertEquals(actual, expected);
			test.log(LogStatus.INFO, "Expected Value: " + expected);
			test.log(LogStatus.INFO, "Actual Value: " + actual);
			test.log(LogStatus.PASS, "Actual and excepted values are matched for '" + logname + "'");
			BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual + " are matched for '"
					+ logname + "'");
		} catch (AssertionError e) {
			test.log(LogStatus.FAIL, "Actual Value: " + actual);
			test.log(LogStatus.FAIL, "Expected Value: " + expected);
			test.log(LogStatus.FAIL, "Actual and excepted values are mismatched for '" + logname + "'");
			BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual + " are not matched for '"
					+ logname + "'");
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error(excepionMessage);
			test.log(LogStatus.FAIL, e);
			Assert.fail();
			Assert.fail();
		}
	}
	
	public String readTableData(String rowWebelement,String rowWebelements)
    {
  	  String memberDetails="";
		List<WebElement> membersRow =driver.findElements(By.xpath(rowWebelement));
		if(membersRow.size()!=0)
		{
			String s=rowWebelements;
			for(int i=0;i<membersRow.size();i++)
			{
				String s1=String.format(s, i+1);
				String memdet="";
				List<WebElement> membersCol =driver.findElements(By.xpath(s1+"//td"));	
				for(int j=0;j<membersCol.size();j++)
				{
					if(j==0)
					{
						memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
					else{
						memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
				}
				memberDetails=memberDetails+","+memdet;	
			}
			waitSleep(1000);
			memberDetails=memberDetails.substring(1,memberDetails.length());
			System.out.println("Actual memberdetails: "+memberDetails);
    }
return memberDetails;
}

public String getListitemstext(String webElement)
{
	String text="";
	List<WebElement> membersRow =driver.findElements(By.xpath(webElement));
	for(int i=1;i<=membersRow.size();i++)
	{
		text=text+"|"+driver.findElement(By.xpath(webElement+"["+i+"]")).getText();
		
	}
	return text;
}
	public void findWebElement(String filePath, String FiledsonPage, boolean framePresemt, String frame)
			throws IOException {
		File yourFile = new File(filePath);
		yourFile.createNewFile();
		FileInputStream in = new FileInputStream(filePath);
		Properties props = new Properties();
		props.load(in);
		String fieldName = "";
		String searchFiled = "";
		String fieldType = "";
		String fieldlabel = "";
		if (FiledsonPage.equalsIgnoreCase("Static")) {
			fieldlabel = FiledsonPage;
			System.out.println("fieldlabel" + fieldlabel);
		} else {
			String[] requiredFileds = FiledsonPage.split("_");
			fieldName = requiredFileds[0];
			searchFiled = requiredFileds[1];
			fieldType = requiredFileds[2];
			fieldlabel = requiredFileds[3];
		}

		try {
			props.get(fieldlabel + "WebElementtype").toString();
			props.get(fieldlabel + "WebElementvalue").toString();
			if (props.get(fieldlabel + "WebElementtype").toString().equals("")
					|| props.get(fieldlabel + "WebElementvalue").toString().equals("")) {
				throw new Exception();
			}
			in.close();
		} catch (Exception e) {
			in.close();
			FileOutputStream out = new FileOutputStream(filePath);
			String[] values = getWebelement(fieldName, searchFiled, fieldType, framePresemt, frame);
			props.setProperty(fieldlabel + "WebElementtype", values[0]);
			props.setProperty(fieldlabel + "WebElementvalue", values[1]);
			props.store(out, null);
			out.close();
		}

	}

	public void findWebElement(String filePath, String FiledsonPage, String Fieldproperty, boolean framePresemt,
			String frame) throws IOException {
		File yourFile = new File(filePath);
		yourFile.createNewFile();
		FileInputStream in = new FileInputStream(filePath);
		Properties props = new Properties();
		props.load(in);
		String fieldName = "";
		String searchFiled = "";
		String fieldType = "";
		String fieldlabel = "";
		System.out.println("Fieldproperty " + Fieldproperty);
		System.out.println("FiledsonPage:" + FiledsonPage);
		if (FiledsonPage.equalsIgnoreCase("Static")) {
			fieldlabel = Fieldproperty;
			System.out.println("fieldlabel*****" + fieldlabel);
		} else {
			String[] requiredFileds = FiledsonPage.split("_");
			fieldName = requiredFileds[0];
			searchFiled = requiredFileds[1];
			fieldType = requiredFileds[2];
			fieldlabel = requiredFileds[3];
			try {
				props.get(fieldlabel + "WebElementtype").toString();
				props.get(fieldlabel + "WebElementvalue").toString();
				System.out
						.println(fieldlabel + "WebElementtype: " + props.get(fieldlabel + "WebElementtype").toString());
				System.out.println(
						fieldlabel + "WebElementvalue: " + props.get(fieldlabel + "WebElementvalue").toString());
				if (props.get(fieldlabel + "WebElementtype").toString().equals("")
						|| props.get(fieldlabel + "WebElementvalue").toString().equals("")) {
					System.out.println("Entered if in find webelement");
					throw new Exception();

				}
				in.close();
			} catch (Exception e) {
				in.close();
				FileOutputStream out = new FileOutputStream(filePath);
				System.out.println("fieldName: " + fieldName + " fieldType:" + fieldType);
				try {
					String[] values = getWebelement(fieldName, searchFiled, fieldType, framePresemt, frame);
					System.out.println("values: " + values[0] + " " + values[1]);
					props.setProperty(fieldlabel + "WebElementtype", values[0]);
					props.setProperty(fieldlabel + "WebElementvalue", values[1]);
					System.out.println(fieldlabel + "WebElementtype: " + values[0]);
					System.out.println(fieldlabel + "WebElementvalue: " + values[1]);
					props.store(out, null);
					out.close();
				} catch (Exception e1) {
					e1.printStackTrace();
					String excepionMessage = Arrays.toString(e.getStackTrace());
					props.setProperty(fieldlabel + "WebElementtype", "");
					props.setProperty(fieldlabel + "WebElementvalue", "");
					props.store(out, null);
					out.close();
					System.out.println("Not able to find the webelement");
					BaseTest.log.error("Not able to find the webelement " + fieldlabel + "WebElementtype" + "-"
							+ fieldlabel + "WebElementvalue", "");
					BaseTest.log.error(excepionMessage);
					test.log(LogStatus.ERROR, "Not able to find the webelement " + fieldlabel + "WebElementtype" + "-"
							+ fieldlabel + "WebElementvalue", "");
					test.log(LogStatus.ERROR,e1);
				}

			}

		}

	}

	public String[] getWebelement(String fieldName,String searchField, String fieldtype,boolean framepresent, String frame)
	{
		String [] values = {"",""};
		if(framepresent)
		{
			driver.switchTo().defaultContent().switchTo().frame(frame);
		}
		String tagName="";
		System.out.println("searchField: "+searchField);
		System.out.println("FieldType: "+fieldtype);
		
		if(fieldtype.equals("a")&&searchField.equals("a"))
		{
			values[0]="xpath";
			values[1]="//"+fieldtype+"[contains(text(),'%s')]";
			
		}else if(fieldtype.equals("span")&&searchField.equals("span"))
		{
			values[0]="xpath";
			values[1]="//"+fieldtype+"[contains(text(),'%s')]";
		}
		else if(fieldtype.equals("div")&&searchField.equals("div"))
		{
			values[0]="xpath";
			values[1]="//"+fieldtype+"[contains(text(),'%s')]";
		}
		else if(fieldtype.equals("h2")&&searchField.equals("h2"))
		{
			values[0]="xpath";
			values[1]="//"+fieldtype+"[contains(text(),'%s')]";
		}
		else if(fieldtype.equals("button")&&searchField.equals("button"))
		{
			values[0]="xpath";
			values[1]="//"+fieldtype+"[contains(text(),'%s')]";
		}
		else if(fieldtype.equals("h3")&&searchField.equals("h3"))
		{
			values[0]="xpath";
			values[1]="//"+fieldtype+"[contains(text(),'"+fieldName+"')]";
		}
		else if(fieldtype.equals("nextspan"))
		{
			values[0]="xpath";
			values[1]="//"+searchField+"[contains(text(),'%s')]//following::span[1]";
		}
		else if(fieldtype.equals("precedinginput")){
			values[0]="xpath";
			values[1]="//"+searchField+"[contains(text(),'%s')]//preceding::input[1]";
		}
		else if(fieldtype.equals("followinginput")){
			values[0]="xpath";
			values[1]="//"+searchField+"[contains(text(),'"+fieldName+"')]//following::input[1]";
		}
		else if(fieldtype.equals("followinginput2")){
			values[0]="xpath";
			values[1]="//"+searchField+"[contains(text(),'"+fieldName+"')]//following::input[2]";
		}
		else if(fieldtype.equals("followingtextarea")){
			values[0]="xpath";
			values[1]="//"+searchField+"[contains(text(),'"+fieldName+"')]//following::textarea[1]";
		}
		else if(fieldtype.equals("followingselect")){
			values[0]="xpath";
			values[1]="//"+searchField+"[contains(text(),'"+fieldName+"')]//following::select[1]";
		}
		else if(fieldtype.equals("followingfollowing")){
			values[0]="xpath";
			values[1]="//"+searchField+"[contains(text(),'"+fieldName+"')]//following::"+searchField+"[contains(text(),'ID')]//following::a[1]";
		}
		else if(fieldtype.equals("followingdiv")){
			values[0]="xpath";
			values[1]="//"+searchField+"[contains(text(),'"+fieldName+"')]//following::div[1]";
		}else if(fieldtype.equals("followingspan")){
			values[0]="xpath";
			values[1]="//"+searchField+"[contains(text(),'"+fieldName+"')]//following::span[1]";
		}
		
		else if(fieldtype.equals("button")&&!searchField.equals("span"))
		{
			if(searchField.equals("buttonancestor"))
			{
				if(driver.findElement(By.xpath("//div[contains(text(),'"+fieldName+"')]")).getText().equals(fieldName))
				{
					values[0]="xpath";
					values[1]="//div[contains(text(),'"+fieldName+"')]//ancestor::button";
				}
			}
			else if(searchField.equals("buttoncontains"))
			{
				if(driver.findElement(By.xpath("//button[contains(text(),'"+fieldName+"')]")).getText().equals(fieldName))
				{
					values[0]="xpath";
					values[1]="//button[contains(text(),'"+fieldName+"')]";
				}
			}else if(searchField.equals("nextspan"))
			{
				if(driver.findElement(By.xpath("//span[contains(text(),'"+fieldName+"')]")).getText().equals(fieldName))
				{
					values[0]="xpath";
					values[1]="//span[contains(text(),'%s')]//following::button[1]";
				}
				
			}
		}
		else{
			if(fieldtype.equals("button"))
			{
				tagName=searchField;
			}
			else{
				tagName=fieldtype;
			}
			List<WebElement>  allElements= driver.findElements(By.tagName(tagName));
			for(int i=0;i<allElements.size();i++)
			{
				if(fieldtype.equals("input"))
				{
					if(!allElements.get(i).getAttribute("type").equals("hidden"))
				{
					if(driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]//preceding::"+searchField+"[1]")).getText().equals(fieldName))
						{
							
								if(!driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("id").equals(""))
								{
									values[0]="id";
									values[1]=driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("id");
								}
								else if(!driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("name").equals(""))
								{
									values[0]="name";
									values[1]=driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("name");
								}
								else if(!driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("class").equals(""))
								{
									values[0]="class";
									values[1]=driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("class");
								}else {
									values[0]="xpath";
									values[1]="(//"+fieldtype+")["+(i+1)+"]";
								}
								break;
							
						}
				}//
				}
				
				if(fieldtype.equals("select"))
				{
					if(driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]//following::"+searchField+"[1]")).getText().equals(fieldName))
					{
						
							if(!driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("id").equals(""))
							{
								values[0]="id";
								values[1]=driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("id");
							}
							else if(!driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("name").equals(""))
							{
								values[0]="name";
								values[1]=driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("name");
							}
							else if(!driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("class").equals(""))
							{
								values[0]="class";
								values[1]=driver.findElement(By.xpath("(//"+fieldtype+")["+(i+1)+"]")).getAttribute("class");
							}else {
								values[0]="xpath";
								values[1]="(//"+fieldtype+")["+(i+1)+"]";
							}
							break;
						
					}
				}
				if(fieldtype.equals("button"))
				{
					 if(driver.findElement(By.xpath("(//"+searchField+")["+(i+1)+"]//following::"+fieldtype+"[1]")).getText().equals(fieldName))
					{
						if(!driver.findElement(By.xpath("(//"+searchField+")["+(i+1)+"]//following::"+fieldtype+"[1]")).getAttribute("id").equals(""))
						{
							values[0]="id";
							values[1]=driver.findElement(By.xpath("(//"+searchField+")["+(i+1)+"]//following::"+fieldtype+"[1]")).getAttribute("id");
						}
						else if(!driver.findElement(By.xpath("(//"+searchField+")["+(i+1)+"]//following::"+fieldtype+"[1]")).getAttribute("name").equals(""))
						{
							values[0]="name";
							values[1]=driver.findElement(By.xpath("(//"+searchField+")["+(i+1)+"]//following::"+fieldtype+"[1]")).getAttribute("name");
						}
						else if(!driver.findElement(By.xpath("(//"+searchField+")["+(i+1)+"]//following::"+fieldtype+"[1]")).getAttribute("class").equals(""))
						{
							values[0]="class";
							values[1]=driver.findElement(By.xpath("(//"+searchField+")["+(i+1)+"]//following::"+fieldtype+"[1]")).getAttribute("class");
						}else {
							values[0]="xpath";
							values[1]="(//"+searchField+")["+(i+1)+"]//following::"+fieldtype+"[1]";
						}
						break;
					}
				}
			}	
		}
		
		return values;
		
	}
	public void assertContains(String expected, String actual, String logname) {
		try {
			Assert.assertTrue(actual.contains(expected));// .assertEquals(actual,
															// expected);
			test.log(LogStatus.INFO, "Expected Value: " + expected);
			test.log(LogStatus.INFO, "Actual Value: " + actual);
			test.log(LogStatus.PASS, "Actual and excepted values are matched for '" + logname + "'");
			BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual + " Expected value contains an Actual value '"
					+ logname + "'");

		} catch (AssertionError e) {
			test.log(LogStatus.FAIL, "Actual Value: " + actual);
			test.log(LogStatus.FAIL, "Expected Value: " + expected);
			test.log(LogStatus.FAIL, "Actual and excepted values are mismatched for '" + logname + "'");
			BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual + " Expected value does not contains an Actual value '"
					+ logname + "'");
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error(excepionMessage);
			test.log(LogStatus.FAIL, e);
			Assert.fail();
		}
	}

//	public void waitForElementToVisible(String locatorTypeIdentifier, String locatorValueIdentifier,
//			String fieldValue) {
//		if (locatorTypeIdentifier.equals("id")) {
//			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id(locatorValueIdentifier)))).click();
//		} else if (locatorTypeIdentifier.equals("name")) {
//			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.name(locatorValueIdentifier)))).click();
//		}
//		if (locatorTypeIdentifier.equals("xpath")) {
//			wait.until(ExpectedConditions.visibilityOf(
//					driver.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))))
//					.click();
//		}
//		
//	}
	
//	public void waitForElementToVisible(String locatorTypeIdentifier, String locatorValueIdentifier,
//			String fieldValue) {
//		if (locatorTypeIdentifier.equals("id")) {
//			wait.until(ExpectedConditions.visibilityOf((WebElement) (By.id(locatorValueIdentifier)))).click();
//		} else if (locatorTypeIdentifier.equals("name")) {
//			wait.until(ExpectedConditions.visibilityOf((WebElement) (By.name(locatorValueIdentifier)))).click();
//		}
//		if (locatorTypeIdentifier.equals("xpath")) {
//			wait.until(ExpectedConditions.visibilityOf(
//					(WebElement) (By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))))
//					.click();
//		}
//		
//	}
	
	public void waitForElementToVisible(String locatorTypeIdentifier, String locatorValueIdentifier,
			String fieldValue) {
		if (locatorTypeIdentifier.equals("id")) {
			wait.until(ExpectedConditions.visibilityOf((WebElement) (By.id(locatorValueIdentifier))));
		} else if (locatorTypeIdentifier.equals("name")) {
			wait.until(ExpectedConditions.visibilityOf((WebElement) (By.name(locatorValueIdentifier))));
		}
		if (locatorTypeIdentifier.equals("xpath")) {
			wait.until(ExpectedConditions.visibilityOf(
					(WebElement) (By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))));
		}
		
	}

	public void waitForElementsToVisible(String xpath) {

		wait.until(ExpectedConditions.visibilityOfAllElements((List<WebElement>) driver.findElements(By.xpath(xpath))));
		//wait.until(ExpectedConditions.visibilityOfAllElements((List<WebElement>) By.xpath(xpath)));

	}
	
	public void waitForFrameTobeVisible(String frameName) {

		//wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(driver.findElement(By.name(frameName))));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.name(frameName)));
				}
	
	public void waitForElementNotToStale(String locatorTypeIdentifier, String locatorValueIdentifier,
			String fieldValue) {
		if (locatorTypeIdentifier.equals("id")) {
			wait.until(ExpectedConditions.stalenessOf((WebElement) (By.id(locatorValueIdentifier))));
		} else if (locatorTypeIdentifier.equals("name")) {
			wait.until(ExpectedConditions.stalenessOf((WebElement) (By.name(locatorValueIdentifier))));
		}
		if (locatorTypeIdentifier.equals("xpath")) {
			wait.until(ExpectedConditions.stalenessOf(
					driver.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))));
		}
		
	}
	
//	public void jsClickWebelement(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
//
//			JavascriptExecutor executor = (JavascriptExecutor)driver;
//			    			 
//
//		if (locatorTypeIdentifier.equals("id")) {
//			wait.until(ExpectedConditions.visibilityOf((WebElement) By.id(locatorValueIdentifier)));
//			executor.executeScript("arguments[0].click();", driver.findElement(By.id(locatorValueIdentifier)));
//		} else if (locatorTypeIdentifier.equals("name")) {
//			wait.until(ExpectedConditions.visibilityOf((WebElement) By.name(locatorValueIdentifier)));
//			executor.executeScript("arguments[0].click();", (WebElement) By.name(locatorValueIdentifier));
//
//		}
//		if (locatorTypeIdentifier.equals("xpath")) {
//			wait.until(ExpectedConditions.visibilityOf(
//					(WebElement)(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))));
//			executor.executeScript("arguments[0].click();", driver.findElement(By.xpath(locatorValueIdentifier.replace("/:", ":"))));
//
//		}
//	}

	public void jsClickWebelement(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {

		JavascriptExecutor executor = (JavascriptExecutor)driver;
		    			 

	if (locatorTypeIdentifier.equals("id")) {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id(locatorValueIdentifier))));
		executor.executeScript("arguments[0].click();", driver.findElement(By.id(locatorValueIdentifier)));
	} else if (locatorTypeIdentifier.equals("name")) {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.name(locatorValueIdentifier))));
		executor.executeScript("arguments[0].click();", driver.findElement(By.name(locatorValueIdentifier)));

	}
	if (locatorTypeIdentifier.equals("xpath")) {
		wait.until(ExpectedConditions.visibilityOf(
				driver.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))));
		executor.executeScript("arguments[0].click();", driver.findElement(By.xpath(locatorValueIdentifier.replace("/:", ":"))));

	}
} 
	public void pressTab(String locatorTypeIdentifier, String locatorValueIdentifier, String fieldValue) {
		if (locatorTypeIdentifier.equals("id")) {
//			wait.until(ExpectedConditions.visibilityOf((WebElement) (By.id(locatorValueIdentifier))));
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id(locatorValueIdentifier))))
			.sendKeys(Keys.TAB);
		} else if (locatorTypeIdentifier.equals("name")) {
//			wait.until(ExpectedConditions.visibilityOf((WebElement) (By.name(locatorValueIdentifier))));
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.name(locatorValueIdentifier))))
			.sendKeys(Keys.TAB);
		}
		if (locatorTypeIdentifier.equals("xpath")) {
//			wait.until(ExpectedConditions.visibilityOf(
//					(WebElement) (By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))));
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement((By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":"))))))
			.sendKeys(Keys.TAB);
		}
		
	}
	
	public void clickOnPage(){
		driver.findElement(By.xpath("//body")).click();
	}

	
	public void waitOnIE(int time){
		try {
			if (RunTestNG_NCompass_MA.Config.get("Browser").toString().equalsIgnoreCase("ie"))
				Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error(excepionMessage);
			test.log(LogStatus.FAIL, e);
			Assert.fail();
		}
	}
}
