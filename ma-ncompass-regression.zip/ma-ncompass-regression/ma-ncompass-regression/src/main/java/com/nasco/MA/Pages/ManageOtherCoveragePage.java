package com.nasco.MA.Pages;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings("rawtypes")
public class ManageOtherCoveragePage extends BasePage {

	
	
	@FindBy(xpath="//label[@id='pyActionLabel']//following::span[1]")
	public WebElement intentID;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget2Ifr");
		return ExpectedConditions.visibilityOf(intentID);
	}
	
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "View Other Coverage", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
		return intentid;
	}
	public void priorManageOtherCoverage(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "priorManageOtherCoverage", true, "PegaGadget2Ifr", "","priorManageOtherCoverage");

			String createdate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "createdate", true, "PegaGadget2Ifr", data.get("Expected_Createdate"), "Create date");
			assertEquals(data.get("Expected_Createdate"), createdate, "createdate");

			String id=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "id", true, "PegaGadget2Ifr", data.get("Expected_ID"), "Id");
			assertEquals(data.get("Expected_ID"), id, "ID");

			String contactname=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "contactname", true, "PegaGadget2Ifr", data.get("Expected_Contactname"), "Contact name");
			assertEquals(data.get("Expected_Contactname"), contactname, "Contact name");

			String membername=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "membername", true, "PegaGadget2Ifr", data.get("Expected_membername"), "member name");
			assertEquals(data.get("Expected_membername"), membername, "member name");

			String status=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget2Ifr", data.get("Expected_status"), "status");
			assertEquals(data.get("Expected_status"), status, "Resolve Operator");

			String createoperator=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "createoperator", true, "PegaGadget2Ifr", data.get("Expected_createoperator"), "createoperator");
			assertEquals(data.get("Expected_createoperator"), createoperator, "Category");

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ocvcomment", true, "PegaGadget2Ifr", "Submitting OID", "Comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "close", true, "PegaGadget2Ifr", "", "close button");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
		
	}
	public void Otherinsurancedetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
		switchToFrame("PegaGadget2Ifr");
		waitSleep(3000);
		String otherinsurancedetails="";
		List<WebElement> ele= driver.findElements(By.xpath("//table[@pl_prop_class='MA-CS-CSD-Data-OtherCoverage']//tr"));
       String s="//table[@pl_prop_class='MA-CS-CSD-Data-OtherCoverage']//tr[%d]";
       for(int i=1;i<ele.size();i++)
    {
	    String s1=String.format(s, i+1);
	    String memdet="";
	    List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
	     for(int j=0;j<colums.size();j++)
	{
		if(j==0)
		{
			memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
		else{
			memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
	}
	otherinsurancedetails=otherinsurancedetails+","+memdet;	
     }

		System.out.println(otherinsurancedetails);
		waitSleep(1000);
		assertEquals(data.get("Expected_other"), otherinsurancedetails, "Member Search Results");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ocvcomment", true, "PegaGadget2Ifr", "Submitting OID", "Comments");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "close", true, "PegaGadget2Ifr", "", "close button");

	}
	public void duplicateCOBdetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
		switchToFrame("PegaGadget2Ifr");
		waitSleep(3000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "icon", true, "PegaGadget2Ifr", "", "icon button");
		String otherinsurancedetails="";
		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pCoverages$l1')]"));
       String s="//tr[contains(@id,'$PpyWorkPage$pCoverages$l1')]";
       for(int i=0;i<ele.size();i++)
    {
	    String s1=String.format(s, i+1);
	    String memdet="";
	    List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
	    System.out.println(colums.size());
	     for(int j=0;j<colums.size();j++)
	    	
	{
		if(j==0)
		{
			System.out.println("action");
			memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
		else{
			memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
		}
	}
	otherinsurancedetails=otherinsurancedetails+","+memdet;	
     }
		
		 ele= driver.findElements(By.xpath("//tr[contains(@id,'$pMembersData$l')]"));
      s="//tr[contains(@id,'$pMembersData$l%d')]";
       for(int i=0;i<ele.size();i++)
    {
	    String s1=String.format(s, i+1);
	    String memdet="";
	    List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
	    System.out.println(colums.size());
	     for(int j=0;j<colums.size();j++)
	    	
	{
		if(j==0)
		{
			System.out.println("action");
			memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
			System.out.println("memdet"+memdet);
		}
		else{
			memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
			System.out.println("memdet2"+memdet);

		}
	}
	otherinsurancedetails=otherinsurancedetails+","+memdet;	
     }
       otherinsurancedetails=otherinsurancedetails.substring(1,otherinsurancedetails.length());
		System.out.println(otherinsurancedetails);
		waitSleep(1000);
		
		assertEquals(data.get("Expected_details"), otherinsurancedetails, "Member Search Results");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ocvcomment", true, "PegaGadget2Ifr", "Submitting OID", "Comments");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "close", true, "PegaGadget2Ifr", "", "close button");

	}
	
	
	
	
	public void clickOtherActions(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{	
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActions", true, "PegaGadget2Ifr", "", "Other Actions");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on clickOtherActions method " + e);
			test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
			Assert.fail();
		}
	}
	
	
	public void routetoCOB(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "routeToCOB", true, "PegaGadget2Ifr", "Route To COB", "Route To COB");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on routetoCOB method " + e);
			test.log(LogStatus.FAIL, "Error on routetoCOB method " + e);
			Assert.fail();
		}
		
	}
	
	public void routetoTPL(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "routeToTPL", true, "PegaGadget2Ifr", "Route To TPL", "Route To TPL");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on routetoTPL method " + e);
			test.log(LogStatus.FAIL, "Error on routetoTPL method " + e);
			Assert.fail();
		}
		
	}
	
	public void performRoutetoCOB(String pageLocatorsPath,String pageFiledsPath,String lastName) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "HasOtherInsurancetrue", true, "PegaGadget2Ifr", "", "Other Insurace Yes");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "OISubscriberDOB", true, "PegaGadget2Ifr", "12/05/2017", "DOB");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "HasOtherInsurancetrue", true, "PegaGadget2Ifr", "", "Other Insurace Yes");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "COBPayer", true, "PegaGadget2Ifr", lastName, "Payer");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "COBOIID", true, "PegaGadget2Ifr", "123456789", "OI ID");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "COBOISubscriber", true, "PegaGadget2Ifr", lastName, "OI Subscriber");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "OIDepedent", true, "PegaGadget2Ifr", "", "Dependent Name");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "HasMedicarefalse", true, "PegaGadget2Ifr", "", "Does the member have Medicare");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "IsSubActivelyWorkingfalse", true, "PegaGadget2Ifr", "", "BCBSMA subscriber actively working");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "OutOnDisabilityfalse", true, "PegaGadget2Ifr", "", "Out on disability");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ESRDfalse", true, "PegaGadget2Ifr", "", "ESRD");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitroutetocob", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(4500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget2Ifr", "Submitting COB", "Comments");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitroutetocob", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(4500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on performRoutetoCOB method " + e);
			test.log(LogStatus.FAIL, "Error on performRoutetoCOB method " + e);
			Assert.fail();
		}
	}
	
	
	public void resolveMOC(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "response", true, "PegaGadget1Ifr", "Resolve", "Response");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "responseComments", true, "PegaGadget1Ifr", "Resolving Intent","Comments");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitResponse", true, "PegaGadget1Ifr", "","Submit");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on resolveMOC method " + e);
			test.log(LogStatus.FAIL, "Error on resolveMOC method " + e);
			Assert.fail();
		}
		
	}
	public void pendingMOC(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "response", true, "PegaGadget1Ifr", "Pend for Additional Information", "Response");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "responseComments", true, "PegaGadget1Ifr", "Pend for Additional Information Intent","Comments");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitResponse", true, "PegaGadget1Ifr", "","Submit");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on resolveMOC method " + e);
			test.log(LogStatus.FAIL, "Error on resolveMOC method " + e);
			Assert.fail();
		}
		
	}
	
	
	public void performRoutetoTPL(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "NoFault", true, "PegaGadget2Ifr", "","No Fault");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WorkersCompensation", true, "PegaGadget2Ifr", "","WorkersCompensation");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "routetoTPLComments", true, "PegaGadget2Ifr", "Submitting COB", "Comments");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitroutetocob", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on performRoutetoTPL method " + e);
			test.log(LogStatus.FAIL, "Error on performRoutetoTPL method " + e);
			Assert.fail();
		}
		
	}
	public void Medicarecoverage(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Medicarecoverage", true, "PegaGadget2Ifr", "","Medicare coverage");

			String medicarecoverage="";
			List<WebElement> ele= driver.findElements(By.xpath("//table[@pl_prop='.Medicare']"));
	       String s="//table[@pl_prop='.Medicare']";
	       for(int i=0;i<ele.size();i++)
	    {
		    String s1=String.format(s, i+1);
		    String memdet="";
		    List<WebElement> colums= driver.findElements(By.xpath(s1+"//th"));
		    System.out.println(colums.size());
		     for(int j=0;j<colums.size();j++)
		    	
		{
			if(j==0)
			{
				System.out.println("action");
				memdet=driver.findElement(By.xpath(s1+"//th["+(j+1)+"]")).getText();
			}
			else{
				memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//th["+(j+1)+"]")).getText();
			}
		}
		     medicarecoverage=medicarecoverage+","+memdet;
		     medicarecoverage=medicarecoverage.substring(1,medicarecoverage.length());
				System.out.println(medicarecoverage);
				waitSleep(1000);
				
				assertEquals(data.get("Expected_medicarecoverage"), medicarecoverage, "Medicare coverage");
 
	    }
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
		
	}

}
