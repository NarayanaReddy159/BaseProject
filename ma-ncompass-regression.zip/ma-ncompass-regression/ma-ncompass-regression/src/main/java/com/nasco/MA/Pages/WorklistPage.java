package com.nasco.MA.Pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
@SuppressWarnings("rawtypes")
public class WorklistPage extends BasePage{

	
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	
	@FindBy(xpath = "//a[contains(text(),'My Work')]")
	public WebElement myWork;
	
	@FindBy(xpath="(//tr[@id='$PpyWorkPage$pCommentPage$pCommentsList$l1']//td[@data-attribute-name='Comments'])[1]")
	public WebElement Comments_SavetoWOrklist_RecentWork;
	
	
	@FindBy(xpath="(//a[@id='pui_filter'])[5]")
	public WebElement InstructionsFilter_Worklist;
	
	@FindBy(xpath="(//a[@id='pui_filter'])[2]")
	public WebElement IDFilter_Worklist;
	
	@FindBy(xpath="//input[contains(@id,'SearchText')]")
	public WebElement Search_recentwork;
	
	@FindBy(xpath="//button[contains(text(),'Apply')]")
	public WebElement ApplyButton_recentwork;
	
	@FindBy(xpath="(//div[@id='HARNESS_CONTENT']//span[contains(text(),'Status')]//following-sibling::div)[1]")
	public WebElement Status;
	
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		switchToFrame("PegaGadget0Ifr");
		return ExpectedConditions.visibilityOf(myWork);
	}
	
	
	public void movetoWorklistPage(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			waitOnIE(4000);
			switchToFrame("PegaGadget0Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "worklist", true, "PegaGadget0Ifr", "", "Worklist tab");
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_PSA method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
			Assert.fail();
		}
	}
	
	
	public void sortandSelectIntent(String pageLocatorsPath,String pageFiledsPath, String intentId) throws Exception
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			switchToFrame("PegaGadget0Ifr");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "idSort", true, "PegaGadget0Ifr", "", "ID Sort");
			waitSleep(5000);
			waitSleep(5000);
			waitSleep(10000);
			waitOnIE(8000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchID", true, "PegaGadget0Ifr", intentId, "Search intent");
			waitOnIE(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "applyBtn", true, "PegaGadget0Ifr", "", "Apply");
			waitSleep(6500);
			waitOnIE(15000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "intentclick", true, "PegaGadget0Ifr", intentId, "Intent "+intentId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
		
	}
	
	public void closeintent(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeIntent", true, "PegaGadget1Ifr", "", "CloseIntent");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on closeintent method " + e);
			test.log(LogStatus.FAIL, "Error on closeintent method " + e);
			Assert.fail();
		}
		}
	public void validateSaveToWOrklist(String pageLocatorsPath,String pageFiledsPath,String comments) throws Exception
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			String commentsText = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Comments_SavetoWOrklist_RecentWork",true,"PegaGadget0Ifr","","comments");
			if(comments.equalsIgnoreCase(commentsText)){
				System.out.println("Expected:" + comments + "Actual:" + commentsText + "::::::::::::::::::::Test Pass:::::::::::::::::::::::::::::");
			}else{
				System.out.println("Expected:" + comments + "Actual:" + commentsText + "::::::::::::::::::::Test Fail:::::::::::::::::::::::::::::");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateSaveToWOrklist method " + e);
			test.log(LogStatus.FAIL, "Error on validateSaveToWOrklist method " + e);
			Assert.fail();
		}
	}
	
	
	public String openIntent_Worklist_Instructions(String pageLocatorsPath,String pageFiledsPath,String intent) throws Exception
	{
		//String claimIntentID=Claim_Worklist.getText();
		String claimIntentID=null;
		try {
			String instructions="Created from "+intent;
			
			System.out.println("Instructions to search :::::::::::::::::::::::::::::::::::"+ instructions);
			waitSleep(2000);
			switchToDefault();
			switchToFrame("PegaGadget0Ifr");
			
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			//waitSleep(4000);
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "worklist", true, "PegaGadget0Ifr", "", "Worklist tab");
			
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "InstructionsFilter_Worklist", true, "PegaGadget0Ifr", "", "ID Sort");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchInstruction", true, "PegaGadget0Ifr", instructions, "Search intent");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "applyBtn", true, "PegaGadget0Ifr", "", "Apply");
			waitSleep(6000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "intentclick", true, "PegaGadget0Ifr", intent, "Intent "+intent);
			
			waitSleep(3000);
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			claimIntentID = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "claimIntentID", true, "PegaGadget1Ifr", intent, "claimIntentID");
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on openIntent_Worklist_Instructions method " + e);
            test.log(LogStatus.FAIL, "Error on openIntent_Worklist_Instructions method " + e);
            Assert.fail();

        }

		return claimIntentID;
	}
	
	public void ValidateViewClaimDetails_Static(String pageLocatorsPath,String pageFiledsPath,String claimNum, String Pref, String ProviderName,String NascoGroupNum, String PatientDOB, String TotalCharge, String TotalDeductible, String TotalCopayment ) throws Exception
	{
		
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			//jsScroll(ClaimNumber, "");
			waitSleep(2000);
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			String actualclaimNum = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "claimNum", true, "PegaGadget0Ifr", "", "claimNumber");
			assertEquals(claimNum,actualclaimNum,"ClaimNumber");
			String actualprefix = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "prefix", true, "PegaGadget0Ifr", "", "prefix");
			assertEquals(Pref,actualprefix,"Prefix");
			String actualProviderName = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ProviderName", true, "PegaGadget0Ifr", "", "ProviderName");
			assertEquals(ProviderName, actualProviderName, "Provider name");
			String actualNascoGrpNum = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "NascoGrpNum", true, "PegaGadget0Ifr", "", "NascoGroupNum");
			assertEquals(NascoGroupNum, actualNascoGrpNum, "NASCO Group Number");
			String actualPatientDOB = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "PatientDOB", true, "PegaGadget0Ifr", "", "PatientDOB");
			assertEquals(PatientDOB, actualPatientDOB, "Patient DOB");
			String actualTotalAmountCharge = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "TotalAmtCharge", true, "PegaGadget0Ifr", "", "Total Amount Charge");
			assertEquals(TotalCharge, actualTotalAmountCharge, "Total Charge Amount");
			String actualDeductible = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Deductible", true, "PegaGadget0Ifr", "", "Total Deductible");
			assertEquals(TotalDeductible, actualDeductible, "Total Deductible");
			String actualTotalCopayment = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "TotalCopay", true, "PegaGadget0Ifr", "", "Total Copay");
			assertEquals(TotalCopayment, actualTotalCopayment, "Total Copayment");
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on ValidateViewClaimDetails_Static method " + e);
            test.log(LogStatus.FAIL, "Error on ValidateViewClaimDetails_Static method " + e);
            Assert.fail();

}

	}
	
	public void ValidateClaimDetails(String pageLocatorsPath,String pageFiledsPath,String line,String status, String fdos,String ldos, String charge, String allowed) throws Exception
	{
		try {
			waitSleep(2000);
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			String actualLine = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "line", true, "PegaGadget0Ifr", "", "Line");
			assertEquals(actualLine, line, "Line #");
			String actualStatucClaim = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget0Ifr", "", "ClaimStatus");
			assertEquals(actualStatucClaim, status, "Status");
			String actualFDOS = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "FDOS", true, "PegaGadget0Ifr", "", "FDOS");
			assertEquals(actualFDOS, fdos, "First DOS");
			String actualLDOS = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "LDOS", true, "PegaGadget0Ifr", "", "LDOS");
			assertEquals(actualLDOS, ldos, "Last DOS");
			String actualCharge = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Charge", true, "PegaGadget0Ifr", "", "Charge");
			assertEquals(actualCharge, charge, "Charge");
			String actualAllowed= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Allowed", true, "PegaGadget0Ifr", "", "Allowed");
			assertEquals(actualAllowed, allowed, "Allowed");
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on ValidateClaimDetails method " + e);
            test.log(LogStatus.FAIL, "Error on ValidateClaimDetails method " + e);
            Assert.fail();

}

	}
	
	public void ValidateProcedure_Diagnosis(String pageLocatorsPath,String pageFiledsPath,String proc_code, String Primary_Diag, String DiagClass) throws Exception
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Procedure_DiagnosisTab", true, "PegaGadget0Ifr", "", "Procedure_DiagnosisTab");
			waitSleep(3000);
			String actualProcedureCode= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ProcedureCode", true, "PegaGadget0Ifr", "", "ProcedureCode");
			assertEquals(actualProcedureCode, proc_code, "Procedure Code");
			String actualPrimaryDiagnosis= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "PrimaryDiagnosis", true, "PegaGadget0Ifr", "", "PrimaryDiagnosis");
			assertEquals(actualPrimaryDiagnosis, Primary_Diag, "Primary Diagnosis");
			String actualDiagnosisClass= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "DiagnosisClass", true, "PegaGadget0Ifr", "", "DiagnosisClass");
			assertEquals(actualDiagnosisClass, DiagClass, "Diagnosis Class");
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on ValidateProcedure_Diagnosis method " + e);
            test.log(LogStatus.FAIL, "Error on ValidateProcedure_Diagnosis method " + e);
            Assert.fail();

}

		
	}
	
	public void ValidateProcessingInfo(String pageLocatorsPath,String pageFiledsPath,String receiptdate, String Claimlocation, String docnum, String cdh, String vipcode) throws Exception
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ProcessingInfo", true, "PegaGadget0Ifr", "", "Processing Information");
			waitSleep(3000);
			
			String actualClaimReceiptDate= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ClaimReceiptDate", true, "PegaGadget0Ifr", "", "actualClaimReceiptDate");
			assertEquals(actualClaimReceiptDate, receiptdate, "Claim Receipt Date");
			String actualClaimLocation= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ClaimLocation", true, "PegaGadget0Ifr", "", "ClaimLocation");
			assertEquals(actualClaimLocation, Claimlocation, "Claim System Location");
			String actualDocumentNumber= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "DocumentNumber", true, "PegaGadget0Ifr", "", "CDHContract");
			assertEquals(actualDocumentNumber, docnum, "Document Number");
			String actualCDHContract= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "CDHContract", true, "PegaGadget0Ifr", "", "ProcedureCode");
			assertEquals(actualCDHContract, cdh, "CDH Contract");
			String actualVIPCode= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "VIPCode", true, "PegaGadget0Ifr", "", "VIPCode");
			assertEquals(actualVIPCode, vipcode, "VIP Code");
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on ValidateProcessingInfo method " + e);
            test.log(LogStatus.FAIL, "Error on ValidateProcessingInfo method " + e);
            Assert.fail();

        }

		
	}
	
	public void validateProviderDetails(String pageLocatorsPath,String pageFiledsPath,String address) throws Exception
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ProviderDetailsTab", true, "PegaGadget0Ifr", "", "Provider Details");
			waitSleep(3000);
			String actualAddress= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Address", true, "PegaGadget0Ifr", "", "Address");
			assertEquals(actualAddress, address, "Address Checkpoint");
			//assertElement(Address, "Address"+Address.getText());
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ServicingFacility", true, "PegaGadget0Ifr", "", "Servicing Facility");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ManagedCare", true, "PegaGadget0Ifr", "", "Managed care");
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on validateProviderDetails method " + e);
            test.log(LogStatus.FAIL, "Error on validateProviderDetails method " + e);
            Assert.fail();

}

	}
	
	public void validateClaimDollars(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ClaimDollars", true, "PegaGadget0Ifr", "", "Claim dollars");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "BCBSDollars", true, "PegaGadget0Ifr", "", "BCBS dollars");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "OIDollars", true, "PegaGadget0Ifr", "", "Other Insurance dollars");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "MedicareDollars", true, "PegaGadget0Ifr", "", "Medicare dollars");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CheckInfo", true, "PegaGadget0Ifr", "", "Check information");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AccountsReceivable", true, "PegaGadget0Ifr", "", "Accounts Receivable");
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on validateClaimDollars method " + e);
            test.log(LogStatus.FAIL, "Error on validateClaimDollars method " + e);
            Assert.fail();

        }

	}
	
	public void validateMedicareDollars(String pageLocatorsPath,String pageFiledsPath,String claimlinenumber,String totalCharge) throws Exception
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "MedicareDollarsTab", true, "PegaGadget0Ifr", "", "Medicare dollars");
			
			String actualClaimLineNumber= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ClaimLineNumber", true, "PegaGadget0Ifr", "", "ClaimLineNumber");
			assertEquals(actualClaimLineNumber, claimlinenumber, "Claim Line Number");		
			//assertElement(ClaimLineNumber, "Claim Line Number"+ClaimLineNumber.getText());
			String actualTotalCharge= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "TotalCharge", true, "PegaGadget0Ifr", "", "TotalCharge");
			assertEquals(actualTotalCharge, totalCharge, "Total Charge");
			//assertElement(TotalCharge, "Total charge"+TotalCharge.getText());
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on validateMedicareDollars method " + e);
            test.log(LogStatus.FAIL, "Error on validateMedicareDollars method " + e);
            Assert.fail();

        }

	}
	
	public void Resolve_Intent(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ReviewedButton", true, "PegaGadget0Ifr", "", "Reviewed button");
			
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "NextActionNo", true, "PegaGadget0Ifr", "", "Next action-No");
			
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit_Resolve", true, "PegaGadget0Ifr", "", "Submit");
			waitSleep(2000);
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on Resolve_Intent method " + e);
            test.log(LogStatus.FAIL, "Error on Resolve_Intent method " + e);
            Assert.fail();

        }

	}
	public void ValidateOtherActions(String pageLocatorsPath,String pageFiledsPath)
	{
		
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "OtherActions", true, "PegaGadget1Ifr", "", "Other Actions");
			//click(OtherActions, "Other Actions");
			waitSleep(2000);
			String AdjustClaim = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AdjustClaim", true, "PegaGadget1Ifr", "", "Adjust Claim");
			assertEquals("Adjust Claim",AdjustClaim, "Adjust claim");
			String ServiceException = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ServiceException", true, "PegaGadget1Ifr", "", "ServiceException");
			assertEquals("Service Exception",ServiceException, "Service exception");
			String RouteforClaimResearch = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "RouteforClaimResearch", true, "PegaGadget1Ifr", "", "RouteforClaimResearch");
			assertEquals("Route for Claim Research",RouteforClaimResearch, "Route for claim research");
			String CancelWork = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "CancelWork", true, "PegaGadget1Ifr", "", "CancelWork");
			assertEquals("Cancel work",CancelWork, "Cancel work");
			String PendingAdditionalWork = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "PendingAdditionalWork", true, "PegaGadget1Ifr", "", "PendingAdditionalWork");
			assertEquals("Pending Additional Work",PendingAdditionalWork, "Pending additional work");
			String CreateFollowup = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "CreateFollowup", true, "PegaGadget1Ifr", "", "CreateFollowup");
			assertEquals("Create follow up",CreateFollowup, "Create follow up");
			String ViewBenefits = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ViewBenefits", true, "PegaGadget1Ifr", "", "ViewBenefits");
			assertEquals("View benefits",ViewBenefits, "View Benefits");
		 } catch (Exception e){
	            e.printStackTrace();
	            BaseTest.log.error("Error on  ValidateOtherActions method " + e);
	            test.log(LogStatus.FAIL, "Error on  ValidateOtherActions method " + e);
	            Assert.fail();

	        }
	}

	public void followUp_ReScheduled(String pageLocatorsPath,String pageFiledsPath,String followUpAttempt, String commentsReschedule)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "followUpAttempt", true, "PegaGadget1Ifr", followUpAttempt, "Follow Up Attempt");
			String reScheduledDate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "reScheduleEndDate", true, "PegaGadget1Ifr", "", "ReScheduled Date");
			validateScheduledDate(reScheduledDate);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsReschedule", true, "PegaGadget1Ifr", commentsReschedule, "Re Scheduled Comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit_Resolve", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(3000);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on followUp_ReScheduled method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on followUp_ReScheduled method " + e);
			Assert.fail();

		}
	}
	
	public void validateScheduledDate(String scheduledDate){
		boolean isScheduledDateOnWeekend = false;
		waitSleep(3000);
		try { 
		if (scheduledDate!=null && !scheduledDate.isEmpty()){
			isScheduledDateOnWeekend = validateDateOnWeekend(scheduledDate);
			BaseTest.log.info("Scheduled Date Captured and Validated." );
			test.log(LogStatus.INFO, "Scheduled Date Captured and Validated.");
		}

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getScheduledDate method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getScheduledDate method " + e);
			Assert.fail();

		}
	}
	private boolean validateDateOnWeekend(String schDate){
		
		boolean matchValue=false;
		
		try{
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy h:mm a");
			Date scheduledDate = (Date)df.parse(schDate); 
			Calendar cl=Calendar.getInstance();
			cl.setTime(scheduledDate);
			if(cl.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY || cl.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY){
				matchValue=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return matchValue;
	}
		
	public void logout()
	{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//a[contains(text(),'New')]//following::a[2]")).click();
		waitSleep(500);
		driver.findElement(By.xpath("//span[contains(text(),'Logout')]")).click();
		waitSleep(500);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		waitSleep(2500);
		BaseTest.log.debug("Successfully Logged Out");
		test.log(LogStatus.INFO, "Successfully Logged Out");
	}
	
	public void validateAssignedTo(String pageLocatorsPath,String pageFiledsPath,String assignTo) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
		waitSleep(3000);
		switchToFrame("PegaGadget1Ifr");

		try{
			String actualAssignTo=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AssignedTo", true, "PegaGadget1Ifr", assignTo, "Assigned To");
			assertEquals(assignTo, actualAssignTo, "Assigned To");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
	public String worklistvalidateStatus(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) throws Exception
	{
		String text="";
		pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
		waitSleep(2500);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2500);
		text=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", "", "Status Intent ID");
		waitSleep(2500);
		System.out.println("Status:"+text);
		assertEquals(data.get("Expected_Status"), text, "Expected_Status");
		
		return text;
		
	}
	
	public void closeIntenet(String pageLocatorsPath,String pageFiledsPath,String intentid) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
		waitSleep(3000);
		//switchToFrame("PegaGadget1Ifr");
		switchToDefault();
		try{
			WebElement ele = driver.findElement(By.xpath("//a[contains(text(),'"+intentid+"')]//following::div[1]//span//a"));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", ele);
			waitSleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
	
	public void ValidateHistorytable(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			waitSleep(4000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
			String winHandleBefore = driver.getWindowHandle();
			System.out.println("winHandleBefore:"+winHandleBefore);
			for(String winHandle : driver.getWindowHandles()){
				System.out.println("winHandle:"+winHandle);
				driver.switchTo().window(winHandle);
			}
			driver.switchTo().defaultContent();
			waitSleep(2500);
			String histroyText=driver.findElement(By.xpath("//tr[contains(@id,'$PD_pyWorkHistory_pa') and contains(@id,'pz$ppxResults$l2')]/td[2]")).getText();
			assertEquals(data.get("Expected_History"),histroyText,"Audit Log");
			driver.close();
			driver.switchTo().window(winHandleBefore);
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
		} catch (Exception e) {
	        e.printStackTrace();
	        BaseTest.log.error("Error on ValidateHistorytable method " + e);
	        test.log(LogStatus.FAIL, "Error on ValidateHistorytable method " + e);
	        Assert.fail();


		}
	}
	
	public void CreateNewTask(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
		waitSleep(5000);
		//switchToFrame("PegaGadget1Ifr");
		try {
			
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createnewwork", true, "PegaGadget1Ifr", "", "create new work");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createRTC", true, "PegaGadget1Ifr", "", "RTC");
			switchToFrame("PegaGadget2Ifr");
			waitSleep(3000);
			
			System.out.println("frame");
			String Status_str = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "RTCStatus", true, "PegaGadget2Ifr", "", "Status");
			String Contact_str = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Contact", true, "PegaGadget2Ifr", "", "Contact");
			String Channel_str = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Channel", true, "PegaGadget2Ifr", "", "Channel");
			String Createoperator_str = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Createoperator", true, "PegaGadget2Ifr", "", "Channel");
			String Assignedto_str = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AssignedTo", true, "PegaGadget2Ifr", "", "Assigned to");
			//String CreateNewIntent_str = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "CreateNewIntent", true, "PegaGadget2Ifr", "", "CreateNewIntent");
			String Actual_str = Status_str + "|"+ Contact_str + "|"+ Channel_str + "|"+ Createoperator_str + "|"+ Assignedto_str;
			assertEquals(data.get("Expected_StatusInfo"),Actual_str,"Intent Status Info");
			waitSleep(2500);
			//WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsFollowUp", true, "PegaGadget2Ifr","Create Follow Up", "Create Follow Up comments");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget2Ifr", "", "Submit");

			
		} catch (Exception e) {
	        e.printStackTrace();
	        BaseTest.log.error("Error on CreateNewTask method " + e);
	        test.log(LogStatus.FAIL, "Error on CreateNewTask method " + e);
	        Assert.fail();


		}
	}
	
	public void compareInteractionIDs(String pageLocatorsPath,String pageFiledsPath) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
		waitSleep(5000);
		//switchToFrame("PegaGadget1Ifr");
		try {
			
			switchToFrame("PegaGadget1Ifr");
			waitSleep(4000);
			String Interaction_old=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interaction", true, "PegaGadget1Ifr", "", "Old InteractionID");
			System.out.println("Interaction_old" + Interaction_old);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createnewwork", true, "PegaGadget1Ifr", "", "create new work");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createRTC", true, "PegaGadget1Ifr", "", "RTC");
			switchToFrame("PegaGadget2Ifr");
			waitSleep(3000);
			String Interaction_new=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interaction", true, "PegaGadget2Ifr", "", "New InteractionID");
			System.out.println("Interaction_new" + Interaction_new);
			
			waitSleep(2500);
			if(Interaction_new.equals(Interaction_old))
			{
				System.out.println("Interaction number in both the intents is same");
				
			}

			
		} catch (Exception e) {
	        e.printStackTrace();
	        BaseTest.log.error("Error on compareInteractionIDs method " + e);
	        test.log(LogStatus.FAIL, "Error on compareInteractionIDs method " + e);
	        Assert.fail();


		}
	}
	public void createnewwork(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorkbasketPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorkbasketPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createnewwork", true, "PegaGadget1Ifr", "createnewwork", "createnewwork");
			waitSleep(2000);
				}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on resolveMOC method " + e);
			test.log(LogStatus.FAIL, "Error on resolveMOC method " + e);
			Assert.fail();
			}
		
		}
	public void History(String pageLocatorsPath,String pageFiledsPath,String Ex_AuditLog,Hashtable<String,String> data) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(3500);
		switchToFrame("PegaGadget1Ifr");
		String AuditLog="";
		try {
				String parentWindow=driver.getWindowHandle();
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
		waitSleep(2000);
		for (String windowHandle : driver.getWindowHandles())
		{
			if(!parentWindow.equals(windowHandle)){
				 driver.switchTo().window(windowHandle);
				 System.out.println("Switched to"+windowHandle);
			}
			System.out.println(windowHandle);
			
		}
		
		switchToDefault();
		waitOnIE(3000);
		waitSleep(3000);
	    AuditLog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AuditLog", true, "PegaGadget1Ifr", "", "Audit Log");
		System.out.println(AuditLog);
		assertEquals( Ex_AuditLog ,AuditLog, "Audit Log");

		driver.close();
		driver.switchTo().window(parentWindow);
		waitSleep(2000);
		
		
		
	
		
		
		} catch (Exception e) {
            e.printStackTrace();
            BaseTest.log.error("Error on createMANAGECLAIM method " + e);
            test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
            Assert.fail();

		}

	}
	public String history(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String Intent) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
		waitSleep(3500);
		switchToFrame("PegaGadget1Ifr");
		String AuditLog="";
		try {

		String parentWindow=driver.getWindowHandle();
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
		waitSleep(2000);
		for (String windowHandle : driver.getWindowHandles())
		{
			if(!parentWindow.equals(windowHandle)){
				 driver.switchTo().window(windowHandle);
				 System.out.println("Switched to"+windowHandle);
			}
			System.out.println(windowHandle);
			
		}
		
		switchToDefault();
		AuditLog="Created from Service Intent "+Intent;
		System.out.println("NLID:"+AuditLog);
		test.log(LogStatus.INFO, "Intent ID:"+AuditLog);

		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$ppxResults$l')]"));
		ele.size();
		String s="//tr[contains(@id,'$ppxResults$l%d')]";
		for(int i=0;i<ele.size();i++)
		{
			String s1=String.format(s, i+1);
			System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
			System.out.println("NLID:"+AuditLog);
			if(driver.findElement(By.xpath(s1+"//td[2]")).getText().equals(AuditLog))
			{
		
				System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
				test.log(LogStatus.PASS, "INTRACTIONID IS MATCHED IN HISTORY "+AuditLog);
				System.out.println("INTRACTIONID IS  MATCHED IN HISTORY "+AuditLog);

				break;
			}
		} 
		
		
		driver.close();
		driver.switchTo().window(parentWindow);
		
		
		
		} catch (Exception e) {
	        e.printStackTrace();
	        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
	        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
	        Assert.fail();


			
		}
		return AuditLog;
	}
	
	public void sortandgetStatus(String pageLocatorsPath,String pageFiledsPath, String intentId,String expectedStatus) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\WorklistPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\WorklistPageFields.properties";
			switchToFrame("PegaGadget0Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "idSort", true, "PegaGadget0Ifr", "", "ID Sort");
			waitSleep(8000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchID", true, "PegaGadget0Ifr", intentId, "Search intent");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "applyBtn", true, "PegaGadget0Ifr", "", "Apply");
			waitSleep(4000);
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "intentStauts", true, "PegaGadget0Ifr", intentId, "Intent Status");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "intentclick", true, "PegaGadget0Ifr", intentId, "Intent "+intentId);
			assertEquals(expectedStatus, actualStatus, "Status");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
		
	}
	
	public void createNewWork(String pageLocatorsPath,String pageFiledsPath, String newWork)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
			waitSleep(4500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("Click",pageLocatorsPath, pageFiledsPath, "newWork", true, "PegaGadget1Ifr", "", "Create new work");
			waitSleep(1500);
			WebElementAction("Click",pageLocatorsPath, pageFiledsPath, "createWork", true, "PegaGadget1Ifr", newWork, newWork);
			//WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "createWork", true, "PegaGadget1Ifr", newWork, newWork);
			waitSleep(3500);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createNewWork method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createNewWork method " + e);
			Assert.fail();

		}
	}
	
	public void validateNewWork(String pageLocatorsPath,String pageFiledsPath, String intentID)
	{
		try {
				pageLocatorsPath= pageLocatorsPath+"\\FollowUpPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\FollowUpPageFields.properties";
				waitSleep(3000);
				switchToFrame("PegaGadget2Ifr");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "followUpScheduled", true, "PegaGadget2Ifr", "", "Follow Up Scheduled");
				List<WebElement> elements = driver.findElements(By.xpath("//*[contains(@id,'$PpyWorkPage$pSelectRelatedIntent$l')]"));
				int row=1;
				for(int i=1;i<=elements.size();i++)
				{
					if(driver.findElement(By.xpath("//*[contains(@id,'$PpyWorkPage$pSelectRelatedIntent$l"+i+"')]/td[3]")).getText().equals(intentID))
					{
						row=i;
						break;
					}
				}
				System.out.println("Row: "+row);
				if(driver.findElement(By.xpath("//*[@id='pySelected"+row+"']")).isSelected())
				{
					test.log(LogStatus.PASS, "Releated intent selected");
					
				}else{
					test.log(LogStatus.FAIL, "Releated intent not selected");
					Assert.fail();
				}
		} 
		catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createNewWork method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createNewWork method " + e);
			Assert.fail();

		}
	}
}