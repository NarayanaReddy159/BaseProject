package com.nasco.MA.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings("rawtypes")
public class LoginPage extends BasePage {
	
	@FindBy(id = "sub")
	public WebElement btnLogin;

//	public Logger log = DriverManager.getlog();
	@SuppressWarnings("unchecked")
	public LoginPage open(String url) {
		
		System.out.println("Page Opened"+url);
		BaseTest.log.info("Driver Initialized !!!");
		DriverManager.getDriver().navigate().to(url);
		BaseTest.log.info("Navigated to URL:"+url);
		test.log(LogStatus.INFO, "Navigated to URL:"+url);
		return (LoginPage) openPage(LoginPage.class);
	}

	@SuppressWarnings("unchecked")
	public HomePage doLoginAsValidUser(String pageLocatorsPath,String pageFiledsPath,
			String username, String password)  {

		try{
			pageLocatorsPath= pageLocatorsPath+"\\LoginPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\LoginPageFields.properties";
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "unTxt", false, "", username, "User Name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "pwdTxt", false, "", password, "Password");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "subBtn", false, "", "", "Login button");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_PSA method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_PSA method " + e);
			Assert.fail();
		}
		
		return (HomePage) openPage(HomePage.class);
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return ExpectedConditions.visibilityOf(btnLogin);
	}


	

}
