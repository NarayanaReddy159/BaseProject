package com.nasco.MA.Regression.Pages;

import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class UpdateMemberPage extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget2Ifr";
	String startDt="",endDt="";
	
	//@Override
	protected ExpectedCondition getPageLoadCondition() {
		//switchToFrame(frame1);
		switchToFrame(frame1);
		//return ExpectedConditions.visibilityOf(intentID);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
		
		
	}
		
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			waitSleep(25000);
			switchToFrame(frame1);
			waitSleep(4000);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, frame1, "Update member", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	
	public void UpdateMember_Details(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget2Ifr");
			String firstName = WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "firstName", true, frame1, "", "firstName");
			String middleName = WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "middleName", true, frame1, "", "middleName");
			String lastName = WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "lastName", true, frame1, "", "lastName");
			String PhoneNumber = WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "PhoneNumber", true, frame1, "", "PhoneNumber");
			String addressLine1 = WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "addressLine1", true, frame1, "", "addressLine1");
			String city = WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "city", true, frame1, "", "city");
			String zipcode = WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "zipcode", true, frame1, "", "zipcode");
			String memberstr = firstName + "|" + middleName + "|" + lastName + "|" + PhoneNumber + "|" + addressLine1 + "|" + city + "|" + zipcode;
			assertEquals(data.get("ExpectedResults"),memberstr,"UpdateMember Results");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on UpdateMember_Details method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on UpdateMember_Details method " + e);
			Assert.fail();
		}
	
	}
	
	public void updateMember_phoneNum(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			WebElementAction("clear",pageLocatorsPath, pageFiledsPath, "PhoneNumber", true, frame1, "", "PhoneNumber clear");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PhoneNumber", true, frame1,data.get("PhoneNumber"), "PhoneNumber");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments", true, frame1,"Test", "Comments");
			waitSleep(2500);
			
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, frame1,"Submit", "Submit_Button");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, frame1,"Submit", "Submit_Button");
			waitSleep(4000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on updateMember_phoneNum method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on updateMember_phoneNum method " + e);
			Assert.fail();
		}
	}
	
	public void verifyMember(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Selectedmemberchkbox", true, "PegaGadget1Ifr","Selected member not on Member Rights list", "Submit_Button");
			waitSleep(2500);
			//Submit_Button.click();
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget1Ifr","Submit", "Submit_Button");
			waitSleep(4000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on verifyMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on verifyMember method " + e);
			Assert.fail();
		}
	}
	
	public void updateMember_ReviewHarness(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "updateMemberbtn", true, "PegaGadget1Ifr","Update Member", "Update MemberButton");
			waitSleep(2500);
			String parentWindow=driver.getWindowHandle();
			//System.out.println(parentWindow);
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
			
			waitSleep(2500);
			for (String windowHandle : driver.getWindowHandles())
			{
				if(!parentWindow.equals(windowHandle)){
					 driver.switchTo().window(windowHandle);
					 //System.out.println("Switched to"+windowHandle);
					 String actual_str1 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Status_ReviewHarness",true, frame1, "", "Status_ReviewHarness");
					 String actual_str2 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"MemberID_ReviewHarness",true, frame1, "", "MemberID_ReviewHarness");
					 String actual_str3 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"AssignedTo_ReviewHarness",true, frame1, "", "AssignedTo_ReviewHarness");
					 String actual_str4 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Channel_ReviewHarness",true, frame1, "", "Channel_ReviewHarness");
					 
					 String  actual_str_con = actual_str1 + "|" + actual_str2 + "|" + actual_str3 + "|" + actual_str4;
					 //System.out.println("Actuial Result:::::::"+ actual_str_con);
					 assertEquals(data.get("ReviewHarnessExpectedResults"),actual_str_con,"Valdiate Expected Results");
					 waitSleep(2500);
					 WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closebtn", true, "PegaGadget1Ifr","Close", "Close Button");
					 waitSleep(4000);
					 
				}
				//System.out.println(windowHandle);
				
			}
			waitSleep(2500);
			
			//driver.close();
			waitSleep(2500);
			driver.switchTo().window(parentWindow);
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget1Ifr","Submit", "Submit_Button");
			waitSleep(4000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on verifyMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on verifyMember method " + e);
			Assert.fail();
		}
	}
	
	
	public void updateState_HI(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "StateDropdown",true,frame1,"","Click State Dropdown");
			waitSleep(2500);
			WebElementAction("SelectbyText",pageLocatorsPath, pageFiledsPath, "StateDropdown",true,frame1,"HI","Click State Dropdown");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments", true, frame1,"Test", "Comments");
			waitSleep(2500);
			
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, frame1,"Submit", "Submit_Button");
			waitSleep(2500);
			
			WebElement StateError = driver.findElement(By.xpath("//div[contains(@id,'StateError')]"));
			
			String Actual_str = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "StateError",true,frame1,"","StateError");
			
			if(StateError.isDisplayed())
			{
				Actual_str="True";
			}
			
			else
			{
				Actual_str="False";
			}
			
			assertEquals(data.get("ExpectedStateError"),Actual_str,"Validate State Error");
			
			waitSleep(4000);
			WebElementAction("SelectbyText",pageLocatorsPath, pageFiledsPath, "StateDropdown",true,frame1,"MA","Click State Dropdown");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, frame1,"Submit", "Submit_Button");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, frame1,"Submit", "Submit_Button");
			waitSleep(4000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on updateState_HI method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on updateState_HI method " + e);
			Assert.fail();
		}
	}
	
	public void updateMember_CancelReviewHarness(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "updateMemberbtn", true, "PegaGadget1Ifr","Update Member", "Update MemberButton");
			waitSleep(2500);
			String parentWindow=driver.getWindowHandle();
			//System.out.println(parentWindow);
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
			waitOnIE(2500);
			waitSleep(2500);
			for (String windowHandle : driver.getWindowHandles())
			{
				if(!parentWindow.equals(windowHandle)){
					 driver.switchTo().window(windowHandle);
					 //System.out.println("Switched to"+windowHandle);
					 String actual_str1 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Status_ReviewHarness",true, frame1, "", "Status_ReviewHarness");
					 String actual_str2 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"MemberID_ReviewHarness",true, frame1, "", "MemberID_ReviewHarness");
					 String actual_str3 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"CreateOperator_ReviewHarness",true, frame1, "", "ResolveOperator_ReviewHarness");
					 String actual_str4 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"ResolveOperator_ReviewHarness",true, frame1, "", "ResolveOperator_ReviewHarness");
					 String actual_str5 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Channel_ReviewHarness",true, frame1, "", "Channel_ReviewHarness");
					 
					 String  actual_str_con = actual_str1 + "|" + actual_str2 + "|" + actual_str3 + "|" + actual_str4 + "|" + actual_str5;
					 assertEquals(actual_str_con,data.get("ReviewHarnessExpectedResults"),"Valdiate Expected Results");
					 waitSleep(2500);
					 WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closebtn", true, "PegaGadget1Ifr","Close", "Close Button");
					 waitSleep(4000);
					 
				}
				//System.out.println(windowHandle);
				
			}
			waitSleep(4000);
			
			//driver.close();
			waitSleep(2500);
			driver.switchTo().window(parentWindow);
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget1Ifr","Submit", "Submit_Button");
			waitSleep(4000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on updateMember_CancelReviewHarness method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on updateMember_CancelReviewHarness method " + e);
			Assert.fail();
		}
	}
	
	
	public void updateMember_WorklistReview(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
//			String parentWindow=driver.getWindowHandle();
//			//System.out.println(parentWindow);
//			driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
//			
//			waitSleep(2500);
//			for (String windowHandle : driver.getWindowHandles())
//			{
//				if(!parentWindow.equals(windowHandle)){
//					 driver.switchTo().window(windowHandle);
//					 //System.out.println("Switched to"+windowHandle);
					 String actual_str1 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Status_ReviewHarness",true, frame1, "", "Status_ReviewHarness");
					 String actual_str2 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"CreateOperator_ReviewHarness",true, frame1, "", "CreateOperator_ReviewHarness");
					 
					 				 
					 String  actual_str_con = actual_str1 + "|" + actual_str2;
					 //System.out.println("Expected Resulsts:::::: "+ actual_str_con);
					 assertEquals(actual_str_con,data.get("ReviewHarnessExpectedResults"),"Valdiate Expected Results");
					 waitSleep(2500);
					// WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closebtn", true, "PegaGadget1Ifr","Close", "Close Button");
					 //waitSleep(4000);
					 
//				}
//				//System.out.println(windowHandle);
//				
//			}
//			waitSleep(4000);
//			
//			driver.close();
			waitSleep(4000);
			//driver.switchTo().window(parentWindow);
			
			waitSleep(4000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on updateMember_WorklistReview method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on updateMember_WorklistReview method " + e);
			Assert.fail();
		}
	}
	
	public void noUpdates(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			switchToFrame(frame1);
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments", true, frame1,"Test", "Comments");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, frame1,"Submit", "Submit_Button");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, frame1,"Submit", "Submit_Button");
			waitSleep(2500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on noUpdates method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on noUpdates method " + e);
			Assert.fail();
		}
	}
	
	@SuppressWarnings("unused")
	public void updateMember_PendingAdditionalInfo(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			String actual_str1 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Status_ReviewHarness",true, "PegaGadget1Ifr", "", "Status_ReviewHarness");
			waitSleep(2500);
			WebElementAction("SelectbyText",pageLocatorsPath, pageFiledsPath, "ResponseDropdown",true,"PegaGadget1Ifr","Route to originating operator","Route to originating operator");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ResolveWorkbasketComments", true, "PegaGadget1Ifr","Test", "Comments");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "revSubmitButton", true, "PegaGadget1Ifr","Submit", "Submit_Button");
			waitSleep(2500);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on updateMember_PendingAdditionalInfo method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on updateMember_PendingAdditionalInfo method " + e);
			Assert.fail();
		}
	}
	
	@SuppressWarnings("unused")
	public void updateMember_PendingAdditionalWork(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			String actual_str1 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Status_ReviewHarness",true, "PegaGadget1Ifr", "", "Status_ReviewHarness");
			waitSleep(2500);
			WebElementAction("SelectbyText",pageLocatorsPath, pageFiledsPath, "ResponseDropdown",true,"PegaGadget1Ifr","Pend for additional information","Pend for additional information");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ResolveWorkbasketComments", true, "PegaGadget1Ifr","Test", "Comments");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "revSubmitButton", true, "PegaGadget1Ifr","Submit", "Submit_Button");
			waitSleep(2500);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on updateMember_PendingAdditionalInfo method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on updateMember_PendingAdditionalInfo method " + e);
			Assert.fail();
		}
	}
	
	
	public void updateMember_ResolveWorkbasket(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data){
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			String actual_str1 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Status_ReviewHarness",true, "PegaGadget1Ifr", "", "Status_ReviewHarness");
			String actual_str2 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"MemberID_ReviewHarness",true, "PegaGadget1Ifr", "", "MemberID_ReviewHarness");
			String actual_str3 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"AssignedTo_ReviewHarness",true, "PegaGadget1Ifr", "", "AssignedTo_ReviewHarness");
			String actual_str4 = WebElementAction("readText",pageLocatorsPath, pageFiledsPath,"Channel_ReviewHarness",true, "PegaGadget1Ifr", "", "Channel_ReviewHarness");

			String  actual_str_con = actual_str1 + "|" + actual_str2 + "|" + actual_str3 + "|" + actual_str4;
			assertEquals(data.get("ReviewHarnessExpectedResults"),actual_str_con,"Valdiate Expected Results");
			waitSleep(2500);
			waitSleep(2500);
			WebElementAction("SelectbyText",pageLocatorsPath, pageFiledsPath, "ResponseDropdown",true,"PegaGadget1Ifr","Resolve","Resolve");
			waitSleep(4000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ResolveWorkbasketComments", true, "PegaGadget1Ifr","Test", "ResolveWorkbasketComments");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WorkbasketSubmitbtn", true, "PegaGadget1Ifr","Submit", "Submit_Button");
			waitSleep(2500);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on updateMember_ResolveWorkbasket method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on updateMember_ResolveWorkbasket method " + e);
			Assert.fail();
		}
	}
	
	public void updateMember_ReviewHarnessHistory(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\UpdateMemberWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\UpdateMemberPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "updateMemberbtn", true, "PegaGadget1Ifr","Update Member", "Update MemberButton");
			waitSleep(2500);
			String Phone=data.get("PhoneNumber");
			 Phone=Phone.substring(Phone.length()-4,Phone.length());
			String parentWindow=driver.getWindowHandle();
			//System.out.println(parentWindow);
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
			String AuditLog="";
			waitSleep(2500);
					 for (String windowHandle : driver.getWindowHandles())
						{
							if(!parentWindow.equals(windowHandle)){
								 String childWIndowHandle=windowHandle;
								 driver.switchTo().window(childWIndowHandle);
								 
								 //System.out.println("Switched to"+childWIndowHandle);
								 WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History Audit Log");
								 waitSleep(2500);
								 for(String windowHandle1 : driver.getWindowHandles())
									{
										if(!windowHandle1.equals(parentWindow) && !windowHandle1.equals(childWIndowHandle))
										{
											String childWIndowHandle1=windowHandle1; 
											driver.switchTo().window(childWIndowHandle1).manage().window().maximize();
											 //System.out.println("Switched to"+childWIndowHandle1);
											 waitSleep(4500);
											 
											 String xpath="//div[contains(text(),'"+Phone+"')]";
											 
											 driver.switchTo().defaultContent();
											 WebElement auditHistory=driver.findElement(By.xpath(xpath));
											// WebElement element = driver.findElement(By.xpath("gbqfd"));
											 JavascriptExecutor executor = (JavascriptExecutor)driver;
											 executor.executeScript("arguments[0].click();", auditHistory);
											// auditHistory.click();
											 waitSleep(3500);
											 
											 if(auditHistory.isDisplayed())
											 {
												 AuditLog="True";
											 }
											 else
											 {
												 AuditLog="False";
											 }
											 
											 driver.close();
											 driver.switchTo().window(childWIndowHandle);
											 
										}
											 
											 
									}
								 
								 

							}
						}
					assertEquals(data.get("Expected_AuditLog") ,AuditLog, "Audit Log");
					 waitSleep(2500);
					 WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closebtn", true, "PegaGadget1Ifr","Close", "Close Button");
					 waitSleep(4000);
					 
				
				////System.out.println(windowHandle);
		
			
			//driver.close();
			waitSleep(2500);
			driver.switchTo().window(parentWindow);
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget1Ifr","Submit", "Submit_Button");
			waitSleep(4000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on updateMember_ReviewHarnessHistory method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on updateMember_ReviewHarnessHistory method " + e);
			Assert.fail();
		}
	}
	
	


}

