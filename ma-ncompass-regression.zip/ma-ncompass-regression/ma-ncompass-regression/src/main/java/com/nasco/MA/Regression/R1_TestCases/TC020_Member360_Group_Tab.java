package com.nasco.MA.Regression.R1_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Regression.Pages.HomePage;
import com.nasco.MA.Regression.Pages.InteractionManagerPage;
import com.nasco.MA.Regression.Pages.LoginPage;
import com.nasco.MA.Regression.Pages.Member360Page;
import com.nasco.MA.Regression.Pages.MemberSearchPage;
import com.nasco.MA.Regression.Pages.VerifyContactPage;
import com.nasco.MA.Regression.Run.RunTestNG_NCompass_MA;
import com.nasco.MA.Regression.Base.BaseTest;
import com.nasco.MA.Regression.utilities.DataProviders;
import com.nasco.MA.Regression.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC020_Member360_Group_Tab extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R1DP")
    public void AUTC020_Member360_Group_Tab(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC020_Member360_Group_Tab");
		String pageLocatorsPath=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC020_Member360_Group_Tab - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC020_Member360_Group_Tab -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		InteractionManagerPage interactionMgr=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath, pageFiledsPath, data.get("Fname"));
		VerifyContactPage verifyContact = interactionMgr.movetoVerifyContact(pageLocatorsPath, pageFiledsPath);
		verifyContact.verifyMember(pageLocatorsPath, pageFiledsPath);
		Member360Page member360= new Member360Page();
		member360.getGroupDetails(pageLocatorsPath, pageFiledsPath, data);
		//interactionMgr.wrapupverifiedIntent("Wrapping Intenraction", "Eligibility", pageLocatorsPath, pageFiledsPath);
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC020_Member360_Group_Tab Completed");
		log.debug("AUTC020_Member360_Group_Tab Completed");
		quit();
		
	}
}
