package com.nasco.MA.Pages;


import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


@SuppressWarnings({"rawtypes","unchecked"})
public class MemberSearchPage extends BasePage {

	

	@FindBy(id = "PegaGadget1Ifr")
	public WebElement frame;
	public void searchMember(String pageLocatorsPath,String pageFiledsPath,String memberID) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "MemberID", true, "PegaGadget1Ifr", memberID, "Member ID");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Search", true, "PegaGadget1Ifr", "", "Search Button");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on searchMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on searchMember method " + e);
			Assert.fail();
		}
		
	}
	
	public void searchMember(String pageLocatorsPath,String pageFiledsPath,
					Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "searchBy", true, "PegaGadget1Ifr", data.get("SearchBy"), "search By");
			waitSleep(1000);
			if(null != data.get("MemberID") && !data.get("MemberID").isEmpty())
			{
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "MemberID", true, "PegaGadget1Ifr", data.get("MemberID"), "Member ID");
			}
			else if(null != data.get("SSN") && !data.get("SSN").isEmpty())
			{
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ssn", true, "PegaGadget1Ifr", data.get("SSN"), "SSN");
			}
			else if(null != data.get("ConfirmID") && !data.get("ConfirmID").isEmpty())
			{
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "confirmID", true, "PegaGadget1Ifr", data.get("ConfirmID"), "Confirmation ID");
			}
			else if(null != data.get("ClaimNumber") && !data.get("ClaimNumber").isEmpty())
			{
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "claimNumber", true, "PegaGadget1Ifr", data.get("ClaimNumber"), "Claim number ID");
			}
			else if(null != data.get("MedicareID") && !data.get("MedicareID").isEmpty())
			{
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "MedicareID", true, "PegaGadget1Ifr", data.get("MedicareID"), "Medicare ID");
			}
			else if(null != data.get("Fname") && !data.get("Fname").isEmpty()&&null != data.get("Lname") && !data.get("Lname").isEmpty())
			{
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fname", true, "PegaGadget1Ifr", data.get("Fname"), "First Name");
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "lname", true, "PegaGadget1Ifr", data.get("Lname"), "Lat Name");
				if(null != data.get("DOB") && !data.get("DOB").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "dob", true, "PegaGadget1Ifr", data.get("DOB"), "dob");	
				}
				if(null != data.get("StreetAddress") && !data.get("StreetAddress").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "streetAddress", true, "PegaGadget1Ifr", data.get("StreetAddress"), "Street Address");
				}
				if(null != data.get("city") && !data.get("city").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, "PegaGadget1Ifr", data.get("city"), "Street Address");
				}
			}
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Search", true, "PegaGadget1Ifr", "", "Search Button");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Search", true, "PegaGadget1Ifr", "Search", "Search Button");
			if(null != data.get("Fname") && !data.get("Fname").isEmpty()&&null != data.get("Lname") && !data.get("Lname").isEmpty())
			{
				if(null != data.get("StreetAddress") && !data.get("StreetAddress").isEmpty())
				{
					waitSleep(60000);
				}
				if(null != data.get("city") && !data.get("city").isEmpty())
				{
					waitSleep(60000);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on searchMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on searchMember method " + e);
			Assert.fail();
		}
		
	}
	
	public void readMemberDetails(String pageLocatorsPath,String pageFiledsPath, String expectedResult)
	{
		String memberDetails="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(9000);
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
			String s="//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				String memdet="";
				List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
				for(int j=0;j<colums.size();j++)
				{
					if(j==0)
					{
						memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
					else{
						memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
				}
				memberDetails=memberDetails+","+memdet;	
			}
			waitSleep(1000);
			memberDetails=memberDetails.substring(1,memberDetails.length());
			System.out.println(memberDetails);
			assertEquals(expectedResult, memberDetails, "Member Search Results");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on readMemberDetails method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on readMemberDetails method " + e);
			Assert.fail();
		}
	}
	
	public InteractionManagerPage selectMemberAndNavigatebyfname(String pageLocatorsPath,String pageFiledsPath,
			String memberSearchFname) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(5000);			
			waitOnIE(4000);
			waitForElementsToVisible("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]");
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
			ele.size();
			String s="//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member id:"+driver.findElement(By.xpath(s1+"//td[4]")).getText());
				if(driver.findElement(By.xpath(s1+"//td[4]")).getText().equals(memberSearchFname))
				{
					System.out.println("Entered if ");
					ClickWebelement("xpath", "//span[contains(text(),'%s')]", memberSearchFname);
					break;
				}
			}
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "Submit", "Submit Button");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on selectMemberAndNavigatebyfname method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on selectMemberAndNavigatebyfname method " + e);
			Assert.fail();
		}
		return (InteractionManagerPage) openPage(InteractionManagerPage.class);
	}
	
	public InteractionManagerResearchPage selectMemberAndNavigatebyfname1(String pageLocatorsPath,String pageFiledsPath,
			String memberSearchFname) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			//waitSleep(20000);
			waitForElementsToVisible("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]");
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
			System.out.println(ele.size());
			String s="//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member id:"+driver.findElement(By.xpath(s1+"//td[4]")).getText());
				
				if(driver.findElement(By.xpath(s1+"//td[4]")).getText().equals(memberSearchFname))
				{
					System.out.println("Entered if ");
					//ClickWebelement("xpath", s1, memberSearchFname); 
					ClickWebelement("xpath", "//span[contains(text(),'%s')]", memberSearchFname);
					break;
				}
			}
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "Submit", "Submit Button");
			waitSleep(2500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on selectMemberAndNavigatebyfname1 method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on selectMemberAndNavigatebyfname1 method " + e);
			Assert.fail();
		}
		return (InteractionManagerResearchPage) openPage(InteractionManagerResearchPage.class);
	}
	
	public void selectMemberAndNavigatebyfname2(String pageLocatorsPath,String pageFiledsPath,
			String memberSearchFname) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			//waitSleep(3000);
			waitForElementsToVisible("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]");
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
			System.out.println(ele.size());
			String s="//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member id:"+driver.findElement(By.xpath(s1+"//td[4]")).getText());
				
				if(driver.findElement(By.xpath(s1+"//td[4]")).getText().equals(memberSearchFname))
				{
					System.out.println("Entered if ");
					//ClickWebelement("xpath", s1, memberSearchFname);
					ClickWebelement("xpath", "//span[contains(text(),'%s')]", memberSearchFname);
					break;
				}
			}
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "Submit", "Submit Button");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on selectMemberAndNavigatebyfname2 method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on selectMemberAndNavigatebyfname2 method " + e);
			Assert.fail();
		}
		
	}

	public InteractionManagerPage sortandSelectIntent(String pageLocatorsPath,String pageFiledsPath, String intentId) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "idSort", true, "PegaGadget1Ifr", "", "ID Sort");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchID", true, "PegaGadget1Ifr", intentId, "Search intent");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "applyBtn", true, "PegaGadget1Ifr", "", "Apply");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "linkbtn", true, "PegaGadget1Ifr", "", "Link");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Followup", true, "PegaGadget1Ifr", "Follow-up", "Followup");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(2500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on sortandSelectIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
		return (InteractionManagerPage) openPage(InteractionManagerPage.class);
	}
	
	public InteractionManagerPage submitNL(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			waitSleep(2500);
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitNL", true, "PegaGadget1Ifr", "", "Submit");
			WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "submitNL", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(2500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on submitNL method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on submitNL method " + e);
			Assert.fail();
		}
		return (InteractionManagerPage) openPage(InteractionManagerPage.class);
	}
	
	
	
	public String getLIInteractionID(String pageLocatorsPath,String pageFiledsPath) 
	{
		String interactionID="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToDefault();
			interactionID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "LVI-ID", false, "", "Interaction ID", "Interaction ID");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getLIInteractionID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getLIInteractionID method " + e);
			Assert.fail();
		}
		return interactionID;
	}

	public void movetoProsMem(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActions", true, "PegaGadget1Ifr", "", "other Actions");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "prosmem", true, "PegaGadget1Ifr", "Prospective Member", "Prospective Member");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on movetoProsMem method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on movetoProsMem method " + e);
			Assert.fail();
		}
		
	}
	
	public void AddProsMem(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "prsFname", true, "PegaGadget1Ifr", data.get("prsMFirstName"), "First name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "prsLname", true, "PegaGadget1Ifr", data.get("prsMLastName"), "Last name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "prsDob", true, "PegaGadget1Ifr", data.get("DOB"), "DOB");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "prsMemtype", true, "PegaGadget1Ifr", data.get("prsMMbrType"), "Membership type");
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "prscallReason", true, "PegaGadget1Ifr", data.get("prsMRsnForCall"), "Call Reason");
			System.out.println("Call Reason: "+data.get("prsMRsnForCall"));
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "prsEdtype", true, "PegaGadget1Ifr", data.get("prsEducationType"), "Education type");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "prsSearch", true, "PegaGadget1Ifr", "", "Search");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "prsmemSel", true, "PegaGadget1Ifr",data.get("prsMFirstName"), "Select Member");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "prsSubmit", true, "PegaGadget1Ifr", "", "Submit");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on AddProsMem method " + e);
			test.log(LogStatus.FAIL, "Error on AddProsMem method " + e);
			Assert.fail();
		}
		
	}
	
	public void searchProsMem(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "prsFname", true, "PegaGadget1Ifr", data.get("prsMFirstName"), "First name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "prsLname", true, "PegaGadget1Ifr", data.get("prsMLastName"), "Last name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "prsDob", true, "PegaGadget1Ifr", data.get("DOB"), "DOB");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "prsPhno", true, "PegaGadget1Ifr", data.get("prsMIntercationId"), "Phone number");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "prsMedno", true, "PegaGadget1Ifr", data.get("prsMMedicareNm"), "Medicare Number");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "prsSearch", true, "PegaGadget1Ifr", "", "Search");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "prsmemSel", true, "PegaGadget1Ifr",data.get("prsMFirstName"), "Select Member");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "prsSubmit", true, "PegaGadget1Ifr", "", "Submit");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on searchProsMem method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on searchProsMem method " + e);
			Assert.fail();
		}
	}
	
	public void getDialogue(String pageLocatorsPath,String pageFiledsPath,
			String expectedDialog,String operatorName,String frame)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			waitSleep(2500);
			switchToFrame(frame);
			String actualDialog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "dialogContent", true, frame, "", "Dialog Content");
			System.out.println("Member Search Dialog: "+actualDialog);
			String expected=String.format(expectedDialog,operatorName);
			System.out.println("expected Dialog: "+expectedDialog);
			//assertEquals(expected, actualDialog, "Dialog");
			//if(expected.contains(actualDialog))
			System.out.println("Actual Dialogue: "+actualDialog);
			System.out.println("Expected Dialogue: "+expectedDialog);
			if(actualDialog.contains(expected))
			{
				System.out.println("Dilalogue Matched");
				test.log(LogStatus.PASS, "Dilalogue Matched");
				test.log(LogStatus.INFO, "Expected Dialog:"+expectedDialog);
				test.log(LogStatus.INFO, "Actual Dialog:"+actualDialog);  
			}
			else{
				System.out.println("Dilalogue Matched");
				test.log(LogStatus.FAIL, "Dilalogue not Matched");
				test.log(LogStatus.INFO, "Expected Dialog:"+expectedDialog);
				test.log(LogStatus.INFO, "Actual Dialog:"+actualDialog);
				Assert.fail();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getDialogue method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getDialogue method " + e);
			Assert.fail();
		}
	}
	
	public void getCoachingTip(String pageLocatorsPath,String pageFiledsPath,
			String expectedDialog,String operatorName,String frame)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			waitSleep(1500);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "coachingTipicon", true, frame, "", "Coaching Tip icon");
			String actualDialog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "coachingTip", true, frame, "", "Coaching Tip");
			System.out.println("Coaching Tip: "+actualDialog);
			String expected=String.format(expectedDialog,operatorName);
			System.out.println("expected Coaching Tip: "+expectedDialog);
			assertEquals(expected, actualDialog, "Coaching Tip");
			waitSleep(1500);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getDialogue method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getDialogue method " + e);
			Assert.fail();
		}
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//span[contains(text(),'Email')]")).click();
		switchToFrame(frame);
		
		waitSleep(1500);
	}
	
	public void getCoachingTips(String pageLocatorsPath,String pageFiledsPath,
			String expectedDialog,String operatorName,String frame)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			waitSleep(1500);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "coachingTipicon", true, frame, "", "Coaching Tip icon");
			String actualDialog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "coachingTip", true, frame, "", "Coaching Tip");
			System.out.println("Coaching Tip: "+actualDialog);
			//String expected=String.format(expectedDialog,operatorName);
			System.out.println("expected Coaching Tip: "+expectedDialog);
			assertEquals(expectedDialog, actualDialog, "Coaching Tip");
			waitSleep(1500);
			try{
				WebElementAction("Click",pageLocatorsPath, pageFiledsPath, "dialogContent", true, frame, "", "Dialog Content");	
			}
			catch(AssertionError e1)
			{
				driver.switchTo().defaultContent();
				driver.findElement(By.xpath("//span[contains(text(),'Email')]")).click();
				switchToFrame(frame);
			}
			
			waitSleep(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getDialogue method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getDialogue method " + e);
			Assert.fail();
		}
	}
	
	
	public void readEligibilityMismatchDetails(String pageLocatorsPath,String pageFiledsPath, String tab,String expectedResult) throws Exception
	{
		String elgMismatchDetails="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(9000);
			if(tab.contains("contracttab")){
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EligibilityMismatchbtn", true, "PegaGadget1Ifr", "", "Eligibility Mismatch");
			}
			if(tab.contains("membertab")){
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "memtabEligibilityMismatchbtn", true, "PegaGadget1Ifr", "", "Eligibility Mismatch");
				}
			if(tab.contains("grouptab")){
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "grptabEligibilityMismatchbtn", true, "PegaGadget1Ifr", "", "Eligibility Mismatch");
				}
			waitSleep(3000);
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pEligibilityMismatches$pSingleValueMismatchList$l')]"));
			String s="//tr[contains(@id,'$PpyWorkPage$pEligibilityMismatches$pSingleValueMismatchList$l%d')]";
			if(ele.size()==0){
				ele= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pEligibilityMismatches$pSubscriberAddressMismatchList$l')]"));
				s="//tr[contains(@id,'$PpyWorkPage$pEligibilityMismatches$pSubscriberAddressMismatchList$l%d')]";
			}
			System.out.println("WebElements Rows  :::::::::::::::::::::::::::::::::::::" + ele.size());
			
			
			//*[@id="$PpyWorkPage$pEligibilityMismatches$pSubscriberAddressMismatchList$l4"]
			
			for(int i=0;i<ele.size()+1;i++)
			{
				String s1=String.format(s, i+1);
				String memdet="";
				List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
				for(int j=0;j<colums.size();j++)
				{
					if(j==0)
					{
						memdet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
					else{
						memdet=memdet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
				}
				elgMismatchDetails=elgMismatchDetails+","+memdet;	
			}
			waitSleep(4000);
			elgMismatchDetails=elgMismatchDetails.substring(1,elgMismatchDetails.length());
			System.out.println(elgMismatchDetails);
			assertEquals(expectedResult, elgMismatchDetails, "Eligibility Mismatch Results");
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//span[contains(text(),'Email')]")).click();
			driver.switchTo().frame("PegaGadget1Ifr");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on readEligibilityMismatchDetails method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on readEligibilityMismatchDetails method " + e);
			Assert.fail();
		}
		
	}
	
	public String movetoContracttab(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		String returnstr="contracttab";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contractTab", true, "PegaGadget1Ifr", "", "Contract Tab");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on movetoContracttab method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on movetoContracttab method " + e);
			Assert.fail();
		}
		return returnstr;
	}
	
	public String movetoMembertab(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		String returnstr="membertab";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "memberTab", true, "PegaGadget1Ifr", "", "Member Tab");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on movetoMembertab method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on movetoMembertab method " + e);
			Assert.fail();
		}
		return returnstr;
	}
	
	
	
	
	public String movetoGrouptab(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		String returnstr="grouptab";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "groupTab", true, "PegaGadget1Ifr", "", "Group Tab");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on movetogrouptab method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on movetogrouptab method " + e);
			Assert.fail();
		}
		return returnstr;
	}
	
	
	
	public void selectMemberAndNavigatebyfnameverifyMember(String pageLocatorsPath,String pageFiledsPath,
			String memberSearchFname) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(5000);			
			waitOnIE(4000);
			waitForElementsToVisible("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]");
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
			ele.size();
			String s="//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member id:"+driver.findElement(By.xpath(s1+"//td[4]")).getText());
				if(driver.findElement(By.xpath(s1+"//td[4]")).getText().equals(memberSearchFname))
				{
					System.out.println("Entered if ");
					ClickWebelement("xpath", "//span[contains(text(),'%s')]", memberSearchFname);
					break;
				}
			}
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "Submit", "Submit Button");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on selectMemberAndNavigatebyfname method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on selectMemberAndNavigatebyfname method " + e);
			Assert.fail();
		}
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return ExpectedConditions.visibilityOf(frame);
	}
	
	public void errormessage(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			waitSleep(2500);
		String errorMessage=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "errorMessage", true, "PegaGadget1Ifr", "", "errorMessage");
			waitSleep(2500);
			System.out.println(errorMessage);
	      assertEquals(data.get("ErrorMessage"), errorMessage, "error Message");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on submitNL method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on submitNL method " + e);
			Assert.fail();
		}
	}
	
	public void validateDOB(String pageLocatorsPath,String pageFiledsPath) 
	{
		String dob="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			dob=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "dob", true, "PegaGadget1Ifr", "", "dob");
			BaseTest.log.debug("DOB converted as MM/DD/YYYY " + dob);
			test.log(LogStatus.PASS, "DOB converted as MM/DD/YYYY " + dob);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateDOB method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateDOB method " + e);
			Assert.fail();
		}
	}
	public String getNONLIInteractionID(String pageLocatorsPath,String pageFiledsPath) 
	{
		String interactionID="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToDefault();
			interactionID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "NONLVI-ID", false, "", "Interaction ID", "Interaction ID");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getLIInteractionID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getLIInteractionID method " + e);
			Assert.fail();
		}
		return interactionID;
	}
	
	public void verifyMember(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			waitSleep(4000);
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Selectedmemberchkbox", true, "PegaGadget1Ifr","Selected member not on Member Rights list", "Selected member not on Member Rights list");
			waitSleep(2500);
			//Submit_Button.click();
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget1Ifr","Submit", "Submit_Button");
			waitSleep(4000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on verifyMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on verifyMember method " + e);
			Assert.fail();
		}
	}
	
	public void selectMemberAndNavigateVerifyMem(String pageLocatorsPath,String pageFiledsPath,
			String memberSearchFname) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\MemberSearchPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\MemberSearchPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(5000);			
			waitOnIE(4000);
			waitForElementsToVisible("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]");
			List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]"));
			ele.size();
			String s="//tr[contains(@id,'$PMemberSearchResults$ppxResults$l%d')]";
			for(int i=0;i<ele.size();i++)
			{
				String s1=String.format(s, i+1);
				System.out.println("Member id:"+driver.findElement(By.xpath(s1+"//td[4]")).getText());
				if(driver.findElement(By.xpath(s1+"//td[4]")).getText().equals(memberSearchFname))
				{
					System.out.println("Entered if ");
					ClickWebelement("xpath", "//span[contains(text(),'%s')]", memberSearchFname);
					break;
				}
			}
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "Submit", "Submit Button");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on selectMemberAndNavigatebyfname method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on selectMemberAndNavigatebyfname method " + e);
			Assert.fail();
		}
		//return (InteractionManagerPage) openPage(InteractionManagerPage.class);
	}

}
