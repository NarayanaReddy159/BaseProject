package com.nasco.MA.Regression.R1_TestCases;

import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Regression.Pages.HomePage;
import com.nasco.MA.Regression.Pages.LoginPage;
import com.nasco.MA.Regression.Pages.Reports;
import com.nasco.MA.Regression.Run.RunTestNG_NCompass_MA;
import com.nasco.MA.Regression.Base.BaseTest;
import com.nasco.MA.Regression.utilities.DataProviders;
import com.nasco.MA.Regression.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class TC028_Verify_Reports extends BaseTest{
	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R1DP")
    public void AUTC028_Verify_Reports(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		//System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC028_Verify_Reports");
		String pageLocatorsPath=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC028_Verify_Reports - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC028_Verify_Reports -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		homepage.movetoReports(pageLocatorsPath, pageFiledsPath);
		test.log(LogStatus.INFO, "My Reports link clicked in Home Page and operator redirected to My Reports");
		log.debug("My Reports link clicked in Home Page and operator redirected to My Reports");
		Reports reports= new Reports();
		reports.getCategories(pageLocatorsPath, pageFiledsPath,data);
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC028_Verify_Reports Completed");
		log.debug("AUTC028_Verify_Reports Completed");
		quit();
		
		
	}
}
