package com.nasco.MA.Pages;


import java.util.Arrays;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


@SuppressWarnings("rawtypes")
public class InteractionManagerPage extends BasePage {
	
	
	
	Actions builder=new Actions(driver);
	
	@FindBy(how=How.XPATH, using ="//button[contains(text(),'Add task')]")
	public WebElement addTask;
	
	String excepionMessage="";
	
	public void addTask(String taskName,String pageLocatorsPath,String pageFiledsPath) {
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTask", true, "PegaGadget1Ifr", "", "add Task");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr", taskName, taskName+" Intent");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTasks", true, "PegaGadget1Ifr", "", "Add Tasks");
			waitSleep(2000); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTask method " + e);
			test.log(LogStatus.FAIL, "Error on addTask method " + e);
			Assert.fail();
		}
	}
	public void wrapupnotverifiedIntent(String pageLocatorsPath,String pageFiledsPath,String interactionReason,String descriptionoftheissue,String descriptionoftheresolution) throws Exception
	{
		pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2500);

		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
		waitSleep(1500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget1Ifr", "", "Submit");
		waitSleep(1500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");

		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "descriptionoftheissue", true, "PegaGadget1Ifr", descriptionoftheissue, "description of the issue");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "descriptionoftheresolution", true, "PegaGadget1Ifr", descriptionoftheresolution, "description of there solution");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
		waitSleep(2500);
	}
	
	public void addTaskResearch(String taskName,String pageLocatorsPath,String pageFiledsPath) {
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTaskResearch", true, "PegaGadget1Ifr", "", "add Task");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr", taskName, taskName+" Intent");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTasks", true, "PegaGadget1Ifr", "", "Add Tasks");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTaskResearch method " + e);
			test.log(LogStatus.FAIL, "Error on addTaskResearch method " + e);
			Assert.fail();
		}
	}
	
	
	public void WrapUpOpenIntent(String comments,String interactionReason,String pageLocatorsPath,
			String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget2Ifr", "Wrap up", "Add Task");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contactNotVerified", true, "PegaGadget2Ifr", "Are you sure", "contact NotVerified");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contactNotVerified", true, "PegaGadget2Ifr", "You are closing", "Confirm Wrap Up");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget2Ifr", "", "Submit");
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on WrapUpOpenIntent method " + e);
			test.log(LogStatus.FAIL, "Error on WrapUpOpenIntent method " + e);
			Assert.fail();
		}
		
	}
	
	public void wrapupClosednotverifiedIntent(String comments,String interactionReason,String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(4000);
			waitOnIE(4000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			waitSleep(5500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(4500);
			waitOnIE(4500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapupClosednotverifiedIntent method " + e);
			test.log(LogStatus.FAIL, "Error on wrapupClosednotverifiedIntent method " + e);
			Assert.fail();
		}
		
	}
	
	public void wrapupNLIntent(String comments,String interactionReason,String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(4000);
			waitOnIE(4000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
			waitSleep(1500);
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget1Ifr", "", "Submit");
//			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			waitOnIE(4500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapupClosednotverifiedIntent method " + e);
			test.log(LogStatus.FAIL, "Error on wrapupClosednotverifiedIntent method " + e);
			Assert.fail();
		}
		
	}
	
	public void wrapupClosedIntent(String comments,String interactionReason,String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			waitOnIE(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(4500);
			waitOnIE(4500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapupClosednotverifiedIntent method " + e);
			test.log(LogStatus.FAIL, "Error on wrapupClosednotverifiedIntent method " + e);
			Assert.fail();
		}
		
	}
		public void wrapupProsMem(String comments,String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			waitOnIE(5500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			waitOnIE(5500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(2500);
			waitOnIE(2500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapupProsMem method " + e);
			test.log(LogStatus.FAIL, "Error on wrapupProsMem method " + e);
			Assert.fail();
		}
		
	}
	public void WrapUpOpenocvIntent(String comments,String interactionReason,String pageLocatorsPath,
			String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(4000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(4500);
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on WrapUpOpenGSIIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on WrapUpOpenGSIIntent method " + e);
			Assert.fail();
		}
		
	}
	

	
	public void wrapupClosednotverifiedMAPD(String comments,String interactionReason,String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitOnIE(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
			waitSleep(1500);
			waitOnIE(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(1500);
			waitOnIE(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "issueDesc", true, "PegaGadget1Ifr", comments, "Issue Description");
			waitSleep(1500);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			waitSleep(2500);
			waitOnIE(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "issueResol", true, "PegaGadget1Ifr", comments, "Issue Resolution");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(2500);
			waitOnIE(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapupClosednotverifiedMAPD method " + e);
			test.log(LogStatus.FAIL, "Error on wrapupClosednotverifiedMAPD method " + e);
			Assert.fail();
		}
		
	}
	
	public void wrapupverifiedIntent(String comments,String interactionReason,String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(2500);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapupverifiedIntent method " + e);
			test.log(LogStatus.FAIL, "Error on wrapupverifiedIntent method " + e);
			Assert.fail();
		}
		
	}
	
	public VerifyContactPage movetoVerifyContact(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActions", true, "PegaGadget1Ifr", "", "Other Actions");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "verifyMember", true, "PegaGadget1Ifr", "Verify member", "Verify Member");
			waitSleep(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on movetoVerifyContact method " + e);
			test.log(LogStatus.FAIL, "Error on movetoVerifyContact method " + e);
			Assert.fail();
		}
		return (VerifyContactPage) openPage(VerifyContactPage.class);
	}
	
	public void movetootherActions()
	{
		try{
			switchToFrame("PegaGadget1Ifr");
			//ClickWebelement("xpath", "//button[@title='Other Actions']", "");
			driver.findElement(By.xpath("//button[@title='Other Actions']")).click();
		}
		catch(AssertionError e)
		{
			/*e.printStackTrace();
			BaseTest.log.error("Error on movetootherActions method " + e);
			test.log(LogStatus.FAIL, "Error on movetootherActions method " + e);
			Assert.fail();*/
		}
	}
	
	@SuppressWarnings("unchecked")
	public RCEPage open() {
		
		return (RCEPage) openPage(RCEPage.class);
	}	
	
	@SuppressWarnings("unchecked")
	public GSIPage openGSI() {
		
		return (GSIPage) openPage(GSIPage.class);
	}	
	@SuppressWarnings("unchecked")
	public WorkbasketPage openworkBasket() {
		
		return (WorkbasketPage) openPage(WorkbasketPage.class);
	}
	
	@SuppressWarnings("unchecked")
	public RecentWorkPage openrecentWork() {
		
		return (RecentWorkPage) openPage(RecentWorkPage.class);
	}
	@SuppressWarnings("unchecked")
	public ManageClaimPage openMangeClaim() {
		
		return (ManageClaimPage) openPage(ManageClaimPage.class);
	}
	
	@SuppressWarnings("unchecked")
	public ManageOtherCoveragePage openMOC() {
		
		return (ManageOtherCoveragePage) openPage(ManageOtherCoveragePage.class);
	}	

	public void ieLogout(String browser){
		try{
			
			waitSleep(2500);
			driver.switchTo().defaultContent();if(browser.equalsIgnoreCase("ie"))
			{
				((JavascriptExecutor)driver).executeScript("document.body.style.zoom='50%';");
			}
			driver.findElement(By.xpath("//a[contains(text(),'New')]//following::a[2]")).click();
			waitSleep(500);
			driver.findElement(By.xpath("//span[contains(text(),'Logout')]")).click();
			waitSleep(500);
			Alert alert = driver.switchTo().alert();
			alert.accept();
			waitSleep(4500);
			BaseTest.log.debug("Successfully Logged Out");
			test.log(LogStatus.INFO, "Successfully Logged Out");
			driver.switchTo().defaultContent();
			if(browser.equalsIgnoreCase("ie"))
			{
				((JavascriptExecutor)driver).executeScript("document.body.style.zoom='100%';");
			}
			
			}
			catch(Exception e)
			{
				excepionMessage = Arrays.toString(e.getStackTrace());
				e.printStackTrace();
				BaseTest.log.error("Error on logout method " + excepionMessage);
				test.log(LogStatus.FAIL, "Error on logout method " + e);
				Assert.fail();
			}
	}
	public void logout()
	{
		try{
		waitSleep(2500);
		waitOnIE(10000);
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//a[contains(text(),'New')]//following::a[2]")).click();
		waitSleep(500);
		waitOnIE(2500);
		driver.findElement(By.xpath("//span[contains(text(),'Logout')]")).click();
		waitSleep(1000);
		waitOnIE(2500);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		waitSleep(4500);
		BaseTest.log.debug("Successfully Logged Out");
		test.log(LogStatus.INFO, "Successfully Logged Out");
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on logout method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on logout method " + e);
			Assert.fail();
		}
	}
	
	public void WrapUpOpenGSIIntent(String comments,String interactionReason,String pageLocatorsPath,
			String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(2000);
			waitOnIE(2000);
			//waitForFrameTobeVisible("PegaGadget1Ifr");
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "WrapUp Button");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "GSIWarning-Submit", true, "PegaGadget2Ifr", "", "Submit");
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "GSIRelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on WrapUpOpenGSIIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on WrapUpOpenGSIIntent method " + e);
			Assert.fail();
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public WorklistPage openWorklist() {
		
		return (WorklistPage) openPage(WorklistPage.class);
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(addTask);
	}
	
	@SuppressWarnings("unchecked")
	public ViewBenefitsPage openViewBenefits() {
		
		return (ViewBenefitsPage) openPage(ViewBenefitsPage.class);
	}	
	
	public void WrapUpOpenVBIntent(String comments,String interactionReason,String pageLocatorsPath,
			String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			//waitForFrameTobeVisible("PegaGadget1Ifr");
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "WrapUp Button");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "GSIWarning-Submit", true, "PegaGadget2Ifr", "", "Submit");
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "VBRelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on WrapUpOpenGSIIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on WrapUpOpenGSIIntent method " + e);
			Assert.fail();
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public FollowUp openFollowUp() {
		
		return (FollowUp) openPage(FollowUp.class);
	}
	
	public void WrapUpOpenFOLIntent(String comments,String interactionReason,String pageLocatorsPath,
			String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
	     	waitOnIE(2000);
			//waitForFrameTobeVisible("PegaGadget1Ifr");
	     	waitOnIE(2000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "WrapUp Button");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "GSIWarning-Submit", true, "PegaGadget2Ifr", "", "Submit");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "GSIRelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on WrapUpOpenGSIIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on WrapUpOpenGSIIntent method " + e);
			Assert.fail();
		}
		
	}
	
	public void clickWrapup(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
			waitSleep(1500);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on clickWrapup method " + e);
			test.log(LogStatus.FAIL, "Error on clickWrapup method " + e);
			Assert.fail();
		}
	}
	
	public void wrapIntent(String comments,String interactionReason,String pageLocatorsPath,
			String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(2500);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapIntent method " + e);
			test.log(LogStatus.FAIL, "Error on wrapIntent method " + e);
			Assert.fail();
		}
	}
	@SuppressWarnings("unchecked")
	public ManageClaimPageIntend openManageClaimPageIntend() {
		
		return (ManageClaimPageIntend) openPage(ManageClaimPageIntend.class);
	}	
	
	@SuppressWarnings("unchecked")
	public Callback_RTCPage openRTC_Callback() {
		
		return (Callback_RTCPage) openPage(Callback_RTCPage.class);
	}
public void WrapUpOpenIntent(String comments,String interactionReason,String pageLocatorsPath,String pageFiledsPath,String frame) 
{
	try{
		pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
		switchToFrame(frame);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, frame, "Wrap up", "Add Task");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contactNotVerified", true, frame, "Are you sure", "contact NotVerified");
		waitSleep(2000);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contactNotVerified", true, frame, "You are closing", "Confirm Wrap Up");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, frame , "", "Submit");
		switchToFrame("PegaGadget1Ifr");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
		waitSleep(5000);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on WrapUpOpenIntent method " + e);
		test.log(LogStatus.FAIL, "Error on WrapUpOpenIntent method " + e);
		Assert.fail();
	}
	
 }
	@SuppressWarnings("unchecked")
	public Manager_toolsPage openManager_tools() {
		
		return (Manager_toolsPage) openPage(Manager_toolsPage.class);
	}
	
	public void clickSuggestedTask(String pageLocatorsPath,String pageFiledsPath, String intentId) {
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
		//	waitForFrameTobeVisible("PegaGadget1Ifr");
			switchToFrame("PegaGadget1Ifr");
			waitForElementsToVisible("//a[contains(text(),'"+intentId+"')]");
			driver.findElement(By.xpath("//a[contains(text(),'"+intentId+"')]")).click();
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SuggestedTask", true, "PegaGadget1Ifr", "", "Suggested Task");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on clickSuggestedTask method " + e);
			test.log(LogStatus.FAIL, "Error on clickSuggestedTask method " + e);
			Assert.fail();
		}
	
	}
	public void wrapupProsMem(String comments,String pageLocatorsPath,String pageFiledsPath,String frame2) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			switchToFrame(frame2);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, frame2, "Wrap up", "Wrap up");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, frame2, "", "Submit");
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapupProsMem method " + e);
			test.log(LogStatus.FAIL, "Error on wrapupProsMem method " + e);
			Assert.fail();
		}
		
	}
	public void wrapupClosednotverifiedIntent(String comments,String interactionReason,String pageLocatorsPath,String pageFiledsPath,String fname) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(2000);
			switchToFrame(fname);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, fname, "Wrap up", "Wrap up");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, fname, "", "Submit");
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapupClosednotverifiedIntent method " + e);
			test.log(LogStatus.FAIL, "Error on wrapupClosednotverifiedIntent method " + e);
			Assert.fail();
		}
		
	}
	
	public void wrapupRTCFromNonLive(String comments,String pageLocatorsPath,String pageFiledsPath,String interactionReason,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(4000);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, frame, "Wrap up", "Wrap up");
			waitSleep(1500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(5000);
		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on addTask method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on addTask method " + e);
			Assert.fail();
		}
	}
	public void addTask(String taskName,String pageLocatorsPath,String pageFiledsPath,String frame ) {
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTask", true, frame, "", "add Task");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "taskName", true, frame, taskName, taskName+" Intent");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTasks", true, frame, "", "Add Tasks");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTask method " + e);
			test.log(LogStatus.FAIL, "Error on addTask method " + e);
			Assert.fail();
		}
	}
	
	public void WrapUpInactiveIntent(String comments,String interactionReason,String pageLocatorsPath,
			String pageFiledsPath,String descriptionoftheissue, String descriptionoftheresolution) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget2Ifr", "Wrap up", "Add Task");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contactNotVerified", true, "PegaGadget2Ifr", "Are you sure", "contact NotVerified");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contactNotVerified", true, "PegaGadget2Ifr", "You are closing", "Confirm Wrap Up");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget2Ifr", "", "Submit");
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "descriptionoftheissue", true, "PegaGadget1Ifr", descriptionoftheissue, "description of the issue");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "descriptionoftheresolution", true, "PegaGadget1Ifr", descriptionoftheresolution, "description of there solution");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on WrapUpOpenIntent method " + e);
			test.log(LogStatus.FAIL, "Error on WrapUpOpenIntent method " + e);
			Assert.fail();
		}
		
	}
	public void pageload()
	{
		waitSleep(5000);
	}
	public void clickverifymember(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		try {
			switchToDefault();
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "verifymember", true, "PegaGadget1Ifr", "verify member", "verifymember");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectmember", true, "PegaGadget1Ifr", "selectmember", "Contact is the selected member");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "memberdob", true, "PegaGadget1Ifr", "memberdob", "memberdob");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget1Ifr", "SubmitButton", "Submit Button");
			waitSleep(5000);
		
		
		} catch (Exception e){
            e.printStackTrace();
            excepionMessage = Arrays.toString(e.getStackTrace());
            BaseTest.log.error("Error on clicksavetoWorklist method " + excepionMessage);
            test.log(LogStatus.FAIL, "Error on cclicksavetoWorklist method " + e);
            Assert.fail();

      }
	}
	public void OtherActions(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "OtherActionMmebr", true, "PegaGadget1Ifr", "", "Other Actions");
			test.log(LogStatus.INFO, "clicked Other Actions");
		} catch (Exception e){
            e.printStackTrace();
            excepionMessage = Arrays.toString(e.getStackTrace());
            BaseTest.log.error("Error on clickOtherActions method" + excepionMessage);
            test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
            Assert.fail();

		}
	}
	
	public void wrapupClosedIntentwithResolution(String comments,String interactionReason,String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, "PegaGadget1Ifr", "Wrap up", "Wrap up");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			//WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpIssueComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpResComments", true, "PegaGadget1Ifr", comments, "Resolution comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(4500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapupClosednotverifiedIntent method " + e);
			test.log(LogStatus.FAIL, "Error on wrapupClosednotverifiedIntent method " + e);
			Assert.fail();
		}
		
	}
	public void pageload(int time)
	{
		waitSleep(time);
	}
}