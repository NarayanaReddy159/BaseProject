package com.nasco.MA.Regression.utilities;


public class EmailHTMLBuilder
{

	public StringBuilder sb = new StringBuilder();
	
	public void appendHeader(String header_content)
	{
		
		sb.append("<html>");
		sb.append("<head>");
		sb.append("<p>"+header_content+"</p>");
		sb.append("<h4></h4>");
			
	}
	
	public void appendLink(String header_content)
	{
		
		sb.append("<html>");
		sb.append("<head>");
		sb.append("<a href="+header_content+">"+header_content+"</a>");
		sb.append("<h4></h4>");
			
	}
	
	public void appendStyle()
	{
		
		sb.append("<style>" +
				"table { border-collapse: collapse; border: 5px solid black; width: 50%; }" + 
				"td { width: 50%; height: 2em; border: 1px solid #ccc;}" +
				"</style>" + "</head>");
		
		
	}
	
	
	public void appendBody()
	{
		sb.append("<body>" + "<table>" + "<tbody>" + "<tr><td>Testcase Name</td><td>Status</td></tr>");
		    	        
	}
	
	public void appendFooter()
	{
		sb.append("</tbody>"+"</table>" +
		           "</body>" +
		           "</html>");
	}
	
	
	public void appendData(String TestCaseName, String TestCaseStatus)
	{

		
		sb.append("<tr><td>")
	       .append(TestCaseName)
	       .append("</td><td>")
	       .append(TestCaseStatus)
	       .append("</td></tr>");

	}
	
	public void appendSummary_Header(String header_Content)
	{
		sb.append("<html>");
		sb.append("<head>");
		//sb.append("<p>Testing</p>");
		sb.append("<h4>"+header_Content+"</h4>");
		sb.append("<style>" +
				"table {margin-bottom:10px;border-collapse:collapse;empty-cells:show}th,td {border:1px solid #009;padding:.25em .5em}th {vertical-align:bottom}td {vertical-align:top}table a {font-weight:bold}.stripe td {background-color: #E6EBF9}.num {text-align:right}.passedodd td {background-color: #3F3}.passedeven td {background-color: #0A0}.skippedodd td {background-color: #DDD}.skippedeven td {background-color: #CCC}.failedodd td,.attn {background-color: #F33}.failedeven td,.stripe .attn {background-color: #D00}.stacktrace {white-space:pre;font-family:monospace}.totop {font-size:85%;text-align:center;border-bottom:2px solid #000}.invisible {display:none}" +
				"</style>" + "</head>");
		sb.append("<body>" + "<table>" + "<tbody>" + "<tr><th>Test</th><th># Total Tcs</th><th># Executed</th><th># Passed</th><th># Failed</th><th># Skipped</th><th>Pass %</th><th>Fail %</th></tr>");
	}
	

	
	public void appendSummary(String test,int total,int executed, int passed, int failed, int skipped, String passpercentage, String failpercentage)
	{
		sb.append("<tr><th>"+test+"</th><th>"+total+"</th><th>"+executed+"</th><th>"+passed+"</th><th>"+failed+"</th><th>"+skipped+"</th><th>"+passpercentage+"</th><th>"+failpercentage+"</th></tr>");
		sb.append("</tbody>"+"</table>"+
		           "</body>" +
		           "</html>");
	}
	
	public void appendSummary_HeaderReleaseWise(String header_Content)
	{
		sb.append("<html>");
		sb.append("<head>");
		//sb.append("<p>Testing</p>");
		sb.append("<h4>"+header_Content+"</h4>");
		sb.append("<style>" +
				"table {margin-bottom:10px;border-collapse:collapse;empty-cells:show}th,td {border:1px solid #009;padding:.25em .5em}th {vertical-align:bottom}td {vertical-align:top}table a {font-weight:bold}.stripe td {background-color: #E6EBF9}.num {text-align:right}.passedodd td {background-color: #3F3}.passedeven td {background-color: #0A0}.skippedodd td {background-color: #DDD}.skippedeven td {background-color: #CCC}.failedodd td,.attn {background-color: #F33}.failedeven td,.stripe .attn {background-color: #D00}.stacktrace {white-space:pre;font-family:monospace}.totop {font-size:85%;text-align:center;border-bottom:2px solid #000}.invisible {display:none}" +
				"</style>" + "</head>");
		sb.append("<body>" + "<table>" + "<tbody>" + "<tr><th>Releases</th><th># Total TCs</th><th># Executed</th><th># Passed</th><th># Failed</th><th># Skipped</th><th># Warnings</th>");
	}
	

	
	public void appendSummary_ReleaseWise(String test,int tottcs,int executed, int passed, int failed, int skipped, int warning)
	{
		sb.append("<tr><th>"+test+"</th><th>"+tottcs+"</th><th>"+executed+"</th><th>"+passed+"</th><th>"+failed+"</th><th>"+skipped+"</th><th>"+warning+"</th>");
//		sb.append("</tbody>"+"</table>"+
//		           "</body>" +
//		           "</html>");
	}
	public void append_closebody(){
		sb.append("</tbody>"+"</table>"+
		           "</body>" +
		           "</html>");
	}
	
	public void appendSummary_HeaderIntentWise(String header_Content)
	{
		sb.append("<html>");
		sb.append("<head>");
		//sb.append("<p>Testing</p>");
		sb.append("<h4>"+header_Content+"</h4>");
		sb.append("<style>" +
				"table {margin-bottom:10px;border-collapse:collapse;empty-cells:show}th,td {border:1px solid #009;padding:.25em .5em}th {vertical-align:bottom}td {vertical-align:top}table a {font-weight:bold}.stripe td {background-color: #E6EBF9}.num {text-align:right}.passedodd td {background-color: #3F3}.passedeven td {background-color: #0A0}.skippedodd td {background-color: #DDD}.skippedeven td {background-color: #CCC}.failedodd td,.attn {background-color: #F33}.failedeven td,.stripe .attn {background-color: #D00}.stacktrace {white-space:pre;font-family:monospace}.totop {font-size:85%;text-align:center;border-bottom:2px solid #000}.invisible {display:none}" +
				"</style>" + "</head>");
		sb.append("<body>" + "<table>" + "<tbody>" + "<tr><th>Intent</th><th># Passed</th><th># Failed</th>");
	}
	

	
	public void appendSummary_IntentWise(String test,int passed, int failed)
	{
		sb.append("<tr><th>"+test+"</th><th>"+passed+"</th><th>"+failed+"</th>");
//		sb.append("</tbody>"+"</table>"+
//		           "</body>" +
//		           "</html>");
	}

	
}
