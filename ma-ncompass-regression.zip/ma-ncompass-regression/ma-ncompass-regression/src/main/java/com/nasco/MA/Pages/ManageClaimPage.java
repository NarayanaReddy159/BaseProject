package com.nasco.MA.Pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;




public class ManageClaimPage extends BasePage {

	@FindBy(xpath="//label[@id='pyActionLabel']//following::span[1]")
	public WebElement intentID;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(intentID);
	}
	public void adjustclaim(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
		waitSleep(2500);
		switchToFrame("PegaGadget1Ifr");
		try {
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "clmotheractions", true, "PegaGadget1Ifr", "", "Other Actions");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Adjust", true, "PegaGadget1Ifr", "", "Adjust Claim");
		waitSleep(2500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "confirm", true, "PegaGadget1Ifr", "", "confirm button");
		waitSleep(3000);
	
		String Errors=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Errors", true, "PegaGadget1Ifr", data.get("ExpectedErrors"), "Errors message");
		System.out.println(Errors);
		assertEquals(data.get("ExpectedErrors"), Errors.substring(0,57 ), "Errors");

		
		} catch (Exception e) {
            e.printStackTrace();
            BaseTest.log.error("Error on createMANAGECLAIM method " + e);
            test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
            Assert.fail();
		}

			
		}
		public void ServiceException(String pageLocatorsPath,String pageFiledsPath,String ServiceExceptionScenario,String Benefittoapply,String Benefitnarrative,String comments) 
		{
			pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			try {
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "clmotheractions", true, "PegaGadget1Ifr", "", "Other Actions");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ServiceException", true, "PegaGadget1Ifr", "", "Service Exception");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ReceiveBillNo", true, "PegaGadget1Ifr", "", "Bill received -No");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ProceedExceptionYes", true, "PegaGadget1Ifr", "", "Proceed Exception -Yes");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ReimbusementNo", true, "PegaGadget1Ifr", "", "Reimbusement_No");
			waitSleep(5000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ServiceExceptionScenario", true, "PegaGadget2Ifr", ServiceExceptionScenario, "Service Exception Scenario");
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Benefittoapply", true, "PegaGadget2Ifr", Benefittoapply, "Benefit to apply");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Benefitnarrative", true, "PegaGadget2Ifr", Benefitnarrative, "Benefit narrative");
	       	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget2Ifr", comments, "Comments");		
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "", "Submit");



			
			} catch (Exception e) {
	            e.printStackTrace();
	            BaseTest.log.error("Error on createMANAGECLAIM method " + e);
	            test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
	            Assert.fail();


			  }
			}
			public void RouteClaimResearch(String pageLocatorsPath,String pageFiledsPath,String researchreason,String CommentsRoute) 
			{
				pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
				waitSleep(2500);
				switchToFrame("PegaGadget1Ifr");
				try {
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "clmotheractions", true, "PegaGadget1Ifr", "", "Other Actions");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RouteClaimResearch", true, "PegaGadget1Ifr", "", "Route Claim Research");
				waitSleep(2000);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "researchreason", true, "PegaGadget2Ifr", researchreason, "research reason");
				waitSleep(2500);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "CommentsRoute", true, "PegaGadget2Ifr", CommentsRoute, "Comments Route");		
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "", "Submit");

				

				
				} catch (Exception e) {
		            e.printStackTrace();
		            BaseTest.log.error("Error on createMANAGECLAIM method " + e);
		            test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
		            Assert.fail();


					
				}
			
		
		
		}
			public void ViewBenefits(String pageLocatorsPath,String pageFiledsPath) 
			{
				pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
				waitSleep(2500);
				switchToFrame("PegaGadget1Ifr");
				try {
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "clmotheractions", true, "PegaGadget1Ifr", "", "Other Actions");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ViewBenefits", true, "PegaGadget1Ifr", "", "View Benefits");
				waitSleep(3000);
				switchToDefault();
				switchToFrame("PegaGadget2Ifr");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "benefitNo", true, "PegaGadget2Ifr", "", "benefit No");
				waitSleep(3000);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "", "Submit");

				

				
				} catch (Exception e) {
		            e.printStackTrace();
		            BaseTest.log.error("Error on createMANAGECLAIM method " + e);
		            test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
		            Assert.fail();


					
				}
			
		
		
		}
			public void PendingAdditionalWork(String pageLocatorsPath,String pageFiledsPath,String Reasontopend,String Enddate,String commentsPending,Hashtable<String,String> data) 
			{
				pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
				waitSleep(2500);
				switchToFrame("PegaGadget1Ifr");
				try {
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "clmotheractions", true, "PegaGadget1Ifr", "", "Other Actions");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "PendingAdditionalWork", true, "PegaGadget1Ifr", "", "Pending Additional Work");
				waitSleep(2000);
				switchToFrame("PegaGadget1Ifr");
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsPending", true, "PegaGadget1Ifr", commentsPending, "comments Pending");

				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Reasontopend", true, "PegaGadget1Ifr", Reasontopend, "Reason to pend");
				
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Enddate", true, "PegaGadget1Ifr", Enddate, "End date");
				waitSleep(2000);


				String parentWindow=driver.getWindowHandle();
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
				waitSleep(2000);
				for (String windowHandle : driver.getWindowHandles())
				{
					if(!parentWindow.equals(windowHandle)){
						 driver.switchTo().window(windowHandle);
						 System.out.println("Switched to"+windowHandle);
					}
					System.out.println(windowHandle);
					
				}
				
				switchToDefault();
				String AuditLog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AuditLog", true, "PegaGadget1Ifr", "", "Audit Log");
				System.out.println(AuditLog);
				assertEquals(AuditLog, data.get("AuditLog"), "Audit Log");

				driver.close();
				driver.switchTo().window(parentWindow);
				waitSleep(2000);
				
				switchToFrame("PegaGadget1Ifr");
				
			String	text = readText("xpath","//span[contains(text(),'Claim number')]","claim");
						System.out.println(text);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SaveButton", true, "PegaGadget1Ifr", "", "Save Button");
				waitSleep(2000);
				
				
				} catch (Exception e) {
		            e.printStackTrace();
		            BaseTest.log.error("Error on createMANAGECLAIM method " + e);
		            test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
		            Assert.fail();


					
				}
			
		
		
		}
			public void ValidateCreateFollowUp(String pageLocatorsPath,String pageFiledsPath,String commentsFollowUp,Hashtable<String,String> data) 
			{
				pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
				waitSleep(2500);
				switchToFrame("PegaGadget1Ifr");
				try {
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "clmotheractions", true, "PegaGadget1Ifr", "", "Other Actions");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createFollowUp1", true, "PegaGadget1Ifr", "", "Create Follow Up");
				waitSleep(3000);
				switchToDefault();
				switchToFrame("PegaGadget2Ifr");
				String	text = readText("xpath","//span[contains(text(),'Assign operator')]","Assign operator");
				System.out.println(text);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "followUpNow", true, "PegaGadget2Ifr", "", "Follow Up Now");
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsFollowUp", true, "PegaGadget2Ifr", commentsFollowUp, "comments Follow Up");

				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget2Ifr", "", "Submit");
				switchToDefault();
				switchToFrame("PegaGadget1Ifr");
				String parentWindow=driver.getWindowHandle();
				waitSleep(2000);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
				waitSleep(2000);
				for (String windowHandle : driver.getWindowHandles())
				{
					if(!parentWindow.equals(windowHandle)){
						 driver.switchTo().window(windowHandle);
						 System.out.println("Switched to"+windowHandle);
					}
					System.out.println(windowHandle);
					
				}
				
				switchToDefault();
				String AuditLog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "AuditLog", true, "PegaGadget1Ifr", "", "Audit Log");
				System.out.println(AuditLog);
				assertEquals(AuditLog.substring(0, 10), data.get("AuditLog"), "Audit Log");

				driver.close();
				driver.switchTo().window(parentWindow);
				waitSleep(2000);

				
				} catch (Exception e) {
		            e.printStackTrace();
		            BaseTest.log.error("Error on createMANAGECLAIM method " + e);
		            test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
		            Assert.fail();


					
				}
	

			}
			
			public void searchClaim(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data) throws Exception
			{
				pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
				waitSleep(3000);
				switchToFrame("PegaGadget2Ifr");
				
				waitSleep(2000);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateSearchOptions", true, "PegaGadget2Ifr", data.get("DateSearchOptions"), "DateSearch Options");
				waitSleep(2000);
		     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "fdos", true, "PegaGadget2Ifr", data.get("FDOS"), "First date of serviceRequired");
		     	WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ldos", true, "PegaGadget2Ifr", data.get("LDOS"), "Last date of service");
		     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchCriteria", true, "PegaGadget2Ifr", "", "Search Criteria");
			
		     	if(null != data.get("ClaimNumber") && !data.get("ClaimNumber").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, "PegaGadget2Ifr", data.get("ClaimNumber"), "Claim Number");
				}
		     	
		     	if(null != data.get("providerName") && !data.get("providerName").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "providerName", true, "PegaGadget2Ifr", data.get("providerName"), "providerName");
				}
		     	
		     	if(null != data.get("NASCOproviderID") && !data.get("NASCOproviderID").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "NASCOproviderID", true, "PegaGadget2Ifr", data.get("NASCOproviderID"), "NASCOproviderID");
				}
		     	
		     	if(null != data.get("claimType") && !data.get("claimType").isEmpty())
				{
					WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimType", true, "PegaGadget2Ifr", data.get("claimType"), "claimType");
				}
		     	
		     	if(null != data.get("claimTypeValue") && !data.get("claimTypeValue").isEmpty())
				{
					WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "claimTypeValue", true, "PegaGadget2Ifr", data.get("claimTypeValue"), "claimTypeValue");
				}
		     	
		     	if(null != data.get("checkNumber") && !data.get("checkNumber").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "checkNumber", true, "PegaGadget2Ifr", data.get("checkNumber"), "checkNumber");
				}
		     	
		     	if(null != data.get("payee") && !data.get("payee").isEmpty())
				{
					WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "payee", true, "PegaGadget2Ifr", data.get("payee"), "payee");
				}
		     	
		     	if(null != data.get("procedureCode") && !data.get("procedureCode").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "procedureCode", true, "PegaGadget2Ifr", data.get("procedureCode"), "procedureCode");
				}
		     	
		     	if(null != data.get("diagnosisCode") && !data.get("diagnosisCode").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "diagnosisCode", true, "PegaGadget2Ifr", data.get("diagnosisCode"), "diagnosisCode");
				}
		     	
		     	if(null != data.get("diagnosisClass") && !data.get("diagnosisClass").isEmpty())
				{
					WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "diagnosisClass", true, "PegaGadget2Ifr", data.get("diagnosisClass"), "diagnosisClass");
				}
		     	
		     	if(null != data.get("requestNumber") && !data.get("requestNumber").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "requestNumber", true, "PegaGadget2Ifr", data.get("requestNumber"), "requestNumber");
				}
		     	
		     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "additionalSearch", true, "PegaGadget2Ifr", "Additional search criteria", "additionalSearch");
				
		     	if(null != data.get("totalAmt") && !data.get("totalAmt").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "totalAmt", true, "PegaGadget2Ifr", data.get("totalAmt"), "totalAmt");
				}
		     	
		     	if(null != data.get("hcpcs") && !data.get("hcpcs").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "hcpcs", true, "PegaGadget2Ifr", data.get("hcpcs"), "hcpcs");
				}
		     	
		     	if(null != data.get("nationalProviderID") && !data.get("nationalProviderID").isEmpty())
				{
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "nationalProviderID", true, "PegaGadget2Ifr", data.get("nationalProviderID"), "nationalProviderID");
				}
		     	
		     	
		     	WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SubmitButton", true, "PegaGadget2Ifr", "", "Submit");
		     	waitSleep(2000);
				String noofclaims=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "noofclaims", true, "PegaGadget2Ifr", "", "noofclaims");
				int claimsCount=Integer.valueOf(noofclaims);
				System.out.println("claimsCount: "+claimsCount);
				if(claimsCount==0)
				{
					test.log(LogStatus.INFO, "No claims found for current search criteria");
				}
				else{
					
					assertEquals(data.get("claimsCount"), noofclaims, "claims Count");
					
				}
		     	
			}
			
			public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
			{	
				String intentid="";
				try{
					pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
					pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
					switchToFrame("PegaGadget2Ifr");
					intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "Search For Claim", "Intent ID");
					intentid= intentid.substring(1, intentid.length()-1);
					System.out.println(intentid);
					test.log(LogStatus.INFO, "Intent ID:"+intentid);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					BaseTest.log.error("Error on getIntentID method " + e);
					test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
					Assert.fail();
				}
				return intentid;
			}
			
			public void getAlertMsg(String pageLocatorsPath,String pageFiledsPath,String expectedstr) 
			{	
				try{
					pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
					pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
					switchToFrame("PegaGadget2Ifr");
					String actualAlertMsg=driver.findElement(By.xpath("//span[contains(text(),'"+expectedstr+"')]")).getText();
					System.out.println("Alert Message found:" + actualAlertMsg);
					assertEquals(expectedstr,actualAlertMsg,"Alert Message");
				}
				catch(Exception e)
				{
					e.printStackTrace();
					BaseTest.log.error("Error on getAlertMsg method " + e);
					test.log(LogStatus.FAIL, "Error on getAlertMsg method " + e);
					Assert.fail();
				}
				
			}
			
			public void CreateFollowUp(String pageLocatorsPath,String pageFiledsPath) 
			{
				pageLocatorsPath= pageLocatorsPath+"\\ManageClaimPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\ManageClaimPageFields.properties";
				waitSleep(4000);
				switchToFrame("PegaGadget1Ifr");
				try {
					waitSleep(4000);
					WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createnewwork", true, "PegaGadget1Ifr", "", "create new work");
					waitSleep(4000);
					WebElementAction("click",pageLocatorsPath, pageFiledsPath, "createFollowUp", true, "PegaGadget1Ifr", "", "pend the claim");
					waitSleep(2500);
					switchToFrame("PegaGadget2Ifr");
					System.out.println("frame");
					WebElementAction("click",pageLocatorsPath, pageFiledsPath, "followuptask", true, "PegaGadget2Ifr", "", "follow-up task");
					waitSleep(2500);
					WebElementAction("type",pageLocatorsPath, pageFiledsPath, "commentsFollowUp", true, "PegaGadget2Ifr","Create Follow Up", "Create Follow Up comments");
					WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget2Ifr", "", "Submit");

					
				} catch (Exception e) {
			        e.printStackTrace();
			        BaseTest.log.error("Error on CreateFollowUp method " + e);
			        test.log(LogStatus.FAIL, "Error on CreateFollowUp method " + e);
			        Assert.fail();


				}
			}

}
