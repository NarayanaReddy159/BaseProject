package com.nasco.MA.Regression.R1_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Regression.Pages.FollowUp;
import com.nasco.MA.Regression.Pages.HomePage;
import com.nasco.MA.Regression.Pages.InteractionManagerPage;
import com.nasco.MA.Regression.Pages.LoginPage;
import com.nasco.MA.Regression.Pages.MemberSearchPage;
import com.nasco.MA.Regression.Pages.WorklistPage;
import com.nasco.MA.Regression.Run.RunTestNG_NCompass_MA;
import com.nasco.MA.Regression.Base.BaseTest;
import com.nasco.MA.Regression.utilities.DataProviders;
import com.nasco.MA.Regression.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC025_FOL_FollowUp_ReScheduled extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R1DP")
    public void AUTC025_FOL_FollowUp_ReScheduled (Hashtable<String,String> data) throws Exception {
		
		setUpFramework();
		//System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC025_FOL_FollowUp_ReScheduled");
		String pageLocatorsPath=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user1"), RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through First Name , Last Name % , DOB %"+data.get("Fname")+","+data.get("Lname")+","+data.get("DOB"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		FollowUp fol =interactionManger.openFollowUp();
		log.debug("Navigate to interaction manger");
		String intentID=fol.getIntentID(pageLocatorsPath, pageFiledsPath);
		fol.create_FollowUp_Scheduled(pageLocatorsPath, pageFiledsPath, data);	
		//System.out.println(intentID);
		interactionManger.wrapupClosednotverifiedIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID);
    	WorklistPage worklist= interactionManger.openWorklist();
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	log.debug("Navigate to Worklist");
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
     	log.debug("Selected intent "+intentID+" from WorkList tab ");
     	worklist.followUp_ReScheduled(pageLocatorsPath, pageFiledsPath, data.get("FollowUpAttempt"),data.get("ReScheduledComments"));
     	worklist.logout();
     	login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user1"), RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
     	worklist.validateAssignedTo(pageLocatorsPath, pageFiledsPath, data.get("Expected_AssignedTo"));
     	

   }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC025_FOL_FollowUp_ReScheduled Completed");
		
		quit();
		
	}

}
