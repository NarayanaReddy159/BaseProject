package com.nasco.MA.Pages;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class ManageChangePage extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget1Ifr";
	String startDt="",endDt="";
	
	//@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame(frame1);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
	}
		
	
	public void validateAlertText(String pageLocatorsPath,String pageFiledsPath,String frame, String expText) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageChangePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageChangePageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			String actualAlertTxt=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Alerts", true, frame, "", "Alerts text");
			assertEquals(expText, actualAlertTxt, "Aleart text");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateAlertText method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateAlertText method " + e);
			Assert.fail();
		}
	 }

	public void SearchAlerts(String pageLocatorsPath,String pageFiledsPath,String frame, String value) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageChangePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageChangePageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "SearchKeyword", true, frame, value, "Alerts");
			waitSleep(1000);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "SearchKeyword", true, frame, value, "Alerts");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AlertsEditBtn", true, frame, "", "Edit Button");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateAlertText method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on SearchAlerts method " + e);
			Assert.fail();
		}
	 }
	
	public void validatePrimaryreasonText(String pageLocatorsPath,String pageFiledsPath,String frame, String expText) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageChangePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageChangePageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			String actualAlertTxt=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "PrimaryText", true, frame, "", "Delegated text");
			assertEquals(expText, actualAlertTxt, "Primary reasion for interaction text");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateAlertText method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validatePrimaryreasonText method " + e);
			Assert.fail();
		}
	 }
	
	public void SearchDelegatedRule(String pageLocatorsPath,String pageFiledsPath,String frame, String value) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageChangePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageChangePageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "SearchKeyword", true, frame, value, "Delegate rule ");
			waitSleep(3000);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "SearchKeyword", true, frame, value, value);
			waitSleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateAlertText method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on SearchDelegatedRule method " + e);
			Assert.fail();
		}
	 }
	
	public void clickEidtBtn(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageChangePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageChangePageFields.properties";
			waitSleep(1000);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditBtn", true, frame, "", "Edit Button");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickEidtBtn method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickEidtBtn method " + e);
			Assert.fail();
		}
	 }
}
