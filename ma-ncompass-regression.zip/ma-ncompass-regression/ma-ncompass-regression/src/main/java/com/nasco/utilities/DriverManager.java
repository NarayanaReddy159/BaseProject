package com.nasco.utilities;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;

public class DriverManager {

	public static ThreadLocal<WebDriver> dr = new ThreadLocal<WebDriver>();
	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();
	public static WebDriver getDriver() {

		return dr.get();

	}

	public static void setWebDriver(WebDriver driver) {

		dr.set(driver);
	}

	public static ExtentTest getExtentReport() {

		return testReport.get();
	}
	
	public static void setExtentReport(ExtentTest test) {

		testReport.set(test);

	}
	
//	public static void setLog(Logger  log) {
//
//		((ThreadLocal<Logger>) log).set(log);
//	}
//	
//	public static Logger getlog() {
//
//		return log.get();
//	}
//	public static void setConfig(Config  conf) {
//
//		config=conf;
//	}
//	
//	public static String getConfig(String key) {
//
//		return config.getProperty(key);
//	}
//	
//	public static Config getConfig() {
//
//		return config;	}
	
}
