package com.nasco.MA.Regression.Pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class Correspondence_RTCPage extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget2Ifr";
	String startDt="",endDt="";
	
	//@Override
	protected ExpectedCondition getPageLoadCondition() {
		//switchToFrame(frame1);
		switchToFrame(frame1);
		//return ExpectedConditions.visibilityOf(intentID);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
		
		
	}
		
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame1);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, frame1, "Select Customer Response Type", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	
	public void SelectCorr(String pageLocatorsPath,String pageFiledsPath) 
	{	
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame1);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CorrRadioBtn", true, frame1, "Correspondence", "Correspondence");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on SelectCorr method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on SelectCorr method " + e);
			Assert.fail();
		}
		
	}
		
	
	public void createCorr(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data,String frame)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame);
			switchToFrame(frame);
			
			waitSleep(4000);
			
			if(!data.get("Channel").equals("Email"))
			{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channel", true, frame, data.get("Channel"), "Channel");
			waitSleep(2500);
			}
			if(data.get("Channel").equals("Email"))
			{
				waitSleep(2500);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "emailAddress", true, frame, data.get("EMailAddress"), "eMailAddress");
				waitSleep(2500);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory"), "emailCategory");
				waitSleep(2500);
				//WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, "", "Press Tab");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
				waitSleep(5000);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory"), "emailCategory");
				waitSleep(2500);
				
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "EmailTemplateName", true, frame, data.get("EmailTemplateName"), "EmailTemplateName");
				waitSleep(5000);
			}
			if(data.get("Channel").equals("Mail"))
			{
				waitSleep(2500);
				//new Actions(driver).moveToElement(addressInfo).doubleClick().build().perform();
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addressInfo", true, frame, "", "Address Info");
				/*WebElementAction("click",pageLocatorsPath, pageFiledsPath, "temporaryaddress", true, frame, "", "Temporary address");
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "addressLine1", true, frame, "Test", "Address Line1");
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "City", true, frame, "Test", "City");
				*/
				waitSleep(2000);
			}
			if(data.get("Channel").equals("Fax"))
			{
				waitSleep(2500);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "1234567890", "FaxNumber");
				waitSleep(2500);
				WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
				//waitSleep(2500);
				//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
				waitSleep(4000);
			}
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(9000);
			if(!data.get("Channel").equals("Fax"))
			{
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame, data.get("LetterName"), "Letter Name");
				waitSleep(2500);
				
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attach", true, frame, "", "Attach");
				//NTestScript.logScreenshotReport(context, testSetup);
			}
			if(data.get("Channel").equals("Mail"))
			{
				waitSleep(2500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
				waitSleep(5000);
			}
			if(data.get("Channel").equals("Email"))
			{
				
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame, data.get("LetterName"), "Letter Name");
				waitSleep(5000);
				
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
				waitSleep(5000);

			}
			if(data.get("Channel").equals("Fax"))
			{
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame, data.get("LetterName"), "Letter Name");
				waitSleep(2500);
				
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attach", true, frame, "", "Attach");
				
				waitSleep(2500);
				
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
				waitSleep(4000);
			}
			waitSleep(3000);
		}catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createCorr method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createCorr method " + e);
			Assert.fail();

		}
	}
	
	
	public void createCorr(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
//			waitForframe1TobeVisible(frame1);
			switchToFrame(frame1);
			
			waitSleep(4000);
			
			if(!data.get("Channel").equals("Email"))
			{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channel", true, frame1, data.get("Channel"), "Channel");
			waitSleep(2500);
			}
			if(data.get("Channel").equals("Email"))
			{
				waitSleep(4000);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "emailAddress", true, frame1, data.get("EMailAddress"), "eMailAddress");
				waitSleep(2500);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame1, data.get("EmailCategory"), "emailCategory");
				waitSleep(2500);
				//WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame1, "", "Press Tab");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(5000);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame1, data.get("EmailCategory"), "emailCategory");
				waitSleep(2500);
				
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "EmailTemplateName", true, frame1, data.get("EmailTemplateName"), "EmailTemplateName");
				waitSleep(5000);
			}
			if(data.get("Channel").equals("Mail"))
			{
				waitSleep(6000);
				//new Actions(driver).moveToElement(addressInfo).doubleClick().build().perform();
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addressInfo", true, frame1, "", "Address Info");
				waitSleep(2000);
			}
			if(data.get("Channel").equals("Fax"))
			{
				waitSleep(2500);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame1, "1234567890", "FaxNumber");
				waitSleep(2500);
				WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame1, "", "Press Tab");
				//waitSleep(2500);
				//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(4000);
			}
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CategoryCorr", true, frame1, data.get("Category"), "Category");
			waitSleep(9000);
			if(!data.get("Channel").equals("Fax"))
			{
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
				waitSleep(2500);
				
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attach", true, frame1, "", "Attach");
				//NTestScript.logScreenshotReport(context, testSetup);
			}
			if(data.get("Channel").equals("Mail"))
			{
				waitSleep(2500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(5000);
			}
			if(data.get("Channel").equals("Email"))
			{
				
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
				waitSleep(5000);
				
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(5000);

			}
			if(data.get("Channel").equals("Fax"))
			{
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
				waitSleep(2500);
				
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attach", true, frame1, "", "Attach");
				
				waitSleep(2500);
				
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(4000);
			}
			waitSleep(3000);
			waitSleep(6000);
		}catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createCorr method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createCorr method " + e);
			Assert.fail();

		}
	}
	
	public String getRTCIntentIDOnWB(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame1);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionIDonWB", true, frame1, "Select Customer Response Type", "Intent ID");
			String intid[] = intentid.split(":");
			intentid= intid[1].substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	public void createCorrMail(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channel", true, frame, data.get("Channel1"), "Channel");
			waitSleep(3500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channel", true, frame, data.get("Channel"), "Channel");
			waitSleep(3500);
			
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addressInfo", true, frame, "", "Address Info");
//			waitSleep(2000);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "temporaryaddress", true, frame, "", "Send to temporary address");
			waitSleep(3000);
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Attention", true, frame, data.get("Attention"), "Attention");
			waitSleep(2000);
	//		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "name", true, frame, data.get("Name"), "name");

		    WebElementAction("type",pageLocatorsPath, pageFiledsPath, "addressline1", true, frame, data.get("Address line 1"), "Address line 1");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "city", true, frame, data.get("City"), "city");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "State", true, frame, data.get("State"), "State");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Zipcode", true, frame, data.get("Zip_code"), "Zip code");

//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addressInfo", true, frame, "", "Address Info");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category1"), "Category");
			
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame, data.get("LetterName"), "Letter Name");
			waitSleep(3000);
		    WebElementAction("type",pageLocatorsPath, pageFiledsPath, "memberphonenumber", true, frame, data.get("PhoneNumber"), "Member phone number");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "previewLetter", true, frame, "", "Preview Letter");
			waitSleep(5000);
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "memberphonenumber", true, frame, "", "Member phone number");
		    waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			
			waitSleep(2500);
		    String 	Documentname=WebElementAction("readtext",pageLocatorsPath, pageFiledsPath, "documentname", true, frame, "", "Document name");
		    String 	Documenttype=WebElementAction("readtext",pageLocatorsPath, pageFiledsPath, "documenttype", true, frame, "", "Document type");
		    waitSleep(3000);
		   // String 	Operator=WebElementAction("readtext",pageLocatorsPath, pageFiledsPath, "Operator", true, frame, "", "Operator	");
			String details=Documentname+"|"+Documenttype;
			//System.out.println(details);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}
	public void createCorrEMail(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			
		//	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Recipientnameemail", true, frame, "Caroline K Burns", "Recipient name");
		//	waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "emailAddress", true, frame, data.get("EMailAddress"), "eMailAddress");
			waitSleep(5000);
			//System.out.println(data.get("EmailCategory1"));
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory1"), "emailCategory");
			waitSleep(2500);
			//WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, "", "Press Tab");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(5000);

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory1"), "emailCategory");
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "EmailTemplateName", true, frame, data.get("EmailTemplateName"), "EmailTemplateName");
			waitSleep(5000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "categoryforemail", true, frame, data.get("Category1"), "Category");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame, data.get("LetterName"), "Letter Name");
			waitSleep(3000);
		    
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Copayment", true, frame, data.get("Copayment"), "Copayment");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Deductible", true, frame, data.get("Deductible"), "Deductible");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Benefitmaximums", true, frame, data.get("Benefitmaximums"), "Benefit maximums");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Firstservicename", true, frame, data.get("First service name"), "First service name");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReferralorAuthorization", true, frame, data.get("ReferralorAuthorization"), "ReferralorAuthorization");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "edit", true, frame, "", "edit");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);


		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}
	public void createCorrFax(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channel", true, frame, data.get("Channel"), "Channel");
			waitSleep(2500);
		//	WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Recipientname", true, frame, data.get("Recipient name"), "Recipient name");

			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "1234567890", "FaxNumber");
			waitSleep(2500);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
			//waitSleep(2500);
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(4000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(9000);
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PlanName", true, frame, data.get("PlanName"), "PlanName");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Monthlypremium", true, frame, data.get("Monthlypremium"), "Monthlypremium");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Premiumpaidyeartodate", true, frame, data.get("Premiumpaidyeartodate"), "Premiumpaidyeartodate");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateRangeOrCalendarYear", true, frame1, data.get("DateRangeOrCalendarYear"), "Calendar year");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateRangeOrCalendarYear", true, frame1, data.get("DateRangeOrCalendarYear1"), "Calendar year");
			waitSleep(2000);

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "DateRangeOrCalendarYear", true, frame1, data.get("DateRangeOrCalendarYear"), "Calendar year");
			waitSleep(5000);

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "CalendarYear", true, frame, data.get("CalendarYear"), "CalendarYear");
			waitSleep(5000);
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "edit", true, frame, "", "edit");
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ResetLetter", true, frame, "", "ResetLetter");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);


			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}
	
	public void CLMEMail(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "emailAddress", true, frame, data.get("EMailAddress"), "eMailAddress");
			waitSleep(5000);
			//System.out.println(data.get("EmailCategory1"));
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory1"), "emailCategory");
			waitSleep(2500);
			//WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, "", "Press Tab");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(5000);

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory1"), "emailCategory");
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "EmailTemplateName", true, frame, data.get("EmailTemplateName"), "EmailTemplateName");
			waitSleep(5000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "categoryforemail", true, frame, data.get("Category"), "Category");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame, data.get("LetterName"), "Letter Name");
			waitSleep(3000);
		    
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(5000);
			waitSleep(4000);


		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}

	public String Audithistory(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
		waitSleep(3500);
		switchToFrame("PegaGadget1Ifr");
		String AuditLog="";
		try {

		String parentWindow=driver.getWindowHandle();
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
		waitSleep(2000);
		for (String windowHandle : driver.getWindowHandles())
		{
			if(!parentWindow.equals(windowHandle)){
				 driver.switchTo().window(windowHandle);
				 //System.out.println("Switched to"+windowHandle);
			}
			//System.out.println(windowHandle);
			
		}
		
		switchToDefault();
		AuditLog="Intent created to generate a claims summary related to claim "+data.get("ClaimNumber") ;
		//System.out.println("NLID:"+AuditLog);
		test.log(LogStatus.INFO, "Intent ID:"+AuditLog);

		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$ppxResults$l')]"));
		ele.size();
		String s="//tr[contains(@id,'$ppxResults$l%d')]";
		for(int i=0;i<ele.size();i++)
		{
			String s1=String.format(s, i+1);
			//System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
			//System.out.println("NLID:"+AuditLog);
			if(driver.findElement(By.xpath(s1+"//td[2]")).getText().equals(AuditLog))
			{
		
				//System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
				test.log(LogStatus.PASS, "INTRACTIONID IS MATCHED IN HISTORY "+AuditLog);
				//System.out.println("INTRACTIONID IS  MATCHED IN HISTORY "+AuditLog);

				break;
			}
		} 
		
		
		driver.close();
		driver.switchTo().window(parentWindow);
		
		
		} catch (Exception e) {
	        e.printStackTrace();
	        @SuppressWarnings("unused")
			String excepionMessage = Arrays.toString(e.getStackTrace());
	        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
	        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
	        Assert.fail();


			
		}
		return AuditLog;

	}

	public void selectdetail(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			
			
			Select Category=new Select(driver.findElement(By.xpath("//label[contains(text(),'Category')]//following::select[1]")));
			//System.out.println(Category.getFirstSelectedOption().getText());
			Select Lettertemplatename=new Select(driver.findElement(By.xpath("//*[@id='LetterName']")));
			//System.out.println(Lettertemplatename.getFirstSelectedOption().getText());
			

		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}

	public void ConfirmnationEMail(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			
			
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "emailAddress", true, frame, data.get("EMailAddress"), "eMailAddress");
			waitSleep(5000);
			//System.out.println(data.get("EmailCategory1"));
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory1"), "emailCategory");
			waitSleep(2500);
			//WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, "", "Press Tab");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(5000);

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory1"), "emailCategory");
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "EmailTemplateName", true, frame, data.get("EmailTemplateName"), "EmailTemplateName");
			waitSleep(5000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "categoryforemail", true, frame, data.get("Category1"), "Category");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame, data.get("LetterName"), "Letter Name");
			waitSleep(3000);
		    
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Providername", true, frame, data.get("Provider name"), "Provider name");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "edit", true, frame, "", "edit");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);


		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}
	public void resolvedunsuccessful(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "resolvedunsuccessful", true, frame, "", "resolved unsuccessful");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comment", true, frame, "Resolved unsuccessful", "comments");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);

			
			

		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}

	public void researchEMail(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			
			
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "emailAddress", true, frame, data.get("EMailAddress"), "eMailAddress");
			waitSleep(5000);
			//System.out.println(data.get("EmailCategory1"));
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory1"), "emailCategory");
			waitSleep(2500);
			//WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, "", "Press Tab");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(5000);

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame, data.get("EmailCategory1"), "emailCategory");
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "EmailTemplateName", true, frame, data.get("EmailTemplateName"), "EmailTemplateName");
			waitSleep(5000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "categoryforemail", true, frame, data.get("Category1"), "Category");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame, data.get("LetterName"), "Letter Name");
			waitSleep(3000);
		    
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "option", true, frame, data.get("Options"), "Letter Name");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "edit", true, frame, "", "edit");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);


		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}
	public void resolvedFax(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channelfax", true, frame, data.get("Channel"), "Channel");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "1234567890", "FaxNumber");
			waitSleep(2500);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
			//waitSleep(2500);
			waitSleep(4000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(9000);
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(2500);
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			//System.out.println(dateFormat.format(date));
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Datepolicyended", true, frame, dateFormat.format(date), "Provider name");

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "edit", true, frame, "", "edit");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);


			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}
	
	public void createCorrFromGSI(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame1);
			
			waitSleep(4000);
			
			if(!data.get("Channel").equals("Email"))
			{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channel", true, frame1, data.get("Channel"), "Channel");
			waitSleep(2500);
			}
			if(data.get("Channel").equals("Email"))
			{
				waitSleep(2500);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "emailAddress", true, frame1, data.get("EMailAddress"), "eMailAddress");
				waitSleep(2500);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame1, data.get("EmailCategory"), "emailCategory");
				waitSleep(2500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(5000);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame1, data.get("EmailCategory"), "emailCategory");
				waitSleep(2500);
				
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "EmailTemplateName", true, frame1, data.get("EmailTemplateName"), "EmailTemplateName");
				waitSleep(5000);
			}
			if(data.get("Channel").equals("Mail"))
			{
				waitSleep(2500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addressInfo", true, frame1, "", "Address Info");
				waitSleep(2000);
			}
			if(data.get("Channel").equals("Fax"))
			{
				waitSleep(2500);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame1, "1234567890", "FaxNumber");
				waitSleep(2500);
				WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame1, "", "Press Tab");
				waitSleep(4000);
			}
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(4000);
//			}
			waitSleep(8000);
		}catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createCorr method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createCorr method " + e);
			Assert.fail();

		}
	}

	public void resolvedFaxIDC(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channelfax", true, frame, data.get("Channel"), "Channel");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "1234567890", "FaxNumber");
			waitSleep(2500);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
			//waitSleep(2500);
			waitSleep(4000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(9000);
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(2500);
			
			String Firstname=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "firstname", true, frame, "", "First name");
			
			
			String Lastname=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "lastname", true, frame, "", "Last name");
			String Streetaddress1=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "streetaddress1", true, frame, "", "Street address 1");
			String City=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "city", true, frame, "", "City");
			String Zipcode=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "Zipcode", true, frame, "", "Zipcode");
 			Select state=new Select(driver.findElement(By.xpath("(//*[@id='State'])[2]")));
            String display=Firstname+"|"+Lastname+"|"+Streetaddress1+"|"+City+"|"+Zipcode+"|"+state.getFirstSelectedOption().getText();
 			//System.out.println("display::"+display);
 			waitSleep(1500);
 			assertEquals(data.get("Excepted_autodispaly"), display, "Auto displayed");
		    WebElementAction("type",pageLocatorsPath, pageFiledsPath, "memberphonenumber", true, frame, data.get("PhoneNumber"), "Member phone number");
		    waitSleep(1500);
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "previewLetter", true, frame, "", "Preview Letter");
			waitSleep(5000);
		    
 			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(3000);
 			
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleteAttachment", true, frame, "", "DeleteAttachment");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(3000);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
		
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "memberphonenumber", true, frame, data.get("PhoneNumber"), "Member phone number");
		    waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(5000);
 			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);
			

			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		 
	}
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionIDcorr", true, frame, "", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	
	public void CorrEmailResend(String pageLocatorsPath,String pageFiledsPath) 
	{	
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			waitOnIE(5000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RTCReviewHarnessbtn", true, "PegaGadget1Ifr", "Respond to Customer", "RTC Review Harness Button");
			waitSleep(3000);
			String mainWindow=driver.getWindowHandle();
			//System.out.println("mainWindow"+mainWindow);
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
				//System.out.println("childWindow"+childWindow);

				if(!mainWindow.equals(childWindow)){
					driver.switchTo().window(childWindow);
					//System.out.println(driver.switchTo().window(childWindow).getTitle());
					waitSleep(2000);
					WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Resendbtn", true, "PegaGadget1Ifr", "Resend", "Resend Button");

					driver.close();
				}
			}
			driver.switchTo().window(mainWindow);

			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on CorrEmailResend method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on CorrEmailResend method " + e);
			Assert.fail();
		}
	}
	
	
	public void createCorrResend(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
//			waitForframe1TobeVisible(frame1);
			switchToFrame(frame1);
			
			waitSleep(4000);
			
			if(!data.get("Channel").equals("Email"))
			{
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channel", true, frame1, data.get("Channel"), "Channel");
			waitSleep(2500);
			}
			if(data.get("Channel").equals("Email"))
			{
				waitSleep(4000);
				waitOnIE(2000);
				//WebElementAction("type",pageLocatorsPath, pageFiledsPath, "emailAddress", true, frame1, data.get("EMailAddress"), "eMailAddress");
				//waitSleep(2500);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame1, data.get("EmailCategory"), "emailCategory");
				waitSleep(2500);
				waitOnIE(2000);
				//WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame1, "", "Press Tab");
				//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(5000);
				waitOnIE(5000);
				/*WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "emailCategory", true, frame1, data.get("EmailCategory"), "emailCategory");
				waitSleep(2500);
				waitOnIE(2000);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "EmailTemplateName", true, frame1, data.get("EmailTemplateName"), "EmailTemplateName");
				waitSleep(5000);*/
			}
			if(data.get("Channel").equals("Mail"))
			{
				waitSleep(6000);
				waitOnIE(6000);
				//new Actions(driver).moveToElement(addressInfo).doubleClick().build().perform();
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addressInfo", true, frame1, "", "Address Info");
				waitSleep(2000);
			}
			if(data.get("Channel").equals("Fax"))
			{
				waitSleep(2500);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame1, "1234567890", "FaxNumber");
				waitSleep(2500);
				WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame1, "", "Press Tab");
				//waitSleep(2500);
				//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(4000);
			}
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CategoryCorr", true, frame1, data.get("Category"), "Category");
			waitSleep(9000);
			if(!data.get("Channel").equals("Fax"))
			{
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
				waitSleep(2500);
				
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attach", true, frame1, "", "Attach");
				//NTestScript.logScreenshotReport(context, testSetup);
			}
			if(data.get("Channel").equals("Mail"))
			{
				waitOnIE(2000);
				waitSleep(2500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(5000);
				waitOnIE(2000);
			}
			if(data.get("Channel").equals("Email"))
			{
				
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
				waitSleep(5000);
				waitOnIE(2000);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(5000);
				waitOnIE(2000);
			}
			if(data.get("Channel").equals("Fax"))
			{
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
				waitSleep(2500);
				waitOnIE(2000);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attach", true, frame1, "", "Attach");
				
				waitSleep(2500);
				waitOnIE(2000);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame1, "", "Submit");
				waitSleep(4000);
			}
			waitSleep(3000);
		}catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createCorr method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createCorr method " + e);
			Assert.fail();

		}
	}
	
	
	
	public void researchFax(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channelfax", true, frame, data.get("Channel"), "Channel");
			waitSleep(5000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "1234567890", "FaxNumber");
			waitSleep(2500);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
			waitSleep(4000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(9000);
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(2500);
			
			waitSleep(1500);
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditLetter", true, frame, "Edit Letter", "Edit Letter");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ResetLetter", true, frame, "Reset Letter", "Reset Letter");
			waitSleep(2500);
 			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleteAttachment", true, frame, "", "DeleteAttachment");
			waitSleep(3000);
			waitOnIE(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(3000);
			waitOnIE(2000);
			waitOnIE(2000);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
			waitOnIE(2000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			
		    waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(5000);
 			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);
			

			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on researchFax method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on researchFax method " + e);
			Assert.fail();
		}
		 
	}
	
	public void createCorrFaxMedicareCMSACTIVE(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channelfax", true, frame, data.get("Channel"), "Channel");
			waitSleep(5000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "1234567890", "FaxNumber");
			waitSleep(2500);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
			
			waitSleep(4000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(9000);
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PlanName", true, frame, data.get("PlanName"), "PlanName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyStartDate", true, frame, data.get("PolicyStartDate"), "PolicyStartDate");
			waitSleep(2500);
						
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditLetter", true, frame, "Edit Letter", "Edit Letter");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ResetLetter", true, frame, "Reset Letter", "Reset Letter");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PlanName", true, frame, data.get("PlanName"), "PlanName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyStartDate", true, frame, data.get("PolicyStartDate"), "PolicyStartDate");
			waitSleep(2500);
			
			
 			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleteAttachment", true, frame, "", "DeleteAttachment");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(3000);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
		
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(1500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PlanName", true, frame, data.get("PlanName"), "PlanName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyStartDate", true, frame, data.get("PolicyStartDate"), "PolicyStartDate");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(5000);
 			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);
			

			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createCorrFaxMedicareCMSACTIVE method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createCorrFaxMedicareCMSACTIVE method " + e);
			Assert.fail();
		}
		 
	}
	
	
	public void createCorrFaxMedicareCMSCANCEL(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channelfax", true, frame, data.get("Channel"), "Channel");
			waitSleep(5000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "1234567890", "FaxNumber");
			waitSleep(2500);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
			waitSleep(4000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(9000);
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PlanName", true, frame, data.get("PlanName"), "PlanName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyStartDate", true, frame, data.get("PolicyStartDate"), "PolicyStartDate");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyEndDate", true, frame, data.get("PolicyEndDate"), "PolicyEndDate");
			waitSleep(2500);
						
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditLetter", true, frame, "Edit Letter", "Edit Letter");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ResetLetter", true, frame, "Reset Letter", "Reset Letter");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PlanName", true, frame, data.get("PlanName"), "PlanName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyStartDate", true, frame, data.get("PolicyStartDate"), "PolicyStartDate");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyEndDate", true, frame, data.get("PolicyEndDate"), "PolicyEndDate");
			waitSleep(2500);
			
 			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleteAttachment", true, frame, "", "DeleteAttachment");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(3000);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
		
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(1500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PlanName", true, frame, data.get("PlanName"), "PlanName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyStartDate", true, frame, data.get("PolicyStartDate"), "PolicyStartDate");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyEndDate", true, frame, data.get("PolicyEndDate"), "PolicyEndDate");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(5000);
 			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);
			

			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createCorrFaxMedicareCMSCANCEL method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createCorrFaxMedicareCMSCANCEL method " + e);
			Assert.fail();
		}
		 
	}
	
	public void createCorrFaxDirectPay(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channelfax", true, frame, data.get("Channel"), "Channel");
			waitSleep(5000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "1234567890", "FaxNumber");
			waitSleep(2500);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
			waitSleep(4000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(9000);
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyEndDate", true, frame, data.get("PolicyEndDate"), "PolicyEndDate");
			waitSleep(2500);
						
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditLetter", true, frame, "Edit Letter", "Edit Letter");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ResetLetter", true, frame, "Reset Letter", "Reset Letter");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyEndDate", true, frame, data.get("PolicyEndDate"), "PolicyEndDate");
			waitSleep(2500);
			
 			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleteAttachment", true, frame, "", "DeleteAttachment");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(3000);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
		
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(1500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PolicyEndDate", true, frame, data.get("PolicyEndDate"), "PolicyEndDate");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(5000);
 			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);
			

			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createCorrFaxDirectPay method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createCorrFaxDirectPay method " + e);
			Assert.fail();
		}
		 
	}
	
	
	public void createCorrFaxClaims(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "channelfax", true, frame, data.get("Channel"), "Channel");
			waitSleep(5000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "1234567890", "FaxNumber");
			waitSleep(2500);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");
			waitSleep(4000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(9000);
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, frame, "1234567890", "ClaimNumber");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ProviderName", true, frame, data.get("ProviderName"), "ProviderName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PatientFirstName", true, frame, data.get("PatientFirstName"), "PatientFirstName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PatientLastName", true, frame, data.get("PatientLastName"), "PatientLastName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Date1", true, frame, data.get("Date1"), "Date1");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Date2", true, frame, data.get("Date2"), "Date2");
			waitSleep(4000);
			driver.findElement(By.xpath("//span[contains(text(),'Reason claim denied')]")).click();
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ReasonOfClaimDenied", true, frame, "Testing", "ReasonOfClaimDenied");
			waitSleep(3000);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditLetter", true, frame, "Edit Letter", "Edit Letter");
			waitSleep(5000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ResetLetter", true, frame, "Reset Letter", "Reset Letter");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, frame, data.get("ClaimNumber"), "ClaimNumber");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ProviderName", true, frame, data.get("ProviderName"), "ProviderName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PatientFirstName", true, frame, data.get("PatientFirstName"), "PatientFirstName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PatientLastName", true, frame, data.get("PatientLastName"), "PatientLastName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Date1", true, frame, data.get("Date1"), "Date1");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Date2", true, frame, data.get("Date2"), "Date2");
			waitSleep(4000);
			driver.findElement(By.xpath("//span[contains(text(),'Reason claim denied')]")).click();
			waitSleep(1500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ReasonOfClaimDenied", true, frame, "Testing", "ReasonOfClaimDenied");
			waitSleep(2500);
			
 			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deleteAttachment", true, frame, "", "DeleteAttachment");
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "EditSubmit", true, frame, "", "EditSubmit");
			waitSleep(3000);
			WebElementAction("pressTab",pageLocatorsPath, pageFiledsPath, "faxNumber", true, frame, "", "Press Tab");

			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, frame, data.get("Category"), "Category");
			waitSleep(3000);
		
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "letterName", true, frame1, data.get("LetterName"), "Letter Name");
			waitSleep(1500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ClaimNumber", true, frame, data.get("ClaimNumber"), "ClaimNumber");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ProviderName", true, frame, data.get("ProviderName"), "ProviderName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PatientFirstName", true, frame, data.get("PatientFirstName"), "PatientFirstName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "PatientLastName", true, frame, data.get("PatientLastName"), "PatientLastName");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Date1", true, frame, data.get("Date1"), "Date1");
			waitSleep(2500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Date2", true, frame, data.get("Date2"), "Date2");
			waitSleep(4000);
			driver.findElement(By.xpath("//span[contains(text(),'Reason claim denied')]")).click();
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ReasonOfClaimDenied", true, frame, "Testing", "ReasonOfClaimDenied");
			waitSleep(2500);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Attachbutton", true, frame, "", "Attach");
			waitSleep(5000);
 			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "", "Submit");
			waitSleep(8000);
			

			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on createCorrFaxClaims method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on createCorrFaxClaims method " + e);
			Assert.fail();
		}
		 
	}
	public String getIntentIDRTC(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Correspondence_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Correspondence_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(5000);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionIDcorr", true, frame, "Create correspondence", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	
}

