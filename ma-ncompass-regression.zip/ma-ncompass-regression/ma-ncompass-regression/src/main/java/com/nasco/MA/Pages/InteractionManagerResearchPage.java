package com.nasco.MA.Pages;


import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;


@SuppressWarnings("rawtypes")
public class InteractionManagerResearchPage extends BasePage {
	
	
	
	Actions builder=new Actions(driver);
	
	@FindBy(how=How.XPATH, using ="//div[contains(text(),'Add task')]//ancestor::button")
	public WebElement addTask;
	
	String excepionMessage="";
	
	public void addTaskResearch(String taskName,String pageLocatorsPath,String pageFiledsPath) {
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTaskResearch", true, "PegaGadget1Ifr", "", "add Task");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr", taskName, "Intent");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTasks", true, "PegaGadget1Ifr", "", "Add Tasks");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTaskResearch method " + e);
			test.log(LogStatus.FAIL, "Error on addTaskResearch method " + e);
			Assert.fail();
		}
	}
	
	public void endResearch(String pageLocatorsPath,String pageFiledsPath) throws Exception{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(3500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "endResearch", true, "PegaGadget1Ifr", "End research", "End Research");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on endResearch method " + e);
			test.log(LogStatus.FAIL, "Error on endResearch method " + e);
			Assert.fail();	
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public RCEPage open() {
		
		return (RCEPage) openPage(RCEPage.class);
	}	
	
	@SuppressWarnings("unchecked")
	public WorkbasketPage openworkBasket() {
		
		return (WorkbasketPage) openPage(WorkbasketPage.class);
	}
	
	@SuppressWarnings("unchecked")
	public RecentWorkPage openrecentWork() {
		
		return (RecentWorkPage) openPage(RecentWorkPage.class);
	}
	
	
	@SuppressWarnings("unchecked")
	public ManageOtherCoveragePage openMOC() {
		
		return (ManageOtherCoveragePage) openPage(ManageOtherCoveragePage.class);
	}	

	public void logout()
	{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//a[contains(text(),'New')]//following::a[2]")).click();
		waitSleep(500);
		driver.findElement(By.xpath("//span[contains(text(),'Logout')]")).click();
		waitSleep(500);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		waitSleep(2500);
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(addTask);
	}
	public void IntentsDisplayed(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	 
	{
		try {
				pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
				switchToFrame("PegaGadget1Ifr");
				waitSleep(5000);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTaskResearch", true, "PegaGadget1Ifr", "", "add Task");
				String Managehecks = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr", data.get("Manage Checks"), "Manage Checks Intent");
				assertEquals("Manage Checks",Managehecks, "Manage Checks");
				String ManageClaims = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr", data.get("Manage Claims"), "Manage Claims Intent");
				assertEquals("Manage Claims",ManageClaims, "Manage Claims");
				String ManageOtherCoverage = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr", data.get("Manage Other Coverage"), "ManageOtherCoverage Intent");
				assertEquals("Manage Other Coverage",ManageOtherCoverage, "Manage Other Coverage");
				String UpdateMember = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr", data.get("Update Member"), "Update MemberIntent");
				assertEquals("Update Member",UpdateMember, "Update Member");
				String ViewAuthorizations = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr",data.get( "View Authorizations"), "ViewAuthorizations Intent");
				assertEquals("View Authorizations",ViewAuthorizations, "View Authorizations");
				String ViewBenefits = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr", data.get("View Benefits"), "ViewBenefits Intent");
				assertEquals("View Benefits",ViewBenefits, "View Benefits");
				String ViewTotals = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr",data.get( "View Totals"), "ViewTotals Intent");
				assertEquals("View Totals",ViewTotals, "View Totals");
				String FindAProvider = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "taskName", true, "PegaGadget1Ifr", data.get("Find a Provider"), "Find A Provider Intent");
				assertEquals("Find A Provider",FindAProvider, "Find A Provider");

				//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Cancel", true, "PegaGadget1Ifr", "Cancel", "Cancel");
		
		} catch (Exception e){
            e.printStackTrace();
            excepionMessage = Arrays.toString(e.getStackTrace());
            BaseTest.log.error("Error on clickOtherActions method" + excepionMessage);
            test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
            Assert.fail();

		}
		
	
	}
	public void endResearch(String pageLocatorsPath,String pageFiledsPath,String frame) throws Exception{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(3500);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "endResearch", true, frame, "End research", "End Research");
			waitSleep(3500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitResearch", true, frame, "Sumbit research", "End Research");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on endResearch method " + e);
			test.log(LogStatus.FAIL, "Error on endResearch method " + e);
			Assert.fail();	
		}
		
	}
	public void endResearchintent(String pageLocatorsPath,String pageFiledsPath,String frame) throws Exception{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(3500);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "endResearch", true, frame, "End research", "End Research");
			waitSleep(3500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitResearch", true, frame, "Sumbit research", "End Research");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on endResearch method " + e);
			test.log(LogStatus.FAIL, "Error on endResearch method " + e);
			Assert.fail();	
		}
		
	}

	
	public void endResearchviewBenefits(String pageLocatorsPath,String pageFiledsPath) throws Exception{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(4000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "endResearch", true, "PegaGadget2Ifr", "End research", "End Research");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on endResearch method " + e);
			test.log(LogStatus.FAIL, "Error on endResearch method " + e);
			Assert.fail();	
		}
		
	}
	
	
	public void endResearchManageChecks(String pageLocatorsPath,String pageFiledsPath) throws Exception{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(4000);
			switchToFrame("PegaGadget3Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "endResearch", true, "PegaGadget3Ifr", "End research", "End Research");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on endResearch method " + e);
			test.log(LogStatus.FAIL, "Error on endResearch method " + e);
			Assert.fail();	
		}
	}
	
	public void endResearchOnAddtask(String pageLocatorsPath,String pageFiledsPath, String frame) throws Exception{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "endResearch", true, frame, "End research", "End Research");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on endResearchOnAddtask method " + e);
			test.log(LogStatus.FAIL, "Error on endResearchOnAddtask method " + e);
			Assert.fail();	
		}
	}
}
