package com.nasco.MA.Regression.Pages;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class ViewTotals extends BasePage {

	@FindBy(xpath="//label[@id='pyActionLabel']//following::span[1]")
	public WebElement intentID;
	
	String excepionMessage="";
	String frame="PegaGadget2Ifr";
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		//switchToFrame("frame");
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame);
	}
	

	
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewTotalsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewTotalsPageFields.properties";
			switchToFrame(frame);
			waitSleep(2000);
	     	waitOnIE(2000);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, frame, "View Totals", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
		
	public void closeintentwithCmments(String pageLocatorsPath,String pageFiledsPath, String comments){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewTotalsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewTotalsPageFields.properties";
			switchToFrame(frame);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, frame, comments, "View Authorization Comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closebutton", true, frame, comments, "View Authorization Close");
			waitOnIE(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on  closeintentwithNotes method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on  closeintentwithNotes method " + e);
			Assert.fail();
		}
	}

	public void clickOtherActions(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{	
			pageLocatorsPath= pageLocatorsPath+"\\ViewTotalsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewTotalsPageFields.properties";
			//switchToFrame(frame);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActions", true, frame, "", "Other Actions");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOtherActions method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
			Assert.fail();
		}
	}
			
	public void clickViewBenefits(String pageLocatorsPath,String pageFiledsPath,String frame){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewTotalsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewTotalsPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ViewBenefits", true, frame, "", "View Benefits");
			waitSleep(4000);
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RequestCostEstimate", true, frame, "", "RequestCostEstimate");
//			waitSleep(3000);
//			switchToFrame("PegaGadget3Ifr");
//			String actualstr = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "RequestCostEstimateDisplay", true, "PegaGadget3Ifr", "", "RequestCostEstimate");
//			assertEquals(data.get("ExpectedReqCostEst"),actualstr,"ExpectedReqCostEst");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on OtherActions method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on OtherActions method " + e);
			Assert.fail();
		}
		
	}
	
	public void validateHistory(String pageLocatorsPath,String pageFiledsPath,String frame){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewTotalsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewTotalsPageFields.properties";
			switchToFrame(frame);
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ViewBenefits", true, frame, "", "View Benefits");
			waitSleep(4000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on OtherActions method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on OtherActions method " + e);
			Assert.fail();
		}
		
	}
	
	public void validateIntentID(String pageLocatorsPath,String pageFiledsPath,String expintId,String frame) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewTotalsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewTotalsPageFields.properties";
			switchToFrame(frame);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, frame, "View Totals", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			assertEquals(expintId,intentid,"Intent Id ");
			//test.log(LogStatus.INFO, "Navigate bach to View Totals Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}
	
	public void getClaimDetails(String pageLocatorsPath,String pageFiledsPath,String reqdate,String frame) 
	{
		try{	
			pageLocatorsPath= pageLocatorsPath+"\\ViewTotalsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewTotalsPageFields.properties";
			//switchToFrame(frame);
			switchToFrame(frame);
			WebElementAction("clear",pageLocatorsPath, pageFiledsPath, "Requestdate", true, frame, "", "Request date");
			waitSleep(1000);
			//WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Enddate", true, frame1, newenddate, "End date");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Requestdate", true, frame, reqdate, "Request date");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Filter", true, frame, "Filter", "Filter");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getClaimDetails method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getClaimDetails method " + e);
			Assert.fail();
		}
	}

	@SuppressWarnings("unused")
	public void validateFinalizeddate(String pageLocatorsPath,String pageFiledsPath,String claimid, String frame){
		String actualClm="",finalizeddate="";
		try{ //'$PpyWorkPage$ppyWorkParty$gMember$pTotals$l1$ppySelected
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			switchToFrame(frame);
//			switchToDefault();
			waitSleep(2000);
			List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gMember$pTotals')]"));
			//System.out.println("tablerows "+tablerows.size());
			String s="(//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gMember$pTotals')])[%d]";  
			for(int i=0;i<tablerows.size();i++)
			{  //$PD_pyWorkHistory_pa58165677102201993pz$ppxResults$l3
				String s1=String.format(s, i+1);
				////System.out.println("Message "+driver.findElement(By.xpath(s1+"//td[2]//input[2]")).getText());
				driver.findElement(By.xpath(s1+"//td[2]//input[2]")).click();
				
				//(//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gMember$pTotals') and contains(@id,'$pAccumsClaims')])[1]//td[2]//a
				waitSleep(2000);
				List<WebElement> claimsrows= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gMember$pTotals') and contains(@id,'$pAccumsClaims')]"));
				String c="(//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gMember$pTotals') and contains(@id,'$pAccumsClaims')])[%d]";
				for(int j=0;j<claimsrows.size();j++){
					String c1=String.format(c, j+1);
					actualClm = driver.findElement(By.xpath(c1+"//td[2]//a")).getText();
					
					if( actualClm.equalsIgnoreCase(claimid) ) 
					{
						assertEquals(claimid,actualClm,"Claim Id");
						finalizeddate=driver.findElement(By.xpath(c1+"//td[13]//span")).getText();
						if (!finalizeddate.isEmpty()){
							test.log(LogStatus.PASS, "Finalized date is populated as: " + finalizeddate);
							BaseTest.log.debug("Finalized date is populated as: " + finalizeddate);
	
						} else {
							test.log(LogStatus.FAIL, "Finalized date is not populated" );
							BaseTest.log.debug("Finalized date is not populated");
							Assert.fail("Finalized date is not populated");
					}
					waitSleep(4000);
					driver.findElement(By.xpath(c1+"//td[2]//a")).click();
					waitSleep(3000);
					selectClaim(pageLocatorsPath,pageFiledsPath,claimid);
					break;
						
				}
			}
			break;	
		}	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on ValidateFinalizeddate method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on ValidateFinalizeddate method " + e);
			Assert.fail();
		}
		
	}
	
	public void selectClaim(String pageLocatorsPath,String pageFiledsPath,String claimid){
		try{ //'$PpyWorkPage$ppyWorkParty$gMember$pTotals$l1$ppySelected
			waitSleep(2000);
			switchToDefault();
			//System.out.println("Inside select claim");
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
				if(!mainWindow.equals(childWindow)){
					driver.switchTo().window(childWindow);
					waitSleep(1000);
					//System.out.println("Title"+driver.switchTo().window(childWindow).getTitle());
					
					String actualMsg = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Claimnumber", true, frame, "Claim number", "Claimnumber");
					if( actualMsg.equalsIgnoreCase(claimid) ) 
					{	//System.out.println("Inside if statement");
						assertEquals(claimid,actualMsg,"Claim Number");
						break;
							
					}
					
					driver.close();
				}
			}
			driver.switchTo().window(mainWindow);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on selectClaim method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on selectClaim method " + e);
			Assert.fail();
		}
		
	}

}
