package com.nasco.MA.Regression.Pages;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class Manage_ChecksPage extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget2Ifr";
	String startDt="",endDt="";
	
	//@Override
	protected ExpectedCondition getPageLoadCondition() {
		//switchToFrame(frame1);
		switchToFrame(frame1);
		//return ExpectedConditions.visibilityOf(intentID);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
		
		
	}
		
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Manage_ChecksPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Manage_ChecksPageFields.properties";
			switchToFrame(frame1);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "intentID", true, frame1, "Find A Provider", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	
	public String getCheckIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Manage_ChecksPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Manage_ChecksPageFields.properties";
			switchToFrame("PegaGadget3Ifr");
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "chkintentID", true, "PegaGadget3Ifr", "Find Check", "Intent ID");
			//= intentid.substring(1, intentid.length()-1);
			//System.out.println("IntentID::::::::::::::::::::::::" + intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, "PegaGadget3Ifr","", "search button");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	public String getNLID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String NLID="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Manage_ChecksPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Manage_ChecksPageFields.properties";
			waitSleep(2500);
			//switchToFrame("PegaGadget1Ifr");
			switchToDefault();
			NLID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "", "Search For Claim", "Intent ID");
			//intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println("NLID:"+NLID);
			test.log(LogStatus.INFO, "Intent ID:"+NLID);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return NLID;
	}
	public void noActionCheck(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Manage_ChecksPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Manage_ChecksPageFields.properties";
			waitSleep(2500);
			switchToFrame(frame);
		
		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "checknumber", true, frame,"850110074", "Check number");
		waitSleep(2500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "search", true, frame,"", "search button");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectCheck", true, frame,"", "selectCheck");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "noAction", true, frame,"", "noAction");

		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame,"", "search button");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}
	public String getIntentID1(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Manage_ChecksPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Manage_ChecksPageFields.properties";
			switchToFrame(frame);
			waitSleep(3500);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionIDclm", true, frame, "Search For Claim", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	public void createGSI_CliamsYes(String pageLocatorsPath,String pageFiledsPath,String category,String subCategory,String comment)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\GSIPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\GSIPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "category", true, "PegaGadget1Ifr", category, "Category");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget1Ifr", subCategory, "Sub Category");
			waitSleep(2000);
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget1Ifr", "", "Submit");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget1Ifr", comment, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget1Ifr", "", "Submit");

			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			BaseTest.log.error("Error on createGSI_CliamsYes method " + e);
			test.log(LogStatus.FAIL, "Error on createGSI_CliamsYes method " + e);
			Assert.fail();

		}
	}
	
	public void resolveCLM(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "responseComments", true, "PegaGadget1Ifr", "Resolving Intent","Comments");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "responseresolve", true, "PegaGadget1Ifr", "responseResolve", "Response Resolve");
			waitSleep(3000);
			WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "submit", true, "PegaGadget1Ifr", "","Submit");
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on resolveMOC method " + e);
			test.log(LogStatus.FAIL, "Error on resolveMOC method " + e);
			Assert.fail();
			}
		
		}
	public void requestCopyCheck(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
			
			try{
				pageLocatorsPath= pageLocatorsPath+"\\Manage_ChecksPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Manage_ChecksPageFields.properties";
				waitSleep(2500);
				switchToFrame(frame);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherAction", true, frame,"", "otherAction");
				waitSleep(2500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RequestCopyofCheck", true, frame,"", "RequestCopyofCheck");
				waitSleep(4000);
				WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Requestreason", true, frame,data.get("Requestreason"), "Requestreason");
				waitSleep(3000);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "checknumber", true, frame,"850110074", "Check number");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "search", true, frame,"", "search button");
				waitSleep(2500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectCheck", true, frame,"", "selectCheck");
				waitSleep(2500);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Comments", true, frame,"Testing Request copy of check", "Comments");

				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "next", true, frame,"", "next button");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on requestCopyCheck method " + e);
				test.log(LogStatus.FAIL, "Error on requestCopyCheck method " + e);
				Assert.fail();
			}
		
	}
	
	public String  resolvedate(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{ 
		String Resolvedate="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			waitSleep(1500);
			switchToFrame(frame);
			waitSleep(2500);
			Properties pageLocatorsprop = new Properties();
			FileInputStream FiledsIn = new FileInputStream(pageLocatorsPath);
			pageLocatorsprop.load(FiledsIn);
			
			try{
				Resolvedate=driver.findElement(By.xpath("(//span[contains(text(),'Resolve date')])[2]")).getText();
//			Resolvedate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "resolvedate", true, frame, "Resolvedate", "Resolvedate");
//				Resolvedate= readText(pageLocatorsprop.getProperty("resolvedateWebElementtype"),
//				pageLocatorsprop.getProperty("resolvedateWebElementvalue"), "");
				test.log(LogStatus.PASS, "Resolvedate is  found " + Resolvedate);

			}
			catch(Exception e)
			{
				test.log(LogStatus.PASS, "Resolvedate is not found " + Resolvedate);

			}
			//System.out.println(Resolvedate);
			waitSleep(5000);
            WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Resolvedate is not found " + Resolvedate);
			Assert.fail();
		}
		return Resolvedate;
	}
	public void noActionCheckAll(String pageLocatorsPath,String pageFiledsPath,String frame,Hashtable<String,String> data) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Manage_ChecksPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Manage_ChecksPageFields.properties";
			waitSleep(2500);
			switchToFrame(frame);
		
		WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "selectAll", true, frame,"All", "All");
		waitSleep(2500);
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "search", true, frame,"", "search button");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectCheck", true, frame,"", "selectCheck");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "noAction", true, frame,"", "noAction");

		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame,"", "search button");
		waitSleep(2500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}	
		public void OtherActionsManageChecks(String pageLocatorsPath,String pageFiledsPath){
			try{
				pageLocatorsPath= pageLocatorsPath+"\\Manage_ChecksPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Manage_ChecksPageFields.properties";
				switchToFrame("PegaGadget2Ifr");
				waitSleep(2500);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherAction", true, "PegaGadget2Ifr", "", "OtherActions");
				waitSleep(4000);
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ManagerChecks", true, "PegaGadget2Ifr", "Manage checks", "Manage Checks");
				waitSleep(3000);
				//switchToFrame("PegaGadget3Ifr");
				//String actualstr = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "RequestCostEstimateDisplay", true, "PegaGadget3Ifr", "", "RequestCostEstimate");
				//assertEquals(data.get("ExpectedReqCostEst"),actualstr,"ExpectedReqCostEst");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on OtherActionsManageChecks method " + e);
				test.log(LogStatus.FAIL, "Error on OtherActionsManageChecks method " + e);
				Assert.fail();
			}
			
		}
		public String getCheckIntentID(String pageLocatorsPath,String pageFiledsPath,String frame) 
		{	
			String intentid="";
			try{
				pageLocatorsPath= pageLocatorsPath+"\\Manage_ChecksPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Manage_ChecksPageFields.properties";
				switchToFrame(frame);
				intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "chkintentID", true, frame, "Find Check", "Intent ID");
				//= intentid.substring(1, intentid.length()-1);
				//System.out.println("IntentID::::::::::::::::::::::::" + intentid);
				test.log(LogStatus.INFO, "Intent ID:"+intentid);
				//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, "PegaGadget3Ifr","", "search button");
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				String excepionMessage = Arrays.toString(e.getStackTrace());
				BaseTest.log.error("Error on getIntentID method " + excepionMessage);
				test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
				Assert.fail();
			}
			return intentid;
		}
		
		public String getNonLID(String pageLocatorsPath,String pageFiledsPath) 
		{	
			String NLID="";
			try{
				pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
				waitSleep(2500);
				//switchToFrame("PegaGadget1Ifr");
				switchToDefault();
				NLID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "NoninteractionID", true, "", "Search For Claim", "Intent ID");
				//intentid= intentid.substring(1, intentid.length()-1);
				//System.out.println("ID:"+NLID);
				test.log(LogStatus.INFO, "Intent ID:"+NLID);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on getIntentID method " + e);
				test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
				Assert.fail();
			}
			return NLID;
		}
		
	}
	




