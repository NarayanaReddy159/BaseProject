package com.nasco.MA.Regression.Pages;


import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
@SuppressWarnings("rawtypes")
public class RecentWorkPage extends BasePage{

	
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	
	@FindBy(xpath = "//a[contains(text(),'My Work')]")
	public WebElement myWork;
	
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		switchToFrame("PegaGadget0Ifr");
		return ExpectedConditions.visibilityOf(myWork);
	}
	public String validateStatus(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) throws Exception
	{
		String text="";
		pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
		waitSleep(2500);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2500);
		text=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", "", "Status Intent ID");
		waitSleep(2500);
		//System.out.println("Status:"+text);
		assertEquals(data.get("Expected_Status"), text, "Expected_Status");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");
		waitSleep(2500);
		return text;
		
	}
	
	public void movetoRecentWorkPage(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
			waitSleep(4500);
			switchToFrame("PegaGadget0Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "recentWork", true, "PegaGadget0Ifr", "", "RecentWork tab");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
			test.log(LogStatus.FAIL, "Error on movetoRecentWorkPage method " + e);
			Assert.fail();
		}
	}
	
	
	
	public void sortandSelectIntent(String pageLocatorsPath,String pageFiledsPath, String intentId) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
			
			switchToFrame("PegaGadget0Ifr");
			waitSleep(2000);
			waitOnIE(3000);

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "idSort", true, "PegaGadget0Ifr", "", "ID Sort");
			waitSleep(3000);
			waitOnIE(3500);
			BaseTest.log.debug("Click the id sort filter");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchID", true, "PegaGadget0Ifr", intentId, "Search intent");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "applyBtn", true, "PegaGadget0Ifr", "", "Apply");
			waitSleep(5000);
			WebElementAction("doubleClick",pageLocatorsPath, pageFiledsPath, "intentclick", true, "PegaGadget0Ifr", intentId, "Intent "+intentId);
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
		
	}
	

	public void performOtherActions(String pageLocatorsPath,String pageFiledsPath
			,String memberFullID, String Comments) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActionsbtn", true, "PegaGadget1Ifr", "", "Other Actions");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addComment", true, "PegaGadget1Ifr", "Add comment", "Add Comment");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget1Ifr", Comments, "Enter Comment");
			waitSleep(2500);
			WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "Submitbtn", true, "PegaGadget1Ifr", "", "Submit Button");
			waitSleep(3500);
			String actualMeberid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "memberID", true, "PegaGadget1Ifr", "Member ID", "Member ID");
			assertEquals(memberFullID, actualMeberid, "Member ID");
			waitSleep(5000);
			String actualCommnets=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "addedCommnets", true, "PegaGadget1Ifr", Comments, "Comments");
			assertEquals(Comments, actualCommnets, "Comments");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on performOtherActions method " + e);
			test.log(LogStatus.FAIL, "Error on performOtherActions method " + e);
			Assert.fail();
		}
	}
	
	public void verifyotherActions(String pageLocatorsPath,String pageFiledsPath,String memberFullID) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			String actualMeberid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "memberID", true, "PegaGadget1Ifr", "Member ID", "Member ID");
			assertEquals(memberFullID, actualMeberid, "Member ID");
			try{
				//ClickWebelement("xpath", "//button[contains(text(),'Other actions')]", "");
				driver.findElement(By.xpath("//button[contains(text(),'Other actions')]")).click();
			}
			catch(Exception e)
			{
				test.log(LogStatus.PASS, "Other Actions button not available");
			}
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on verifyotherActions method " + e);
			test.log(LogStatus.FAIL, "Error on verifyotherActions method " + e);
			Assert.fail();
		}
		
	}
	
	public void validateRecentWork(String pageLocatorsPath,String pageFiledsPath,String memberFullID,String status,String MemID, String channel,String CreateOperator,String ResolveOperator,String category,String subCategory) 
	{
		try{
			String actualMeberid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "memberID", true, "PegaGadget1Ifr", "Member ID", "Member ID");
			assertEquals(memberFullID, actualMeberid, "Member ID");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
	
	public void ValidateResolvedIntent(String pageLocatorsPath,String pageFiledsPath,String status) throws Exception
	{
		try {
			switchToDefault();
			switchToFrame("PegaGadget1Ifr");
			pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
			waitSleep(3000);
			String Actualstatus= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget0Ifr", "", "Status");
			assertEquals(Actualstatus, status, "Status");
        } catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on ValidateResolvedIntent method " + e);
            test.log(LogStatus.FAIL, "Error on ValidateResolvedIntent method " + e);
            Assert.fail();

        }

	}
	
	public String getClaimID(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		String text="";
		try {
			pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			text=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "claimIntentID", true, "PegaGadget1Ifr", "", "Manage claim Intent ID");
			waitSleep(2500);
			//System.out.println("Clm:"+text);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");
			waitSleep(2500);
		} catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on getClaimID method" + e);
            test.log(LogStatus.FAIL, "Error on getClaimID method " + e);
            Assert.fail();

		}
		return text;
		
	}
		
	public String closeIntent(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		String text="";
		try {
			pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");
			waitSleep(2500);
		} catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on getClaimID method" + e);
            test.log(LogStatus.FAIL, "Error on getClaimID method " + e);
            Assert.fail();

		}
		return text;
		
	}
	public String validateEmailtemplatename(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) throws Exception
	{
		String text="";
		pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
		waitSleep(2500);
		switchToFrame("PegaGadget1Ifr");
		waitSleep(2500);
		text=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "emailtemplatename", true, "PegaGadget1Ifr", "", "Email template name");
		waitSleep(2500);
		//System.out.println("Status:"+text);
		assertEquals(data.get("EmailTemplateName"), text, "Email Template Name");
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");
		waitSleep(2500);
		return text;
		
	}
	
	public void resolveDate()
	{
		try {
			switchToFrame("PegaGadget1Ifr");
			try{
				driver.findElement(By.xpath("(//span[contains(text(),'Resolve date')])[2]")).getText();
				test.log(LogStatus.PASS, "Resolved date is available on recent work page");
			}
			catch(Exception e1)
			{
				test.log(LogStatus.PASS, "Resolved date is not available on recent work page");
			}
			
		} catch (Exception e){
            e.printStackTrace();
            BaseTest.log.error("Error on resolveDate method" + e);
            test.log(LogStatus.FAIL, "Error on resolveDate method " + e);
            Assert.fail();

		}
	}
	
	public void auditHistoryWrap(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\RecentWorkPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\RecentWorkPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "historyBtn", true, "PegaGadget1Ifr", "", "History");
			
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				driver.switchTo().window(childWindow);
				//System.out.println(driver.switchTo().window(childWindow).getTitle());
				String auditLog=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "historyAudit", false, "", "", "History Audit");
				waitSleep(1000);
				//System.out.println(auditLog);
				assertEquals(data.get("ExpectedHistoryAudit"), auditLog, "Audit log");
				driver.close();
				}
			}
			driver.switchTo().window(mainWindow);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
            BaseTest.log.error("Error on auditHistoryWrap method" + e);
            test.log(LogStatus.FAIL, "Error on auditHistoryWrap method " + e);
            Assert.fail();
		}
	}
}
