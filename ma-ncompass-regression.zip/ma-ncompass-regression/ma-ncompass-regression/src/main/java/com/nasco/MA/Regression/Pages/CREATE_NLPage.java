package com.nasco.MA.Regression.Pages;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;

@SuppressWarnings("rawtypes")
public class CREATE_NLPage extends BasePage {
	
	@FindBy(xpath = "(//h3[contains(text(),'Contract')])[2]")
	public WebElement contractTab;



	

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(contractTab);
	}


	
		
	public void NL_Interactions(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "linkInteraction", true, "PegaGadget1Ifr", "", "link Interaction");
			waitSleep(2500);
			String duplicateText= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "duplicateText", true, "PegaGadget1Ifr", "", "duplicate Text");
			waitSleep(2500);
			String FollowUpText= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "followUpText", true, "PegaGadget1Ifr", "", "FollowUp Text");
			waitSleep(1500);
			String NLI= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "NLI", true, "PegaGadget1Ifr", "", "NLI Text");
			String Interactiondetails=duplicateText+"|"+FollowUpText+"|"+NLI.substring(0, 3);
			//System.out.println("Interactiondetailstext::"+Interactiondetails);

			assertEquals(data.get("Expectedadjustdetails"),Interactiondetails,"adjust");
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "cancel", true, "PegaGadget1Ifr", "", "duplicate Text");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Error on switchMemberPrivacy method " + e);
			Assert.fail();
		}
		
	}
	public void clickOtherActions(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{	
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherActions", true, "PegaGadget1Ifr", "", "Other Actions");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on clickOtherActions method " + e);
			test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
			Assert.fail();
		}
	}
	public void ExitInteraction(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{	
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "exitInteraction", true, "PegaGadget1Ifr", "", "Exit Interaction");
			waitSleep(1500);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comment", true, "PegaGadget1Ifr", "WrapUp Comments", "WrapUp Comments");
			waitSleep(1500);
			//System.out.println("click1");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "", "submit button");
			waitSleep(1500);
			//System.out.println("click");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on clickOtherActions method " + e);
			test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
			Assert.fail();
		}
	}
	public void vaildatethedata(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		String AuthRows="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			List<String> headerRow= new ArrayList<String>();
            headerRow.add("Status");
            headerRow.add("Channel");
            headerRow.add("Create operator");
            //headerRow.add("Comments");
            headerRow.add("Source for interaction");
            headerRow.add("Primary Reason For Interaction");


ArrayList<String> rowData= new ArrayList<String>();
                                    for(int j=0;j<headerRow.size();j++)
                                    {											
                                    rowData.add(driver.findElement(By.xpath("(//div[contains(@class,'layout layout-noheader layout-noheader-workarea_wrap')])[2]//span[contains(text(),'"+headerRow.get(j)+"')]/following::div[1]")).getText());
                                          if(j==0){
                                                AuthRows=rowData.get(j);
                                          }else{
                                                AuthRows=AuthRows + "|" + rowData.get(j);
                                          }
                                    }
                        
                              
                        
                        waitSleep(4000);
                        //rowData=AuthRows;
                        //AuthRows=AuthRows.substring(1,AuthRows.length());
                        //System.out.println(AuthRows);
                        assertEquals(data.get("Expected_details"), AuthRows, "Authorizations Rows Details");
                        WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
		
	}
	public String NL_DUPLICATE(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{ 
		String NLI="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "linkInteraction", true, "PegaGadget1Ifr", "", "link Interaction");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "duplicate", true, "PegaGadget1Ifr", "", "duplicate input");
			waitSleep(1500);
			NLI= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "NLI", true, "PegaGadget1Ifr", "", "NLI Text");
			waitSleep(1500);
			//System.out.println("NLI::"+NLI);
			test.log(LogStatus.INFO, "Intent ID:"+NLI);
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, "PegaGadget1Ifr", "", "submit Text");
		    waitSleep(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Error on switchMemberPrivacy method " + e);
			Assert.fail();
		}
		return NLI;

}
	public void WrapUp(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{	
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comment", true, "PegaGadget1Ifr", "WrapUp Comments", "WrapUp Comments");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit", true, "PegaGadget1Ifr", "", "submit button");
			waitSleep(4500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on clickOtherActions method " + e);
			test.log(LogStatus.FAIL, "Error on clickOtherActions method " + e);
			Assert.fail();
		}
	}
	public String NL_FOLLOWUP(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{ 
		String NLI="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "linkInteraction", true, "PegaGadget1Ifr", "", "link Interaction");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "followup", true, "PegaGadget1Ifr", "", "followup input");
			waitSleep(2500);
			waitOnIE(2500);
			NLI= WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "NLI", true, "PegaGadget1Ifr", "", "NLI Text");
			waitSleep(2500);
			waitOnIE(2500);
			//System.out.println("NLI::"+NLI);
			test.log(LogStatus.INFO, "Intent ID:"+NLI);
		    WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, "PegaGadget1Ifr", "", "submit Text");
		    waitSleep(8000);
		   // waitForFrameTobeVisible("PegaGadget1Ifr");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Error on switchMemberPrivacy method " + e);
			Assert.fail();
		}
		return NLI;

}
	public String history(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
		waitSleep(3500);
		switchToFrame("PegaGadget1Ifr");
		String AuditLog="";
		try {

		String parentWindow=driver.getWindowHandle();
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
		waitSleep(2000);
		for (String windowHandle : driver.getWindowHandles())
		{
			if(!parentWindow.equals(windowHandle)){
				 driver.switchTo().window(windowHandle);
				 //System.out.println("Switched to"+windowHandle);
			}
			//System.out.println(windowHandle);
			
		}
		
		switchToDefault();
		String intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ID", true, "", "Search For Claim", "Intent ID");
		//intentid= intentid.substring(1, intentid.length()-1);
		//System.out.println("NLID:"+intentid);
		test.log(LogStatus.INFO, "Intent ID:"+intentid);
        int j=0;
		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$ppxResults$l')]"));
		//System.out.println("size of the row::::"+ele.size());
		String s="//tr[contains(@id,'$ppxResults$l%d')]";
		for(int i=0;i<=ele.size();i++)
		{
			String s1=String.format(s, i+1);
			//System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
			
			//System.out.println("This is from::"+driver.findElement(By.xpath(s1+"//td[2]")).getText().toUpperCase());
			
			if(driver.findElement(By.xpath(s1+"//td[2]")).getText().toUpperCase().contains(intentid))
			
			{
				j=1;
//				//System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
				test.log(LogStatus.PASS, "INTRACTIONID IS MATCHED IN HISTORY "+intentid);
				break;
				
			}
//			else
//			{
//				//System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
//				//test.log(LogStatus.FAIL, "INTRACTIONID IS NOT MATCHED IN HISTORY "+intentid);
//			
//			}
		}
		if(j==1)
		{
//			//System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
			test.log(LogStatus.PASS, "INTRACTIONID IS MATCHED IN HISTORY "+intentid);
			
		}
		if(j==0)
		{
//			//System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
			test.log(LogStatus.FAIL, "INTRACTIONID IS NOT MATCHED IN HISTORY "+intentid);
		
		}
		
		driver.close();
		driver.switchTo().window(parentWindow);
		
		
		
		} catch (Exception e) {
	        e.printStackTrace();
	        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
	        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
	        Assert.fail();


			
		}
		return AuditLog;


		
	}
	public String getNLID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String NLID="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(2500);
			//switchToFrame("PegaGadget1Ifr");
			switchToDefault();
			NLID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "", "Search For Claim", "Intent ID");
			//intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println("ID:"+NLID);
			test.log(LogStatus.INFO, "Intent ID:"+NLID);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return NLID;
	}
	
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(5000);
			switchToFrame("PegaGadget2Ifr");
			waitSleep(3000);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "intentid", true, "PegaGadget2Ifr", "Search For Claim", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println("Intentid:"+intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	public void NL_SKIP(String pageLocatorsPath,String pageFiledsPath) 
	{ 
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitNLV", true, "PegaGadget1Ifr", "", "submit button");
			
			waitSleep(6000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Error on switchMemberPrivacy method " + e);
			Assert.fail();
		}

	}
	public void unlinkdisplay(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{ 
		String unlinkdisplay="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			waitOnIE(20000);
			switchToDefault();
			waitOnIE(20000);
			unlinkdisplay=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Unlink", true, "", "Unlink", "Unlink button");
			//System.out.println("unlinkdisplay:"+unlinkdisplay);
			test.log(LogStatus.INFO, "Intent ID:"+unlinkdisplay);
			assertEquals(data.get("Expected_unlink"), unlinkdisplay, "unlink display");
			
		waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Error on switchMemberPrivacy method " + e);
			Assert.fail();
		}

	}
	public void unlink(String pageLocatorsPath,String pageFiledsPath) 
	{ 
		@SuppressWarnings("unused")
		String unlinkdisplay="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToDefault();
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Unlink", true, "", "Unlink", "Unlink button");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectLVID", true, "", "selectLVID", "selectLVID button");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Unlink", true, "", "Unlink", "Unlink button");
			waitOnIE(7500);
			
		waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Error on switchMemberPrivacy method " + e);
			Assert.fail();
		}

	}
	public void Vaildateinteraction(String pageLocatorsPath,String pageFiledsPath,String NLID) 
	{ 
		String Linkedinteractions="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			Linkedinteractions=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Linkedinteractions", true, "PegaGadget1Ifr", "Linkedinteractions", "Linked interactions");
			
			//System.out.println(Linkedinteractions);
			assertEquals(NLID, Linkedinteractions, "Linkedinteractions");
			waitSleep(5000);
            WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Error on switchMemberPrivacy method " + e);
			Assert.fail();
		}

	}
	public String  resolvedate(String pageLocatorsPath,String pageFiledsPath) 
	{ 
		String Resolvedate="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			try{
			Resolvedate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "resolvedate", true, "PegaGadget1Ifr", "Resolvedate", "Resolvedate");
			}
			catch(AssertionError e)
			{
				test.log(LogStatus.PASS, "Resolvedate is  found " + Resolvedate);

			}
			//System.out.println(Resolvedate);
			waitSleep(5000);
            WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Resolvedate is not found " + Resolvedate);
			Assert.fail();
		}
		return Resolvedate;

	}
	public void  vaildateresolvedate(String pageLocatorsPath,String pageFiledsPath,String resolvedate1,String resolvedate2 ) 
	{ 
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			//switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			assertEquals(resolvedate1, resolvedate2, "resolvedate");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Error on switchMemberPrivacy method" + e);
			Assert.fail();
		}

		
	}
	public void  recentresolvedate(String pageLocatorsPath,String pageFiledsPath) 
	{ 
		String recentresolvedate="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			try{
				recentresolvedate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "recentresolvedate", true, "PegaGadget1Ifr", "Resolvedate", "Resolvedate");
			}
			catch(AssertionError e)
			{
				test.log(LogStatus.PASS, "Resolvedate is not found " + recentresolvedate);

			}
			//System.out.println(recentresolvedate);
			waitSleep(5000);
            WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Resolvedate is not found " + recentresolvedate);
			Assert.fail();
		}

	}
	public String Unlinkhistory(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String NLID2,String NLID1) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
		waitSleep(3500);
		switchToFrame("PegaGadget1Ifr");
		String AuditLog="";
		try {

		String parentWindow=driver.getWindowHandle();
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
		waitSleep(2000);
		for (String windowHandle : driver.getWindowHandles())
		{
			if(!parentWindow.equals(windowHandle)){
				 driver.switchTo().window(windowHandle);
				 //System.out.println("Switched to"+windowHandle);
			}
			//System.out.println(windowHandle);
			
		}
		
		switchToDefault();
		AuditLog=data.get("Operator")+" "+"linked"+" "+NLID2+" "+"to"+" "+NLID1;
		//System.out.println("NLID:"+AuditLog);
		test.log(LogStatus.INFO, "Intent ID:"+AuditLog);

		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$ppxResults$l')]"));
		ele.size();
		String s="//tr[contains(@id,'$ppxResults$l%d')]";
		for(int i=0;i<ele.size();i++)
		{
			String s1=String.format(s, i+1);
			//System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
			//System.out.println("NLID:"+AuditLog);
			if(driver.findElement(By.xpath(s1+"//td[2]")).getText().equals(AuditLog))
			{
		
				//System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
				test.log(LogStatus.PASS, "INTRACTIONID IS MATCHED IN HISTORY "+AuditLog);
				//System.out.println("INTRACTIONID IS  MATCHED IN HISTORY "+AuditLog);

				break;
			}
		} 
		
		
		driver.close();
		driver.switchTo().window(parentWindow);
		
		
		
		} catch (Exception e) {
	        e.printStackTrace();
	        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
	        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
	        Assert.fail();


			
		}
		return AuditLog;

	}
//	public String  resolvedate(String pageLocatorsPath,String pageFiledsPath,String frame) 
//	{ 
//		String Resolvedate="";
//		try{
//			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
//			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
//			waitSleep(1500);
//			switchToFrame(frame);
//			waitSleep(2500);
//			try{
//			Resolvedate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "resolvedate", true, frame, "Resolvedate", "Resolvedate");
//			}
//			catch(AssertionError e)
//			{
//				test.log(LogStatus.PASS, "Resolvedate is not found " + Resolvedate);
//
//			}
//			//System.out.println(Resolvedate);
//			waitSleep(5000);
//            WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");
//
//		
//		}
//		catch(Exception e)
//		{
////			e.printStackTrace();
////			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
////			//test.log(LogStatus.FAIL, "Resolvedate is not found " + Resolvedate);
////			Assert.fail();
//		}
//		return Resolvedate;
//	}
	public void sortandSelectInteraction(String pageLocatorsPath,String pageFiledsPath,String frame ,String intentId) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			
			switchToFrame(frame);
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "idSort", true, frame, "", "ID Sort");
			waitSleep(3000);
			BaseTest.log.debug("Click the id sort filter");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "searchID", true, frame, intentId, "Search intent");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "applyBtn", true, frame, "", "Apply");
			waitSleep(2500);
			}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(LogStatus.FAIL, "Error on sortandSelectIntent method " + e);
			Assert.fail();
		}
		
	}
	public String  	Allworkresolveddate(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{ 
		String Allworkresolveddate="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(1500);
			switchToFrame(frame);
			waitSleep(2500);
			try{
				Allworkresolveddate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Allworkresolveddate", true, frame, "	All work resolved date", "Allworkresolveddate");
			}
			catch(AssertionError e)
			{
				test.log(LogStatus.PASS, "All work resolved date is not found " + Allworkresolveddate);

			}
			//System.out.println(Allworkresolveddate);
			waitSleep(5000);
            WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Resolvedate is not found " + Allworkresolveddate);
			Assert.fail();
		}
		return Allworkresolveddate;
	}
	public String  resolvedate(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{ 
		String Resolvedate="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ManageOtherCoveragePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ManageOtherCoveragePageFields.properties";
			waitSleep(1500);
			switchToFrame(frame);
			waitSleep(2500);
			Properties pageLocatorsprop = new Properties();
			FileInputStream FiledsIn = new FileInputStream(pageLocatorsPath);
			pageLocatorsprop.load(FiledsIn);
			
			try{
//				Resolvedate=driver.findElement(By.xpath("(//span[contains(text(),'Resolve date')])[2]")).getText();
//			Resolvedate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "resolvedate", true, frame, "Resolvedate", "Resolvedate");
				//Resolvedate= readText(pageLocatorsprop.getProperty("resolvedateWebElementtype"),
				//pageLocatorsprop.getProperty("resolvedateWebElementvalue"), "");
				Resolvedate=driver.findElement(By.xpath("(//span[contains(text(),'Resolve date')])[2]")).getText();
				test.log(LogStatus.PASS, "Resolvedate is  found " + Resolvedate);

			}
			catch(Exception e)
			{
				test.log(LogStatus.PASS, "Resolvedate is not found " + Resolvedate);

			}
			//System.out.println(Resolvedate);
			waitSleep(5000);
            WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closeBtn", true, "PegaGadget1Ifr", "", "Close");

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on switchMemberPrivacy method " + e);
			test.log(LogStatus.FAIL, "Resolvedate is not found " + Resolvedate);
			Assert.fail();
		}
		return Resolvedate;
	}
	
	public String getNonLID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String NLID="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\CREATE_NLPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\CREATE_NLPageFields.properties";
			waitSleep(2500);
			//switchToFrame("PegaGadget1Ifr");
			switchToDefault();
			NLID=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "NoninteractionID", true, "", "Search For Claim", "Intent ID");
			//intentid= intentid.substring(1, intentid.length()-1);
			//System.out.println("ID:"+NLID);
			test.log(LogStatus.INFO, "Intent ID:"+NLID);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return NLID;
	}
}