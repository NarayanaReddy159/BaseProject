package com.nasco.MA.Pages;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class Callback_RTCPage extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget2Ifr";
	String startDt="",endDt="";
	
	//@Override
	protected ExpectedCondition getPageLoadCondition() {
		//switchToFrame(frame1);
		switchToFrame(frame1);
		//return ExpectedConditions.visibilityOf(intentID);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
		
		
	}
		
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
			switchToFrame(frame1);
			waitOnIE(2000);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, frame1, "Select Customer Response Type", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
		
	
	public void create_CallbackNow(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame1);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Callback", true, frame1, "Callback", "Callback");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
//			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Reasonforcallback", true, frame1, data.get("Reasonforcallback"), "Reason for callback");
			

			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Contactname", true, frame1, data.get("Contactname"), "Contact name");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CallbackNow", true, frame1, "Now", "Callback Now");
			waitSleep(1000);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, frame1, data.get("Comments"), "comments");
			waitSleep(1000);

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Callbacknumber", true, frame1, data.get("Callbacknumber"), "Callback number");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");

			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CallbackAttempt", true, frame1, data.get("CallbackAttempt"), "Callback Attempt");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Attemptcomments", true, frame1, data.get("AttemptComments"), "comments Attempt");

			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitAttempt", true, frame1, "", "Submit");
			waitSleep(2000);
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_Callback method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_Callback method " + e);
			Assert.fail();

		}
	}
	
	public void create_CallbackSchedule(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame1);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Callback", true, frame1, "Callback", "Callback");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
//			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Reasonforcallback", true, frame1, data.get("Reasonforcallback"), "Reason for callback");
			waitSleep(1000);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CallbackScheduled", true, frame1, "Now", "Callback Scheduled");
			waitSleep(1000);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Contactname", true, frame1, data.get("Contactname"), "Contact name");
			waitSleep(1000);
			
			String startDate=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "Startdate", true, frame1, "", "Start date");
			System.out.println("startDate::"+startDate);
			String [] date=startDate.split(" ");
			String newdate=date[0].toString()+" "+"9:00 AM";
			System.out.println("newdate"+newdate);
			startDt = newdate;
			WebElementAction("clear",pageLocatorsPath, pageFiledsPath, "Startdate", true, frame1, "", "Start date");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Startdate", true, frame1, newdate, "Start date");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "comments", true, frame1, "", "Comments");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, frame1, data.get("Comments"), "comments");
			

			waitSleep(3000);
//			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Contactname", true, frame1, data.get("Contactname"), "Contact name");
//			waitSleep(1000);
//			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, frame1, data.get("Comments"), "comments");
//			waitSleep(1000);
			String endDate=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "Enddate", true, frame1, "", "End date");
			String [] date1=endDate.split(" ");
			String newenddate=date1[0].toString()+" "+"6:00 PM";
			System.out.println("newenddate::"+newenddate);
			endDt=newenddate;
			WebElementAction("clear",pageLocatorsPath, pageFiledsPath, "Enddate", true, frame1, "", "End date");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Enddate", true, frame1, newenddate, "End date");
			waitSleep(2000);
//			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Callbacknumber", true, frame1, "", "Callback Number");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Callbacknumber", true, frame1, data.get("Callbacknumber"), "Callback number");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
			waitSleep(2000);
//			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Attemptcomments", true, frame1, data.get("AttemptComments"), "comments Attempt");
//
//			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CallbackAttempt", true, frame1, data.get("CallbackAttempt"), "Callback Attempt");
//			
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitAttempt", true, frame1, "", "Submit");

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_Callback method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_Callback method " + e);
			Assert.fail();

		}
	}

	public void validateStatus(String pageLocatorsPath,String pageFiledsPath,String status) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
			switchToFrame(frame1);
			waitSleep(3000);
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Status", true, frame1, "Status", "Participation status");
			assertEquals(status, actualStatus, "Status");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateStatus method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateStatus method " + e);
			Assert.fail();
		}
	}

	public void reviewHorness_Scheduled_CorrepondenceNo(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame1);
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Attemptcomments", true, frame1, data.get("AttemptComments"), "comments Attempt");
			waitSleep(1000);
			waitOnIE(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CallbackAttemptHarness", true, frame1, data.get("CallbackAttempt"), "Callback Attempt");
			
	//		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Attemptcomments", true, frame1, data.get("AttemptComments"), "comments Attempt");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "correspondenceNoHarness", true, frame1, "", "correspondence Harness as No");
			waitSleep(1000);
			String startDate=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "StartdateHarness", true, frame1, "", "Start date");
			System.out.println("startDate::"+startDate);
			String [] date=startDate.split(" ");
			String newdate=date[0].toString()+" "+"9:00 AM";
			System.out.println("newdate"+newdate);
			WebElementAction("clear",pageLocatorsPath, pageFiledsPath, "StartdateHarness", true, frame1, "", "Start date");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "StartdateHarness", true, frame1, newdate, "Start date");
			waitSleep(2000);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "correspondenceNoHarness", true, frame1, "", "correspondence Harness as No");
						
			String endDate=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "Enddate", true, frame1, "", "End date");
			String [] date1=endDate.split(" ");
			String newenddate=date1[0].toString()+" "+"6:00 PM";
			System.out.println("newenddate::"+newenddate);
			WebElementAction("clear",pageLocatorsPath, pageFiledsPath, "EnddateHarness", true, frame1, "", "End date");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "EnddateHarness", true, frame1, newenddate, "End date");
			waitSleep(2000);

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitHarness", true, frame1, "", "Submit");
			waitSleep(2000);
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on reviewHorness_Scheduled_CorrepondenceNo method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on reviewHorness_Scheduled_CorrepondenceNo method " + e);
			Assert.fail();

		}
	}

	public void reviewHorness_Scheduled_CorrepondenceYes(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame1);
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Attemptcomments", true, frame1, data.get("AttemptComments"), "comments Attempt");
			waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CallbackAttemptHarness", true, frame1, data.get("CallbackAttempt"), "Callback Attempt");
			waitSleep(3000);
	//		WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Attemptcomments", true, frame1, data.get("AttemptComments"), "comments Attempt");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "correspondenceYesHarness", true, frame1, "", "correspondence Harness as Yes");
			waitSleep(1000);
			String startDate=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "StartdateHarness", true, frame1, "", "Start date");
			System.out.println("startDate::"+startDate);
			String [] date=startDate.split(" ");
			String newdate=date[0].toString()+" "+"9:00 AM";
			System.out.println("newdate"+newdate);
			WebElementAction("clear",pageLocatorsPath, pageFiledsPath, "StartdateHarness", true, frame1, "", "Start date");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "StartdateHarness", true, frame1, newdate, "Start date");
			waitSleep(2000);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "correspondenceYesHarness", true, frame1, "", "correspondence Harness as Yes");
			waitSleep(2000);			
			String endDate=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "EnddateHarness", true, frame1, "", "End date");
			String [] date1=endDate.split(" ");
			String newenddate=date1[0].toString()+" "+"6:00 PM";
			System.out.println("newenddate::"+newenddate);
			WebElementAction("clear",pageLocatorsPath, pageFiledsPath, "EnddateHarness", true, frame1, "", "End date");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "EnddateHarness", true, frame1, newenddate, "End date");
			waitSleep(2000);

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitHarness", true, frame1, "", "Submit");
			waitSleep(8000);
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on reviewHorness_Scheduled_CorrepondenceNo method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on reviewHorness_Scheduled_CorrepondenceNo method " + e);
			Assert.fail();

		}

	}
		
	public void validateIntentIDOnCorrespondence(String pageLocatorsPath,String pageFiledsPath,String intentId) 
		{	
			String intentidCor="";
			try{
				pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
				pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
				switchToFrame(frame1);
				waitSleep(4000);

				intentidCor=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionIDCorreespondence", true, frame1, "Create correspondence", "Intent ID");
				System.out.println("intentidCor1:::"+intentidCor);
				intentidCor= intentidCor.substring(1, intentidCor.length()-1);
				System.out.println("intentidCor:::"+intentidCor);
				assertEquals(intentId, intentidCor, "Create correspondence intent Id");
				test.log(LogStatus.INFO, "Intent ID:"+intentidCor);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				String excepionMessage = Arrays.toString(e.getStackTrace());
				BaseTest.log.error("Error on getIntentID method " + excepionMessage);
				test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
				Assert.fail();
			}
		}

	public void update_Scheduled_Correpondence(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame1);
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CategoryCorr", true, frame1, data.get("Category"), "Category");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "EmailId", true, frame1, data.get("EmailId"), "Email Id");
			waitSleep(1000);
						
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Emailtemplatename", true, frame1, data.get("Emailtemplatename"), "Emailtemplate name");
			
			waitSleep(2000);

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitCorrespondence", true, frame1, "", "Submit");
			waitSleep(2000);
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on update_Scheduled_Correpondence method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on update_Scheduled_Correpondence method " + e);
			Assert.fail();

		}

	}
	
	public void takeOwnership(String pageLocatorsPath,String pageFiledsPath,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame1);
			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "TransferComments", true, frame1, comments, "Transfer Comments");
			waitSleep(1000);
	
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "TakeOwnership", true, frame1, "", "Take Ownership");
			waitSleep(2000);
			Alert alert = driver.switchTo().alert();
			alert.accept();
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on takeOwnership method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on takeOwnership method " + e);
			Assert.fail();

		}

	}

	public void updateSuggestedIntent(String pageLocatorsPath,String pageFiledsPath,String callbackAttempt,String comments)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
			waitSleep(4000);
			switchToFrame(frame1);

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Attemptcomments", true, frame1, comments , "comments Attempt");
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CallbackAttempt", true, frame1, callbackAttempt, "Callback Attempt");
			waitSleep(1000);
		
//			String date=WebElementAction("getAttribteValue",pageLocatorsPath, pageFiledsPath, "DateandTime", true, frame1, "", "Date and Time");
//			String [] date1=date.split(" ");
//			String newdate=date1[0].toString()+" "+"6:00 PM";
//			System.out.println("newenddate::"+newdate);
//			WebElementAction("clear",pageLocatorsPath, pageFiledsPath, "DateandTime", true, frame1, "", "Date and Time");
//			waitSleep(1000);
//			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "DateandTime", true, frame1, newdate, "Date and Time");
//			waitSleep(2000);
//
//			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitAttempt", true, frame1, "", "Submit");
			waitSleep(2000);
		
	} catch (Exception e){
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on create_Callback method " + excepionMessage);
		test.log(LogStatus.FAIL, "Error on create_Callback method " + e);
		Assert.fail();

	}

	}
	
	public void WrapUpOpenIntent(String comments,String interactionReason,String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WrapUpButton", true, frame, "Wrap up", "Add Task");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contactNotVerified", true, frame, "Are you sure", "contact NotVerified");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "contactNotVerified", true, frame, "You are closing", "Confirm Wrap Up");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Warning-Submit", true, frame , "", "Submit");
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RelatedtoPrior-No", true, "PegaGadget1Ifr", "No", "Related to Prior-No");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ReasonForInteraction", true, "PegaGadget1Ifr", interactionReason, "Reason For Interaction");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "WrapUpComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Submit-WrapUp", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on WrapUpOpenIntent method " + e);
			test.log(LogStatus.FAIL, "Error on WrapUpOpenIntent method " + e);
			Assert.fail();
		}
	 }
	
	public void calcualteSLA(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
			waitSleep(2000);
			switchToFrame(frame);
			String endDate=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "EndDateRecentwork", true, frame1, "", "End date");
			
			
			String goal=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ServiceIntentGoal", true, frame1, "", "Service Intent Goal");
			String deadLine=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "ServiceIntentDeadline", true, frame1, "", "Service Intent Deadline");
			String format = "MM/dd/yyyy hh:mm a";
			 
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			Date creDt = sdf.parse(endDate);
			Date goalDt = sdf.parse(goal);
			Date deadLineDt = sdf.parse(deadLine);
			long diff = deadLineDt.getTime() - creDt.getTime();
			long diff1 = goalDt.getTime() - creDt.getTime();
			int diffhrs = (int) (diff / (60 * 60 * 1000));
			System.out.println("endDate::"+endDate);
			System.out.println("goal::"+goal);
			System.out.println("deadLine::"+deadLine);
			System.out.println("difference between Hours: " + diffhrs);
			if (diffhrs==24){
				BaseTest.log.debug("Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be " + diffhrs+" hrs");
				test.log(LogStatus.INFO, "Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be " + diffhrs+" hrs");
			} else {
				BaseTest.log.error("Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be 24 hrs");
				test.log(LogStatus.FAIL, "Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be 24 hrs");
				Assert.fail("Difference should be 24 hrs but the value is "+diffhrs);
			}
			
			int diffh = (int) (diff1 / (60 *60 * 1000));
			System.out.println("difference between Hours: " + diffh);
 
			if (diffh==2){
				BaseTest.log.debug("Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be " + diffh+" hrs");
				test.log(LogStatus.INFO, "Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be " +diffh+" hrs");
			} else {
				BaseTest.log.error("Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be 24 hrs");
				test.log(LogStatus.FAIL, "Difference between creation date "+endDate+" and  Service Intent Goal "+goal+" should be 24 hrs");
				Assert.fail("Difference should be 24 hrs but the value is "+diffh);
			}
			
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on WrapUpOpenIntent method " + e);
			test.log(LogStatus.FAIL, "Error on WrapUpOpenIntent method " + e);
			Assert.fail();
		}
	 }
	
	public void create_Correspondence(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";

			switchToFrame(frame1);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Correspondence", true, frame1, "Correspondence", "Correspondence");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
			waitSleep(3500);
			/*WebElementAction("jsClick",pageLocatorsPath, pageFiledsPath, "Correspondence", true, frame1, "Correspondence", "Correspondence");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
			waitSleep(3500);*/
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_Callback method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_Callback method " + e);
			Assert.fail();

		}
	}
	
	public void create_FullfillmentLive(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame1);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Fulfillment", true, frame1, "Fulfillment", "Fulfillment");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "ProductOrLOB", true, frame1, data.get("ProductOrLOB"), "Product Or LOB");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Typeoffulfillment", true, frame1, data.get("Typeoffulfillment"), "Type of fulfillment");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Methodofresponse", true, frame1, data.get("Methodofresponse"), "Method of response");
			waitSleep(2000);
		    WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Document", true, frame1, data.get("Document"), "Document");
            waitSleep(2500);
            driver.findElement(By.xpath("//*[contains(@id,'DocumentTitle$ppxResults$l1')]/td[2]")).click();
            waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddBtn", true, frame1, "Add", "Add Button");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "AddBtn", true, frame1, "Add", "Add Button");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Sendtotemporaryaddress", true, frame1, "Send to temporary address", "Send to temporary address");
			waitSleep(1000);
			
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Addressline1", true, frame1, data.get("Addressline1"), "Address line 1");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "City", true, frame1, data.get("City"), "City");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "FulfillmentComments", true, frame1, data.get("Comments"), "Fulfillment comments");
			waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Country", true, frame1, data.get("Country"), "Country");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "State", true, frame1, data.get("State"), "State");
//			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Zipcode", true, frame1, data.get("Zipcode"), "Zip code");
			
//			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "FulfillmentComments", true, frame1, data.get("Comments"), "Fulfillment comments");
//			waitSleep(1000);

			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Nextbtn", true, frame1, "Next", "Next button");
			waitSleep(3000);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "Submit", "Submit");
			waitSleep(10000);

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_Callback method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_Callback method " + e);
			Assert.fail();

		}
	}
	public void create_CallbackNow(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data,String frame)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame);
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Callback", true, frame, "Callback", "Callback");
			waitSleep(3000);

			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame, "", "Submit");
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "Reasonforcallback", true, frame, data.get("Reasonforcallback"), "Reason for callback");
			

			waitSleep(2000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Contactname", true, frame, data.get("Contactname"), "Contact name");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CallbackNow", true, frame, "Now", "Callback Now");
			waitSleep(1000);
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, frame, data.get("Comments"), "comments");
			waitSleep(1000);

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Callbacknumber", true, frame, data.get("Callbacknumber"), "Callback number");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame, "", "Submit");
			
			waitSleep(2000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "CallbackAttempt", true, frame, data.get("CallbackAttempt"), "Callback Attempt");
			waitSleep(3000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "Attemptcomments", true, frame, data.get("AttemptComments"), "comments Attempt");

			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitAttempt", true, frame, "", "Submit");
			waitSleep(3000);
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_Callback method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_Callback method " + e);
			Assert.fail();

		}
	}
	public void validateCreateNewWork(String pageLocatorsPath,String pageFiledsPath,String memId,String nlId, String frame){
		pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
		waitSleep(1000);
		try {
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "CreatenewWork", true, frame, "Create new work", "Create new work");
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame, "", "Submit");
//			Actions action = new Actions(driver);
//			action.moveToElement(driver.findElement(By.xpath("//button[contains(text(),'Create new work')]"))).click().perform();
//			action.moveToElement(driver.findElement(By.xpath("//li//following::span[contains(text(),'Respond to Customer')]"))).click().build().perform();
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ReportToCustCreateNewWork", true, frame, "", "Report To Customer");
			
			waitSleep(2000);
			switchToFrame("PegaGadget2Ifr");
			String actualMeberid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "memberID", true, "PegaGadget2Ifr", "Member ID", "Member ID");
			assertContains(memId, actualMeberid, "Member Id");
			String actualNLId=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "NLInteractionNum", true, "PegaGadget2Ifr", "", "Non live interaction Id");
			assertContains(nlId, actualNLId, "Member Id");
	
			
			

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_Callback method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_Callback method " + e);
			Assert.fail();

		}

	}
	
	public void validateUrgency(String pageLocatorsPath,String pageFiledsPath, String frame){
		pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//		waitForFrameTobeVisible(frame1);
		try {
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, frame, "History", "History");
			waitSleep(2000);
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				driver.switchTo().window(childWindow);
				System.out.println(driver.switchTo().window(childWindow).getTitle());
				waitSleep(2000);
				String actualurgency=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "UrgencyVal", false, "", "", "Urgency");
				assertEquals("13", actualurgency, "Urgency ");
		
				driver.close();
				}
			}
			driver.switchTo().window(mainWindow);
			} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_Callback method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_Callback method " + e);
			Assert.fail();

		}

	}
	
	public void validateMemberAndIntenetId(String pageLocatorsPath,String pageFiledsPath,String memId, String status) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
			switchToFrame(frame1);
		
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Status", true, frame1, "Status", "Participation status");
			assertEquals(status, actualStatus, "Status");
			
			String actualMeberid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "memberID", true, "PegaGadget1Ifr", "Member ID", "Member ID");
			assertContains(memId, actualMeberid, "Member Id");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateStatus method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateStatus method " + e);
			Assert.fail();
		}
	}
	
	public void otherAction_SelctCustResType(String pageLocatorsPath,String pageFiledsPath,String frame)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
//			waitForFrameTobeVisible(frame1);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Fulfillment", true, frame, "Fulfillment", "Fulfillment");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "OtherAction", true, frame, "", "OtherAction");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SelectCustomerResponse", true, frame, "Select Customer Response", "Select Customer Response");
			waitSleep(2000);
			
			if (driver.findElement(By.xpath("//label[contains(text(),'Select Customer Response Type')]")).isDisplayed()){
				test.log(LogStatus.PASS, "Select Customer Response Type is populated");
				BaseTest.log.debug("Select Customer Response Type is populated");
			} 
//			else {
//				test.log(LogStatus.PASS, "Select Customer Response Type is populated");
//				BaseTest.log.debug("Select Customer Response Type is populated");
//				Assert.fail();
//			}

		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on otherAction_SelctCustResType method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on otherAction_SelctCustResType method " + e);
			Assert.fail();

		}
	}

	public void callbacOnPerformHarness(String pageLocatorsPath,String pageFiledsPath, String frame)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";
			switchToFrame(frame);
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Callback", true, frame1, "Callback", "Callback");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on callbacOnPerformHarness method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on callbacOnPerformHarness method " + e);
			Assert.fail();

		}
	}
	
	public void validateDefaultSelectedIntent(String pageLocatorsPath, String pageFiledsPath,String frame,String intentId)   
	{
		
		try{//$PpyWorkPage$pSelectRelatedIntent$l1
			switchToFrame(frame);
			List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage')]"));
			System.out.println("tablerows "+tablerows.size());
			String s="(//tr[contains(@id,'$PpyWorkPage$pSelectRelatedIntent$l')])[%d]";  
			for(int i=0;i<tablerows.size();i++)
			{ 
				String s1=String.format(s, i+1);
				System.out.println("s1"+s1);
				System.out.println("intent id "+driver.findElement(By.xpath(s1+"//td[3]//a")).getText());
				if( (driver.findElement(By.xpath(s1+"//td[3]//a")).getText()).equalsIgnoreCase(intentId) ) 
				{
					if (driver.findElement(By.xpath(s1+"//td[1]//input[2]")).isSelected()) {
						BaseTest.log.info("By default selected the intent as  "+intentId );
						test.log(LogStatus.INFO, "By default selected the intent as  "+intentId );
	
						break;
					}
				}
			}	
			waitSleep(2000);
		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateDefaultSelectedIntent method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateDefaultSelectedIntent method " + e);
			Assert.fail();
		}
		
	}
	public void RTC_callback(String pageLocatorsPath,String pageFiledsPath,String frame,String frame1)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\Callback_RTCPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Callback_RTCPageFields.properties";

			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "respondcustomer", true, frame, "respondcustomer", "respondcustomer");
			waitSleep(5000);
			switchToFrame(frame1);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Callback", true, frame1, "Callback", "Callback");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitRTC", true, frame1, "", "Submit");
						waitSleep(2000);
			
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on otherAction_SelctCustResType method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on otherAction_SelctCustResType method " + e);
			Assert.fail();

		}
	}


}
