package com.nasco.MA.Regression.Pages;

import java.util.Hashtable;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;
@SuppressWarnings("rawtypes")
public class VerifyContactPage extends BasePage{

	@FindBy(xpath="//span[contains(text(),'Contact is the selected member')]")
	public WebElement selectedMember;
	
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(selectedMember);
	}

	public void createContact(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\VerifyContactPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\VerifyContactPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectedMemberNo", true, "PegaGadget1Ifr", "", "Selected Member No");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "quickContact", true, "PegaGadget1Ifr", "Create contact for this call", "Quick Contact");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "contactName", true, "PegaGadget1Ifr", data.get("ContactName"), "Contact Name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "phoneNumber", true, "PegaGadget1Ifr", data.get("ContactPhone"), "Contact Phone");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "contactType", true, "PegaGadget1Ifr", data.get("ContactType"), "ContactType");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "verifyDob", true, "PegaGadget1Ifr", "", "Verify Dob");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBtn", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on createContact method " + e);
			test.log(LogStatus.FAIL, "Error on createContact method " + e);
			Assert.fail();
		}
		
	}
	
	public void verifyMemberpwdOverride(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\VerifyContactPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\VerifyContactPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectedMemberYes", true, "PegaGadget1Ifr", "", "Selected Member No");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "pwdOverride", true, "PegaGadget1Ifr", "", "Override password verification");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "verifyDob", true, "PegaGadget1Ifr", "", "Verify Dob");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBtn", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on verifyMemberpwdOverride method " + e);
			test.log(LogStatus.FAIL, "Error on verifyMemberpwdOverride method " + e);
			Assert.fail();
		}
	}
	
	public void verifyMember(String pageLocatorsPath,String pageFiledsPath) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\VerifyContactPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\VerifyContactPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "selectedMemberYes", true, "PegaGadget1Ifr", "", "Selected Member No");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "verifyDob", true, "PegaGadget1Ifr", "", "Verify Dob");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBtn", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(4500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on verifyMember method " + e);
			test.log(LogStatus.FAIL, "Error on verifyMember method " + e);
			Assert.fail();
		}
		
	}
	
}
