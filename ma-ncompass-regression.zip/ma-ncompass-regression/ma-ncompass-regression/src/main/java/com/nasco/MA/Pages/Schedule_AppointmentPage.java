package com.nasco.MA.Pages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;



@SuppressWarnings("rawtypes")
public class Schedule_AppointmentPage extends BasePage {

	String excepionMessage="";
	
	public String frame1="PegaGadget2Ifr";
	String startDt="",endDt="";
	
	//@Override
	protected ExpectedCondition getPageLoadCondition() {
		//switchToFrame(frame1);
		switchToFrame(frame1);
		//return ExpectedConditions.visibilityOf(intentID);
		return ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1);
		
		
	}
		
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Schedule_AppointmentPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Schedule_AppointmentPageFields.properties";
			switchToFrame(frame1);
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, frame1, "Select Customer Response Type", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
	
	public void supplementaltools(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		String AuthRows="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Schedule_AppointmentPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Schedule_AppointmentPageFields.properties";
			switchToFrame(frame);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "supplementaltools", true, frame, "Supplemental tools", "Supplemental tools");
			
			List<String> headerRow= new ArrayList<String>();
            headerRow.add("BCBS Association Find a Doctor");
            headerRow.add("DenteMax");
            headerRow.add("Find a Doctor & Estimate Costs");
            headerRow.add("Global Core");
            headerRow.add("MyBlue");
            headerRow.add("NPPES NPI Registry");


ArrayList<String> rowData= new ArrayList<String>();
                                    for(int j=0;j<headerRow.size();j++)
                                    {
                                    rowData.add(driver.findElement(By.xpath("//div[contains(@class,'layout layout-noheader layout-noheader-default')]//a[contains(text(),'"+headerRow.get(j)+"')]")).getText());
                                          if(j==0){
                                                AuthRows=rowData.get(j);
                                          }else{
                                                AuthRows=AuthRows + "|" + rowData.get(j);
                                          }
                                    }
                        
                              
                        
                        waitSleep(4000);
                        //rowData=AuthRows;
                        //AuthRows=AuthRows.substring(1,AuthRows.length());
                        System.out.println(AuthRows);
                      assertEquals(data.get("Expected_details"), AuthRows, "Authorizations Rows Details");
                 
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}
	public void scheduleAppointment(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data,String frame) 
	{	
		
		try{
			pageLocatorsPath= pageLocatorsPath+"\\Schedule_AppointmentPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\Schedule_AppointmentPageFields.properties";
			switchToFrame(frame);
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "scheduleappointment", true, frame, "Schedule Appointment", "Schedule Appointment");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "newappointment", true, frame, "+ New appointment", "New Appointment");
			waitSleep(1500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "providername", true, frame, data.get("Providername"), "Provider name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "typeandspecialty", true, frame, data.get("Typeandspecialty"), "Type and specialty");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "state", true, frame, data.get("State"), "State");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "zipcode", true, frame, data.get("Zip_code"), "Zip code");
			waitSleep(3000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "appointmentoutcome", true, frame, data.get("Appointmentoutcome"), "Appointment outcome");
			waitSleep(1500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "appointmentreasone", true, frame, data.get("Appointmentreasone"), "Appointment reasone");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "appointmentoutcome", true, frame, data.get("Appointmentoutcome"), "Appointment outcome");

			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, frame, "Schedule Appointment", "comments");
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submit", true, frame, "Sumbit", "submit button");

			waitSleep(3000);
                 
				}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		
	}
	public String Unlinkhistory(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		pageLocatorsPath= pageLocatorsPath+"\\Schedule_AppointmentPageWebelements.properties";
		pageFiledsPath=pageFiledsPath+"\\Schedule_AppointmentPageFields.properties";
		waitSleep(3500);
		switchToFrame("PegaGadget1Ifr");
		String AuditLog="";
		try {

		String parentWindow=driver.getWindowHandle();
		WebElementAction("click",pageLocatorsPath, pageFiledsPath, "History", true, "PegaGadget1Ifr", "", "History");
		waitSleep(2000);
		for (String windowHandle : driver.getWindowHandles())
		{
			if(!parentWindow.equals(windowHandle)){
				 driver.switchTo().window(windowHandle);
				 System.out.println("Switched to"+windowHandle);
			}
			System.out.println(windowHandle);
			
		}
		
		switchToDefault();
		AuditLog="State: "+data.get("State")+";"+" "+"Zip Code: "+data.get("Zip_code")+"."+" Appointment outcome: "+data.get("Appointmentoutcome")+"."+" Appointment reason: "+data.get("Appointmentreasone")+".";
		System.out.println("NLID:"+AuditLog);
		test.log(LogStatus.INFO, "Intent ID:"+AuditLog);

		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$ppxResults$l')]"));
		ele.size();
		String s="//tr[contains(@id,'$ppxResults$l%d')]";
		for(int i=0;i<ele.size();i++)
		{
			String s1=String.format(s, i+1);
			System.out.println("Member Name:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
			if(driver.findElement(By.xpath(s1+"//td[2]")).getText().equals(AuditLog))
			{
		
				System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
				test.log(LogStatus.PASS, "INTRACTIONID IS MATCHED IN HISTORY "+AuditLog);
				System.out.println("INTRACTIONID IS  MATCHED IN HISTORY "+AuditLog);

				break;
			}
		} 
		
		
		driver.close();
		driver.switchTo().window(parentWindow);
		
		
		
		} catch (Exception e) {
	        e.printStackTrace();
	        BaseTest.log.error("Error on createMANAGECLAIM method " + e);
	        test.log(LogStatus.FAIL, "Error on createMANAGECLAIM method " + e);
	        Assert.fail();


			
		}
		return AuditLog;

	}

}


