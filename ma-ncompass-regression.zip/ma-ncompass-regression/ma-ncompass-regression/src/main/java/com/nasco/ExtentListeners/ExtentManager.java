package com.nasco.ExtentListeners;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;


public class ExtentManager {
	//private static String location =System.getProperty("user.dir") + "\\test-output\\surefire-reports\\html\\";
	private static ExtentReports extent;
	public static String fileName;
	
	
	public static ExtentReports getInstance(){
	
		if(extent==null){
			//Thu 30:20:00
//			System.out.println("config"+config.getProperty("EXTREPORT_LOC"));
//			System.out.println("location::"+loc);
			Date d = new Date();
			fileName = "NCompass_MA_ExtentReport"+d.toString().replace(":", "_").replace(" ", "_")+".html";
			//extent = new ExtentReports(System.getProperty("user.dir")+"\\test-output\\surefire-reports\\html\\"+fileName,true,DisplayOrder.OLDEST_FIRST);
			extent = new ExtentReports(RunTestNG_NCompass_MA.Config.getProperty("EXTREPORT_LOC")+fileName,true,DisplayOrder.OLDEST_FIRST);
			//extent.loadConfig(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\extentconfig\\ReportsConfig.xml"));
			extent.loadConfig(new File(RunTestNG_NCompass_MA.Config.getProperty("EXTREPORTCONFIG")));
		}
		
		return extent;
		
	}
	
    public static String screenshotPath;
	public static String screenshotName;
	
	public static void captureScreenshot(String testCaseName) {

		File scrFile = ((TakesScreenshot) DriverManager.getDriver()).getScreenshotAs(OutputType.FILE);

		Date d = new Date();
		screenshotName = testCaseName+"_"+d.toString().replace(":", "_").replace(" ", "_") + ".jpg";
//		System.out.println(screenshotName);
		System.out.println(RunTestNG_NCompass_MA.Config.getProperty("EXTREPORT_LOC") + screenshotName);
		try {
			//FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir") + "\\test-output\\surefire-reports\\html\\" + screenshotName));
			//FileUtils.copyFile(scrFile, new File(Constants.EXTREPORT_LOC +testCaseName+"_"+ screenshotName));
			FileUtils.copyFile(scrFile, new File(RunTestNG_NCompass_MA.Config.getProperty("EXTREPORT_LOC")+ screenshotName));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
	}

}
