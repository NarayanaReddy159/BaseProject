package com.nasco.MA.Regression.utilities;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

import com.nasco.MA.Regression.Run.RunTestNG_NCompass_MA;



public class DataProviders {
	
	@DataProvider(name="MA_Ncompass_R1DP",parallel=true)
	public static Object[][] getDataR1(Method m) {

		//System.out.println(m.getName());
		//System.out.println(System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("R1_XL_PATH"));
		////System.out.println();
		ExcelReader excel = new ExcelReader(System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("R1_XL_PATH"));
		String testcase = m.getName();
		return DataUtil.getData(testcase, excel);
	
	}
	
	@DataProvider(name="MA_Ncompass_R2DP",parallel=true)
	public static Object[][] getDataR2(Method m) {

		//System.out.println(m.getName());
		
		ExcelReader excel = new ExcelReader(System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("R2_XL_PATH"));
		String testcase = m.getName();
		return DataUtil.getData(testcase, excel);
	
	}
	
	@DataProvider(name="MA_Ncompass_R3DP",parallel=true)
	public static Object[][] getDataR3(Method m) {

		//System.out.println(m.getName());
		
		ExcelReader excel = new ExcelReader(System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("R3_XL_PATH"));
		String testcase = m.getName();
		return DataUtil.getData(testcase, excel);
	
	}
	
	@DataProvider(name="MA_Ncompass_R4DP",parallel=true)
	public static Object[][] getDataR4(Method m) {

		//System.out.println(m.getName());
		
		ExcelReader excel = new ExcelReader(System.getProperty("user.dir")+RunTestNG_NCompass_MA.Config.getProperty("R4_XL_PATH"));
		String testcase = m.getName();
		return DataUtil.getData(testcase, excel);
	
	}

}
