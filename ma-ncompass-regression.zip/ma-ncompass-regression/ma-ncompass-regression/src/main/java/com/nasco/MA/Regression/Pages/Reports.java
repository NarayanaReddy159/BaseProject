package com.nasco.MA.Regression.Pages;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;

@SuppressWarnings("rawtypes")
public class Reports extends BasePage {
	
	@FindBy(xpath = "//div[contains(text(),'Welcome')]")
	public WebElement btnLogin;
	String excepionMessage = "";
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		switchToFrame("PegaGadget0Ifr");
		return ExpectedConditions.visibilityOf(btnLogin);
	}

	public void getCategories(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	 {
		try{
			Properties pageLocatorsprop = new Properties();
			pageLocatorsPath= pageLocatorsPath+"\\ReportsWebelements.properties";
			FileInputStream FiledsIn = new FileInputStream(pageLocatorsPath);
			pageLocatorsprop.load(FiledsIn);
			String cat=pageLocatorsprop.getProperty("categoryWebelementvalue");
			
			List<WebElement> categories=driver.findElements(By.xpath(cat));
			assertEquals(data.get("ExpectedPublicCategoriesCount"), String.valueOf(categories.size()), "Public Categories");
			cat="("+cat+")[%d]";
			for(int i=1;i<=categories.size();i++)
			{
				String s1=String.format(cat, i);
				test.log(LogStatus.INFO, "Public Category: " + driver.findElement(By.xpath(s1)).getText());
			}
			cat=cat+"//following::span[3]";
			assertEquals(data.get("ExpectedInteractionReports"),driver.findElement(By.xpath(String.format(cat, 1))).getText(), "Interaction Reports");
			assertEquals(data.get("ExpectedMiscellaneousReports"),driver.findElement(By.xpath(String.format(cat, 2))).getText(), "Miscellaneous Reports");
			assertEquals(data.get("ExpectedServiceIntentReports"),driver.findElement(By.xpath(String.format(cat, 3))).getText(), "Service Intent Reports");
			assertEquals(data.get("ExpectedTimeLinessReports"),driver.findElement(By.xpath(String.format(cat, 4))).getText(), "TimeLiness Reports");
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on movetoReports method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on movetoReports method " + e);
			Assert.fail();
		}
	 }
	
	public void getReports(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	 {
		try{
			Properties pageLocatorsprop = new Properties();
			pageLocatorsPath= pageLocatorsPath+"\\ReportsWebelements.properties";
			FileInputStream FiledsIn = new FileInputStream(pageLocatorsPath);
			pageLocatorsprop.load(FiledsIn);
			
			String cat=pageLocatorsprop.getProperty("categoryWebelementvalue");
			List<WebElement> categories=driver.findElements(By.xpath(cat));
			cat="("+cat+")[%d]";
			int rowCount=0;
			for(int i=1;i<=categories.size();i++)
			{
				String s1=String.format(cat, i);
				if(driver.findElement(By.xpath(s1)).getText().equals(data.get("PublicCategory")))
				{
					driver.findElement(By.xpath(s1)).click();
					rowCount=i;
					break;
				}
			}
			cat=cat+"//following::span[3]";
			String reportsCount=driver.findElement(By.xpath(String.format(cat, rowCount))).getText();
			waitSleep(3500);
			String t1=pageLocatorsprop.getProperty("reportlinkWebelementvalue");
					//"//tr[@id='$PD_pzReportBrowser7$ppzRBShortcuts$l%d']/td[2]";
			String actualReports="|";
			for(int i=1;i<=Integer.valueOf(reportsCount);i++)
			{
				String s1=String.format(t1, i);
				actualReports=actualReports+driver.findElement(By.xpath(s1)).getText()+"|";
				//System.out.println(driver.findElement(By.xpath(s1)).getText());
			}
			//System.out.println(actualReports);
			assertEquals(data.get("ExpectedReports"), actualReports, "Reports");
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on getReports method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getReports method " + e);
			Assert.fail();
		}
	 }
	
	public void getReportDetails(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	 {
		try{
			Properties pageLocatorsprop = new Properties();
			pageLocatorsPath= pageLocatorsPath+"\\ReportsWebelements.properties";
			FileInputStream FiledsIn = new FileInputStream(pageLocatorsPath);
			pageLocatorsprop.load(FiledsIn);
			
			String cat=pageLocatorsprop.getProperty("categoryWebelementvalue");
			List<WebElement> categories=driver.findElements(By.xpath(cat));
			cat="("+cat+")[%d]";
			int rowCount=0;
			for(int i=1;i<=categories.size();i++)
			{
				String s1=String.format(cat, i);
				if(driver.findElement(By.xpath(s1)).getText().equals(data.get("PublicCategory")))
				{
					driver.findElement(By.xpath(s1)).click();
					rowCount=i;
					break;
				}
			}
			cat=cat+"//following::span[3]";
			String reportsCount=driver.findElement(By.xpath(String.format(cat, rowCount))).getText();
			waitSleep(3500);
			String t1=pageLocatorsprop.getProperty("reportlinkWebelementvalue");
			for(int i=1;i<=Integer.valueOf(reportsCount);i++)
			{
				String s1=String.format(t1, i);
				//System.out.println(driver.findElement(By.xpath(s1)).getText());
				if(driver.findElement(By.xpath(s1)).getText().equals(data.get("ReportName")))
				{
					driver.findElement(By.xpath(s1+"//a")).click();
					break;
				}
			}
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			String reportRow=pageLocatorsprop.getProperty("reportHeaderWebelementvalue");
					//"//*[@id='report_body']/table/tbody/tr[1]/th";
			List<WebElement> reportRows=driver.findElements(By.xpath(reportRow));
			reportRow=reportRow+"[%d]";
			String actual="|";
			for(int i=1;i<=reportRows.size();i++)
			{
				String s1=String.format(reportRow, i);
				////System.out.println(driver.findElement(By.xpath(s1)).getText());
				actual=actual+driver.findElement(By.xpath(s1)).getText()+"|";
			}
			
			//System.out.println(actual);
			//assertEquals(data.get("ExpectedReportFileds"), actual, "Report Headers");
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on getReportDetails method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getReportDetails method " + e);
			Assert.fail();
		}
	 }

}
