package com.nasco.MA.Regression.Pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.MA.Regression.Setup.BasePage;
import com.nasco.MA.Regression.Base.BaseTest;
import com.nasco.MA.Regression.Run.RunTestNG_NCompass_MA;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;

@SuppressWarnings("rawtypes")
public class HomePage extends BasePage {
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	String excepionMessage = "";

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return ExpectedConditions.visibilityOf(frame);
	}
	
	@SuppressWarnings("unchecked")
	public MemberSearchPage clickOnLiveInteractionMember(String pageLocatorsPath,String pageFiledsPath) 
			 {
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "interaction", false, "", "New", "New Interaction");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "PhoneLive", false, "", "Phone Live Interaction - Member", "Phone Live Interaction - Member");
			waitSleep(2000);
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on clickOnLiveInteractionMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnLiveInteractionMember method " + e);
			Assert.fail();
		}
		return (MemberSearchPage) openPage(MemberSearchPage.class);

	}
	
	@SuppressWarnings("unchecked")
	public MemberSearchPage clickOnWaikINInteractionMember(String pageLocatorsPath,
			String pageFiledsPath)  {
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "interaction", false, "", "New", "New Interaction");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "WalkIn", false, "", "Walk-in Live Interaction - Member", "Walk-in Live Interaction - Member");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnWaikINInteractionMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnWaikINInteractionMember method " + e);
			Assert.fail();
		}
		return (MemberSearchPage) openPage(MemberSearchPage.class);
	}
	
	@SuppressWarnings("unchecked")
	public MemberSearchPage clickOnChatInteractionMember(String pageLocatorsPath,
			String pageFiledsPath)   
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "interaction", false, "", "New", "New Interaction");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Chat", false, "", "Chat Live Interaction - Member", "Chat Live Interaction - Member");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnChatInteractionMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnChatInteractionMember method " + e);
			Assert.fail();
		}
		return (MemberSearchPage) openPage(MemberSearchPage.class);
	}
	
	@SuppressWarnings("unchecked")
	public MemberSearchPage clickOnResearchInteractionMember(String pageLocatorsPath,
			String pageFiledsPath)   
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "interaction", false, "", "New", "New Interaction");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Research", false, "", "Research Interaction - Member", "Research Interaction - Member");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnResearchInteractionMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnResearchInteractionMember method " + e);
			Assert.fail();
		}
		return (MemberSearchPage) openPage(MemberSearchPage.class);
	}
	
	public void clickOnNonliveInteractionMember(String pageLocatorsPath,
			String pageFiledsPath)   
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "interaction", false, "", "New", "New Interaction");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "NonLive", false, "", "Non Live Interaction - Member", "Non Live Interaction - Member");
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "NLContact", true, "PegaGadget1Ifr", "Testing", "Contact name");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "NLDocumentNumber", true, "PegaGadget1Ifr", "123456789012", "Document number");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "NLSOI", true, "PegaGadget1Ifr", "Social media", "Source of interaction");
			waitSleep(2500);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "NLcommnets", true, "PegaGadget1Ifr", "Testing Non Live Interaction", "Comments");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "NLContact", true, "PegaGadget1Ifr", "Testing", "Contact name");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "NLSubmit", true, "PegaGadget1Ifr", "", "Submit");
			waitSleep(1500);
			waitOnIE(2500);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "NLROI", true, "PegaGadget1Ifr", "Facebook", "Source of interaction");
			waitSleep(1500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "NLSubmit", true, "PegaGadget1Ifr", "", "Submit");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnNonliveInteractionMember method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnNonliveInteractionMember method " + e);
			Assert.fail();
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public RecentWorkPage openrecentWork() {
		waitSleep(2000);
		return (RecentWorkPage) openPage(RecentWorkPage.class);
	}
	
	
	@SuppressWarnings("unchecked")
	public HomePage open() {
		
		return (HomePage) openPage(HomePage.class);
	}

	@SuppressWarnings("unchecked")
	public WorkbasketPage openworkBasket() {
		
		return (WorkbasketPage) openPage(WorkbasketPage.class);
	}
	
	@SuppressWarnings("unchecked")
	public GSIPage openGSI() {
		
		return (GSIPage) openPage(GSIPage.class);
	}	
	
	@SuppressWarnings("unchecked")
	public WorklistPage openWorklist() {
		
		return (WorklistPage) openPage(WorklistPage.class);
	}
	
	public void logout()
	{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//a[contains(text(),'New')]//following::a[2]")).click();
		waitSleep(500);
		driver.findElement(By.xpath("//span[contains(text(),'Logout')]")).click();
		waitSleep(500);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		waitSleep(2500);
	}
	
	public void routeToOriginator(String pageLocatorsPath,String pageFiledsPath, String comments) {
		try{ 
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
//			waitForFrameTobeVisible("PegaGadget1Ifr");
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "routeToOriginator", true, "PegaGadget1Ifr", "", "Route To Originator");
			waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "gsiComments", true, "PegaGadget1Ifr", comments, "comments");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitGSI", true, "PegaGadget1Ifr", "", "Submit");		
			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Not able to route To Originator");
			BaseTest.log.error(excepionMessage);
			test.log(LogStatus.FAIL, "Not able to route To Originator");
			test.log(LogStatus.FAIL,e);
			Assert.fail();
		
		}
	}

	public void NavigateToProcedureDiagCodeLookUp(String pageLocatorsPath, String pageFiledsPath)   
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Resources", false, "", "Resources", "Resources Link");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ProcedureDiagCode", false, "", "Diagnosis Code Look Up", "Procedure/Diagnosis Code Look Up");
			waitSleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnResources method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnResources method " + e);
			Assert.fail();
		}
		
	}
	
	public void searchAndValidateProcedureCodes(String pageLocatorsPath, String pageFiledsPath,String procedureCode, String expectedResult)   
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				driver.switchTo().window(childWindow);
				//System.out.println(driver.switchTo().window(childWindow).getTitle());
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "SearchBy", false, "", procedureCode, "Search by");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchBtn", false, "", "Search", "Search Button");
				validateCodesDetails(pageLocatorsPath, pageFiledsPath,expectedResult);
			
				driver.close();
				}
			}
			driver.switchTo().window(mainWindow);
			
		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnResources method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnResources method " + e);
			Assert.fail();
		}
		
	}

	public void validateCodesDetails(String pageLocatorsPath, String pageFiledsPath,String expectedResult)   
	{
		String CodeDetails="";
		try{
//			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
//			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'$PProcedureResultsPage$ppxResults$l')]"));
			String s="//tr[contains(@id,'$PProcedureResultsPage$ppxResults$l%d')]";
			
			for(int i=0;i<tablerows.size();i++)
			{
				String s1=String.format(s, i+1);
				String codedet="";
				List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
				for(int j=0;j<colums.size();j++)
				{
					if(j==0)
					{
						codedet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
					else{
						codedet=codedet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
				}
				CodeDetails=CodeDetails+","+codedet;	
			}
			waitSleep(1000);
			CodeDetails=CodeDetails.substring(1,CodeDetails.length());
			//System.out.println(CodeDetails);
			assertEquals(expectedResult, CodeDetails, "Procedure code Results");

		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateCodesDetails method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateCodesDetails method " + e);
			Assert.fail();
		}
		
	}

	public void searchAndValidateDiagnosisCodes(String pageLocatorsPath, String pageFiledsPath,String procedureCode, String expectedResult)   
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				driver.switchTo().window(childWindow);
				//System.out.println(driver.switchTo().window(childWindow).getTitle());
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "DiagnosisCodeTab", false, "", "Diagnosis code", "Diagnosis Code Tab");
				waitSleep(1000);
				WebElementAction("type",pageLocatorsPath, pageFiledsPath, "DiagCodeInput", false, "", procedureCode, "Search by");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "DiagSearchBtn", false, "", "", "Search Button");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "DiagSearchBtn", false, "", "", "Search Button");
				waitSleep(3000);
				validateDiagCodesDetails(pageLocatorsPath, pageFiledsPath,expectedResult);
			
				driver.close();
				}
			}
			driver.switchTo().window(mainWindow);
			
		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnResources method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnResources method " + e);
			Assert.fail();
		}
		
	}
	
	public void getDialogue(String pageLocatorsPath, String pageFiledsPath)   
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				driver.switchTo().window(childWindow);
				//System.out.println(driver.switchTo().window(childWindow).getTitle());
				test.log(LogStatus.PASS, "No Dialogue Tip available in Procedure code tab");
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "DiagnosisCodeTab", false, "", "Diagnosis code", "Diagnosis Code Tab");
				waitSleep(1000);
				test.log(LogStatus.PASS, "No Dialogue Tip available in Procedure code tab");
				driver.close();
				}
			}
			driver.switchTo().window(mainWindow);
			
		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnResources method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnResources method " + e);
			Assert.fail();
		}
		
	}
	
	public void validateDiagCodesDetails(String pageLocatorsPath, String pageFiledsPath,String expectedResult)   
	{
		String CodeDetails="";
		try{
//			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
//			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'$PDiagnosisResultsPage$ppxResults$l1')]"));
			String s="//tr[contains(@id,'$PDiagnosisResultsPage$ppxResults$l%d')]";
			
			for(int i=0;i<tablerows.size();i++)
			{
				String s1=String.format(s, i+1);
				String codedet="";
				List<WebElement> colums= driver.findElements(By.xpath(s1+"//td"));
				for(int j=0;j<colums.size();j++)
				{
					if(j==0)
					{
						codedet=driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
					else{
						codedet=codedet+"|"+driver.findElement(By.xpath(s1+"//td["+(j+1)+"]")).getText();
					}
				}
				CodeDetails=CodeDetails+","+codedet;	
			}
			waitSleep(1000);
			CodeDetails=CodeDetails.substring(1,CodeDetails.length());
			//System.out.println(CodeDetails);
			assertEquals(expectedResult, CodeDetails, "Diagnosis code Results");

		} catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateDiagCodesDetails method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateDiagCodesDetails method " + e);
			Assert.fail();
		}
		
	}

//	public void switchToAdminPortal(String pageLocatorsPath,String pageFiledsPath) {
//		try{ 
//			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
//			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
//			driver.switchTo().defaultContent();
//			driver.findElement(By.xpath("//a[contains(text(),'New')]//following::a[2]")).click();
//			
//			Actions action = new Actions(driver);
//			action.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Switch portal')]"))).moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Admin Portal')]"))).click().build().perform();
//			waitSleep(3000);
//			Alert alert = driver.switchTo().alert();
//			alert.accept();
//		} catch (Exception e){
//			e.printStackTrace();
//			excepionMessage = Arrays.toString(e.getStackTrace());
//			BaseTest.log.error("Error on switchToAdminPortal method " + excepionMessage);
//			test.log(LogStatus.FAIL, "Error on switchToAdminPortal method " + e);
//			test.log(LogStatus.FAIL,e);
//			Assert.fail();
//		
//		}
//	}
//
//	public void switchToNcompassPortal(String pageLocatorsPath,String pageFiledsPath, String username) {
//		try{ 
//			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
//			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
//			driver.switchTo().defaultContent();
//			//String username=RunTestNG_NCompass_MA.Config.getProperty("username_user1");
//			driver.findElement(By.xpath("//a[contains(text(),'"+username+"')]")).click();
//			waitSleep(1000);
//			Actions action = new Actions(driver);
//			action.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Switch portal')]"))).moveToElement(driver.findElement(By.xpath("//span[contains(text(),'BlueView')]"))).click().build().perform();
//			waitSleep(1000);
//			Alert alert = driver.switchTo().alert();
//			alert.accept();
//		} catch (Exception e){
//			e.printStackTrace();
//			excepionMessage = Arrays.toString(e.getStackTrace());
//			BaseTest.log.error("Error on switchToAdminPortal method " + excepionMessage);
//			test.log(LogStatus.FAIL, "Error on switchToAdminPortal method " + e);
//			test.log(LogStatus.FAIL,e);
//			Assert.fail();
//		
//		}
//	}

	public void switchToAdminPortal(String pageLocatorsPath,String pageFiledsPath) {
        try{ 
              pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
              pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
              waitSleep(3000);
        if(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString().equalsIgnoreCase("ie"))
              {
                    String url=RunTestNG_NCompass_MA.Config.getProperty("URL").toString();
                    driver.navigate().to(url+"uqEpdfKsJtRFE1FUhOz1MA%5B%5B*/!STANDARD?pyActivity=Data-Portal.ShowSelectedPortal&portal=AdminPortal&Name=CPMHCInteractionPortal&developer=false&isPreviewFrame=");
                    
              }
              else{
                    driver.switchTo().defaultContent();
                  driver.findElement(By.xpath("//a[contains(text(),'New')]//following::a[2]")).click();
                    waitSleep(1000);
                    Actions action = new Actions(driver);
                    action.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Switch portal')]"))).moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Admin Portal')]"))).click().build().perform();
                    waitSleep(3000);
                    Alert alert = driver.switchTo().alert();
                    alert.accept();
              }
              
              
        } catch (Exception e){
              e.printStackTrace();
              excepionMessage = Arrays.toString(e.getStackTrace());
              BaseTest.log.error("Error on switchToAdminPortal method " + excepionMessage);
              test.log(LogStatus.FAIL, "Error on switchToAdminPortal method " + e);
              test.log(LogStatus.FAIL,e);
              Assert.fail();
        
        }
  }

  public void switchToNcompassPortal(String pageLocatorsPath,String pageFiledsPath, String username) {
        try{ 
              pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
              pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
        if(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString().equalsIgnoreCase("ie"))
              {
                    String url=RunTestNG_NCompass_MA.Config.getProperty("URL").toString();
                    driver.navigate().to(url+"uqEpdfKsJtRFE1FUhOz1MA%5B%5B*/!STANDARD?pyActivity=Data-Portal.ShowSelectedPortal&portal=CPMHCInteractionPortal&Name=AdminPortal&developer=false&isPreviewFrame=");
              }
              else{
                    driver.switchTo().defaultContent();
                    driver.findElement(By.xpath("//a[contains(text(),'"+username+"')]")).click();
                    waitSleep(1000);
                    Actions action = new Actions(driver);
                    action.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Switch portal')]"))).moveToElement(driver.findElement(By.xpath("//span[contains(text(),'BlueView')]"))).click().build().perform();
                    waitSleep(1000);
                    Alert alert = driver.switchTo().alert();
                    alert.accept();
              }
              
              
        } catch (Exception e){
              e.printStackTrace();
              excepionMessage = Arrays.toString(e.getStackTrace());
              BaseTest.log.error("Error on switchToAdminPortal method " + excepionMessage);
              test.log(LogStatus.FAIL, "Error on switchToAdminPortal method " + e);
              test.log(LogStatus.FAIL,e);
              Assert.fail();
        
        }
  }

	public void waittoloadHomePage() {
		//waitForElementsToVisible("//tr[contains(@id,'$PMemberSearchResults$ppxResults$l')]");
		if(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString().equalsIgnoreCase("ie"))
		{
			waitOnIE(3500);
		}else{
			waitForFrameTobeVisible("PegaGadget0Ifr");	
		}
		
		
	}
	
	@SuppressWarnings("unchecked")
	public Callback_RTCPage openRTC_Callback() {
		
		return (Callback_RTCPage) openPage(Callback_RTCPage.class);
	}
	
	public void clickOnMangeChane(String pageLocatorsPath,String pageFiledsPath)   
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			switchToDefault();
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ManageChange", false, "", "Manage Change", "Manage Change");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on clickOnMangeChane method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on clickOnMangeChane method " + e);
			Assert.fail();
		}
		
	}
	
	public void validateInformation(String pageLocatorsPath,String pageFiledsPath) {
		try{ 
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
	
			if (driver.findElement(By.xpath("//span[contains(text(),'My Worklist')]")).isDisplayed()) {
				BaseTest.log.info("My Worklist is displayed");
				test.log(LogStatus.PASS, "My Worklist is displayed");
			} else {
				BaseTest.log.error("My Worklist is not displayed");
				test.log(LogStatus.FAIL, "My Worklist is not displayed");
			}
			
			if (driver.findElement(By.xpath("//span[contains(text(),'Manage Operators')]")).isDisplayed()) {
				BaseTest.log.info("Manage Operators is displayed");
				test.log(LogStatus.PASS, "Manage Operators is displayed");
			} else {
				BaseTest.log.error("Manage Operators is not displayed");
				test.log(LogStatus.FAIL, "Manage Operators is not displayed");
			}
		} catch (Exception e){
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on switchToAdminPortal method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on switchToAdminPortal method " + e);
			test.log(LogStatus.FAIL,e);
			Assert.fail();
		
		}
	}

	public void validateInfoOnNcompass(String pageLocatorsPath,String pageFiledsPath) {
		try{ 
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			switchToFrame("PegaGadget0Ifr");
			if (driver.findElement(By.xpath("(//h3[contains(text(),'Work List')])[2]")).isDisplayed()) {
				BaseTest.log.info("Work List is displayed");
				test.log(LogStatus.PASS, "Work List is displayed");
			} else {
				BaseTest.log.error("Work List is not displayed");
				test.log(LogStatus.FAIL, "Work List is not displayed");
			}
			
			if (driver.findElement(By.xpath("//h3[contains(text(),'Recent work')]")).isDisplayed()) {
				BaseTest.log.info("Recent work is displayed");
				test.log(LogStatus.PASS, "Recent work is displayed");
			} else {
				BaseTest.log.error("Recent work is not displayed");
				test.log(LogStatus.FAIL, "Recent work is not displayed");
			}
		} catch (Exception e){
			e.printStackTrace();
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on switchToAdminPortal method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on switchToAdminPortal method " + e);
			test.log(LogStatus.FAIL,e);
			Assert.fail();
		
		}
	}
	
	public void movetoReports(String pageLocatorsPath,String pageFiledsPath) 
	 {
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			switchToFrame("PegaGadget0Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "MyReports", true, "PegaGadget0Ifr", "My Reports", "My Reports");
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on movetoReports method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on movetoReports method " + e);
			Assert.fail();
		}
	 }
	
	public void getPortal(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			switchToFrame("PegaGadget0Ifr");
			
			String portalLink="//h3[@class='layout-group-item-title']";
			List<WebElement> portalAccess=driver.findElements(By.xpath(portalLink));
			portalLink="("+portalLink+")[%d]";
			test.log(LogStatus.PASS, "Below are CSR Portal tabs");
			//System.out.println("CSR Portal tabs:");
			for(int i=1;i<=portalAccess.size();i++)
			{
				String s1=String.format(portalLink, i);
				test.log(LogStatus.PASS, driver.findElement(By.xpath(s1)).getText());
				//System.out.println(driver.findElement(By.xpath(s1)).getText());
			}
			
			portalLink="//a[contains(@class,'Dashboard')]";
			portalAccess=driver.findElements(By.xpath(portalLink));
			portalLink="("+portalLink+")[%d]";
			test.log(LogStatus.PASS, "Below are Portal Links");
			//System.out.println("Portal Links:");
			for(int i=1;i<=portalAccess.size();i++)
			{
				String s1=String.format(portalLink, i);
				test.log(LogStatus.PASS, driver.findElement(By.xpath(s1)).getText());
				//System.out.println(driver.findElement(By.xpath(s1)).getText());
			}
			//WebElementAction("click",pageLocatorsPath, pageFiledsPath, "interaction", false, "", "New", "New Interaction");
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//a[contains(text(),'New')]")).click();
			portalLink="//span[@class='menu-item-title']";
			portalAccess=driver.findElements(By.xpath(portalLink));
			portalLink="("+portalLink+")[%d]";
			test.log(LogStatus.PASS, "Below are interactions available to operator");
			//System.out.println("Interactions");
			for(int i=1;i<=portalAccess.size();i++)
			{
				String s1=String.format(portalLink, i);
				test.log(LogStatus.PASS, driver.findElement(By.xpath(s1)).getText());
				//System.out.println(driver.findElement(By.xpath(s1)).getText());
			}
			
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on getPortal method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getPortal method " + e);
			Assert.fail();
		}
	}
	
	public void getIntents(String pageLocatorsPath,String pageFiledsPath)
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\InteractionMangerPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\InteractionMangerPageFields.properties";
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "addTask", true, "PegaGadget1Ifr", "", "add Task");
			
			String portalLink="//a[@class='Add_task']";
			List<WebElement> portalAccess=driver.findElements(By.xpath(portalLink));
			//System.out.println("Intents size: "+portalAccess.size());
			portalLink="("+portalLink+")[%d]";
			test.log(LogStatus.PASS, "Below are Intents available to operator");
			//System.out.println("CSR Portal tabs:");
			for(int i=1;i<=portalAccess.size();i++)
			{
				String s1=String.format(portalLink, i);
				test.log(LogStatus.PASS, driver.findElement(By.xpath(s1)).getText());
				//System.out.println(driver.findElement(By.xpath(s1)).getText());
			}
			driver.findElement(By.xpath("(//div[contains(text(),'Cancel')])[4]//ancestor::button")).click();
			waitSleep(1500);
			
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on getPortal method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getPortal method " + e);
			Assert.fail();
		}
	}
	
	public void switchPortalAndValidate(String pageLocatorsPath,String pageFiledsPath,String uname,Hashtable<String,String> data)
	{
		
		try{
			switchToAdminPortal(pageLocatorsPath,pageFiledsPath);
			pageLocatorsPath= pageLocatorsPath+"\\HomePageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\HomePageFields.properties";
			waitSleep(3500);
			
//			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "userMenu", true, "PegaGadget1Ifr", "", "userMenu");
//			waitSleep(2500);
//			driver.switchTo().defaultContent();
//			driver.findElement(By.xpath("//a[contains(text(),'New')]//following::a[2]")).click();
//			
//			Actions action = new Actions(driver);
//			waitSleep(2500);
//			action.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Switch portal')]"))).moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Admin Portal')]"))).click().build().perform();
//			waitSleep(1000);
//			Alert alert = driver.switchTo().alert();
//			alert.accept();
			
			waitSleep(2000);
			ArrayList<String> headerRow= new ArrayList<String>();
			ArrayList<String> dataRow= new ArrayList<String>();
			headerRow.add("Manage Change");
			headerRow.add("Delegated results displayed");
			headerRow.add("Manage Operators");
			headerRow.add("Skill");
			headerRow.add("WorkBasket");
			headerRow.add("WorkGroup");
			try{
				switchToDefault();
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ManageChange", false, "", "Manage Change", "Manage Change");
				dataRow.add("True");
			}catch(Exception e){
				dataRow.add("False");
			}
			driver.switchTo().defaultContent();
			driver.switchTo().frame("PegaGadget1Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "ManageChange_Search_Input", true, "PegaGadget1Ifr", "Add Newborn", "ManageChange_Search_Input");
			WebElementAction("presstab",pageLocatorsPath, pageFiledsPath, "ManageChange_Search_Input", true, "PegaGadget1Ifr", "", "Press Tab ManageChange_Search_Input");
			waitSleep(4000);
			WebElement DelegatedRules_Result = driver.findElement(By.xpath("//span[contains(text(),'Add Newborn')]"));
			if(DelegatedRules_Result.isDisplayed())
			{
				dataRow.add("True");
			}else {
				dataRow.add("False");
			}

			driver.switchTo().defaultContent();
				
			WebElement manageOperators_Link = driver.findElement(By.xpath("//span[contains(text(),'Manage Operators')]//ancestor::a"));
			if(manageOperators_Link.isDisplayed())
			{
				dataRow.add("True");
			}else {
				dataRow.add("False");
			}
			manageOperators_Link.click();
			driver.switchTo().defaultContent();
			driver.switchTo().frame("PegaGadget2Ifr");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "SearchByNameorUserID", true, "PegaGadget2Ifr", uname, "ManageChange_Search_Input");
			waitSleep(2000);
			driver.switchTo().defaultContent();
			
			waitSleep(3000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "userMenu2", false, "", "", "userMenu2");
			waitSleep(3000);
			driver.switchTo().defaultContent();
			driver.switchTo().frame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "SearchByNameorUserID_SearchButton", true, "PegaGadget2Ifr", "", "SearchByNameorUserID");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "UpdateButton", true, "PegaGadget2Ifr", "", "UpdateButton");
			
			
			WebElement Skill = driver.findElement(By.xpath("//input[contains(@id,'SkillName1')]"));
			WebElement WorkBasket = driver.findElement(By.xpath("//input[contains(@id,'BasketName1')]"));
			WebElement Workgroup = driver.findElement(By.xpath("//input[contains(@id,'WorkGroup')]"));
			
				
			dataRow.add(Skill.getAttribute("value"));
			dataRow.add(WorkBasket.getAttribute("value"));
			dataRow.add(Workgroup.getAttribute("value"));
			
			String actualResultStr="";
			for(int i=0;i<=5;i++){
				if(i==5){
					actualResultStr=actualResultStr + dataRow.get(i);
				}else{
				actualResultStr=actualResultStr + dataRow.get(i) + "|";
				}
				
			}
			//System.out.println("ExpectedResults::::::::"+actualResultStr);
			
			assertEquals(data.get("ExpectedResults"),actualResultStr,"ResultsValidation");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "cancelbtn",true, "PegaGadget2Ifr", "", "Cancel button");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "closebtn",true, "PegaGadget2Ifr", "", "close button");
			
		}
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			e.printStackTrace();
			BaseTest.log.error("Error on switchPortalAndValidate method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on switchPortalAndValidate method " + e);
			Assert.fail();
		}
		
		
	}
	
}

