package com.nasco.MA.Pages;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nasco.Setup.BasePage;
import com.nasco.testcases.BaseTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;




public class ViewBenefitsPage extends BasePage {

	@FindBy(xpath="//label[@id='pyActionLabel']//following::span[1]")
	public WebElement intentID;
	
	String excepionMessage="";
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget2Ifr");
		return ExpectedConditions.visibilityOf(intentID);
	}
	

	
	public String getIntentID(String pageLocatorsPath,String pageFiledsPath) 
	{	
		String intentid="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			intentid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "interactionID", true, "PegaGadget2Ifr", "View Benefits", "Intent ID");
			intentid= intentid.substring(1, intentid.length()-1);
			System.out.println(intentid);
			test.log(LogStatus.INFO, "Intent ID:"+intentid);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on getIntentID method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on getIntentID method " + e);
			Assert.fail();
		}
		return intentid;
	}
		
	public void create_BEN_Quote_Benefit(String pageLocatorsPath,String pageFiledsPath, Hashtable<String,String> data)
	{
		try {
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			if (data.get("IsBenefitQuoted").equalsIgnoreCase("Y")) {
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "quoteBenefitYes", true, "PegaGadget2Ifr", "", "quote Benefit as Yes");
			} else {
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "quoteBenefitNo", true, "PegaGadget2Ifr", "", "quote Benefit as No");
			}
			
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "topicCategory", true, "PegaGadget2Ifr", data.get("TopicCategory"), "Topic Category");
			//waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "subcategory", true, "PegaGadget2Ifr", data.get("SubCategory"), "Sub Category");
			//waitSleep(1000);
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "providerReq", true, "PegaGadget2Ifr", data.get("ProviderReq"), "Provider Requirements - Name");
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "participationSt", true, "PegaGadget2Ifr", data.get("ParticipationSt"), "Participation Status");
			waitSleep(1000);
			WebElementAction("selectbytext",pageLocatorsPath, pageFiledsPath, "pos", true, "PegaGadget2Ifr", data.get("PoS"), "Plase of Service");
			waitSleep(1000);
			if (data.get("DeductibleInd").equalsIgnoreCase("Y"))
				WebElementAction("click",pageLocatorsPath, pageFiledsPath, "deductibleIndYes", true, "PegaGadget2Ifr", "", "Deductible Indicator Yes");
			
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "deductibleInNet", true, "PegaGadget2Ifr", data.get("DeductibleInNet"), "Deductible In Net");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget2Ifr", data.get("Comments"), "comments");
			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "deductibleOutNet", true, "PegaGadget2Ifr", data.get("DeductibleOutNet"), "Deductible Out Net");
//			WebElementAction("type",pageLocatorsPath, pageFiledsPath, "comments", true, "PegaGadget2Ifr", data.get("Comments"), "comments");
			
			
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
		} catch (Exception e){
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on create_BEN_Quote_Benefit method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on create_BEN_Quote_Benefit method " + e);
			Assert.fail();

		}
	}
	
	public void validateBenefit(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			String actualStatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "status", true, "PegaGadget1Ifr", data.get("Expected_Status"), "Status");
			assertEquals(data.get("Expected_Status"), actualStatus, "Status");
			
			String actualContact=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "contact", true, "PegaGadget1Ifr", data.get("Expected_Contact"), "Contact");
			assertEquals(data.get("Expected_Contact"), actualContact, "Contact");

			String actualMeberid=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "memberId", true, "PegaGadget1Ifr", data.get("Expected_MemberId"), "Member Id");
			assertEquals(data.get("Expected_MemberId"), actualMeberid, "Member Id");

			String actualChannel=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "channel", true, "PegaGadget1Ifr", data.get("Expected_Channel"), "Channel");
			assertEquals(data.get("Expected_Channel"), actualChannel, "Channel");

			String actualCreateOperator=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "createOperator", true, "PegaGadget1Ifr", data.get("Expected_CreateOperator"), "Create Operator");
			assertEquals(data.get("Expected_CreateOperator"), actualCreateOperator, "Create Operator");

			String actualResolveOperator=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "resolveOperator", true, "PegaGadget1Ifr", data.get("Expected_ResolvedOperator"), "Resolved Operator");
			assertEquals(data.get("Expected_ResolvedOperator"), actualResolveOperator, "Resolve Operator");

			String actualCategory=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "categoryReviewHarness", true, "PegaGadget1Ifr", data.get("Expected_TopicCategory"), "Topic Category");
			assertEquals(data.get("Expected_TopicCategory"), actualCategory, "Category");

			String actualSubCategory=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "subCategoryReviewHarness", true, "PegaGadget1Ifr", data.get("Expected_SubCategory"), "Sub Category");
			assertEquals(data.get("Expected_SubCategory"), actualSubCategory, "Sub Category");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
	
	public void validateBenefitSomeMoreInfo(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data) 
	{
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			switchToFrame("PegaGadget1Ifr");
			String actualName=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "name", true, "PegaGadget1Ifr", "Name", "Name");
			assertEquals(data.get("Expected_Name"), actualName, "Name");
			
			String actualParticipationstatus=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Participationstatus", true, "PegaGadget1Ifr", "Participation status", "Participation status");
			assertEquals(data.get("Expected_Participationstatus"), actualParticipationstatus, "Participation status");
			
			String actualPlaceofservice=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "Placeofservice", true, "PegaGadget1Ifr", "Place of service", "Place of service");
			assertEquals(data.get("Expected_Placeofservice"), actualPlaceofservice, "Place of service");
			
			String actualComments=WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "CommentsReviewHarness", true, "PegaGadget1Ifr", "Comments", "Comments");
			assertEquals(data.get("Expected_Comments"), actualComments, "Comments");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateRecentWork method " + e);
			test.log(LogStatus.FAIL, "Error on validateRecentWork method " + e);
			Assert.fail();
		}
	}
	
	public void viewPSA(String pageLocatorsPath,String pageFiledsPath,String frame){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			waitSleep(2500);
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "PSATab", true, frame, "", "PSATab");
			waitSleep(5000);
			waitSleep(3000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on viewPSA method " + e);
			test.log(LogStatus.FAIL, "Error on viewPSA method " + e);
			Assert.fail();
		}
		
	}
	public void viewOLB(String pageLocatorsPath,String pageFiledsPath){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			waitSleep(3000);
			switchToFrame("PegaGadget2Ifr");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ViewLaunchBenefits", true, "PegaGadget2Ifr", "", "ViewLaunchBenefits");
			waitSleep(3000);	
			waitSleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on viewOLB method " + e);
			test.log(LogStatus.FAIL, "Error on viewOLB method " + e);
			Assert.fail();
		}
		
	}
	
	public void OtherActions(String pageLocatorsPath,String pageFiledsPath,Hashtable <String,String> data){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherAction", true, "PegaGadget2Ifr", "", "OtherActions");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "RequestCostEstimate", true, "PegaGadget2Ifr", "", "RequestCostEstimate");
			waitSleep(3000);
			switchToFrame("PegaGadget3Ifr");
			String actualstr = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "RequestCostEstimateDisplay", true, "PegaGadget3Ifr", "", "RequestCostEstimate");
			assertEquals(data.get("ExpectedReqCostEst"),actualstr,"ExpectedReqCostEst");
//			if(driver.findElement(By.xpath("//label[contains(text(),'Document Cost Estimate Request')]")).isDisplayed())
//			{
//				//NTestScript.logScreenshotReport(context, testSetup);
//			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActions method " + e);
			test.log(LogStatus.FAIL, "Error on OtherActions method " + e);
			Assert.fail();
		}
		
	}
	
	public void validateLaunchbenefits(String pageLocatorsPath,String pageFiledsPath,String frame) 
	{
		try{
			waitSleep(2000);
			switchToFrame(frame);
			
			if (driver.findElement(By.xpath("//button[contains(text(),'Launch benefits')]")).isDisplayed()) {
				BaseTest.log.info("Launch benefits is displayed");
				test.log(LogStatus.PASS, "Launch benefits is displayed");
			} else {
				BaseTest.log.error("Launch benefits is not displayed");
				test.log(LogStatus.FAIL, "Launch benefits is not displayed");
				Assert.fail();
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on validateLaunchbenefits method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on validateLaunchbenefits method " + e);
			Assert.fail();
		}
	 }
	public void navigateHistory(String pageLocatorsPath,String pageFiledsPath,String frame){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			switchToFrame(frame);
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "Tools", true, frame, "View Benefits", "Tools");
			waitSleep(2000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ViewHistory", true, frame, "", "View History");
			waitSleep(1000);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on navigateHistory method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on navigateHistory method " + e);
			Assert.fail();
		}
		
	}
	
	public void ValidateHistoryEntry(String pageLocatorsPath,String pageFiledsPath,String entryMsg){
		String actualMsg="";
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
//			switchToFrame(frame);
			waitSleep(2000);
			String mainWindow=driver.getWindowHandle();
			Set<String> windowhandle =driver.getWindowHandles();
			Iterator<String> itr= windowhandle.iterator();
			while(itr.hasNext()){
				String childWindow=itr.next();
			if(!mainWindow.equals(childWindow)){
				driver.switchTo().window(childWindow);
				System.out.println(driver.switchTo().window(childWindow).getTitle());
				waitSleep(2000);
				List<WebElement> tablerows= driver.findElements(By.xpath("//tr[contains(@id,'$PD_pyWorkHistory_pa')]"));
				System.out.println("tablerows "+tablerows.size());
				String s="(//tr[contains(@id,'PD_pyWorkHistory_pa')])[%d]";  
				for(int i=0;i<tablerows.size();i++)
				{  //$PD_pyWorkHistory_pa58165677102201993pz$ppxResults$l3
					String s1=String.format(s, i+1);
					System.out.println("Expected Msg "+entryMsg);
					System.out.println("Message "+driver.findElement(By.xpath(s1+"//td[2]//div")).getText());
					actualMsg = driver.findElement(By.xpath(s1+"//td[2]//div")).getText();
					if( actualMsg.equalsIgnoreCase(entryMsg) ) 
					{
						assertEquals(entryMsg,actualMsg,"Entry Message on history");
		
						break;
						
					}
				}	
		
				driver.close();
				}
			}
			driver.switchTo().window(mainWindow);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on navigateHistory method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on navigateHistory method " + e);
			Assert.fail();
		}
		
	}
	
	public void submitViewBenefit(String pageLocatorsPath,String pageFiledsPath, String frame){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			switchToFrame(frame);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "quoteBenefitNo", true, frame, "", "quote Benefit as No");
			waitSleep(1000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on  closeintentwithNotes method " + excepionMessage);
			test.log(LogStatus.FAIL, "Error on  closeintentwithNotes method " + e);
			Assert.fail();
		}
	}
	
	public void OtherActionsViewBenefits(String pageLocatorsPath,String pageFiledsPath){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitSleep(2500);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "otherAction", true, "PegaGadget2Ifr", "", "OtherActions");
			waitSleep(4000);
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "ViewBenefits", true, "PegaGadget2Ifr", "View benefits", "View Benefits");
			waitSleep(3000);
			//switchToFrame("PegaGadget3Ifr");
			//String actualstr = WebElementAction("readText",pageLocatorsPath, pageFiledsPath, "RequestCostEstimateDisplay", true, "PegaGadget3Ifr", "", "RequestCostEstimate");
			//assertEquals(data.get("ExpectedReqCostEst"),actualstr,"ExpectedReqCostEst");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsViewBenefits method " + e);
			test.log(LogStatus.FAIL, "Error on OtherActionsViewBenefits method " + e);
			Assert.fail();
		}
		
	}
	
	
	public void ValidateViewBenefits(String pageLocatorsPath,String pageFiledsPath,Hashtable<String,String> data){
		try{
			pageLocatorsPath= pageLocatorsPath+"\\ViewBenefitsPageWebelements.properties";
			pageFiledsPath=pageFiledsPath+"\\ViewBenefitsPageFields.properties";
			switchToFrame("PegaGadget2Ifr");
			waitSleep(2500);
			ArrayList<String> headerRow = new ArrayList<String>();
			ArrayList<String> dataRow = new ArrayList<String>();
			ArrayList<String> datavalues = new ArrayList<String>();
			datavalues.add("Member ID");
			datavalues.add("Account number");
			datavalues.add("Account name");
			datavalues.add("Group number");
			datavalues.add("Group name");
			datavalues.add("Plan name");
			datavalues.add("Coverage package code");
			datavalues.add("Coverage package code prefix");
			datavalues.add("PCP state affiliation");
			datavalues.add("Financial arrangement");
			datavalues.add("MCC compliant");
			datavalues.add("Anniversary date");
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget3Ifr");
			String Actual_str="";
			for (int i = 0; i < datavalues.size(); i++) {
				//headerRow.add(datavalues.get(i));
				if(i==0){
					Actual_str = driver.findElement(By.xpath("//span[contains(text(),'" + datavalues.get(i) + "')]//following-sibling::div")).getText();
				}
				Actual_str = Actual_str + "|" + driver.findElement(By.xpath("//span[contains(text(),'" + datavalues.get(i) + "')]//following-sibling::div")).getText();
			}
			System.out.println("Actual String displayed :" + Actual_str);
			assertEquals(data.get("ExpectedResults"),Actual_str,"View Benefit Displayed Results");
			WebElementAction("click",pageLocatorsPath, pageFiledsPath, "submitBEN", true, "PegaGadget2Ifr", "", "Submit");
			waitSleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on ValidateViewBenefits method " + e);
			test.log(LogStatus.FAIL, "Error on ValidateViewBenefits method " + e);
			Assert.fail();
		}
		
	}
}
