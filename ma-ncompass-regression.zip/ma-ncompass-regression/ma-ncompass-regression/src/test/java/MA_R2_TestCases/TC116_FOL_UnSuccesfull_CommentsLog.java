package MA_R2_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.FollowUp;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC116_FOL_UnSuccesfull_CommentsLog extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC116_FOL_UnSuccesfull_CommentsLog (Hashtable<String,String> data) throws Exception {
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC116_FOL_UnSuccesfull_CommentsLog");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user1"), RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through SSN "+data.get("Social Security number"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		FollowUp fol =interactionManger.openFollowUp();
		log.debug("Navigate to interaction manger");
		String intentID=fol.getIntentID(pageLocatorsPath, pageFiledsPath);
		log.debug("intent ID "+intentID);
		fol.create_FollowUp_Scheduled(pageLocatorsPath, pageFiledsPath, data);
		interactionManger.wrapupClosednotverifiedIntent("Wrapping interaction", "Eligibility", pageLocatorsPath, pageFiledsPath);
		WorklistPage worklist= interactionManger.openWorklist();
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
     	fol.FollowUp_Attempt(pageLocatorsPath, pageFiledsPath, data,data.get("FollowUpAttempt"));
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
     	test.log(LogStatus.PASS, "Work item "+intentID+" is in operator worklist");
     	fol.verifyCommentsLog(intentID, intentID, data);
     	fol.closeFollowup(pageLocatorsPath, pageFiledsPath);
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
     	fol.FollowUp_Attempt(pageLocatorsPath, pageFiledsPath, data,data.get("FollowUpAttempt1"));
     	
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC116_FOL_UnSuccesfull_CommentsLog Completed");
		log.debug("End the TC Execution:- AUTC116_FOL_UnSuccesfull_CommentsLog Completed");
		quit();
		
	}

}
