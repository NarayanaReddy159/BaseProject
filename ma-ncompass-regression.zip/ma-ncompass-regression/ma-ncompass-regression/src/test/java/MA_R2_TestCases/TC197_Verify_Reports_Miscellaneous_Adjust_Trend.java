package MA_R2_TestCases;

import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.Reports;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class TC197_Verify_Reports_Miscellaneous_Adjust_Trend extends BaseTest{
	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC197_Verify_Reports_Miscellaneous_Adjust_Trend(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC197_Verify_Reports_Miscellaneous_Adjust_Trend");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC197_Verify_Reports_Miscellaneous_Adjust_Trend - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC197_Verify_Reports_Miscellaneous_Adjust_Trend -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		homepage.movetoReports(pageLocatorsPath, pageFiledsPath);
		test.log(LogStatus.INFO, "My Reports link clicked in Home Page and operator redirected to My Reports");
		log.debug("My Reports link clicked in Home Page and operator redirected to My Reports");
		Reports reports= new Reports();
		reports.getReportDetails(pageLocatorsPath, pageFiledsPath,data);
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC197_Verify_Reports_Miscellaneous_Adjust_Trend Completed");
		log.debug("AUTC197_Verify_Reports_Miscellaneous_Adjust_Trend Completed");
		quit();
		
		
	}
}
