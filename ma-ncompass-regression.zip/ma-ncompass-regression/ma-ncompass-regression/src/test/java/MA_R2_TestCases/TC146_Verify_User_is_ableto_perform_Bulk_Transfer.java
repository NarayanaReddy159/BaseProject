package MA_R2_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.Manager_toolsPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC146_Verify_User_is_ableto_perform_Bulk_Transfer extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC146_Verify_User_is_ableto_perform_Bulk_Transfer (Hashtable<String,String> data) throws Exception {
	
		String frame0="PegaGadget0Ifr", frame1= "PegaGadget1Ifr";
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC146_Verify_User_is_ableto_perform_Bulk_Transfer");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC146_Verify_User_is_ableto_perform_Bulk_Transfer - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC146_Verify_User_is_ableto_perform_Bulk_Transfer -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		Manager_toolsPage tool=new Manager_toolsPage();
		tool.movetoManagetooltab(pageLocatorsPath, pageFiledsPath, frame0);
		tool.movetoTranfer(pageLocatorsPath, pageFiledsPath, frame0);
		tool.filterAssignments(pageLocatorsPath, pageFiledsPath, frame1);
		tool.selectaction(pageLocatorsPath, pageFiledsPath, frame1,data.get("Transferto"),data.get("Operator"),data);

	}
	
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC146_Verify_User_is_ableto_perform_Bulk_Transfer Completed");
		
		quit();
		
	}

}
