package MA_R2_TestCases;

import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class TC183_Actors_CSR_ManageClaims extends BaseTest{
	


	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC183_Actors_CSR_ManageClaims(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC183_Actors_CSR_ManageClaims");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC183_Actors_CSR_ManageClaims - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_csr"), RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		log.debug("AUTC183_Actors_CSR_ManageClaims -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_csr")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_csr")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		test.log(LogStatus.INFO, "Operator able to create interaction");
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data);
		test.log(LogStatus.INFO, "Operator able to access Member Search Page");
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		test.log(LogStatus.INFO, "Operator able to access Interaction Manager Page");
		InteractionManagerPage interactionMgr=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath, pageFiledsPath, data.get("Fname"));
		log.debug(data.get("Fname")+" Selected from the search results and navigated to interaction manager page");
		interactionMgr.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		GSIPage gsi =interactionMgr.openGSI();
		log.debug("Navigate to interaction manger");
		gsi.getIntentID(pageLocatorsPath, pageFiledsPath);
		gsi.searchManageClaim(pageLocatorsPath, pageFiledsPath, data);
		gsi.selectClaim(pageLocatorsPath, pageFiledsPath);
		gsi.movetoOtherActions(pageLocatorsPath, pageFiledsPath);
		gsi.getOptions(pageLocatorsPath, pageFiledsPath, "otherOptions", "Adjust Claim", "PegaGadget2Ifr", "Adjust Claim");
		gsi.getOptions(pageLocatorsPath, pageFiledsPath, "otherOptions", "Route for Claim Research", "PegaGadget2Ifr", "Route for Claim Research");
		gsi.getOptions(pageLocatorsPath, pageFiledsPath, "otherOptions", "Pending Additional Work", "PegaGadget2Ifr", "Pending Additional Work");
		gsi.cancelWork(pageLocatorsPath, pageFiledsPath);
		interactionMgr.wrapupClosednotverifiedIntent("Wrapping intent", data.get("Intent"), pageLocatorsPath, pageFiledsPath);
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC183_Actors_CSR_ManageClaims Completed");
		log.debug("AUTC183_Actors_CSR_ManageClaims Completed");
		quit();
		
	}
}
