package MA_R2_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC040_ELIGIBILITY_MISMATCH_FNLN_STREET extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC040_ELIGIBILITY_MISMATCH_FNLN_STREET(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC040_ELIGIBILITY_MISMATCH_FNLN_STREET");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC040_ELIGIBILITY_MISMATCH_FNLN_STREET - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC040_ELIGIBILITY_MISMATCH_FNLN_STREET -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		InteractionManagerPage interactionMgr=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath, pageFiledsPath, data.get("Fname"));
		String tabstr = searchMember.movetoContracttab(pageLocatorsPath, pageFiledsPath);
		searchMember.readEligibilityMismatchDetails(pageLocatorsPath, pageFiledsPath, tabstr,data.get("ExpectedSingleValueField"));
		searchMember.movetoMembertab(pageLocatorsPath, pageFiledsPath);
		interactionMgr.wrapupClosednotverifiedIntent("Wrapping Interaction", "Eligibility", pageLocatorsPath, pageFiledsPath);
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC040_ELIGIBILITY_MISMATCH_FNLN_STREET Completed");
		
		quit();
		
	}
}
