package MA_R2_TestCases;

import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageClaimPageIntend;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class TC178_CLM_ServiceException_ExceptionLeadershipApproval extends BaseTest{
	


	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC178_CLM_ServiceException_ExceptionLeadershipApproval(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC178_CLM_ServiceException_ExceptionLeadershipApproval");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC178_CLM_ServiceException_ExceptionLeadershipApproval - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC178_CLM_ServiceException_ExceptionLeadershipApproval -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		GSIPage gsi =interactionManger.openGSI();
		String intentID=gsi.getIntentID(pageLocatorsPath, pageFiledsPath);
		log.debug("Navigate to GSI page");
     	gsi.search_Claimselect(pageLocatorsPath, pageFiledsPath,data.get("DateSearchOptions"),data.get("FDOS"), data.get("LDOS"),data.get("ClaimNumber"));
     	ManageOtherCoveragePage manageothercoverage = interactionManger.openMOC();
     	manageothercoverage.clickOtherActions(pageLocatorsPath,pageFiledsPath);
     	ManageClaimPageIntend claim=interactionManger.openManageClaimPageIntend();
     	claim.serviceException(pageLocatorsPath, pageFiledsPath, data);
     	interactionManger.wrapupClosednotverifiedIntent("Wrapping interaction", data.get("Intent"), pageLocatorsPath, pageFiledsPath);
     	WorkbasketPage workbasket= new WorkbasketPage();
     	workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
     	workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Workbasket"));
     	workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
     	claim.approvedServiceException(pageLocatorsPath, pageFiledsPath, data);
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC178_CLM_ServiceException_ExceptionLeadershipApproval Completed");
		log.debug("AUTC178_CLM_ServiceException_ExceptionLeadershipApproval Completed");
		quit();
		
	}
}
