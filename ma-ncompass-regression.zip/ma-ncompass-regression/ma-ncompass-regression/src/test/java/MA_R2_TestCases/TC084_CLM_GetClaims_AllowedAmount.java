package MA_R2_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC084_CLM_GetClaims_AllowedAmount extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC084_CLM_GetClaims_AllowedAmount (Hashtable<String,String> data) throws Exception {
		
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC084_CLM_GetClaims_AllowedAmount");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC084_CLM_GetClaims_AllowedAmount - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC084_CLM_GetClaims_AllowedAmount -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		String interaction=searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		log.debug("Interaction id: "+interaction);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Member Search Completed");
		InteractionManagerPage interactionMgr=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath, pageFiledsPath, data.get("Fname"));
		log.debug(data.get("Fname")+" Selected from the search results and navigated to interaction manager page");
		interactionMgr.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		GSIPage gsi =interactionMgr.openGSI();
		log.debug("Navigate to interaction manger");
		gsi.getIntentID(pageLocatorsPath, pageFiledsPath);
		gsi.createGSI_CliamsYes(pageLocatorsPath, pageFiledsPath, data.get("Category"), data.get("SubCategory"), data.get("Comments"));
		gsi.searchClaim(pageLocatorsPath, pageFiledsPath, data);
		interactionMgr.WrapUpOpenIntent("Wrapping intent", data.get("Intent"), pageLocatorsPath, pageFiledsPath);

   }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC084_CLM_GetClaims_AllowedAmount Completed");
		
		quit();
		
	}

}
