package MA_R2_TestCases;

import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class TC086_Verify_CLM_Getclaims_Reviewed extends BaseTest{
	//Verify Manage Other Coverage details for member with COB coverage.


	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC086_Verify_CLM_Getclaims_Reviewed(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC086_Verify_CLM_Getclaims_Reviewed");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC086_Verify_CLM_Getclaims_Reviewed - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC086_Verify_CLM_Getclaims_Reviewed -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		GSIPage gsi =interactionManger.openGSI();
		String intentID=gsi.getIntentID(pageLocatorsPath, pageFiledsPath);
		log.debug("Navigate to GSI page");
     	gsi.search_Claimselect(pageLocatorsPath, pageFiledsPath,data.get("DateSearchOptions"),data.get("FDOS"), data.get("LDOS"),data.get("ClaimNumber"));
     	gsi.claim_reviewed(pageLocatorsPath, pageFiledsPath);
     	interactionManger.wrapupClosednotverifiedIntent("Wrapping interaction", data.get("Intent"), pageLocatorsPath, pageFiledsPath);
     	RecentWorkPage recentWork=interactionManger.openrecentWork();
     	recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
     	recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
     	recentWork.validateStatus(pageLocatorsPath, pageFiledsPath, data);
     	
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC086_Verify_CLM_Getclaims_Reviewed Completed");
		log.debug("AUTC086_Verify_CLM_Getclaims_Reviewed Completed");
		quit();
		
	}
}
