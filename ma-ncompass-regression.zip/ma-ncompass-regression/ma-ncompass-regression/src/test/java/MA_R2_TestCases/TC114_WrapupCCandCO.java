package MA_R2_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.testcases.BaseTest;
import com.nasco.utilities.DataProviders;


public class TC114_WrapupCCandCO extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC114_WrapupCCandCO(Hashtable<String,String> data) throws Exception {
		
	// this test case created for reporting purpose as this functionality us out of scope for R4
	}
	@AfterMethod
	public void tearDown() {
		
		quit();
		
	}
}
