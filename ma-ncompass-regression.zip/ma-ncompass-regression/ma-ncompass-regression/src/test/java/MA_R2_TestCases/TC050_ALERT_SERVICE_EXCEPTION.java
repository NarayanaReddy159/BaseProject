package MA_R2_TestCases;

import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.nasco.MA.Pages.*;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC050_ALERT_SERVICE_EXCEPTION extends BaseTest{
	
	
	
    
	@Test (dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC050_ALERT_SERVICE_EXCEPION(Hashtable<String,String> data) throws Exception {
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC050_ALERT_SERVICE_EXCEPION");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC050_ALERT_SERVICE_EXCEPION - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC050_ALERT_SERVICE_EXCEPION -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		GSIPage gsi =interactionManger.openGSI();
		log.debug("Navigate to interaction manger");
		gsi.getIntentID(pageLocatorsPath, pageFiledsPath);
		gsi.search_Claimselect(pageLocatorsPath, pageFiledsPath,data.get("DateSearchOptions"),data.get("FDOS"), data.get("LDOS"),data.get("ClaimNumber"));
		ManageClaimPage mngclmpg = new ManageClaimPage();
		mngclmpg.getAlertMsg(pageLocatorsPath,pageFiledsPath,data.get("ExpectedAlertMsg"));

    }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO,"AUTC50_ALERT_SERVICE_EXCEPION Test Completed");
		
		quit();
		
	}

}
