package MA_R2_TestCases;

import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class TC190_Actors_CSRA_Workbaskets extends BaseTest{
	


	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC190_Actors_CSRA_Workbaskets(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC190_Actors_CSRA_Workbaskets");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC190_Actors_CSRA_Workbaskets - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_CSRA"), RunTestNG_NCompass_MA.Config.getProperty("password_CSRA"));
		WorkbasketPage workbasket = new WorkbasketPage();
		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
		workbasket.getWorkbaskets(pageLocatorsPath, pageFiledsPath, "Process Real-time Adjustment");
		workbasket.getWorkbaskets(pageLocatorsPath, pageFiledsPath, "SSL User Claim Adjustment");
		workbasket.getWorkbaskets(pageLocatorsPath, pageFiledsPath, "Claims Hotline User Claim Adjustment");
		workbasket.getWorkbaskets(pageLocatorsPath, pageFiledsPath, "Claims Adjustment Back-office Processor");
		workbasket.getWorkbaskets(pageLocatorsPath, pageFiledsPath, "Employee Services");
		workbasket.getWorkbaskets(pageLocatorsPath, pageFiledsPath, "Appeals and Grievances");
		workbasket.getWorkbaskets(pageLocatorsPath, pageFiledsPath, "Medicare");
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC190_Actors_CSRA_Workbaskets Completed");
		log.debug("AUTC190_Actors_CSRA_Workbaskets Completed");
		quit();
		
	}
}
