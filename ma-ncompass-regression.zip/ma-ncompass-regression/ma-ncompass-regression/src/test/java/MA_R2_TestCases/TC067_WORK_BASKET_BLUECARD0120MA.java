package MA_R2_TestCases;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageClaimPageIntend;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class TC067_WORK_BASKET_BLUECARD0120MA extends BaseTest{
	//Verify Manage Other Coverage details for member with COB coverage.


	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R2DP")
    public void AUTC067_WORK_BASKET_BLUECARD0120MA(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC067_WORK_BASKET_BLUECARD0120MA");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC067_WORK_BASKET_BLUECARD0120MA - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user5"), RunTestNG_NCompass_MA.Config.getProperty("password_user5"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user5")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user5"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user5")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user5"));
		
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
//		GSIPage gsi =interactionManger.openGSI();
//		log.debug("Navigate to GSI page");
//     	gsi.search_Claimselect(pageLocatorsPath, pageFiledsPath,data.get("DateSearchOptions"),data.get("FDOS"), data.get("LDOS"),data.get("ClaimNumber"));
		ManageClaimPageIntend claim=interactionManger.openManageClaimPageIntend();
		String intentID=claim.getIntentID(pageLocatorsPath, pageFiledsPath);
		claim.search_OnlyClaim(pageLocatorsPath, pageFiledsPath, data.get("ClaimNumber"));
		claim.selectMeber(pageLocatorsPath, pageFiledsPath, data.get("Fname"));
		ManageOtherCoveragePage manageothercoverage = interactionManger.openMOC();
		manageothercoverage.clickOtherActions(pageLocatorsPath,pageFiledsPath);
		ManageOtherCoveragePage MOC=new ManageOtherCoveragePage();
     	MOC.clickOtherActions(pageLocatorsPath, pageFiledsPath);
		claim.adjustclaim(pageLocatorsPath, pageFiledsPath);
		claim.adjustclaimreason(pageLocatorsPath, pageFiledsPath,data,"PegaGadget2Ifr");
		interactionManger.wrapupClosednotverifiedMAPD("Wrapping up the intent", data.get("InteractionReason"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Id"+data.get("Intent"));
		WorkbasketPage workbasket= interactionManger.openworkBasket();
		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
		workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Workbasket"));
		log.debug("Navigate to selected intent "+intentID+" from Workbasket tab ");
		workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		workbasket.workbasketvalidateAssign(pageLocatorsPath, pageFiledsPath,data.get("Workbasket"));
		workbasket.clickOtherActions(pageLocatorsPath, pageFiledsPath);
		workbasket.cancel(pageLocatorsPath, pageFiledsPath);
       
		
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC067_WORK_BASKET_BLUECARD0120MA Completed");
		
		quit();
		
	}

	
		
}
