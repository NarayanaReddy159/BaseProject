package MA_R1_TestCases;

import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.VerifyContactPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class TC030_Actors_CustomerServices extends BaseTest{
	


	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R1DP")
    public void AUTC030_Actors_CustomerServices(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC030_Actors_CustomerServices");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC030_Actors_CustomerServices - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_csr"), RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		log.debug("AUTC030_Actors_CustomerServices -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_csr")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_csr")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		homepage.getPortal(pageLocatorsPath, pageFiledsPath);
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		test.log(LogStatus.INFO, "Operator able to create interaction");
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data);
		test.log(LogStatus.INFO, "Operator able to access Member Search Page");
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		test.log(LogStatus.INFO, "Operator able to access Interaction Manager Page");
		VerifyContactPage verifyContact=interactionManger.movetoVerifyContact(pageLocatorsPath, pageFiledsPath);
		log.debug("Moved to verify contact page");
		verifyContact.verifyMember(pageLocatorsPath, pageFiledsPath);
		test.log(LogStatus.INFO, "Operator able to verify member");
		homepage.getIntents(pageLocatorsPath, pageFiledsPath);
		interactionManger.wrapupverifiedIntent("Wrapping Interaction", "Eligibility", pageLocatorsPath, pageFiledsPath);
		test.log(LogStatus.INFO, "Operator able to wrap the interaction");
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC030_Actors_CustomerServices Completed");
		log.debug("AUTC030_Actors_CustomerServices Completed");
		quit();
		
	}
}
