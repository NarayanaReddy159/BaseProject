package MA_R1_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC026_GSI_Intenet_TranslationReq_Resolved extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R1DP")
    public void AUTC026_GSI_Intenet_TranslationReq_Resolved (Hashtable<String,String> data) throws Exception {
	
		//String frame0="PegaGadget0Ifr", frame1= "PegaGadget1Ifr", frame2= "PegaGadget2Ifr";
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC026_GSI_Intenet_TranslationReq_Resolved");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_csr"), RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_csr")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_csr")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
//		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		GSIPage gsi =interactionManger.openGSI();
		log.debug("Navigate to interaction manger");
		String intentID=gsi.getIntentID(pageLocatorsPath, pageFiledsPath);
		gsi.createGSI_TranslationReq(pageLocatorsPath, pageFiledsPath, data.get("Category"), data.get("SubCategory"), data.get("Language"),data.get("Comments"));	
		System.out.println(intentID);
		homepage.logout();
		login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		WorkbasketPage workbasket= interactionManger.openworkBasket();
		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
//		homepage.waittoloadHomePage();
		workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Workbasket"));
		workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
     	gsi.resolve_ProcessGSI_WithoutClaim(pageLocatorsPath, pageFiledsPath,data.get("ResolveComments"));
     	homepage.logout();
     	login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_csr"), RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
     	RecentWorkPage recentWork =homepage.openrecentWork();
		recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
		log.debug("Navigate to the Recentwork ");
		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Navigate to selected intent "+intentID+" from recent work tab ");
		gsi.validateRecentWorkInfo(pageLocatorsPath, pageFiledsPath, data);
		test.log(LogStatus.INFO, "The GSI request resolved successfully");

   }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC026_GSI_Intenet_TranslationReq_Resolved Completed");
		
		quit();
		
	}

}
