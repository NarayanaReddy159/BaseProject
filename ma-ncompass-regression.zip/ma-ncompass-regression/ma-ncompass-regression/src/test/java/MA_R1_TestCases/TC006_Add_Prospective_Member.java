package MA_R1_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.Member360Page;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC006_Add_Prospective_Member extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R1DP")
    public void AUTC006_Add_Prospective_Member(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		
		test=DriverManager.getExtentReport();
		log.info("Inside TC006_Add_Prospective_Member");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("TC006_Add_Prospective_Member - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("TC006_Add_Prospective_Member -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.movetoProsMem(pageLocatorsPath, pageFiledsPath);
		log.debug("Moved to Prospective Member page");
		searchMember.AddProsMem(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Prospective Member Added");
		InteractionManagerPage interactionMgr= new InteractionManagerPage();
		Member360Page member360= new Member360Page();
		member360.getProsHeaderDetails(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Prospective Member Header details read successfully");
		interactionMgr.wrapupProsMem("Wrapping interaction", pageLocatorsPath, pageFiledsPath);
		log.debug("Interaction wraaped up successfully");
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "TC006_Add_Prospective_Member Completed");
		log.debug("TC006_Add_Prospective_Member Completed");
		quit();
		
	}
}
