package MA_R1_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.Member360Page;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.VerifyContactPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC021_Member360_Interactions_Tab extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R1DP")
    public void AUTC021_Member360_Interactions_Tab(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC021_Member360_Interactions_Tab");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC021_Member360_Interactions_Tab - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC021_Member360_Interactions_Tab -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		InteractionManagerPage interactionMgr=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath, pageFiledsPath, data.get("Fname"));
		VerifyContactPage verifyContact = interactionMgr.movetoVerifyContact(pageLocatorsPath, pageFiledsPath);
		verifyContact.verifyMember(pageLocatorsPath, pageFiledsPath);
		Member360Page member360= new Member360Page();
		member360.getInteractions(pageLocatorsPath, pageFiledsPath, data);
		//interactionMgr.wrapupverifiedIntent("Wrapping Intenraction", "Eligibility", pageLocatorsPath, pageFiledsPath);
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC021_Member360_Interactions_Tab Completed");
		log.debug("AUTC021_Member360_Interactions_Tab Completed");
		quit();
		
	}
}
