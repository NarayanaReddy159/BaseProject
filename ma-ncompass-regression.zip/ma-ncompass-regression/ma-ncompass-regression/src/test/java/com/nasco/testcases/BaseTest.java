package com.nasco.testcases;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;

import com.nasco.ExtentListeners.ExtentListeners;
import com.nasco.utilities.DriverFactory;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.Keys;
public class BaseTest {

	private WebDriver driver;
	public static Logger log = LogManager.getLogger(BaseTest.class.getName());
//	public Logger log = LogManager.getLogger(BaseTest.class.getName());
	private String defaultUserName;
	private String defaultPassword;	
    public static JavascriptExecutor js;
    protected ExtentTest test;
//    protected Logger log;
	public String getDefaultUserName() {
		return defaultUserName;
	}

	public void setDefaultUserName(String defaultUserName) {
		this.defaultUserName = defaultUserName;
	}


	public String getDefaultPassword() {
		return defaultPassword;
	}

	public void setDefaultPassword(String defaultPassword) {
		this.defaultPassword = defaultPassword;
	}

	@BeforeSuite
	public void beforeSuite(){
//		DriverFactory.setConfigPropertyFilePath(
//				System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\Config.properties");
//		DriverManager.setLog(log);
		configureLog4jLogging();
	}
	
	public void setUpFramework() {
//		DriverFactory.setChromeDriverExePath(
//				System.getProperty("user.dir") + "//src//test//resources//executables//chromedriver.exe");
//		DriverFactory.setGeckoDriverExePath(
//				System.getProperty("user.dir") + "//src//test//resources//executables//geckodriver.exe");
//		DriverFactory.setIeDriverExePath(
//				System.getProperty("user.dir") + "//src//test//resources//executables//IEDriverServer.exe");
		System.out.println("path:::"+RunTestNG_NCompass_MA.Config.getProperty("ChromeDriver"));
		DriverFactory.setChromeDriverExePath(RunTestNG_NCompass_MA.Config.getProperty("ChromeDriver"));
		DriverFactory.setIeDriverExePath(RunTestNG_NCompass_MA.Config.getProperty("IEDriver"));
	}
	
	
	public void extentLogWarning(String message) {
		
		ExtentListeners.testReport.get().log(LogStatus.WARNING, message);
	}

	public void configureLog4jLogging() {
		String log4jConfigFile = System.getProperty("user.dir") + File.separator + "src\\main\\resources\\properties" + File.separator
				+ "log4j2.properties";
	
		System.out.println("log4jConfigFile--"+RunTestNG_NCompass_MA.Config.getProperty("log4jPropertiesFilepath"));
//		PropertyConfigurator.configure(log4jConfigFile);
		 //System.setProperty("user.dir","G:\\Automation Execution\\Log4j");  
		//System.setProperty("log4j.configurationFile", "/src/main/resources/properties/log4j2.properties");
		System.setProperty("log4j.configurationFile", RunTestNG_NCompass_MA.Config.getProperty("log4jPropertiesFilepath"));
		//System.setProperty("log4j.configurationFile", log4jConfigFile);
	}

	public void openBrowser(String browser) {
		

		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					DriverFactory.getChromeDriverExePath());
			System.out.println("Launching : " + browser);
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("profile.default_content_setting_values.notifications", 2);
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", prefs);
			options.addArguments("--disable-extensions");
			options.addArguments("--disable-infobars");
			log.info("Launching Chrome");	
			driver = new ChromeDriver(options);
		} else if (browser.equalsIgnoreCase("firefox")) {
			System.out.println("Launching : " + browser);
			System.setProperty("webdriver.gecko.driver",
					DriverFactory.getGeckoDriverExePath());
			driver = new FirefoxDriver();
			log.info("Launching firefox");
		} else if (browser.equalsIgnoreCase("ie")){
			System. setProperty("webdriver.ie.driver", DriverFactory.getIeDriverExePath());
			InternetExplorerOptions options = new InternetExplorerOptions();
			options.ignoreZoomSettings();
			options.setCapability("nativeEvents",false);
			options.introduceFlakinessByIgnoringSecurityDomains();
			options.setCapability("disable-popup-blocking", true);
			driver = new InternetExplorerDriver(options);
			((JavascriptExecutor)driver).executeScript("document.body.style.zoom='80%';");
			
	
		}

		DriverManager.setWebDriver(driver);
		log.info("Driver Initialized !!!");
//		ThreadContext.put("id", UUID.randomUUID().toString());
		DriverManager.getDriver().manage().window().maximize();
		DriverManager.getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		driver.get(Config.getProperty("URL"));
		System.out.println("username"+RunTestNG_NCompass_MA.Config.getProperty("username"));
		setDefaultUserName(RunTestNG_NCompass_MA.Config.getProperty("username"));
		setDefaultPassword(RunTestNG_NCompass_MA.Config.getProperty("password"));
	
//		page = new PageGenerator(DriverManager.getDriver());
//        js= (JavascriptExecutor)driver;
	}

	public void quit() {
		try {
			Thread.sleep(2000);
			DriverManager.getDriver().quit();
			log.info("Test Execution Completed !!!");
		} 
		catch (Exception e) {
            e.printStackTrace();
            String excepionMessage = Arrays.toString(e.getStackTrace());
            BaseTest.log.error("Not able to quit the browser " + excepionMessage);
            test.log(LogStatus.FAIL, "Not able to quit the browser " + e);
            Assert.fail();
		}

	}
}
