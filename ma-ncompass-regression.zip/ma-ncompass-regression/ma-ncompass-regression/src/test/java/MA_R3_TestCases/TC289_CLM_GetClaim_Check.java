package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.Correspondence_RTCPage;
import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageClaimPageIntend;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC289_CLM_GetClaim_Check extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC289_CLM_GetClaim_Check(Hashtable<String,String> data) throws Exception {
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC289_CLM_GetClaim_Check");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through SSN "+data.get("Social Security number"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		// rtc =interactionManger.openRTC_Callback();
		ManageClaimPageIntend claim=interactionManger.openManageClaimPageIntend();
		log.debug("Navigate to ManageClaim page");
		String intentID=claim.getIntentIDCLM(pageLocatorsPath, pageFiledsPath);
		System.out.println(intentID);
		claim.search_Claimselect(pageLocatorsPath, pageFiledsPath,data.get("DateSearchOptions"),data.get("FDOS"), data.get("LDOS"),data.get("ClaimNumber"));
		claim.claimstatus(pageLocatorsPath, pageFiledsPath, data);
		claim.claimdetails(pageLocatorsPath, pageFiledsPath, data);
		claim.ViewClaimStatement(pageLocatorsPath, pageFiledsPath);
		claim.viewClaimDetails(pageLocatorsPath, pageFiledsPath,"PegaGadget2Ifr",data);
		claim.LaunchRTC(pageLocatorsPath, pageFiledsPath);
		Correspondence_RTCPage RTC=new Correspondence_RTCPage();
		String intentID1=RTC.getIntentIDRTC(pageLocatorsPath, pageFiledsPath,"PegaGadget3Ifr");
		System.out.println(intentID1);
		RTC.CLMEMail(pageLocatorsPath, pageFiledsPath, "PegaGadget3Ifr", data);
		interactionManger.pageload();
		interactionManger.WrapUpOpenIntent("Wrapping up the intent", data.get("Intent"),pageLocatorsPath,pageFiledsPath,"PegaGadget2Ifr"); 
		RecentWorkPage recentWork= new InteractionManagerPage().openrecentWork();
     	recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
        recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID1);
        RTC.Audithistory(pageLocatorsPath, pageFiledsPath, data);
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC289_CLM_GetClaim_Check Completed");
		log.debug("AUTC289_CLM_GetClaim_Check Completed");
		
		quit();
		
	}

}
