package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.Request_ID_CardPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC284_IDC_RequestIDCard_InActive extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC284_IDC_RequestIDCard_InActive (Hashtable<String,String> data) throws Exception {
		String frame2="PegaGadget2Ifr", frame1="PegaGadget1Ifr";
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC284_IDC_RequestIDCard_InActive");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through SSN "+data.get("Social Security number"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		Request_ID_CardPage IDC =new Request_ID_CardPage();
		log.debug("Navigate to interaction manger");
		String intentID=IDC.getInactiveIntentID(pageLocatorsPath, pageFiledsPath);
		System.out.println(intentID);
		IDC.validateMessage(pageLocatorsPath, pageFiledsPath, data.get("Message"), frame2);
		interactionManger.WrapUpInactiveIntent("Wrapping up the intent",data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath,data.get("Descriptionoftheissue"),data.get("Descriptionoftheresolution"));
		log.debug("Intent Name"+data.get("Intent")+" & Inactive Intent Id"+intentID);
		WorklistPage worklispg = new WorklistPage();
		worklispg.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
		log.debug("Clicked Worklist tab link");
		worklispg.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Sort and Select Intent by ID");
		IDC.clickSubmit(pageLocatorsPath, pageFiledsPath, frame1);	
		RecentWorkPage recentWork =homepage.openrecentWork();
		recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
		log.debug("Navigate to the Recentwork ");
		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Navigate to the Recentwork ");
		IDC.validateStatus(pageLocatorsPath, pageFiledsPath, data.get("Expected_Status"), frame1);
		log.debug("Validated on recent work page ");

	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC284_IDC_RequestIDCard_InActive Completed");
		log.debug("AUTC284_IDC_RequestIDCard_InActive Completed");
		
		quit();
		
	}

}
