package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.VerifyContactPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC204_Ncompass_Portal extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
	public void AUTC204_Ncompass_Portal(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC204_Ncompass_Portal");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user1"), RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		if (data.get("SwitchToNcompass").equalsIgnoreCase("Yes")){
			homepage.switchToAdminPortal(pageLocatorsPath,pageFiledsPath);
			homepage.switchToNcompassPortal(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user1"));
			homepage.validateInfoOnNcompass(pageLocatorsPath, pageFiledsPath);
		} else {
			test.log(LogStatus.INFO, "SwitchToAdmin option is other than Yes. So not Swithcing to Admin portal");
			log.debug("SwitchToAdmin option is other than Yes. So not Swithcing to Admin portal");
		}
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC204_Ncompass_Portal Completed");
		log.debug("AUTC204_Ncompass_Portal Completed");
		quit();
		
	}
}
