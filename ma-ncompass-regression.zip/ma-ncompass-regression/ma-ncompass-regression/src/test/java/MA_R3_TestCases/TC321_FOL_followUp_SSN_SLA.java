package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.FollowUp;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC321_FOL_followUp_SSN_SLA extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC321_FOL_followUp_SSN_SLA (Hashtable<String,String> data) throws Exception {
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC321_FOL_followUp_SSN_SLA");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through SSN "+data.get("SSN"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		//Callback_RTCPage rtc =interactionManger.openRTC_Callback();
		FollowUp fol =interactionManger.openFollowUp();
		log.debug("Navigate to interaction manger");
		String intentID=fol.getIntentID(pageLocatorsPath, pageFiledsPath);
		fol.create_FollowUp_Scheduled(pageLocatorsPath, pageFiledsPath, data);	
		System.out.println(intentID);
		interactionManger.WrapUpOpenFOLIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID+" created");
		RecentWorkPage recentWork =homepage.openrecentWork();
		recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
		log.debug("Navigate to the Recentwork ");
		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Navigate to selected intent "+intentID+" from recent work tab ");
		fol.calcualteSLA(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr");
		log.debug("Verified SLAs ");
   }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC321_FOL_followUp_SSN_SLA Completed");
		log.debug("AUTC321_FOL_followUp_SSN_SLA Completed");
		
		quit();
		
	}

}
