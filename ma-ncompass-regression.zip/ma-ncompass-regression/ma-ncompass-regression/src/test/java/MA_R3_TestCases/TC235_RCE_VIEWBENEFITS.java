package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.Correspondence_RTCPage;
import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageClaimPageIntend;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RCEPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.ViewBenefitsPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC235_RCE_VIEWBENEFITS extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC235_RCE_VIEWBENEFITS(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC235_RCE_VIEWBENEFITS");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC235_RCE_VIEWBENEFITS - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC235_RCE_VIEWBENEFITS -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		ViewBenefitsPage viewben = new ViewBenefitsPage();
		String intentID = viewben.getIntentID(pageLocatorsPath, pageFiledsPath);
		System.out.println("Intent ID : " + intentID);
		viewben.OtherActions(pageLocatorsPath, pageFiledsPath, data);
		interactionManger.WrapUpOpenIntent("Wrapping up the intent", data.get("Intent"),pageLocatorsPath,pageFiledsPath,"PegaGadget3Ifr");
		RecentWorkPage recentWork=interactionManger.openrecentWork();
	    recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
	    recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
	    recentWork.validateStatus(pageLocatorsPath, pageFiledsPath, data);	
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "TC235_RCE_VIEWBENEFITS Completed");
		
		quit();
		
	}
}
