package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC215_RTC_CALLBACK_NOW_CORRESPONDENCE extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC215_RTC_CALLBACK_NOW_CORRESPONDENCE (Hashtable<String,String> data) throws Exception {
		HomePage homepage;
		MemberSearchPage searchMember;
		InteractionManagerPage interactionManger;
		Callback_RTCPage rtc;
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC215_RTC_CALLBACK_NOW_CORRESPONDENCE");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_csr"),RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_csr")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_csr")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_csr"));
		searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeberid "+data.get("MemberID"));
		interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		//rtc =interactionManger.openRTC_Callback();
		rtc = new Callback_RTCPage();
		log.debug("Navigate to interaction manger");
		String intentID=rtc.getIntentID(pageLocatorsPath, pageFiledsPath);
		rtc.create_CallbackSchedule(pageLocatorsPath, pageFiledsPath,data);
		System.out.println(intentID);
		interactionManger.wrapupClosednotverifiedIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID);
		homepage.logout();
		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeberid "+data.get("MemberID"));
		interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.clickSuggestedTask(pageLocatorsPath,pageFiledsPath,intentID);
		log.debug("Click suggested intent "+intentID);
		rtc = new Callback_RTCPage(); //interactionManger.openRTC_Callback("PegaGadget2Ifr");
		rtc.frame1="PegaGadget2Ifr";
		rtc.takeOwnership(pageLocatorsPath,pageFiledsPath,data.get("TransferComments"));
		log.debug("Ownership taken");
		rtc.WrapUpOpenIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath,"PegaGadget2Ifr");
		homepage.waittoloadHomePage();


   }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC215_RTC_CALLBACK_NOW_CORRESPONDENCE Completed");
		log.debug("AUTC215_RTC_CALLBACK_NOW_CORRESPONDENCE Completed");
		
		quit();
		
	}

}
