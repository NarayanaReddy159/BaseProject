package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageChangePage;
import com.nasco.MA.Pages.PrimaryReasonForInteraction;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC211_Manage_Change_Add extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC211_Manage_Change_Add(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		ManageChangePage managechg;
		PrimaryReasonForInteraction prfi;
		String frame1="PegaGadget1Ifr",frame2="PegaGadget2Ifr";
		
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC211_Manage_Change_Add");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user3"), RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user3")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user3")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		homepage.switchToAdminPortal(pageLocatorsPath,pageFiledsPath);
		homepage.clickOnMangeChane(pageLocatorsPath,pageFiledsPath);
		log.debug("Navigated to Manage Change");
		managechg = new ManageChangePage();
		managechg.SearchDelegatedRule(pageLocatorsPath,pageFiledsPath,frame1,data.get("SearchAlert"));
		managechg.clickEidtBtn(pageLocatorsPath, pageFiledsPath, frame1);
		log.debug("Navigated to Primary Reason For Interaction page");
		prfi= new PrimaryReasonForInteraction();
		prfi.createPrimaryReason(pageLocatorsPath, pageFiledsPath, frame2, data.get("PrimaryReasonForInteraction"));
		log.debug("Primary Reason added");
		prfi.deletePrimaryReason(pageLocatorsPath, pageFiledsPath, frame2, data.get("PrimaryReasonForInteraction"));
		log.debug("Primary reason deleted");
			
	
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC211_Manage_Change_Add Completed");
		log.debug("AUTC211_Manage_Change_Add Completed");
		quit();
		
	}
}
