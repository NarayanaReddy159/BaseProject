package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.CREATE_NLPage;
import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageClaimPageIntend;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.Manage_ChecksPage;
import com.nasco.MA.Pages.Member360Page;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.VerifyContactPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC273_Wrapup_Live_ReviewHarness extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
	public void AUTC273_Wrapup_Live_ReviewHarness(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC273_Wrapup_Live_ReviewHarness");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC273_Wrapup_Live_ReviewHarness -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		homepage.clickOnLiveInteractionMember(pageLocatorsPath, pageFiledsPath);
		MemberSearchPage searchMember =  new MemberSearchPage();
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		searchMember.selectMemberAndNavigatebyfname2(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		Manage_ChecksPage CHK=new Manage_ChecksPage();
		String LID=CHK.getNLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+LID);
	    System.out.println("LID::"+LID);
		InteractionManagerPage  inter= new InteractionManagerPage();
		inter.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		String intentID=CHK.getIntentID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+intentID);
	    System.out.println(intentID);
	    inter.WrapUpOpenIntent("Wrapping up the intent", data.get("Intent"), pageLocatorsPath, pageFiledsPath,"PegaGadget2Ifr");
		log.debug("Intent Id"+data.get("Intent"));
		RecentWorkPage recentWork= new InteractionManagerPage().openrecentWork();
     	recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
        recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, LID);
		log.debug("Navigate to selected intent "+LID+" from recent work tab ");
        String resolvedate1= CHK.resolvedate(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr");
        
		homepage.clickOnNonliveInteractionMember(pageLocatorsPath, pageFiledsPath);
		searchMember.getNONLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		searchMember.selectMemberAndNavigatebyfname2(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		String NLID=CHK.getNonLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+NLID);
	    System.out.println(NLID);
	    CREATE_NLPage nlpage=new CREATE_NLPage();
	    nlpage.sortandSelectInteraction(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr" ,LID);
	    inter.pageload();	
	    nlpage.NL_FOLLOWUP(pageLocatorsPath, pageFiledsPath, data);
	    inter.pageload();
	   	   
	    inter.addTask(data.get("Intent1").toString(),pageLocatorsPath,pageFiledsPath,"PegaGadget1Ifr");
		log.debug("Add Intent "+data.get("Intent1"));
		String intentID1=CHK.getIntentID1(pageLocatorsPath, pageFiledsPath,"PegaGadget2Ifr");
		test.log(LogStatus.INFO, "Intent ID:"+intentID1);
		System.out.println("claim::"+intentID1);
		inter.wrapupProsMem("Wrapping up the intent",pageLocatorsPath,pageFiledsPath,"PegaGadget2Ifr");
		log.debug("Intent Id"+data.get("Intent"));
		inter.logout();
		login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC273_Wrapup_Live_ReviewHarness -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
	
	 	recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
        recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, NLID);
		log.debug("Navigate to selected intent "+NLID+" from recent work tab ");
		CHK.resolvedate(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr");
		
        WorklistPage worklist= inter.openWorklist();
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
     	log.debug("Navigate to selected intent "+intentID+" from WorkList tab ");
     	CHK.noActionCheckAll(pageLocatorsPath, pageFiledsPath, "PegaGadget1Ifr", data);
     	log.debug("Navigate to interaction manger");
		inter.logout();
		login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC273_Wrapup_Live_ReviewHarness -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));

     	recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
        recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, LID);
		log.debug("Navigate to selected intent "+LID+" from recent work tab ");
		CHK.resolvedate(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr");
		worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
		recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Navigate to selected intent "+intentID+" from recent work tab ");
		CHK.resolvedate(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr");

		worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
		inter.pageload();
	    worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID1);
	    log.debug("Navigate to selected intent "+intentID1+" from WorkList tab ");
	    CHK.createGSI_CliamsYes(pageLocatorsPath, pageFiledsPath, data.get("category"), data.get("subCategory"), data.get("Comments"));
	    inter.logout();
		login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC273_Wrapup_Live_ReviewHarness -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));

	    WorkbasketPage workbasket= inter.openworkBasket();
		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
		workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Workbasket"));
		log.debug("Navigate to selected intent "+intentID+" from Workbasket tab ");
		workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID1);
		CHK.resolveCLM(pageLocatorsPath,pageFiledsPath);

//	    inter.logout();
//		login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
//		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
//		log.debug("AUTC273_Wrapup_Live_ReviewHarness -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
//		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));

	    recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
        recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, NLID);
		log.debug("Navigate to selected intent "+NLID+" from recent work tab ");
		CHK.resolvedate(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr");
		worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
	    recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);

		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID1);
		log.debug("Navigate to selected intent "+NLID+" from recent work tab ");
		CHK.resolvedate(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr");
		worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);

		recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
        recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, LID);
		log.debug("Navigate to selected intent "+LID+" from recent work tab ");
		CHK.resolvedate(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr");
		worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
	    recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);

		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, NLID);
		log.debug("Navigate to selected intent "+intentID+" from recent work tab ");
		CHK.resolvedate(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr");

			}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC273_Wrapup_Live_ReviewHarness Completed");
		log.debug("AUTC273_Wrapup_Live_ReviewHarness Completed");		
		quit();
		
	}
}
