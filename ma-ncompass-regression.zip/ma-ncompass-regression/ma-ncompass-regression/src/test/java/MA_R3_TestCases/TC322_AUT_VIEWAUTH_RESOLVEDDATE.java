package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.CREATE_NLPage;
import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.FollowUp;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.ViewAuthorizationsPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC322_AUT_VIEWAUTH_RESOLVEDDATE extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC322_AUT_VIEWAUTH_RESOLVEDDATE (Hashtable<String,String> data) throws Exception {
		String frame1="PegaGadget1Ifr" ,frame2="PegaGadget2Ifr";
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC322_AUT_VIEWAUTH_RESOLVEDDATE");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through Member Id "+data.get("MemberID"));
		CREATE_NLPage nlpage=new CREATE_NLPage();
		String lid=nlpage.getNLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+lid);
	    System.out.println(lid);
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		//Callback_RTCPage rtc =interactionManger.openRTC_Callback();
		FollowUp fol =interactionManger.openFollowUp();
		log.debug("Navigate to interaction manger");
		String intentID=fol.getIntentID(pageLocatorsPath, pageFiledsPath);
		fol.create_FollowUp_Scheduled(pageLocatorsPath, pageFiledsPath, data);	
		System.out.println(intentID);
		interactionManger.WrapUpOpenFOLIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID+" created");
		RecentWorkPage recentWork =homepage.openrecentWork();
		recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
		log.debug("Navigate to the Recentwork ");
		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, lid);
		log.debug("Navigate to selected intent "+lid+" from recent work tab ");
        //String resolvedate=nlpage.resolvedate(pageLocatorsPath, pageFiledsPath);
		String resolvedate=nlpage.resolvedate(pageLocatorsPath, pageFiledsPath, frame1);
		WorklistPage worklist= homepage.openWorklist();
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
    	log.debug("The Follow up intent select successfully");
    	fol.clickCreateNewWork_ViewAuthorization(pageLocatorsPath, pageFiledsPath, frame1);
    	log.debug("Navigate to View Authorization ");
    	String viewauthintentID=fol.getViewAuthIntentID(pageLocatorsPath, pageFiledsPath, frame1);
    	System.out.println("viewauthintentID:"+viewauthintentID);
    	fol.closeViewAuth(pageLocatorsPath, pageFiledsPath,frame2);
    	log.debug("Close View Authorization "+viewauthintentID);
    	fol.FollowUp_Attempt(pageLocatorsPath, pageFiledsPath, data.get("AttemptComments"), data.get("FollowupAttempt"), frame1);
    	log.debug("Resolved follow up intent "+intentID);
		recentWork =homepage.openrecentWork();
		recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
		log.debug("Navigate to the Recentwork ");
		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, lid);
		log.debug("Navigate to selected interaction "+lid+" from recent work tab ");
		String resolvedate3=nlpage.resolvedate(pageLocatorsPath, pageFiledsPath);
		System.out.println("resolvedate3::"+resolvedate3);
    	recentWork =homepage.openrecentWork();
//		recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
//		log.debug("Navigate to the Recentwork ");
		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, viewauthintentID);
		ViewAuthorizationsPage auth = new ViewAuthorizationsPage();
		log.debug("Navigate to selected interaction "+viewauthintentID+" from recent work tab ");
        //String resolvedate1= nlpage.resolvedate(pageLocatorsPath, pageFiledsPath);
		String resolvedate1= auth.getResolveDate(pageLocatorsPath, pageFiledsPath,frame1);
        System.out.println("resolvedate1::"+resolvedate1);
        auth.closeViewAuth(pageLocatorsPath, pageFiledsPath, frame1);
        recentWork =homepage.openrecentWork();
		recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, lid);
		log.debug("Navigate to selected intent "+lid+" from recent work tab ");
        String resolvedate2= nlpage.resolvedate(pageLocatorsPath, pageFiledsPath);
        System.out.println("resolvedate2::"+resolvedate2);
        nlpage.vaildateresolvedate(pageLocatorsPath, pageFiledsPath, resolvedate1, resolvedate2);
	}	
		
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC322_AUT_VIEWAUTH_RESOLVEDDATE Completed");
		log.debug("AUTC322_AUT_VIEWAUTH_RESOLVEDDATE Completed");
		
		quit();
		
	}

}
