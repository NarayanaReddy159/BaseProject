package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.CREATE_NLPage;
import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.FollowUp;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC319_FOL_CREATEFOLLOWUP_RELATED_INTENT extends BaseTest{
	HomePage homepage;
	MemberSearchPage searchMember;
	InteractionManagerPage interactionManger;
	String frame1="PegaGadget1Ifr",frame2="PegaGadget2Ifr";
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC319_FOL_CREATEFOLLOWUP_RELATED_INTENT (Hashtable<String,String> data) throws Exception {
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC319_FOL_CREATEFOLLOWUP_RELATED_INTENT");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user1"), RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through Member Id "+data.get("MemberID"));
		CREATE_NLPage nlpage=new CREATE_NLPage();
		String lid=nlpage.getNLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+lid);
	    System.out.println(lid);
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		//Callback_RTCPage rtc =interactionManger.openRTC_Callback();
		FollowUp fol =interactionManger.openFollowUp();
		log.debug("Navigate to interaction manger");
		String intentID=fol.getIntentID(pageLocatorsPath, pageFiledsPath);
		fol.create_FollowUp_Scheduled(pageLocatorsPath, pageFiledsPath, data);	
		System.out.println(intentID);
		interactionManger.WrapUpOpenFOLIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID+" created");
		
		homepage.logout();
		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user2"),RunTestNG_NCompass_MA.Config.getProperty("password_user2"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user2")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user2"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user2")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user2"));
		searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeberid "+data.get("MemberID"));
		nlpage=new CREATE_NLPage();
		String lid1=nlpage.getNLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+lid1);
	    System.out.println("lid1::"+lid1);
		interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.clickSuggestedTask(pageLocatorsPath,pageFiledsPath,intentID);
		log.debug("Click suggested intent "+intentID);
		fol.takeOwnership(pageLocatorsPath,pageFiledsPath,data.get("TransferComments"),frame2);
		log.debug("Ownership taken");
		fol.closeOnDocResolution(pageLocatorsPath, pageFiledsPath, frame2);
		log.debug("Closed on document resolution screen");
		//interactionManger.WrapUpOpenFOLIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath);
		interactionManger.WrapUpOpenIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"), pageLocatorsPath, pageFiledsPath, frame1);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID+" created");

		WorklistPage worklist= homepage.openWorklist();
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
    	log.debug("The Follow up intent select successfully");
    	fol.clickCreateNewWork_CreateFollowup(pageLocatorsPath, pageFiledsPath, frame1);
    	
    	fol.clickScheduledOnHarmess(pageLocatorsPath, pageFiledsPath, frame2);
    	fol.validateDefaultSelectedIntent(pageLocatorsPath, pageFiledsPath, frame2, intentID);
  	
		log.debug("Validated default selected intent as "+intentID);
   }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC319_FOL_CREATEFOLLOWUP_RELATED_INTENT Completed");
		log.debug("AUTC319_FOL_CREATEFOLLOWUP_RELATED_INTENT Completed");
		
		quit();
		
	}

}
