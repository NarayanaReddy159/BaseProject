package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.CREATE_NLPage;
import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.FollowUp;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.ViewAuthorizationsPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC323_AUT_VIEWAUTH_RELATED_INTENT extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC323_AUT_VIEWAUTH_RELATED_INTENT (Hashtable<String,String> data) throws Exception {
		String frame1="PegaGadget1Ifr" ,frame2="PegaGadget2Ifr",frame3="PegaGadget3Ifr";
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC323_AUT_VIEWAUTH_RELATED_INTENT");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through Member Id "+data.get("MemberID"));
		CREATE_NLPage nlpage=new CREATE_NLPage();
		String lid=nlpage.getNLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+lid);
	    System.out.println(lid);
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		//Callback_RTCPage rtc =interactionManger.openRTC_Callback();
		FollowUp fol =interactionManger.openFollowUp();
		log.debug("Navigate to interaction manger");
		//GSIPage gsi = new GSIPage();
		String intentID=fol.getIntentID(pageLocatorsPath, pageFiledsPath);
		fol.create_FollowUp_Scheduled(pageLocatorsPath, pageFiledsPath, data);	
		System.out.println(intentID);
		interactionManger.WrapUpOpenFOLIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID+" created");
		WorklistPage worklist= homepage.openWorklist();
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
    	log.debug("The Follow up intent select successfully");
    	fol.clickCreateNewWork_ViewAuthorization(pageLocatorsPath, pageFiledsPath, frame1);
       	String viewauthintentID=fol.getViewAuthIntentID(pageLocatorsPath, pageFiledsPath, frame1);
    	System.out.println("viewauthintentID:"+viewauthintentID);
    	ViewAuthorizationsPage vauth = new ViewAuthorizationsPage();
     	vauth.clickCreateNewWork_RTC(pageLocatorsPath, pageFiledsPath, frame2);
     	Callback_RTCPage rtc = new Callback_RTCPage();
     	rtc.callbacOnPerformHarness(pageLocatorsPath, pageFiledsPath, frame3);
    	log.debug("Navigate to Respond to customer page");
    	rtc.validateDefaultSelectedIntent(pageLocatorsPath, pageFiledsPath, frame3, viewauthintentID);
    	
  	}	
		
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC323_AUT_VIEWAUTH_RELATED_INTENT Completed");
		log.debug("AUTC323_AUT_VIEWAUTH_RELATED_INTENT Completed");
		
		quit();
		
	}

}
