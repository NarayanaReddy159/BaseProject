package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.CREATE_NLPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.Member360Page;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.VerifyContactPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC246_Create_NL_LinkSI extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
	public void AUTC246_Create_NL_LinkSI(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC246_Create_NL_LinkSI");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC246_Create_NL_LinkSI -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		homepage.clickOnLiveInteractionMember(pageLocatorsPath, pageFiledsPath);
		MemberSearchPage searchMember =  new MemberSearchPage();
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		searchMember.selectMemberAndNavigatebyfname2(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
	    InteractionManagerPage  inter= new InteractionManagerPage();
	    inter.pageload();
		CREATE_NLPage nlpage=new CREATE_NLPage();
		String LID=nlpage.getNLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+LID);
	    System.out.println("LID::"+LID);
	    
		inter.logout();
			
		login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Verify_RCE_LVI_Tools -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		homepage.clickOnNonliveInteractionMember(pageLocatorsPath, pageFiledsPath);
		searchMember.getNONLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		searchMember.selectMemberAndNavigatebyfname2(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		String NLID=nlpage.getNonLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+NLID);
	    System.out.println("NLID::"+NLID);
	    nlpage.sortandSelectInteraction(pageLocatorsPath, pageFiledsPath,"PegaGadget1Ifr" ,LID);
	    inter.pageload();
	    nlpage.NL_FOLLOWUP(pageLocatorsPath, pageFiledsPath, data);
	    
		inter.logout();
		
		login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Verify_RCE_LVI_Tools -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		WorklistPage worklist= inter.openWorklist();
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, LID);	
     	nlpage.unlink(pageLocatorsPath, pageFiledsPath);
     	
     	inter.logout();
  		login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
  		homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
  		log.debug("Verify_RCE_LVI_Tools -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
  		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
  		RecentWorkPage recentWork= new InteractionManagerPage().openrecentWork();
     	recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
        recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, NLID);
        nlpage.vaildatethedata(pageLocatorsPath, pageFiledsPath,data);

     	
     	
			}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC246_Create_NL_LinkSI Completed");
		log.debug("AUTC246_Create_NL_LinkSI Completed");
		quit();
		
	}
}
