package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.CREATE_NLPage;
import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC279_RTC_Fullfillment_NL extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC279_RTC_Fullfillment_NL (Hashtable<String,String> data) throws Exception {
		String frame1="PegaGadget1Ifr";
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC279_RTC_Fullfillment_NL");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		homepage.clickOnNonliveInteractionMember(pageLocatorsPath, pageFiledsPath);
		MemberSearchPage searchMember =  new MemberSearchPage();
		searchMember.getNONLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		searchMember.selectMemberAndNavigatebyfname2(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		CREATE_NLPage nlpage=new CREATE_NLPage();
		String LID=nlpage.getNonLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+LID);
	    System.out.println(LID);
	    nlpage.NL_SKIP(pageLocatorsPath, pageFiledsPath);

	    InteractionManagerPage  inter= new InteractionManagerPage();
	    inter.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		Callback_RTCPage rtc = new Callback_RTCPage();
		String intentID=rtc.getIntentID(pageLocatorsPath, pageFiledsPath);
		rtc.create_FullfillmentLive(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Call back Fulfillment created");
		System.out.println("intentID::"+intentID);
		inter.pageload(2000);
		inter.wrapupRTCFromNonLive("Warpup Non Live Interaction", pageLocatorsPath, pageFiledsPath, data.get("PrimaryReasionForInteraction"), frame1);
		inter.pageload(2000);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID);
		WorkbasketPage workbasket= inter.openworkBasket();
		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
		log.debug("Navigated to workbasket");
		workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Workbasket"));
		workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Navigate to selected intent "+intentID+" from Workbasket ");
		rtc.frame1="PegaGadget1Ifr";
		rtc.validateCreateNewWork(pageLocatorsPath, pageFiledsPath, data.get("MemberID"),LID, "PegaGadget1Ifr");
		log.debug("Navigate to selected RTC through Create new work");
   }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC279_RTC_Fullfillment_NL Completed");
		log.debug("AUTC279_RTC_Fullfillment_NL Completed");
		
		quit();
		
	}

}
