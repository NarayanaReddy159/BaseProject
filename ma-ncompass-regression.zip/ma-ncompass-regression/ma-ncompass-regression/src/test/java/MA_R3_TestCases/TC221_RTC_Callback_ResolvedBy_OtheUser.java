package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.Manager_toolsPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC221_RTC_Callback_ResolvedBy_OtheUser extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC221_RTC_Callback_ResolvedBy_OtheUser (Hashtable<String,String> data) throws Exception {
		String frame0="PegaGadget0Ifr", frame1= "PegaGadget1Ifr";
		Callback_RTCPage rtc;
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC221_RTC_Callback_ResolvedBy_OtheUser");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user3"), RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user3")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user3")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through SSN "+data.get("Social Security number"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		//Callback_RTCPage rtc =interactionManger.openRTC_Callback();
		rtc = new Callback_RTCPage();
		log.debug("Navigate to interaction manger");
		String intentID=rtc.getIntentID(pageLocatorsPath, pageFiledsPath);
		rtc.create_CallbackSchedule(pageLocatorsPath, pageFiledsPath,data);
		System.out.println(intentID);
		interactionManger.wrapupClosednotverifiedIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID+" created");
	  	WorklistPage worklist= interactionManger.openWorklist();
     	worklist.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Navigate to selected intent "+intentID+" from WorkList tab ");
		worklist.validateAssignedTo(pageLocatorsPath, pageFiledsPath, data.get("AssignTo"));
		log.debug("validated assigedn to "+data.get("AssignTo"));
		worklist.closeIntenet(pageLocatorsPath, pageFiledsPath,intentID);
		log.debug("Closedi ntent");
		Manager_toolsPage tool=new Manager_toolsPage();
		tool.movetoManagetooltab(pageLocatorsPath, pageFiledsPath, frame0);
		log.debug("Navigated to Mange Tool tab");
		tool.movetoTranfer(pageLocatorsPath, pageFiledsPath, frame0);
		tool.filterAssignmentsDetails(pageLocatorsPath, pageFiledsPath, frame1);
		log.debug("Filter the values");
		tool.selectIntent(pageLocatorsPath, pageFiledsPath, intentID,frame1);
		log.debug("Select an intent "+intentID);
		tool.selectaction(pageLocatorsPath, pageFiledsPath, frame1,data.get("Transferto"),data.get("Operator"),data);
		log.debug("Transfer an intent "+intentID);
		homepage.logout();
		login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user1"), RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		WorklistPage worklist1= interactionManger.openWorklist();
     	worklist1.movetoWorklistPage(pageLocatorsPath, pageFiledsPath);
     	worklist1.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Navigate to selected intent "+intentID+" from WorkList tab ");
		worklist1.validateAssignedTo(pageLocatorsPath, pageFiledsPath, data.get("AssignToOtherUser"));
		log.debug("verified assign to other user "+intentID);
		rtc = new Callback_RTCPage();
		rtc.frame1="PegaGadget1Ifr";
		rtc.updateSuggestedIntent(pageLocatorsPath,pageFiledsPath,data.get("CallbackAttempt"),data.get("AttemptComments"));
		log.debug(intentID+" Intent resolved ");
		

   }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC221_RTC_Callback_ResolvedBy_OtheUser Completed");
		log.debug("AUTC221_RTC_Callback_ResolvedBy_OtheUser Completed");
		
		quit();
		
	}

}
