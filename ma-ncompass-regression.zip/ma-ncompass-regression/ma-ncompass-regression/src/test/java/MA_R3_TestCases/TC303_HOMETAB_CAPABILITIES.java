package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.VerifyContactPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC303_HOMETAB_CAPABILITIES extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
	public void AUTC303_HOMETAB_CAPABILITIES(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside TC303_HOMETAB_CAPABILITIES");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user3"), RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user1")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user1"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user3")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		if (data.get("SwitchToAdmin").equalsIgnoreCase("Yes")){
			homepage.switchPortalAndValidate(pageLocatorsPath, pageFiledsPath, RunTestNG_NCompass_MA.Config.getProperty("username_user3"),data);
		} else {
			test.log(LogStatus.INFO, "SwitchToAdmin option is other than Yes. So not Swithcing to Admin portal");
			log.debug("SwitchToAdmin option is other than Yes. So not Swithcing to Admin portal");
		}
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "TC303_HOMETAB_CAPABILITIES Completed");
		log.debug("TC303_HOMETAB_CAPABILITIES Completed");
		quit();
		
	}
}
