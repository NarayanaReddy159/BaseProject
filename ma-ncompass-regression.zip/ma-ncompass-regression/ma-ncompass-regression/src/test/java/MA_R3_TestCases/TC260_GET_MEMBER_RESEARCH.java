package MA_R3_TestCases;

import java.util.Hashtable;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerResearchPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class TC260_GET_MEMBER_RESEARCH extends BaseTest{
	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC260_GET_MEMBER_RESEARCH(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside TC260_GET_MEMBER_RESEARCH");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("TC260_GET_MEMBER_RESEARCH - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("TC260_GET_MEMBER_RESEARCH -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnResearchInteractionMember(pageLocatorsPath, pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		searchMember.readMemberDetails(pageLocatorsPath, pageFiledsPath,data.get("ExpectedMemberDetails"));log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerResearchPage interactionManger=searchMember.selectMemberAndNavigatebyfname1(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		interactionManger.endResearch(pageLocatorsPath, pageFiledsPath);
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "TC260_GET_MEMBER_RESEARCH Completed");
		
		quit();
		
	}
}
