package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC370_GSI_1099HC_REQUESTFORCORRECTION extends BaseTest{
	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC370_GSI_1099HC_REQUESTFORCORRECTION (Hashtable<String,String> data)  {
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC370_GSI_1099HC_REQUESTFORCORRECTION");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));

		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());

		try {
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		GSIPage gsi =interactionManger.openGSI();
		log.debug("Navigate to interaction manger");
		String intentID=gsi.getIntentID(pageLocatorsPath, pageFiledsPath);
		gsi.createGSI_Taxforms_Correction(pageLocatorsPath, pageFiledsPath, data.get("Category"), data.get("SubCategory"),data.get("RequestType"),data.get("Requesttaxyear"),data.get("Methodofresponse"),data.get("Recipienttype"),data.get("EmailAddr"),data.get("Comments"));
		System.out.println(intentID);
		interactionManger.WrapUpOpenGSIIntent("Wrapup interaction",data.get("Intent"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Id"+data.get("Intent"));
		RecentWorkPage recentWork= new InteractionManagerPage().openrecentWork();
     	recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
        recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Navigate to selected intent "+intentID+" from recent work tab ");
		recentWork.validateStatus(pageLocatorsPath, pageFiledsPath, data);
	
		}
		
		catch (Exception e) {
            e.printStackTrace();
            BaseTest.log.error("Error on AUTC370_GSI_1099HC_REQUESTFORCORRECTION method " + e);
            test.log(LogStatus.FAIL, "Error on AUTC370_GSI_1099HC_REQUESTFORCORRECTION method " + e);
            Assert.fail();
		}
		
     
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC370_GSI_1099HC_REQUESTFORCORRECTION Completed");
		BaseTest.log.info("AUTC370_GSI_1099HC_REQUESTFORCORRECTION Completed");
		quit();
		
	}

}	


