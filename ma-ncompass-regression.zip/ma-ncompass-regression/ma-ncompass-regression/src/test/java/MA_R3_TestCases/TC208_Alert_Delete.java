package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.AlertsPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageChangePage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC208_Alert_Delete extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC208_Alert_Delete(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		ManageChangePage managechg;
		AlertsPage altpage;
		String frame1="PegaGadget1Ifr",frame2="PegaGadget2Ifr";
		
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC208_Alert_Delete");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,RunTestNG_NCompass_MA.Config.getProperty("username_user3"), RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user3")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username_user3")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password_user3"));
		homepage.switchToAdminPortal(pageLocatorsPath,pageFiledsPath);
		homepage.clickOnMangeChane(pageLocatorsPath,pageFiledsPath);
		log.debug("Navigated to Manage Change");
		managechg = new ManageChangePage();
		managechg.SearchAlerts(pageLocatorsPath,pageFiledsPath,frame1,data.get("SearchAlert"));
		log.debug("Navigated to Alerts page");
		altpage= new AlertsPage();
		altpage.createAlert(pageLocatorsPath, pageFiledsPath, frame2, data.get("Category"), data.get("Criticality"), data.get("Level"), data.get("Referenceid"), data.get("Subject"), data.get("Description"));
		altpage.deleteAlert(pageLocatorsPath, pageFiledsPath, frame2, data.get("Category"), data.get("Criticality"), data.get("Level"), data.get("Referenceid"), data.get("Subject"), data.get("Description"));
		log.debug("Alert Deleted ");
			
	
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC208_Alert_Delete Completed");
		log.debug("AUTC208_Alert_Delete Completed");
		quit();
		
	}
}
