package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.Correspondence_RTCPage;
import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageClaimPageIntend;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RCEPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC230_RCE_WRITTEN extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC230_RCE_WRITTEN(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC230_RCE_WRITTEN");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC230_RCE_WRITTEN - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC230_RCE_WRITTEN -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		RCEPage rce = new RCEPage();
		String intentID = rce.getIntentID(pageLocatorsPath, pageFiledsPath);
		System.out.println("Intent ID : " + intentID);
		rce.sendtoResearchEmail(pageLocatorsPath, pageFiledsPath);
     	interactionManger.WrapUpOpenocvIntent("Wrapping up the intent", data.get("Intent"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Id"+data.get("Intent"));
		WorkbasketPage workbasket= interactionManger.openworkBasket();
		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
		workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Workbasket"));
		workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		ManageClaimPageIntend mngclaim = new ManageClaimPageIntend();
		mngclaim.resolveCLM(pageLocatorsPath, pageFiledsPath);
		Correspondence_RTCPage corrrtc = new Correspondence_RTCPage();
		corrrtc.createCorr(pageLocatorsPath, pageFiledsPath, data);
	
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC230_RCE_WRITTEN Completed");
		
		quit();
		
	}
}
