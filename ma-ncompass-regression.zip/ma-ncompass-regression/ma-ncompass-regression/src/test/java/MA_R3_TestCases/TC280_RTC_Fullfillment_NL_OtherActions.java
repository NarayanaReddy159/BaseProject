package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.CREATE_NLPage;
import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC280_RTC_Fullfillment_NL_OtherActions extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC280_RTC_Fullfillment_NL_OtherActions (Hashtable<String,String> data) throws Exception {
		String frame1="PegaGadget1Ifr",frame2="PegaGadget2Ifr";
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC280_RTC_Fullfillment_NL_OtherActions");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		homepage.clickOnNonliveInteractionMember(pageLocatorsPath, pageFiledsPath);
		MemberSearchPage searchMember =  new MemberSearchPage();
		searchMember.getNONLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		searchMember.selectMemberAndNavigatebyfname2(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		CREATE_NLPage nlpage=new CREATE_NLPage();
		String LID=nlpage.getNonLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+LID);
	    System.out.println(LID);
	    nlpage.NL_SKIP(pageLocatorsPath, pageFiledsPath);

	    InteractionManagerPage  inter= new InteractionManagerPage();
	    inter.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		Callback_RTCPage rtc = new Callback_RTCPage();
		rtc.frame1="PegaGadget2Ifr";
		String intentID=rtc.getIntentID(pageLocatorsPath, pageFiledsPath);
		rtc.otherAction_SelctCustResType(pageLocatorsPath, pageFiledsPath, frame2);
		log.debug("Call back Fulfillment created");
		System.out.println("intentID::"+intentID);

	   }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC280_RTC_Fullfillment_NL_OtherActions Completed");
		log.debug("AUTC280_RTC_Fullfillment_NL_OtherActions Completed");
		
		quit();
		
	}

}
