package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.CREATE_NLPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.Member360Page;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.VerifyContactPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC238_Create_NL_Interaction extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
	public void AUTC238_Create_NL_Interaction(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC238_Create_NL_Interaction");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC238_Create_NL_Interaction -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		homepage.clickOnNonliveInteractionMember(pageLocatorsPath, pageFiledsPath);
		MemberSearchPage searchMember =  new MemberSearchPage();
		searchMember.getNONLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		searchMember.selectMemberAndNavigatebyfname2(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		CREATE_NLPage nlpage=new CREATE_NLPage();
		nlpage.NL_Interactions(pageLocatorsPath, pageFiledsPath, data);
		nlpage.clickOtherActions(pageLocatorsPath, pageFiledsPath);
		nlpage.ExitInteraction(pageLocatorsPath, pageFiledsPath);
			}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC238_Create_NL_Interaction Completed");
		log.debug("AUTC238_Create_NL_Interaction Completed");
		quit();
		
	}
}
