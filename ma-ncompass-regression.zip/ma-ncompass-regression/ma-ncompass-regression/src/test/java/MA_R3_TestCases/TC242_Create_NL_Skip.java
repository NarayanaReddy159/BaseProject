package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.CREATE_NLPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.Member360Page;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.VerifyContactPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC242_Create_NL_Skip extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
	public void AUTC242_Create_NL_Skip(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC242_Create_NL_Skip");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC242_Create_NL_Skip -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		homepage.clickOnNonliveInteractionMember(pageLocatorsPath, pageFiledsPath);
		MemberSearchPage searchMember =  new MemberSearchPage();
		searchMember.getNONLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		searchMember.selectMemberAndNavigatebyfname2(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		CREATE_NLPage nlpage=new CREATE_NLPage();
		String NLID=nlpage.getNonLID(pageLocatorsPath, pageFiledsPath);
	    test.log(LogStatus.INFO, "Intent ID:"+NLID);
	    System.out.println(NLID);
	    
		nlpage.NL_SKIP(pageLocatorsPath, pageFiledsPath);
		InteractionManagerPage inter=new InteractionManagerPage();
		inter.pageload();
		inter.wrapupNLIntent("Wrapping up the intent", data.get("interactionReason"), pageLocatorsPath, pageFiledsPath);
		log.debug("Intent Id"+data.get("Intent"));
	    inter.pageload();
		RecentWorkPage recentWork= new InteractionManagerPage().openrecentWork();
     	recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
        recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, NLID);
        nlpage.vaildatethedata(pageLocatorsPath, pageFiledsPath,data);
		}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC242_Create_NL_Skip Completed");
		log.debug("AUTC242_Create_NL_Skip Completed");
		quit();
		
	}
}
