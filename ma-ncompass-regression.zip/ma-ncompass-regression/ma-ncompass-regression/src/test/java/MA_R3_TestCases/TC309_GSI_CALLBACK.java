package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.Correspondence_RTCPage;
import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC309_GSI_CALLBACK extends BaseTest{
	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC309_GSI_CALLBACK (Hashtable<String,String> data)  {
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC309_GSI_CALLBACK");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));

		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());

		try {
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		GSIPage gsi =interactionManger.openGSI();
		log.debug("Navigate to interaction manger");
		String intentID=gsi.getIntentID(pageLocatorsPath, pageFiledsPath);
		gsi.createGSI_Taxforms_Correction(pageLocatorsPath, pageFiledsPath, data.get("GSICategory"), data.get("SubCategory"),data.get("RequestType"),data.get("Requesttaxyear"),data.get("Methodofresponse"),data.get("Recipienttype"),data.get("EMailAddress"),data.get("Comments"));
		System.out.println(intentID);
		interactionManger.WrapUpOpenGSIIntent("Wrapup interaction",data.get("Intent"),pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Id"+data.get("Intent"));
		WorkbasketPage workbasket= interactionManger.openworkBasket();
		log.debug("Open Workbasket");
		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
		log.debug("Moved to Workbasket");
		workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Workbasket"));
		log.debug("Select Workbasket from List :" + data.get("Workbasket"));
		workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		log.debug("Sort and Select Intent");
		gsi.ValidateIntentStatusOnWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("GSIExpected_Status"));
		gsi.ValidateAssignedToOnWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Assignedto"));
		gsi.clickCorrespondenceOnWB(pageLocatorsPath, pageFiledsPath, data.get("CorrespondenceComments"), "PegaGadget1Ifr");
		Correspondence_RTCPage corr = new Correspondence_RTCPage();
		corr.createCorrFromGSI(pageLocatorsPath, pageFiledsPath, data);
		RecentWorkPage recentWork=interactionManger.openrecentWork();
		log.debug("Clicked the recent work tab");	
		//recentWork.wait(5000);
	    recentWork.movetoRecentWorkPage(pageLocatorsPath, pageFiledsPath);
	    recentWork.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
	    log.debug("Selected the intent on recent work tab");	
	    gsi.validatestatusAfterCorresp(pageLocatorsPath, pageFiledsPath, data.get("Expected_Status"),"PegaGadget2Ifr");


    }
		catch (Exception e) {
            e.printStackTrace();
            BaseTest.log.error("Error on AUTC309_GSI_CALLBACK method " + e);
            test.log(LogStatus.FAIL, "Error on AUTC309_GSI_CALLBACK method " + e);
            Assert.fail();
		}
		
     
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC309_GSI_CALLBACK Completed");
		BaseTest.log.info("AUTC309_GSI_CALLBACK Completed");
		quit();
		
	}

}	


