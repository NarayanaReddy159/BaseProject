package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.Callback_RTCPage;
import com.nasco.MA.Pages.Correspondence_RTCPage;
import com.nasco.MA.Pages.FollowUp;
import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageClaimPageIntend;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RecentWorkPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.MA.Pages.WorklistPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC367_GSI_1099HC_RELATEDINTENT extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC367_GSI_1099HC_RELATEDINTENT(Hashtable<String,String> data) throws Exception {
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC367_GSI_1099HC_RELATEDINTENT");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through SSN "+data.get("Social Security number"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		GSIPage GSI=new GSIPage();
		String intentID=GSI.getIntentID(pageLocatorsPath, pageFiledsPath);
		System.out.println(intentID);
		GSI.createGSI_Taxforms_Correction(pageLocatorsPath, pageFiledsPath, data.get("Category"), data.get("SubCategory"),data.get("RequestType"),data.get("Requesttaxyear"),data.get("Methodofresponse"),data.get("Recipienttype"),data.get("EmailAddr"),data.get("Comments"));
		interactionManger.WrapUpOpenGSIIntent("Wrapup interaction",data.get("Intent"),pageLocatorsPath,pageFiledsPath);
        log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID);
		interactionManger.pageload();
		WorkbasketPage workbasket= interactionManger.openworkBasket();
		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
		workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Workbasket"));
		log.debug("Navigate to selected intent "+intentID+" from Workbasket tab ");
		workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		workbasket.createnewwork(pageLocatorsPath, pageFiledsPath);
		Callback_RTCPage RTC=new Callback_RTCPage();
		RTC.RTC_callback(pageLocatorsPath, pageFiledsPath, "PegaGadget1Ifr","PegaGadget2Ifr");
		FollowUp follow=new FollowUp();
		follow.validateDefaultSelectedIntent(pageLocatorsPath, pageFiledsPath, "PegaGadget2Ifr", intentID);
	}
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC367_GSI_1099HC_RELATEDINTENT Completed");
		log.debug("AUTC367_GSI_1099HC_RELATEDINTENT Completed");
		
		quit();
		
	}

}
