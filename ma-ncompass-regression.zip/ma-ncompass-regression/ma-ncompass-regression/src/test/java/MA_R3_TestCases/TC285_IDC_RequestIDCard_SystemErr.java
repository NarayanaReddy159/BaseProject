package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.Request_ID_CardPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC285_IDC_RequestIDCard_SystemErr extends BaseTest{
	
	
    
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC285_IDC_RequestIDCard_SystemErr (Hashtable<String,String> data) throws Exception {
		String frame1="PegaGadget1Ifr",frame2="PegaGadget2Ifr";
		
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Start the TC Execution:- AUTC285_IDC_RequestIDCard_SystemErr");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through SSN "+data.get("Social Security number"));
		InteractionManagerPage interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		Request_ID_CardPage IDC =new Request_ID_CardPage();
		log.debug("Navigate to interaction manger");
		String intentID=IDC.getIntentID(pageLocatorsPath, pageFiledsPath);
		System.out.println(intentID);
		IDC.DocumentIDCardRequest(pageLocatorsPath, pageFiledsPath, data, frame2);
		//IDC.cardGreatethan1(pageLocatorsPath, pageFiledsPath, data, frame2);
		log.debug("Navigate to selected intent "+intentID+" from DocumentIDCardRequest tab ");
		IDC.clickSubmit(pageLocatorsPath, pageFiledsPath,frame2);
		interactionManger.wrapupProsMem("Wrapping up the intent",pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID);
		WorkbasketPage workbasket= interactionManger.openworkBasket();
		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
		workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("Workbasket"));
		log.debug("Navigate to selected intent "+intentID+" from Workbasket tab ");
		workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID);
		IDC.validateStatus(pageLocatorsPath, pageFiledsPath, data.get("Expected_Status"), frame1);
		log.debug("Validated on recent work page ");
		IDC.closeIntenet(pageLocatorsPath, pageFiledsPath, intentID);
//		IDC.resolveIntent(pageLocatorsPath,pageFiledsPath,data.get("ResolvedComments"),frame1);
//		log.debug("Resolved initent "+intentID);

		searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath, pageFiledsPath, data);
		log.debug("Searching a Memeber through SSN "+data.get("Social Security number"));
		interactionManger=searchMember.selectMemberAndNavigatebyfname(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
	
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		String intentID1=IDC.getIntentID(pageLocatorsPath, pageFiledsPath);
		System.out.println(intentID1);
	
		IDC.DocumentIDCardRequest(pageLocatorsPath, pageFiledsPath, data, frame2);
		log.debug("Navigate to selected intent "+intentID+" from DocumentIDCardRequest tab ");
		IDC.clickSubmit(pageLocatorsPath, pageFiledsPath,frame2);
		interactionManger.wrapupProsMem("Wrapping up the intent",pageLocatorsPath,pageFiledsPath);
		log.debug("Intent Name"+data.get("Intent")+" & Intent Id"+intentID1);
		workbasket= interactionManger.openworkBasket();
//		workbasket.movetoWorkbasketPage(pageLocatorsPath, pageFiledsPath);
		workbasket.selectWorkbasket(pageLocatorsPath, pageFiledsPath, data.get("NextWorkbasket"));
		log.debug("Navigate to selected intent "+intentID1+" from Workbasket tab ");
		workbasket.sortandSelectIntent(pageLocatorsPath, pageFiledsPath, intentID1);
		workbasket.workbasketvalidateStatus(pageLocatorsPath, pageFiledsPath, data.get("NextIntent_status"));
	


		
		 }
	
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "End the TC Execution:- AUTC285_IDC_RequestIDCard_SystemErr Completed");
		log.debug("AUTC285_IDC_RequestIDCard_SystemErr Completed");
		
		quit();
		
	}

}
