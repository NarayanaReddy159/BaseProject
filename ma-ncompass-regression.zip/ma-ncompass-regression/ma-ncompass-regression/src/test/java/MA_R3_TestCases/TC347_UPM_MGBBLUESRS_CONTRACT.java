package MA_R3_TestCases;

import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.MA.Pages.Correspondence_RTCPage;
import com.nasco.MA.Pages.GSIPage;
import com.nasco.MA.Pages.HomePage;
import com.nasco.MA.Pages.InteractionManagerPage;
import com.nasco.MA.Pages.LoginPage;
import com.nasco.MA.Pages.ManageClaimPageIntend;
import com.nasco.MA.Pages.ManageOtherCoveragePage;
import com.nasco.MA.Pages.MemberSearchPage;
import com.nasco.MA.Pages.RCEPage;
import com.nasco.MA.Pages.UpdateMemberPage;
import com.nasco.MA.Pages.WorkbasketPage;
import com.nasco.testcases.BaseTest;
import com.nasco.testcases.RunTestNG_NCompass_MA;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

public class TC347_UPM_MGBBLUESRS_CONTRACT extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="MA_Ncompass_R3DP")
    public void AUTC347_UPM_MGBBLUESRS_CONTRACT(Hashtable<String,String> data) throws Exception {
		setUpFramework();
		System.out.println("inside");
		test=DriverManager.getExtentReport();
		log.info("Inside AUTC347_UPM_MGBBLUESRS_CONTRACT");
		String pageLocatorsPath=RunTestNG_NCompass_MA.Config.getProperty("paggeWebElementspath").toString();
		String pageFiledsPath=RunTestNG_NCompass_MA.Config.getProperty("pageFieldspath").toString();
		openBrowser(RunTestNG_NCompass_MA.Config.getProperty("Browser").toString());
		log.debug("AUTC347_UPM_MGBBLUESRS_CONTRACT - Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : "+RunTestNG_NCompass_MA.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_MA.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(pageLocatorsPath,pageFiledsPath,getDefaultUserName(), getDefaultPassword());
		log.debug("AUTC347_UPM_MGBBLUESRS_CONTRACT -Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		test.log(LogStatus.INFO, "Username entered as "+RunTestNG_NCompass_MA.Config.getProperty("username")+" and Password entered as "+RunTestNG_NCompass_MA.Config.getProperty("password"));
		MemberSearchPage searchMember = homepage.clickOnLiveInteractionMember(pageLocatorsPath,pageFiledsPath);
		searchMember.getLIInteractionID(pageLocatorsPath, pageFiledsPath);
		searchMember.searchMember(pageLocatorsPath,pageFiledsPath,data.get("MemberID"));
		log.debug("Searching a Memeber ID "+data.get("MemberID"));
		searchMember.selectMemberAndNavigatebyfnameverifyMember(pageLocatorsPath,pageFiledsPath,data.get("Fname"));
		System.out.println("Select a Memeber By using first name :::::::::::::::::::::::::::::::::::"+data.get("Fname"));
		log.debug("Select a Memeber By using first name "+data.get("Fname"));
		UpdateMemberPage uptMem = new UpdateMemberPage();
		uptMem.verifyMember(pageLocatorsPath, pageFiledsPath);
		InteractionManagerPage interactionManger= new InteractionManagerPage();
		interactionManger.addTask(data.get("Intent").toString(),pageLocatorsPath,pageFiledsPath);
		log.debug("Add Intent "+data.get("Intent"));
		
		log.debug("Navigate to interaction manger");
		String intentID = uptMem.getIntentID(pageLocatorsPath, pageFiledsPath);
		System.out.println("Intent ID : " + intentID);
		
		uptMem.UpdateMember_Details(pageLocatorsPath, pageFiledsPath, data);
		uptMem.updateMember_phoneNum(pageLocatorsPath, pageFiledsPath, data);
		interactionManger.wrapupClosednotverifiedIntent("Wrapping up the intent", data.get("PrimaryReasionForInteraction"),pageLocatorsPath,pageFiledsPath);
			
	}
	@AfterMethod
	public void tearDown() {
		
		test.log(LogStatus.INFO, "AUTC347_UPM_MGBBLUESRS_CONTRACT Completed");
		
		quit();
		
	}
}
